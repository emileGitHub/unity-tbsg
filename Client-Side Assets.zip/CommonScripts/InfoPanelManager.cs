﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class InfoPanelManager : MonoBehaviour {

    public List<GameObject> InfoPanels { get; private set; }
    private Transform m_canvas;

    // Awake is called before Update for the first frame
    void Awake()
    {
        InfoPanels = new List<GameObject>();
        m_canvas = GameObject.FindGameObjectWithTag("Canvas").transform;
    }

    public void AddInfoPanel(GameObject _infoPanel)
    {
        if (_infoPanel != null)
            InfoPanels.Add(_infoPanel);
    }

    public void RemoveInfoPanel(GameObject _infoPanel)
    {
        if (InfoPanels.Exists(x => x == _infoPanel))
            InfoPanels.Remove(_infoPanel);
    }
}
