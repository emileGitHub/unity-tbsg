﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

[RequireComponent(typeof(RectTransform))]
[RequireComponent(typeof(BoxCollider2D))]
public class ColliderSizeManagerForUI : MonoBehaviour {

    private RectTransform RectTransform;
    private BoxCollider2D Collider;

	// Awake is called before Update for the first frame
	void Start () {
        RectTransform = this.GetComponent<RectTransform>();
        Collider = this.GetComponent<BoxCollider2D>();
	}
	
	// Update is called once per frame
	void Update () {

        float RectWidth = RectTransform.rect.width;
        float RectHeight = RectTransform.rect.height;
        Vector2 RectSize = new Vector2(RectWidth, RectHeight);

        Vector2 colliderBoundsSize = Collider.bounds.size;

        if(RectSize != colliderBoundsSize)
        {
            //Expand the size of collider to match the RectTransform
            float correctSizeX = Collider.size.x * (RectSize.x / colliderBoundsSize.x);
            float correctSizeY = Collider.size.y * (RectSize.y / colliderBoundsSize.y);
            Collider.size = new Vector2(correctSizeX, correctSizeY);
        }

	}
}
