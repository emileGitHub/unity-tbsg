﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnityEngine;

namespace EEANGames.UnityEngine.ExtensionMethods
{
    public static class TransformExtension
    {
        public static void ClearChildren(this Transform _transform)
        {
            List<GameObject> children = new List<GameObject>();

            foreach (Transform child in _transform)
            {
                children.Add(child.gameObject);
            }

            _transform.DetachChildren();

            foreach (GameObject go in children)
            {
                GameObject.Destroy(go);
            }

        }
    }
}
