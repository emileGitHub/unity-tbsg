﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnityEngine;

public sealed class MaterialContainer
{
    private static MaterialContainer m_instance;

    public static MaterialContainer Instance { get { return m_instance ?? (m_instance = new MaterialContainer()); } }

    private MaterialContainer() { }


    #region Properties
    public List<Material> RarityMaterials { get; private set; }
    #endregion


    #region Public Functions
    public void Initialize(List<Material> _rarityMaterials)
    {
        RarityMaterials = _rarityMaterials;
    }
    #endregion
}
