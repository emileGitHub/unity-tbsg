﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

namespace EEANGames.TBSG._01.Unity
{
    [RequireComponent(typeof(Button))]
    public class SkillDetailPopUpController : MonoBehaviour, IPointerEnterHandler, IPointerExitHandler
    {
        #region Properties
        public Text SkillName { get; private set; }
        public Text Effects { get; private set; }
        #endregion

        #region Private Fields
        private bool m_hover;

        private GameObject m_detailPopUp;
        #endregion

        // Awake is called before Update for the first frame
        void Awake()
        {
            m_hover = false;

            m_detailPopUp = this.transform.Find("Panel@DetailPopUp").gameObject;
            SkillName = m_detailPopUp.transform.Find("Text@SkillName").GetComponent<Text>();
            Effects = m_detailPopUp.transform.Find("Text@Effects").GetComponent<Text>();

            m_detailPopUp.SetActive(false);
        }

        public void OnPointerEnter(PointerEventData _eventData) { m_detailPopUp.SetActive(true); }

        public void OnPointerExit(PointerEventData _eventData) { m_detailPopUp.SetActive(false); }
    }
}
