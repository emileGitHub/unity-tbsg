﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

namespace EEANGames.TBSG._01.Unity
{
    //Referenced by components in the editor
    public class SceneConnector : MonoBehaviour
    {

        #region Public Member Variables
        public static string m_nextScene = m_defaultScene;
        #endregion

        #region Private Member Variables
        private const string m_defaultScene = "scn_Title";
        #endregion

        #region Public Functions
        public void ToScene(string _sceneNameToLoad)
        {
            GoToScene(_sceneNameToLoad);
        }

        public static void GoToScene(string _sceneNameToLoad)
        {
            m_nextScene = _sceneNameToLoad;
            SceneManager.LoadScene("scn_Loader");
        }
        #endregion

    }
}
