﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

namespace EEANGames.TBSG._01.Unity
{
    //Referenced by components in the editor
    public class SceneConnector : MonoBehaviour
    {
        #region Properties
        public static int SceneChangeCount { get; private set; } = 0;
        #endregion

        #region Public Fields
        public static string m_nextScene = DEFAULT_SCENE;
        #endregion

        #region Private Fields
        private const string DEFAULT_SCENE = "scn_Title";
        #endregion

        #region Public Methods
        public void ToScene(string _sceneNameToLoad)
        {
            GoToScene(_sceneNameToLoad);
        }

        public static void GoToScene(string _sceneNameToLoad)
        {
            m_nextScene = _sceneNameToLoad;
            SceneChangeCount++;
            SceneManager.LoadScene("scn_Loader");
        }
        #endregion

    }
}
