﻿using EEANGames.UnityEngine.EventSystems;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using static UnityEngine.EventSystems.PointerEventData;

public class Anim_ButtonHighlightedState : StateMachineBehaviour {

    private bool m_isInitialized = false;

    private CustomStandaloneInputModule m_inputModule;

    private void Initialize(Animator _animator)
    {
        m_inputModule = GameObject.FindGameObjectWithTag("EventSystem").GetComponent<CustomStandaloneInputModule>();
        if (!m_inputModule)
            return;

        m_isInitialized = true;
    }

    // OnStateEnter is called when a transition starts and the state machine starts to evaluate this state
    //override public void OnStateEnter(Animator animator, AnimatorStateInfo stateInfo, int layerIndex) {
    //
    //}

    // OnStateUpdate is called on each Update frame between OnStateEnter and OnStateExit callbacks
    override public void OnStateUpdate(Animator animator, AnimatorStateInfo stateInfo, int layerIndex)
    {
        if (!m_isInitialized)
            Initialize(animator);
        if (!m_isInitialized)
            return;

        if (animator.gameObject == m_inputModule.CurrentRaycastObject)
        {
            switch (m_inputModule.CurrentPointerState_Left)
            {
                case FramePressState.Pressed:
                    animator.Play("Pressed");
                    break;
                default:
                    break;
            }
        }
        else
            animator.Play("Normal");
    }

    // OnStateExit is called when a transition ends and the state machine finishes evaluating this state
    //override public void OnStateExit(Animator animator, AnimatorStateInfo stateInfo, int layerIndex) {
    //
    //}

    // OnStateMove is called right after Animator.OnAnimatorMove(). Code that processes and affects root motion should be implemented here
    //override public void OnStateMove(Animator animator, AnimatorStateInfo stateInfo, int layerIndex) {
    //
    //}

    // OnStateIK is called right after Animator.OnAnimatorIK(). Code that sets up animation IK (inverse kinematics) should be implemented here.
    //override public void OnStateIK(Animator animator, AnimatorStateInfo stateInfo, int layerIndex) {
    //
    //}
}
