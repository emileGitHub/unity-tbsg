﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

[RequireComponent(typeof(Text))]
public class TextHider : MonoBehaviour {

    private Text Text;

    public float VanishingVelocity; //Numbers smaller than 0 will be set to 0 and numbers greater than 1 will be set to 1;
    public float LifeSpan;
    private float startTime;

    private bool isProcessActive;

	// Awake is called before Update for the first frame
	void Start () {
        Text = this.GetComponent<Text>();
        isProcessActive = false;
	}
	
	// Update is called once per frame
	void FixedUpdate () {

        if (LifeSpan < 0)
            LifeSpan = 0;

        if (VanishingVelocity < 0)
            VanishingVelocity = 0;
        else if (VanishingVelocity > 1)
            VanishingVelocity = 1;


        Color TextColor = Text.color;
        if (TextColor.a == 1f)
        {
            startTime = Time.realtimeSinceStartup;
            isProcessActive = true;
        }
        else if (TextColor.a == 0)
            isProcessActive = false;

        if (isProcessActive && Time.realtimeSinceStartup > startTime + LifeSpan)
        {
            float Alpha = TextColor.a - VanishingVelocity;

            if (Alpha < 0)
                Alpha = 0;

            Text.color = new Color(TextColor.r, TextColor.b, TextColor.g, Alpha);
        }
    }
}
