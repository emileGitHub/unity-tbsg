﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

[RequireComponent(typeof(RectTransform))]
[RequireComponent(typeof(CanvasRenderer))]
[RequireComponent(typeof(Image))]
public class NonRectButtonTest : Button {

    private float m_latestScreenWidth;
    private float m_latestScreenHeight;

    //private float m_lastClickTime;
    //private bool m_isPressed;

    private float m_imageLeft;
    private float m_imageBottom;
    private float m_imageRight;
    private float m_imageTop;

    private float m_imageWidth;
    private float m_imageHeight;

    private bool m_isPointerOver;
    private bool m_isPressed;

    private Texture2D m_texture;

	// Use this for initialization
	protected override void Awake () {
        base.Awake();
        //m_lastClickTime = 0;
        //m_isPressed = false;

        m_isPointerOver = false;
        m_isPressed = false;

        UpdateScreenSizeInfo();

        UpdateReferenceTexture();
    }
	
	// Update is called once per frame
	void Update () {
        if (WasScreenResized())
        {
            UpdateScreenSizeInfo();
            UpdateReferenceTexture();
        }

        if (HasPointerMoved())
        {
            if (HasPointerEntered())
                TransitionImage(eImageStatus.Hovered);

            if (HasPointerExited())
                TransitionImage(eImageStatus.Normal);

            if (HasPointerBeenPressed())
                TransitionImage(eImageStatus.Pressed);

            if (HasPointerBeenReleased())
                TransitionImage(eImageStatus.Normal);
        }
    }

    private bool WasScreenResized()
    {
        if (m_latestScreenWidth != Screen.width)
            return true;

        if (m_latestScreenHeight != Screen.height)
            return true;

        return false;
    }

    private bool HasPointerMoved() { return (Input.GetAxis("Mouse X") != 0) || (Input.GetAxis("Mouse Y") != 0); }

    private bool HasPointerEntered()
    {
        if (!m_isPointerOver
            && IsPixelAlphaZeroAtPosition(Input.mousePosition)) //Checks for the world position of the mouse. Nothing occurs if position is out of the Button's rect.
        {
            m_isPointerOver = true; // The pointer is actually over the button.
            return true;
        }

        return false;
    }

    private bool HasPointerExited()
    {
        if (m_isPointerOver
            && IsPixelAlphaZeroAtPosition(Input.mousePosition)) //Checks for the world position of the mouse. Nothing occurs if position is out of the the Button's rect.
        {
            m_isPointerOver = false; // The pointer is actually not over the button.
            return true;
        }

        return false;
    }

    private bool HasPointerBeenPressed()
    {
        if (!m_isPressed && Input.GetMouseButtonDown(0))
        {
            m_isPressed = true;
            return true;
        }

        return false;
    }

    private bool HasPointerBeenReleased()
    {
        if (m_isPressed && Input.GetMouseButtonUp(0))
        {
            m_isPressed = false;
            return true;
        }

        return false;
    }

    private bool IsPositionWithinRectTransform(Vector3 _position) { return _position.x >= m_imageLeft && _position.x <= m_imageRight && _position.y >= m_imageBottom && _position.y <= m_imageTop; }

    private void UpdateScreenSizeInfo()
    {
        m_latestScreenWidth = Screen.width;
        m_latestScreenHeight = Screen.height;
        Debug.Log("Screen size has been updated.");
    }

    private void UpdateReferenceTexture()
    {
        Vector3[] sb = new Vector3[4];
        this.image.rectTransform.GetWorldCorners(sb);

        m_imageLeft = sb[0].x;
        m_imageBottom = sb[0].y;
        m_imageRight = sb[2].x;
        m_imageTop = sb[2].y;

        m_imageWidth = m_imageRight - m_imageLeft;
        m_imageHeight = m_imageTop - m_imageBottom;

        Texture2D originalTexture = this.image.sprite.texture;
        m_texture = new Texture2D(originalTexture.width, originalTexture.height, originalTexture.format, false);
        m_texture.LoadRawTextureData(originalTexture.GetRawTextureData());
        m_texture.Apply();
        Debug.Log("Reference texture has been updated.");
    }

    private enum eImageStatus
    {
        Normal,
        Hovered,
        Pressed,
        Disabled
    }

    private void TransitionImage(eImageStatus _imageStatus)
    {
        switch (transition)
        {
            default: // case Transition.None
                break;
            case Transition.ColorTint:
                {
                    switch (_imageStatus)
                    {
                        default: // case eImageStatus.Normal
                            this.image.color = colors.normalColor;
                            break;
                        case eImageStatus.Hovered:
                            this.image.color = colors.highlightedColor;
                            break;
                        case eImageStatus.Pressed:
                            this.image.color = colors.pressedColor;
                            break;
                        case eImageStatus.Disabled:
                            this.image.color = colors.disabledColor;
                            break;
                    }
                }
                break;
            case Transition.SpriteSwap:
                {
                    switch (_imageStatus)
                    {
                        default: // case eImageStatus.Normal
                            //this.image.sprite = this.targetGraphic.;
                            break;
                        case eImageStatus.Hovered:
                            this.image.sprite = this.spriteState.highlightedSprite;
                            break;
                        case eImageStatus.Pressed:
                            this.image.sprite = this.spriteState.pressedSprite;
                            break;
                        case eImageStatus.Disabled:
                            this.image.sprite = this.spriteState.disabledSprite;
                            break;
                    }
                }
                break;
        }
    }

    private bool IsPixelAlphaZeroAtPosition(Vector3 _pointerPosition)
    {
        if (IsPositionWithinRectTransform(_pointerPosition))
        {
            float relativePositionX = (_pointerPosition.x - m_imageLeft) / m_imageWidth; // Between 0 and 1
            float relativePositionY = (_pointerPosition.y - m_imageBottom) / m_imageHeight; // Between 0 and 1

            int pixelX = Convert.ToInt32(relativePositionX * m_texture.width - 1);
            int pixelY = Convert.ToInt32(relativePositionY * m_texture.height - 1);

            Color colorAtMousePosition = m_texture.GetPixel(pixelX, pixelY);
            //Debug.Log("Color at Pixel(" + pixelX.ToString() + ", " + pixelY.ToString() + "): " + colorAtMousePosition.ToString());

            if (colorAtMousePosition.a == 0f)
                return true;
        }

        return false;
    }

    public override void OnPointerEnter(PointerEventData eventData) { }
    public override void OnPointerExit(PointerEventData eventData) { }
    public override void OnPointerClick(PointerEventData eventData) { }
    public override void OnPointerDown(PointerEventData eventData) { }
    public override void OnPointerUp(PointerEventData eventData) { }
}
