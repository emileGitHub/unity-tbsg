﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public sealed class SpriteContainer
{
    private static SpriteContainer m_instance;

    public static SpriteContainer Instance { get { return m_instance ?? (m_instance = new SpriteContainer()); } }

    private SpriteContainer(){ }


    #region Properties
    public List<Sprite> ElementIcons { get; private set; }
    public List<Sprite> SmallRarityFrames { get; private set; }
    public List<Sprite> LargeRarityFrames { get; private set; }
    #endregion


    #region Public Functions
    public void Initialize(List<Sprite> _elementIcons, List<Sprite> _smallRarityFrames, List<Sprite> _largeRarityFrames)
    {
        ElementIcons = _elementIcons;
        SmallRarityFrames = _smallRarityFrames;
        LargeRarityFrames = _largeRarityFrames;
    }
    #endregion

}
