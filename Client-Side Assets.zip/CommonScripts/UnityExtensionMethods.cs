﻿using System;
using System.Collections.Generic;
using UnityEngine;

namespace EEANGames.UnityEngine.ExtensionMethods
{
    public static class CharExtension
    {
        public static string IntoColorTag(this char _char, Color32 _color) { return "<color=" + _color.ToHexString() + ">" + _char + "</color>"; }
    }

    public static class StringExtension
    {
        public static string IntoColorTag(this string _string, Color32 _color) { return "<color=" + _color.ToHexString() + ">" + _string + "</color>"; }
    }

    public static class TransformExtension
    {
        public static void ClearChildren(this Transform _transform)
        {
            List<GameObject> children = new List<GameObject>();

            foreach (Transform child in _transform)
            {
                children.Add(child.gameObject);
            }

            _transform.DetachChildren();

            foreach (GameObject go in children)
            {
                GameObject.Destroy(go);
            }
        }
    }

    public static class RectTransformExtension
    {
        public static void SetLeft(this RectTransform _rectTransform, float _left) { _rectTransform.offsetMin = new Vector2(_left, _rectTransform.offsetMin.y); }

        public static void SetRight(this RectTransform _rectTransform, float _right) { _rectTransform.offsetMax = new Vector2(-_right, _rectTransform.offsetMax.y); }

        public static void SetTop(this RectTransform _rectTransform, float _top) { _rectTransform.offsetMax = new Vector2(_rectTransform.offsetMax.x, -_top); }

        public static void SetBottom(this RectTransform _rectTransform, float _bottom) { _rectTransform.offsetMin = new Vector2(_rectTransform.offsetMin.x, _bottom); }

        public static void SetPosition(this RectTransform _rectTransform, float _left, float _right, float _top, float _bottom)
        {
            _rectTransform.SetLeft(_left);
            _rectTransform.SetRight(_right);
            _rectTransform.SetTop(_top);
            _rectTransform.SetBottom(_bottom);
        }
    }

    public static class ColorExtension
    {
        public static string ToHexString(this Color _color)
        {
            Color32 color = _color;
            return color.ToHexString();
        }

        public static Color RGBShift(this Color _color, eFixedGradient _colorShiftType, int _timesToShift, bool _fromRedToYellow = true)
        {
            Color32 color = _color;
            return color.RGBShift(_colorShiftType, _timesToShift, _fromRedToYellow);
        }
        public static Color RGBShift(this Color _color, ePointToPointGradient _gradientType, Color _initColor, Color _endColor, int _numOfColorsInBetween, int _timesToShift)
        {
            Color32 color = _color;
            return color.RGBShift(_gradientType, _initColor, _endColor, _numOfColorsInBetween, _timesToShift);
        }
    }

    public static class Color32Extension
    {
        public static string ToHexString(this Color32 _color) { return "#" + _color.r.ToString("X2") + _color.g.ToString("X2") + _color.b.ToString("X2") + _color.a.ToString("X2"); }

        public static Color32 RGBShift(this Color32 _color, eFixedGradient _gradientType, int _timesToShift, bool _fromRedToYellow = true)
        {
            switch (_gradientType)
            {
                case eFixedGradient._1536Colors:
                    return RGBShift_FixedGradient_1536Colors(_color, _timesToShift, _fromRedToYellow);
                default:
                    return _color;
            }
        }
        public static Color32 RGBShift(this Color32 _color, ePointToPointGradient _gradientType, Color32 _initColor, Color32 _endColor, int _numOfColorsInBetween, int _timesToShift)
        {
            switch (_gradientType)
            {
                case ePointToPointGradient.Loop:
                    return RGBShift_PointToPointGradient_Loop(_color, _initColor, _endColor, _numOfColorsInBetween, _timesToShift);
                default:
                    return _color;
            }
        }

        private static Color32 RGBShift_FixedGradient_1536Colors(Color32 _color, int _timesToShift, bool _fromRedToYellow)
        {
            if (_color.r != 255 && _color.g != 255 && _color.b != 255) //At least one property must be 255
                return _color;
            else if (_color.r > 0 && _color.g > 0 && _color.b > 0) //Only two properties can be greater than 0 at the same time
                return _color;

            if (_fromRedToYellow) // (r, g, b) => (255, 0, 0) -> (255, 255, 0)
            {
                for (int i = 0; i < _timesToShift; i++)
                {
                    if (_color.r == 255)
                    {
                        if (_color.b > 0)
                            _color.b--;
                        else if (_color.b == 0 && _color.g != 255)
                            _color.g++;
                        else if (_color.g == 255)
                            _color.r--;
                    }
                    else if (_color.g == 255)
                    {
                        if (_color.r > 0)
                            _color.r--;
                        else if (_color.r == 0 && _color.b != 255)
                            _color.b++;
                        else if (_color.b == 255)
                            _color.g--;
                    }
                    else // if (_color.b == 255)
                    {
                        if (_color.g > 0)
                            _color.g--;
                        else if (_color.g == 0 && _color.r != 255)
                            _color.r++;
                        else if (_color.r == 255)
                            _color.b--;
                    }
                }
            }
            else // from Red to Magenta (r, g, b) => (255, 0, 0) -> (255, 0, 255)
            {
                for (int i = 0; i < _timesToShift; i++)
                {
                    if (_color.r == 255)
                    {
                        if (_color.g > 0)
                            _color.g--;
                        else if (_color.g == 0 && _color.b != 255)
                            _color.b++;
                        else if (_color.b == 255)
                            _color.r--;
                    }
                    else if (_color.g == 255)
                    {
                        if (_color.b > 0)
                            _color.b--;
                        else if (_color.b == 0 && _color.r != 255)
                            _color.r++;
                        else if (_color.r == 255)
                            _color.g--;
                    }
                    else // if (_color.b == 255)
                    {
                        if (_color.r > 0)
                            _color.r--;
                        else if (_color.r == 0 && _color.g != 255)
                            _color.g++;
                        else if (_color.g == 255)
                            _color.b--;
                    }
                }
            }

            return _color;
        }

        private static Color32 RGBShift_PointToPointGradient_Loop(Color32 _color, Color32 _initColor, Color32 _endColor, int _numOfColorsInBetween, int _timesToShift)
        {
            if (_numOfColorsInBetween < 0)
                return _color;

            bool isInitRLess = _endColor.r >= _initColor.r;
            bool isInitGLess = _endColor.g >= _initColor.g;
            bool isInitBLess = _endColor.b >= _initColor.b;

            byte difference_r = Convert.ToByte(isInitRLess ? (_endColor.r - _initColor.r) : (_initColor.r - _endColor.r));
            byte diffegence_g = Convert.ToByte(isInitGLess ? (_endColor.g - _initColor.g) : (_initColor.g - _endColor.g));
            byte difference_b = Convert.ToByte(isInitBLess ? (_endColor.b - _initColor.b) : (_initColor.b - _endColor.b));

            int denominator = _numOfColorsInBetween + 1;
            byte differenceForMidpoints_r = Convert.ToByte(difference_r / denominator);
            byte differenceForMidpoints_g = Convert.ToByte(diffegence_g / denominator);
            byte differenceForMidpoints_b = Convert.ToByte(difference_b / denominator);

            List<Color32> colors = new List<Color32> { _initColor };
            for (int i = 1; i < _numOfColorsInBetween; i++)
            {
                byte r = Convert.ToByte(isInitRLess ? (_initColor.r + differenceForMidpoints_r * i) : (_endColor.r + differenceForMidpoints_r * i));
                byte g = Convert.ToByte(isInitGLess ? (_initColor.g + differenceForMidpoints_g * i) : (_endColor.g + differenceForMidpoints_g * i));
                byte b = Convert.ToByte(isInitBLess ? (_initColor.b + differenceForMidpoints_b * i) : (_endColor.b + differenceForMidpoints_b * i));

                Color32 midPoint = new Color32(r, g, b, _color.a);
                colors.Add(midPoint);
            }
            colors.Add(_endColor);

            for (int i = 0; i < colors.Count; i++)
            {
                if (colors[i].r == _color.r && colors[i].g == _color.g && colors[i].b == _color.b)
                {
                    int targetIndex = i + _timesToShift;
                    if (_timesToShift > colors.Count - 1)
                        targetIndex %= colors.Count;

                    _color = colors[targetIndex];

                    break;
                }
            }

            return _color;
        }
    }

    public enum eFixedGradient
    {
        _1536Colors,
    }

    public enum ePointToPointGradient
    {
        Loop,
        PingPong,
    }
}
