﻿//using System.Collections;
//using System.Collections.Generic;
//using UnityEngine;

//[RequireComponent(typeof(OVRRaycaster))]
//public class RayCastVisualizer : MonoBehaviour {

//    private OVRRaycaster m_ovrRaycaster;

//	// Use this for initialization
//	void Awake () {
//        m_ovrRaycaster = this.GetComponent<OVRRaycaster>();
//	}
	
//	// Update is called once per frame
//	void Update () {
		
//	}
//}
