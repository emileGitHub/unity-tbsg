﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EEANGames.Network.ResponseHandling
{
    public static class DataLoader
    {
        public static string RemoveOpeningAndClosingTags(string _string, string _tagTitle)
        {
            string openingTag = "<" + _tagTitle + ">";
            string closingTag = "</" + _tagTitle + ">";

            _string = _string.Remove(0, openingTag.Length);
            _string = _string.Remove(_string.Length - closingTag.Length, closingTag.Length);

            return _string;
        }
    }
}
