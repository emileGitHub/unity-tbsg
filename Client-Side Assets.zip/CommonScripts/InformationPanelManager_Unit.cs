﻿using EEANGames.TBSG._01.MainClassLib;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using UnityEngine.UI;

[RequireComponent(typeof(InformationPanelManager))]
public class InformationPanelManager_Unit : MonoBehaviour {

    [SerializeField]
    public GameObject UnitInfoPanelPrefab;

    private InformationPanelManager mainInformationPanelManager;

    private List<GameObject> InfoPanels;
    private Transform Canvas;

    // Use this for initialization
    void Awake()
    {
        mainInformationPanelManager = this.transform.GetComponent<InformationPanelManager>();
        InfoPanels = new List<GameObject>();
        Canvas = GameObject.FindGameObjectWithTag("Canvas").transform;
    }

    public void InstantiateInfoPanel(int _unitUniqueId)
    {
        GameObject infoPanel = Instantiate(UnitInfoPanelPrefab, Canvas, false);
        infoPanel.transform.Find("BackGround").Find("CloseButton").GetComponent<Button>().onClick.AddListener(() => RemoveInfoPanel());
        //RectTransform rt = infoPanel.GetComponent<RectTransform>();
        InfoPanels.Add(infoPanel);
        mainInformationPanelManager.AddInfoPanel(infoPanel);

        Unit unitData = GameDataContainer.Instance.Player.UnitsOwned.First(x => x.UniqueId == _unitUniqueId);

        UpdateInfoPanel(infoPanel, unitData);
    }

    private void UpdateInfoPanel(GameObject _infoPanel, Unit _unitData)
    {
        Transform infoPanelBG = _infoPanel.transform.Find("BackGround");

        infoPanelBG.Find("UnitNickname").GetComponent<Text>().text = _unitData.Nickname;

        Transform unitCard = infoPanelBG.Find("UnitCard");
        unitCard.Find("NamePlate").Find("Name").GetComponent<Text>().text = _unitData.BaseInfo.Name;
        unitCard.Find("Level").GetComponent<Text>().text = Calculator.Level(_unitData).ToString();
        unitCard.Find("MaxHP").Find("Amount").GetComponent<Text>().text = Calculator.MaxHP(_unitData).ToString();
        unitCard.Find("PhyStr").Find("Amount").GetComponent<Text>().text = Calculator.PhysicalStrength(_unitData).ToString();
        unitCard.Find("PhyRes").Find("Amount").GetComponent<Text>().text = Calculator.PhysicalResistance(_unitData).ToString();
        unitCard.Find("MagStr").Find("Amount").GetComponent<Text>().text = Calculator.MagicalStrength(_unitData).ToString();
        unitCard.Find("MagRes").Find("Amount").GetComponent<Text>().text = Calculator.MagicalResistance(_unitData).ToString();
        unitCard.Find("Vit").Find("Amount").GetComponent<Text>().text = Calculator.Vitality(_unitData).ToString();


        int element1_index = Convert.ToInt32(_unitData.BaseInfo.Elements[0]) - 1;
        int element2_index = Convert.ToInt32(_unitData.BaseInfo.Elements[1]) - 1;

        Transform E1 = unitCard.Find("ElementIcon1");
        Transform E2 = unitCard.Find("ElementIcon2");
        Transform S1 = unitCard.Find("SpecieIcon1");
        Transform S2 = unitCard.Find("SpecieIcon2");
        Transform S3 = unitCard.Find("SpecieIcon3");

        if (element1_index < 0)
            E1.GetComponent<CanvasRenderer>().SetAlpha(0);
        else
        {
            E1.GetComponent<CanvasRenderer>().SetAlpha(1f);
            E1.GetComponent<UnityEngine.UI.Image>().sprite = SpriteContainer.Instance.ElementIcons[element1_index];
        }

        if (element2_index < 0)
            E2.GetComponent<CanvasRenderer>().SetAlpha(0);
        else
        {
            E2.GetComponent<CanvasRenderer>().SetAlpha(1f);
            E2.GetComponent<UnityEngine.UI.Image>().sprite = SpriteContainer.Instance.ElementIcons[element2_index];
        }
    }

    //Remove newest info panel
    public void RemoveInfoPanel()
    {
        GameObject infoPanel = InfoPanels[InfoPanels.Count - 1];
        mainInformationPanelManager.RemoveInfoPanel(infoPanel);
        InfoPanels.Remove(infoPanel);
        Destroy(infoPanel);
    }
}
