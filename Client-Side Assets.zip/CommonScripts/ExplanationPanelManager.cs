﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ExplanationPanelManager : MonoBehaviour
{
    #region
    private GameObject m_explanationMenu;
    #endregion

    // Awake is called before Update for the first frame
    void Awake()
    {
        m_explanationMenu = this.transform.Find("ExplanationMenu").gameObject;
    }

    public void ShowMenu() { m_explanationMenu.SetActive(true); }

    public void HideMenu() { m_explanationMenu.SetActive(false); }
}
