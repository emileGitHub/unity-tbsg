﻿using EEANGames.TBSG._01.MainClassLib;
using EEANGames.TBSG._01.Unity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnityEngine.Events;

namespace EEANGames.TBSG._01.Unity
{
    public static class GachaConfirmationPopUpCreator
    {
        #region Private Fields
        private const string POSITIVE_COLOR_OPENING_TAG = "<color=blue>";
        private const string NEGATIVE_COLOR_OPENING_TAG = "<color=red>";
        private const string COLOR_CLOSING_TAG = "</color>";
        private const string POSITIVE_YES_LABEL = "Roll";
        private const string NO_BUTTON_LABEL = "Cancel";
        #endregion

        public static void CreatePopUp(Gacha _gacha, GachaRollRequester _gachaRollRequester, int _timesToRoll)
        {
            string popUpTitle = _gacha.Title;

            eCostType costType = _gacha.CostType;
            int playerPossesion = GetPlayerPossesion(costType);
            int costValue = _gacha.CostValue * _timesToRoll;

            bool isPossesionEnough = playerPossesion >= costValue;

            string colorOpeningTag = isPossesionEnough ? POSITIVE_COLOR_OPENING_TAG : NEGATIVE_COLOR_OPENING_TAG;
            string popUpMessage = GeneratePopUpMessage(GenerateCostTypeString(costType), playerPossesion, costValue, colorOpeningTag);

            string yesButtonLabel = isPossesionEnough ? POSITIVE_YES_LABEL : GenerateNegativeYesButtonLabel(costType);

            UnityAction positiveYesMethod = () => _gachaRollRequester.Request_RollGacha(_gacha, _timesToRoll);
            //UnityAction negativeYesMethod = () => SceneConnector.GoToScene("scn_Shop");
            //UnityAction yesMethod = isPossesionEnough ? positiveYesMethod : negativeYesMethod;
            UnityAction yesMethod = isPossesionEnough ? positiveYesMethod : null;

            PopUpWindowManager.Instance.CreateYesNoPopUp(popUpTitle, popUpMessage, yesButtonLabel, NO_BUTTON_LABEL, yesMethod);
        }

        private static string GenerateCostTypeString(eCostType _costType) { return _costType.ToString() + "(s)"; }

        private static int GetPlayerPossesion(eCostType _costType) { return _costType == eCostType.Gem ? GameDataContainer.Instance.Player.GemsOwned : GameDataContainer.Instance.Player.GoldOwned; }

        private static string GeneratePopUpMessage(string _costTypeString, int _playerPossesion, int _costValue, string _colorOpeningTag)
        {
            return "Would you like to roll this gacha by spending " + _costValue.ToString() + " " + _costTypeString + "?"
                                        + "\n\n"
                                        + _costTypeString + "owned: <color=green>" + _playerPossesion.ToString() + COLOR_CLOSING_TAG + " > " + _colorOpeningTag + (_playerPossesion - _costValue).ToString() + COLOR_CLOSING_TAG;
        }

        private static string GenerateNegativeYesButtonLabel(eCostType _costType) { return "Buy " + _costType.ToString(); }
    }
}
