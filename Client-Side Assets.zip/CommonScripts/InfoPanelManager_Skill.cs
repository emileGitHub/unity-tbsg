﻿using EEANGames.TBSG._01.MainClassLib;
using EEANGames.ImageConverter.Unity;
using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

[RequireComponent(typeof(InfoPanelManager))]
[RequireComponent(typeof(InfoPanelManager_Effect))]
public class InfoPanelManager_Skill : MonoBehaviour
{

    #region Serialized Fields
    public GameObject SkillInfoPanelPrefab;
    public GameObject EffectButtonPrefab;
    #endregion

    #region Private Fields
    private InfoPanelManager m_mainInfoPanelManager;
    private InfoPanelManager_Effect m_infoPanelManager_effect;

    private List<GameObject> m_infoPanels;
    private Transform m_canvas;
    #endregion

    //Use this for initialization

    void Awake()
    {
        m_infoPanels = new List<GameObject>();
        m_canvas = GameObject.FindGameObjectWithTag("Canvas").transform;
        m_mainInfoPanelManager = this.GetComponent<InfoPanelManager>();
        m_infoPanelManager_effect = this.GetComponent<InfoPanelManager_Effect>();
    }


    public void InstantiateInfoPanel(Skill _skill)
    {
        GameObject infoPanel = Instantiate(SkillInfoPanelPrefab, m_canvas, false);
        infoPanel.transform.Find("Image@Background").Find("Button@Close").GetComponent<Button>().onClick.AddListener(() => RemoveInfoPanel(infoPanel));
        m_infoPanels.Add(infoPanel);
        m_mainInfoPanelManager.AddInfoPanel(infoPanel);

        InitializeInfoPanel(infoPanel, _skill);
    }

    private void InitializeInfoPanel(GameObject _infoPanel, Skill _skill)
    {
        try
        {
            Transform infoPanelBG = _infoPanel.transform.Find("Image@Background");
            infoPanelBG.Find("Text@SkillName").GetComponent<Text>().text = _skill.BaseInfo.Name;
            infoPanelBG.Find("Panel@Level").Find("Text@Value").GetComponent<Text>().text = _skill.Level.ToString();
            // infoPanelBG.Find("Panel@MaxNumOfTargets").Find("Text@Value").GetComponent<Text>().text = _skill.MaxNumberOfTargets.ToValue<string>(m_mainScript.BattleSystemCore);

            if (_skill is CostRequiringSkill)
            {
                CostRequiringSkill crs = _skill as CostRequiringSkill;

                infoPanelBG.Find("Panel@SPRequired").Find("Text@Value").GetComponent<Text>().text = crs.BaseInfo.SPCost.ToString();

                Text itemsRequired = infoPanelBG.Find("Panel@ItemsRequired").Find("Text@Values").GetComponent<Text>();
                itemsRequired.text = string.Empty;
                foreach (var itemCost in crs.BaseInfo.ItemCosts)
                {
                    itemsRequired.text += itemCost.Key + " x" + itemCost.Value.ToString() + "\n";
                }
            }

            Transform effects = infoPanelBG.Find("Panel@Effects"); ///////////////////////////////////////////////////Change the UI.
            GameObject tmp_effect = Instantiate(EffectButtonPrefab, effects);
            Button tmp_effectButton = tmp_effect.GetComponent<Button>();
            // Effect e = _skill.Effect;
            //tmp_effectButton.onClick.AddListener(() => m_infoPanelManager_Effect.InstantiateInfoPanel(e));
            //SetIcon
            tmp_effect.transform.Find("Text@Title").GetComponent<Text>().text = tmp_effect.name;

        }
        catch (Exception ex)
        {
            Debug.Log("InfoPanelManager_Skill_SinglePlayer.InitializeInfoPanel() : " + ex.Message);
        }
    }

    //Remove newest info panel
    public void RemoveInfoPanel(GameObject _infoPanel)
    {
        m_mainInfoPanelManager.RemoveInfoPanel(_infoPanel);
        m_infoPanels.Remove(_infoPanel);
        Destroy(_infoPanel);
    }
}

