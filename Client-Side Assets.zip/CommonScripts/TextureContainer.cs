﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public sealed class TextureContainer
{
    private static TextureContainer m_instance;

    public static TextureContainer Instance { get { return m_instance ?? (m_instance = new TextureContainer()); } }

    private TextureContainer() { }


    #region Properties
    public List<Texture2D> UnitTextures { get; private set; }
    #endregion


    #region Public Functions
    public void Initialize(List<Texture2D> _unitTextures)
    {
        UnitTextures = _unitTextures;
    }
    #endregion

}
