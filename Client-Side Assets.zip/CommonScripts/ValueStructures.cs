﻿using System;
using System.Collections.Generic;
using UnityEngine;

[Serializable]
public struct ValueSet_Float01
{
    public float m_value;
    public eValueType01 m_valueType;
}

[Serializable]
public struct ValueSet_Float02
{
    public float m_value;
    public eValueType02 m_valueType;
}

public enum eValueType01
{
    Fixed,
    RelativeToParent
}

public enum eValueType02
{
    Fixed,
    RelativeToParent,
    RelativeToAnotherSide
}
