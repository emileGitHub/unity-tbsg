﻿using EEANGames.ImageConverter.Unity;
using EEANGames.TBSG._01.MainClassLib;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using UnityEngine.UI;

[RequireComponent(typeof(InfoPanelManager))]
[RequireComponent(typeof(InfoPanelManager_Skill))]
public class InfoPanelManager_Unit : MonoBehaviour {

    #region Serialized Fields
    public GameObject UnitInfoPanelPrefab;
    public GameObject SkillButtonPrefab;
    #endregion

    private InfoPanelManager m_mainInfoPanelManager;
    private InfoPanelManager_Skill m_infoPanelManager_skill;

    private List<GameObject> m_infoPanels;
    private Transform m_canvas;

    // Awake is called before Update for the first frame
    void Awake()
    {
        m_infoPanels = new List<GameObject>();
        m_canvas = GameObject.FindGameObjectWithTag("Canvas").transform;
        m_mainInfoPanelManager = this.GetComponent<InfoPanelManager>();
        m_infoPanelManager_skill = this.GetComponent<InfoPanelManager_Skill>();
    }

    public void InstantiateInfoPanel(int _unitUniqueId)
    {
        Unit unit = GameDataContainer.Instance.Player.UnitsOwned.First(x => x.UniqueId == _unitUniqueId);

        InstantiateInfoPanel(unit);
    }
    public void InstantiateInfoPanel(Unit _unit)
    {
        GameObject infoPanel = Instantiate(UnitInfoPanelPrefab, m_canvas, false);
        infoPanel.transform.Find("Image@Background").Find("Button@Close").GetComponent<Button>().onClick.AddListener(() => RemoveInfoPanel(infoPanel));
        m_infoPanels.Add(infoPanel);
        m_mainInfoPanelManager.AddInfoPanel(infoPanel);

        InitializeInfoPanel(infoPanel, _unit);
    }

    private void InitializeInfoPanel(GameObject _infoPanel, Unit _unit)
    {
        Transform infoPanelBG = _infoPanel.transform.Find("Image@Background");
        infoPanelBG.Find("Text@UnitNickname").GetComponent<Text>().text = _unit.Nickname;

        Transform unitCard = infoPanelBG.Find("UnitCard");
        Transform namePlate = unitCard.Find("Image@NamePlate");
        int rarityIndex = (Convert.ToInt32(_unit.BaseInfo.Rarity) / 20) - 1;
        namePlate.Find("Image@Texture").GetComponent<Image>().sprite = SpriteContainer.Instance.RaritySprites[rarityIndex];
        namePlate.Find("Text@Name").GetComponent<Text>().text = _unit.BaseInfo.Name;
        unitCard.Find("Text@Level").GetComponent<Text>().text = Calculator.Level(_unit).ToString();
        unitCard.Find("MaxHP").Find("Text@Value").GetComponent<Text>().text = Calculator.MaxHP(_unit).ToString();
        unitCard.Find("PhyStr").Find("Text@Value").GetComponent<Text>().text = Calculator.PhysicalStrength(_unit).ToString();
        unitCard.Find("PhyRes").Find("Text@Value").GetComponent<Text>().text = Calculator.PhysicalResistance(_unit).ToString();
        unitCard.Find("MagStr").Find("Text@Value").GetComponent<Text>().text = Calculator.MagicalStrength(_unit).ToString();
        unitCard.Find("MagRes").Find("Text@Value").GetComponent<Text>().text = Calculator.MagicalResistance(_unit).ToString();
        unitCard.Find("Vit").Find("Text@Value").GetComponent<Text>().text = Calculator.Vitality(_unit).ToString();

        unitCard.Find("Image@Unit").GetComponent<Image>().sprite = UnityImageConverter.ByteArrayToSprite(_unit.BaseInfo.IconAsBytes);

        int element1_index = Convert.ToInt32(_unit.BaseInfo.Elements[0]) - 1;
        int element2_index = Convert.ToInt32(_unit.BaseInfo.Elements[1]) - 1;
        Transform elementBackground = unitCard.Find("Image@ElementBackground");
        Transform element1 = elementBackground.Find("Image@Element1");
        Transform element2 = elementBackground.Find("Image@Element2");

        if (element1_index < 0)
            element1.GetComponent<CanvasRenderer>().SetAlpha(0);
        else
        {
            element1.GetComponent<CanvasRenderer>().SetAlpha(1f);
            element1.GetComponent<Image>().sprite = SpriteContainer.Instance.ElementIcons[element1_index];
        }

        if (element2_index < 0)
            element2.GetComponent<CanvasRenderer>().SetAlpha(0);
        else
        {
            element2.GetComponent<CanvasRenderer>().SetAlpha(1f);
            element2.GetComponent<Image>().sprite = SpriteContainer.Instance.ElementIcons[element2_index];
        }

        Transform targetAreaTypes = unitCard.Find("Panel@TargetAreaTypes");
        targetAreaTypes.Find("Image@MovementRangeType").Find("Text").GetComponent<Text>().text = _unit.BaseInfo.MovementRangeClassification.ToString();
        targetAreaTypes.Find("Image@NonMovementActionRangeType").Find("Text").GetComponent<Text>().text = _unit.BaseInfo.NonMovementActionRangeClassification.ToString();

        Transform skills = infoPanelBG.Find("Panel@Skills");
        foreach (Skill skill in _unit.Skills)
        {
            GameObject tmp_skill = Instantiate(SkillButtonPrefab, skills);
            tmp_skill.name = skill.BaseInfo.Name;
            Button tmp_skillButton = tmp_skill.GetComponent<Button>();
            tmp_skillButton.onClick.AddListener(() => m_infoPanelManager_skill.InstantiateInfoPanel(skill));
            //SetIcon
            tmp_skill.transform.Find("Text@Title").GetComponent<Text>().text = skill.BaseInfo.Name;
        }
    }

    //Remove newest info panel
    public void RemoveInfoPanel(GameObject _infoPanel)
    {
        m_mainInfoPanelManager.RemoveInfoPanel(_infoPanel);
        m_infoPanels.Remove(_infoPanel);
        Destroy(_infoPanel);
    }
}
