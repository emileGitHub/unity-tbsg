﻿//using System.Collections;
//using System.Collections.Generic;
//using UnityEngine;
//using UnityEngine.UI;

//[RequireComponent(typeof(Text))]
//public class TurnIdentifierTextManager : MonoBehaviour {

//    private Text myText;
//    private LocalPlayerIdentifier LocalPlayerIdentifier;

//    private int FrameCounter;

//	// Use this for initialization
//	void Awake () {
//        FrameCounter = 0;
//        myText = this.GetComponent<Text>();
//        LocalPlayerIdentifier = GameObject.Find("LocalPlayerIdentifier").GetComponent<LocalPlayerIdentifier>();
//    }

//    // Update is called once per frame
//    void FixedUpdate () {

//        if(LocalPlayerIdentifier.isInitialized)
//        {
//            //Update every 50 frames;
//            FrameCounter++;
//            if (FrameCounter >= 50)
//            {
//                FrameCounter = 0; // Reset FrameCounter

//                myText.text = (LocalPlayerIdentifier.PlayerController.isMyTurn) ? "Your Turn" : "Opponent's Turn";
//            }
//        }

//	}
//}
