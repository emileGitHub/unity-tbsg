﻿using EEANGames.ImageConverter.Unity;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

[RequireComponent(typeof(Image))]
public class ImageColorBlender : MonoBehaviour {

    public eBlendingMethod BlendingMethod;
    public Color Color = Color.white;

    private Image m_image;

	// Awake is called before Update for the first frame
	void Awake () {
        m_image = this.GetComponent<Image>();
        BlendColor();
	}

    private void BlendColor()
    {
        switch (BlendingMethod)
        {
            case eBlendingMethod.Add:
                Add();
                break;
            case eBlendingMethod.Lighten:
                Lighten();
                break;
            default:
                break;
        }
    }

    private void Add()
    {
        Texture2D targetTexture = GetCopyTexture();

        Color[] pixels = targetTexture.GetPixels();
        for (int i = 0; i < pixels.Length; i++)
        {
            pixels[i].r += Color.r;
            pixels[i].g += Color.g;
            pixels[i].b += Color.b;
        }

        SetTexture(targetTexture, pixels);
    }

    private void Lighten()
    {
        Texture2D targetTexture = GetCopyTexture();

        Color[] pixels = targetTexture.GetPixels();
        for (int i = 0; i < pixels.Length; i++)
        {
            pixels[i].r = (pixels[i].r >= Color.r) ? pixels[i].r : Color.r;
            pixels[i].g = (pixels[i].g >= Color.g) ? pixels[i].g : Color.g;
            pixels[i].b = (pixels[i].b >= Color.b) ? pixels[i].b : Color.b;
        }
        
        SetTexture(targetTexture, pixels);
    }

    private Texture2D GetCopyTexture()
    {
        Texture2D originalTexture = m_image.sprite.texture;

        // Create a new texture from the original texture
        Texture2D copy = new Texture2D(originalTexture.width, originalTexture.height, originalTexture.format, false);
        copy.LoadRawTextureData(originalTexture.GetRawTextureData());

        return copy;
    }

    private void SetTexture(Texture2D _targetTexture, Color[] _pixels)
    {
        _targetTexture.SetPixels(_pixels);

        //Apply all modifications to m_targetTexture
        _targetTexture.Apply();

        m_image.sprite = UnityImageConverter.TextureToSprite(_targetTexture);
    }

    public enum eBlendingMethod
    {
        Add,
        Lighten
    }
}
