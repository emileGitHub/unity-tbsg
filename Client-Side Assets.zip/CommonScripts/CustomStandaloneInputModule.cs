﻿using EEANGames.TBSG._01.MainClassLib;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using UnityEditor;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

namespace EEANGames.UnityEngine.EventSystems
{
    [AddComponentMenu("Event/Custom Standalone Input Module")]
    [RequireComponent(typeof(ScreenResizingDetector))]
    [RequireComponent(typeof(EventSystem))]
    public class CustomStandaloneInputModule : StandaloneInputModule
    {
        #if UNITY_EDITOR
        [MenuItem("GameObject/UI/Custom Event System Set")]
        private static void CreateCustomSetOfEventSystemComponents(){ new GameObject("EventSystem", typeof(CustomStandaloneInputModule)); }
        #endif

        private readonly MouseState m_mouseState = new MouseState();

        private List<ButtonInfo> m_buttonInfos;

        public GameObject CurrentRaycastObject { get; private set; }
        public PointerEventData.FramePressState CurrentPointerState_Left { get; private set; }

        protected override void Awake()
        {
            base.Awake();

            m_buttonInfos = new List<ButtonInfo>();

            UpdateReferenceTextures();
        }

        protected override MouseState GetMousePointerEventData(int id)
        {
            // Populate the left button...
            PointerEventData leftData;
            var created = GetPointerData(kMouseLeftId, out leftData, true);

            leftData.Reset();

            if (created)
                leftData.position = input.mousePosition;

            Vector2 pos = input.mousePosition;
            if (Cursor.lockState == CursorLockMode.Locked)
            {
                // We don't want to do ANY cursor-based interaction when the mouse is locked
                leftData.position = new Vector2(-1.0f, -1.0f);
                leftData.delta = Vector2.zero;
            }
            else
            {
                leftData.delta = pos - leftData.position;
                leftData.position = pos;
            }
            leftData.scrollDelta = input.mouseScrollDelta;
            leftData.button = PointerEventData.InputButton.Left;
            eventSystem.RaycastAll(leftData, m_RaycastResultCache);
            var raycast = FindFirstAcceptableRaycast(m_RaycastResultCache); // Get the first RaycastResult that meets specific requirements.
            leftData.pointerCurrentRaycast = raycast;
            CurrentRaycastObject = leftData.pointerCurrentRaycast.gameObject ?? null; // Set current raycast game object for external reference
            m_RaycastResultCache.Clear();

            // copy the apropriate data into right and middle slots
            PointerEventData rightData;
            GetPointerData(kMouseRightId, out rightData, true);
            CopyFromTo(leftData, rightData);
            rightData.button = PointerEventData.InputButton.Right;

            PointerEventData middleData;
            GetPointerData(kMouseMiddleId, out middleData, true);
            CopyFromTo(leftData, middleData);
            middleData.button = PointerEventData.InputButton.Middle;

            m_mouseState.SetButtonState(PointerEventData.InputButton.Left, StateForMouseButton(0), leftData);
            m_mouseState.SetButtonState(PointerEventData.InputButton.Right, StateForMouseButton(1), rightData);
            m_mouseState.SetButtonState(PointerEventData.InputButton.Middle, StateForMouseButton(2), middleData);

            CurrentPointerState_Left = m_mouseState.GetButtonState(PointerEventData.InputButton.Left).eventData.buttonState;

            return m_mouseState;
        }

        private RaycastResult FindFirstAcceptableRaycast(List<RaycastResult> _candidates)
        {
            List<RaycastResult> candidatesWithGameObject = _candidates.Where(x => x.gameObject).ToList();
            if (candidatesWithGameObject.Count > 0)
            {
                List<RaycastResult> candidatesWithoutButtonComponent = new List<RaycastResult>();
                foreach (RaycastResult candidate in candidatesWithGameObject) // For each RaycastResult that has a non-null gameObject,
                {
                    Button button = candidate.gameObject.GetComponent<Button>();
                    if (button == null) // If the gameObject does not contain a Button component
                        candidatesWithoutButtonComponent.Add(candidate);
                    else
                    {
                        // Register ButtonInfo if not registered yet.
                        if (!m_buttonInfos.Any(x => x.Button == button))
                        {
                            m_buttonInfos.Add(new ButtonInfo(button));
                            m_buttonInfos.Last().UpdateButtonInfo();
                        }

                        // Return RaycastResult if the pixel of the Button Image pointed by the pointer is not transparent
                        if (!IsPixelAlphaZeroAtPosition(input.mousePosition, m_buttonInfos.Find(x => x.Button == button)))
                            return candidate;
                    }
                }

                // Unless a RaycastResult met all of the above requirements, return the first RaycastResult without a Button component
                if (candidatesWithoutButtonComponent.Count > 0)
                    return candidatesWithoutButtonComponent.First();
            }

            // No RaycastResult had a satisfactory gameObject. Hence return a new RaycastResult.
            return new RaycastResult();
        }

        public void UpdateReferenceTextures()
        {
            foreach (ButtonInfo imageInfo in m_buttonInfos)
            {
                imageInfo.UpdateButtonInfo();
            }
        }

        private bool IsPixelAlphaZeroAtPosition(Vector2 _pointerPosition, ButtonInfo _buttonInfo)
        {
            if (_buttonInfo.IsPositionWithinRectTransform(_pointerPosition))
            {
                float relativePositionX = (_pointerPosition.x - _buttonInfo.Left) / _buttonInfo.Width; // Between 0 and 1
                float relativePositionY = (_pointerPosition.y - _buttonInfo.Bottom) / _buttonInfo.Height; // Between 0 and 1

                int pixelX = Convert.ToInt32(relativePositionX * _buttonInfo.TextureCopy.width - 1);
                int pixelY = Convert.ToInt32(relativePositionY * _buttonInfo.TextureCopy.height - 1);

                Color colorAtMousePosition = _buttonInfo.TextureCopy.GetPixel(pixelX, pixelY);
                Debug.Log("Color at Pixel(" + pixelX.ToString() + ", " + pixelY.ToString() + "): " + colorAtMousePosition.ToString());

                if (colorAtMousePosition.a == 0f)
                    return true;
            }

            return false;
        }

        private class ButtonInfo
        {
            public ButtonInfo(Button _button)
            {
                Button = _button;
            }

            public Button Button { get; }

            public float Left { get; private set; }
            public float Bottom { get; private set; }
            public float Right { get; private set; }
            public float Top { get; private set; }

            public float Width { get { return Right - Left; } }
            public float Height { get { return Top - Bottom; } }

            public Texture2D TextureCopy { get; private set; } // Perform tasks using a copy instead of original.

            public void UpdateButtonInfo()
            {
                Vector3[] sb = new Vector3[4];
                Button.image.rectTransform.GetWorldCorners(sb);

                Left = sb[0].x;
                Bottom = sb[0].y;
                Right = sb[2].x;
                Top = sb[2].y;

                Texture2D originalTexture = Button.image.sprite.texture;
                TextureCopy = new Texture2D(originalTexture.width, originalTexture.height, originalTexture.format, false);
                TextureCopy.LoadRawTextureData(originalTexture.GetRawTextureData());
                TextureCopy.Apply();
                Debug.Log("Reference texture has been updated.");
            }

            public bool IsPositionWithinRectTransform(Vector2 _position)
            {
                return _position.x >= Left && _position.x <= Right && _position.y >= Bottom && _position.y <= Top;
            }
        }
    }
}
