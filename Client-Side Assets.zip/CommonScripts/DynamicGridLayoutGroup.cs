﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEditor;

[RequireComponent(typeof(RectTransform))]
public class DynamicGridLayoutGroup : MonoBehaviour {

    #region Serialized Fields
    public bool IsFixedNumOfElementsPerRow;
    public bool IsFixedNumOfElementsPerColumn;

    public int NumOfElementsPerRow;
    public int NumOfElementsPerColumn;

    public ValueSet_Float02 ElementSizeX;
    public ValueSet_Float02 ElementSizeY;

    public ValueSet_Float01 PaddingLeft;
    public ValueSet_Float01 PaddingRight;
    public ValueSet_Float01 PaddingTop;
    public ValueSet_Float01 PaddingBottom;

    public GridLayoutGroup.Corner StartCorner;
    public GridLayoutGroup.Axis StartAxis;
    #endregion

    #region Private Member Variables
    private RectTransform m_rectTransform;
    private float m_rectTransformWidth;
    private float m_rectTransformHeight;

    //Values of variables below this line are Relative To Parent Rect Transform
    private Rect m_padding;
    private Vector2 m_spacing;

    private Vector2 m_totalPadding;
    private Vector2 m_totalSpacingBetweenElements;

    private float m_elementWidth;
    private float m_elementHeight;
    #endregion

    // Use this for initialization
    void Awake () {
        m_rectTransform = this.GetComponent<RectTransform>();

        m_padding = new Rect();
        m_spacing = new Vector2(0, 0);

        m_totalPadding = new Vector2(0, 0);
        m_totalSpacingBetweenElements = new Vector2(0, 0);

        RefreshGridLayout();
    }

    private void OnTransformChildrenChanged()
    {
        RefreshGridLayout();
    }

    private void RefreshGridLayout()
    {
        try
        {
            m_rectTransformWidth = m_rectTransform.rect.width;
            m_rectTransformHeight = m_rectTransform.rect.height;

            //Calculate padding
            if (PaddingLeft.m_valueType == eValueType01.RelativeToParent)
                m_padding.xMin = PaddingLeft.m_value;
            else
                m_padding.xMin = PaddingLeft.m_value / (float)m_rectTransformWidth;

            if (PaddingRight.m_valueType == eValueType01.RelativeToParent)
                m_padding.xMax = PaddingRight.m_value;
            else
                m_padding.xMax = PaddingRight.m_value / (float)m_rectTransformWidth;

            if (PaddingTop.m_valueType == eValueType01.RelativeToParent)
                m_padding.yMin = PaddingTop.m_value;
            else
                m_padding.yMin = PaddingTop.m_value / (float)m_rectTransformWidth;

            if (PaddingBottom.m_valueType == eValueType01.RelativeToParent)
                m_padding.yMax = PaddingBottom.m_value;
            else
                m_padding.yMax = PaddingBottom.m_value / (float)m_rectTransformWidth;

            m_totalPadding = new Vector2(m_padding.xMin + m_padding.xMax, m_padding.yMin + m_padding.yMax);

            //Calculate element size
            if(ElementSizeX.m_valueType == eValueType02.Fixed)
                m_elementWidth = ElementSizeX.m_value / m_rectTransformWidth;
            else if (ElementSizeX.m_valueType == eValueType02.RelativeToParent)
                m_elementWidth = ElementSizeX.m_value;

            if (ElementSizeY.m_valueType == eValueType02.Fixed)
                m_elementHeight = ElementSizeY.m_value / m_rectTransformHeight;
            else if (ElementSizeY.m_valueType == eValueType02.RelativeToParent)
                m_elementHeight = ElementSizeY.m_value;

            //...if value type is relative to the other side, calculate based on the value set above
            if (ElementSizeX.m_valueType == eValueType02.RelativeToAnotherSide)
            {
                m_elementWidth = ((m_elementHeight * m_rectTransformHeight) * ElementSizeX.m_value) / m_rectTransformWidth;

                if (!IsFixedNumOfElementsPerRow)
                    NumOfElementsPerRow = 1;

                if(m_elementWidth * NumOfElementsPerRow + m_totalPadding.x > 1)
                {
                    m_elementWidth = (1 - m_totalPadding.x - 0.01f) / NumOfElementsPerRow; // 0.01f is the amount for spacing

                    m_elementHeight = ((m_elementWidth * m_rectTransformWidth) / ElementSizeX.m_value) / m_rectTransformHeight;
                }

            }

            if (ElementSizeY.m_valueType == eValueType02.RelativeToAnotherSide)
            {
                m_elementHeight = ((m_elementWidth * m_rectTransformWidth) * ElementSizeY.m_value) / m_rectTransformHeight;

                if (!IsFixedNumOfElementsPerColumn)
                    NumOfElementsPerColumn = 1;

                if(m_elementHeight * NumOfElementsPerColumn + m_totalPadding.y > 1)
                {
                    m_elementHeight = (1 - m_totalPadding.y - 0.01f) / NumOfElementsPerColumn; // 0.01f is the amount for spacing

                    m_elementWidth = ((m_elementHeight * m_rectTransformHeight) / ElementSizeY.m_value) / m_rectTransformWidth;
                }
            }


            //Calculate spacing
            if (IsFixedNumOfElementsPerRow && NumOfElementsPerRow > 1)
                m_spacing.x = (1 - (m_totalPadding.x + m_elementWidth * NumOfElementsPerRow)) / (NumOfElementsPerRow - 1);

            if (IsFixedNumOfElementsPerColumn && NumOfElementsPerColumn > 1)
                m_spacing.y = (1 - (m_totalPadding.y + m_elementHeight * NumOfElementsPerColumn)) / (NumOfElementsPerColumn - 1);

            //Set size and position of each cell within the grid
            //Do not modify Rect Information
            for (int i = 0; i < this.transform.childCount; i++) //...instead, modify anchor
            {
                RectTransform rt = this.transform.GetChild(i).GetComponent<RectTransform>();

                if (i >= NumOfElementsPerRow * NumOfElementsPerColumn) //...if there are more elements than desired amount, destroy the element
                    Destroy(rt.gameObject);

                int cellRow = 0;
                int cellColumn = 0;

                if (StartAxis == GridLayoutGroup.Axis.Horizontal)
                {
                    cellRow = i / NumOfElementsPerRow;
                    cellColumn = i % NumOfElementsPerRow;
                }
                else
                {
                    cellRow = i % NumOfElementsPerColumn;
                    cellColumn = i / NumOfElementsPerColumn;
                }

                switch (StartCorner)
                {
                    default: //GridLayoutGroup.Corner.UpperLeft
                        rt.anchorMin = new Vector2(m_padding.xMin + cellColumn * (m_elementWidth + m_spacing.x), 1 - (m_padding.yMax + m_elementHeight + cellRow * (m_elementHeight + m_spacing.y)));
                        break;
                    case GridLayoutGroup.Corner.UpperRight:
                        rt.anchorMin = new Vector2(1 - (m_padding.xMax + m_elementWidth + cellColumn * (m_elementWidth + m_spacing.x)), 1 - (m_padding.yMax + m_elementHeight + cellRow * (m_elementHeight + m_spacing.y)));
                        break;
                    case GridLayoutGroup.Corner.LowerLeft:
                        rt.anchorMin = new Vector2(m_padding.xMin + cellColumn * (m_elementWidth + m_spacing.x), m_padding.yMin + cellRow * (m_elementHeight + m_spacing.y));
                        break;
                    case GridLayoutGroup.Corner.LowerRight:
                        rt.anchorMin = new Vector2(1 - (m_padding.xMax + m_elementWidth + cellColumn * (m_elementWidth + m_spacing.x)), m_padding.yMin + cellRow * (m_elementHeight + m_spacing.y));
                        break;
                }

                rt.anchorMax = new Vector2(rt.anchorMin.x + m_elementWidth, rt.anchorMin.y + m_elementHeight);
            }
        }
        catch (Exception ex)
        {
            Debug.Log("DynamicGridLayoutGroup.RefreshGridLayout() : " + ex.Message);
        }
    }
}
