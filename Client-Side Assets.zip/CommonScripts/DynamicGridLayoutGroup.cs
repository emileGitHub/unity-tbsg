﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEditor;
using EEANGames.UnityEngine.ExtensionMethods;
using UnityEngine.SceneManagement;
using EEANGames.TBSG._01.Unity;

[RequireComponent(typeof(RectTransform))]
public class DynamicGridLayoutGroup : MonoBehaviour {

    #region Serialized Fields
    public int ScriptExecutionPriorityLevel; // Lower values have higher priority

    public bool IsFixedNumOfElementsPerRow;
    public bool IsFixedNumOfElementsPerColumn;

    public int ElementHorizontalAlignment; // { "None", "Left", "Center", "Right" }
    public int ElementVerticalAlignment; // { "None", "Bottom", "Center", "Top" }

    public int NumOfElementsPerRow;
    public int NumOfElementsPerColumn;

    public bool IsHorizontallyExpansive;
    public bool IsVerticallyExpansive;

    public ValueSet_Float02 ElementSizeX;
    public ValueSet_Float02 ElementSizeY;

    public ValueSet_Float01 PaddingLeft;
    public ValueSet_Float01 PaddingRight;
    public ValueSet_Float01 PaddingTop;
    public ValueSet_Float01 PaddingBottom;

    public GridLayoutGroup.Corner StartCorner;
    public GridLayoutGroup.Axis StartAxis;
    #endregion

    #region Properties
    public static bool AreAllInitialized
    {
        get
        {
            int uninitializedCount = 0;
            foreach (var entry in m_executionLevel_numberOfScriptsToInitialize)
            {
                uninitializedCount += entry.Value;
            }

            return uninitializedCount == 0;
        }
    }
    #endregion

    #region Private Fields
    private RectTransform m_rectTransform;
    private float m_rectTransformWidth;
    private float m_rectTransformHeight;

    //Values of the five variables below are Relative To Parent Rect Transform
    private Rect m_padding;
    private Vector2 m_spacing;
    private Vector2 m_totalPadding;
    private float m_elementWidth;
    private float m_elementHeight;

    private int m_numberOfTimesExpanded;

    private bool m_isInitialized;

    private static int m_currentExecutionLevel = 1; //Used to identify whether this script can be executed
    private static Dictionary<int, int> m_executionLevel_numberOfScriptsToInitialize = new Dictionary<int, int>();
    private static int m_sceneChangeCount = 0;
    #endregion

    // Awake is called before Start and Update for the first frame
    void Awake()
    {
        m_rectTransform = this.GetComponent<RectTransform>();

        m_padding = new Rect();
        m_spacing = new Vector2(0, 0);

        m_totalPadding = new Vector2(0, 0);

        m_numberOfTimesExpanded = 0;

        if (ScriptExecutionPriorityLevel < 1)
            ScriptExecutionPriorityLevel = 1;

        m_isInitialized = false;

        string currentSceneName = SceneManager.GetActiveScene().name;
        if (SceneConnector.SceneChangeCount != m_sceneChangeCount) // Scene has changed
        {
            m_sceneChangeCount = SceneConnector.SceneChangeCount; // Update

            m_currentExecutionLevel = 1; // Initialize
            m_executionLevel_numberOfScriptsToInitialize.Clear(); // Initialize
        }

        if (!m_executionLevel_numberOfScriptsToInitialize.ContainsKey(ScriptExecutionPriorityLevel))
            m_executionLevel_numberOfScriptsToInitialize.Add(ScriptExecutionPriorityLevel, 1);
        else
            m_executionLevel_numberOfScriptsToInitialize[ScriptExecutionPriorityLevel] += 1;
    }

    // Update is called once per frame
    void Update()
    {
        if (m_currentExecutionLevel >= ScriptExecutionPriorityLevel)
        {
            if (!m_isInitialized)
            {
                bool succeeded = RefreshGridLayout();
                if (succeeded)
                {
                    m_executionLevel_numberOfScriptsToInitialize[ScriptExecutionPriorityLevel]--;
                    m_isInitialized = true;

                    if (m_executionLevel_numberOfScriptsToInitialize.ContainsKey(m_currentExecutionLevel)
                        && m_executionLevel_numberOfScriptsToInitialize[m_currentExecutionLevel] == 0)
                    {
                        m_currentExecutionLevel++;
                    }
                }
            }
        }
    }

    private void OnTransformChildrenChanged()
    {
        if (m_isInitialized)
            RefreshGridLayout();
    }

    private bool RefreshGridLayout()
    {
        if (ScriptExecutionPriorityLevel > m_currentExecutionLevel)
            return false;

        try
        {
            //Getting the size of the rectangle of the gameobject.
            m_rectTransformWidth = m_rectTransform.rect.width;
            m_rectTransformHeight = m_rectTransform.rect.height;

            //Calculate padding for the case where elements do not need to be centered
            if (ElementHorizontalAlignment == 0) // Horizontal alignment is not specified
            {
                if (PaddingLeft.m_valueType == eValueType01.RelativeToParent)
                    m_padding.xMin = PaddingLeft.m_value;
                else
                    m_padding.xMin = PaddingLeft.m_value / (float)m_rectTransformWidth;

                if (PaddingRight.m_valueType == eValueType01.RelativeToParent)
                    m_padding.xMax = PaddingRight.m_value;
                else
                    m_padding.xMax = PaddingRight.m_value / (float)m_rectTransformWidth;

                //Adjust horizontal padding if the rect transform is expansive
                if (IsHorizontallyExpansive)
                {
                    m_padding.xMin /= 1 + m_numberOfTimesExpanded;
                    m_padding.xMax /= 1 + m_numberOfTimesExpanded;
                }
            }
            else //Set temporal values
            {
                m_padding.xMin = 0;
                m_padding.xMax = 0;
            }

            if (ElementVerticalAlignment == 0) // Vertical alignment is not specified
            {
                if (PaddingBottom.m_valueType == eValueType01.RelativeToParent)
                    m_padding.yMin = PaddingBottom.m_value;
                else
                    m_padding.yMin = PaddingBottom.m_value / (float)m_rectTransformWidth;

                if (PaddingTop.m_valueType == eValueType01.RelativeToParent)
                    m_padding.yMax = PaddingTop.m_value;
                else
                    m_padding.yMax = PaddingTop.m_value / (float)m_rectTransformWidth;

                //Adjust vertical padding if the rect transform is expansive
                if (IsVerticallyExpansive)
                {
                    m_padding.yMin /= 1 + m_numberOfTimesExpanded;
                    m_padding.yMax /= 1 + m_numberOfTimesExpanded;
                }
            }
            else //Set temporal values
            {
                m_padding.yMin = 0;
                m_padding.yMax = 0;
            }

            //Get the total horizontal and vertical padding
            m_totalPadding = new Vector2(m_padding.xMin + m_padding.xMax, m_padding.yMin + m_padding.yMax);

            //Calculate element size
            if (ElementSizeX.m_valueType == eValueType02.Fixed)
                m_elementWidth = ElementSizeX.m_value / m_rectTransformWidth;
            else if (ElementSizeX.m_valueType == eValueType02.RelativeToParent)
                m_elementWidth = ElementSizeX.m_value;
            else
                m_elementWidth = 0;

            if (ElementSizeY.m_valueType == eValueType02.Fixed)
                m_elementHeight = ElementSizeY.m_value / m_rectTransformHeight;
            else if (ElementSizeY.m_valueType == eValueType02.RelativeToParent)
                m_elementHeight = ElementSizeY.m_value;
            else
                m_elementHeight = 0;

            //Adjust element size if the rect transform is expansive
            if (IsHorizontallyExpansive)
                m_elementWidth /= 1 + m_numberOfTimesExpanded;

            if (IsVerticallyExpansive)
                m_elementHeight /= 1 + m_numberOfTimesExpanded;

            //...if value type is relative to the other side, calculate based on the value set above
            if (ElementSizeX.m_valueType == eValueType02.RelativeToAnotherSide)
            {
                m_elementWidth = ((m_elementHeight * m_rectTransformHeight) * ElementSizeX.m_value) / m_rectTransformWidth;

                float widthAvailableForElements = 1 - m_totalPadding.x;

                if (m_elementWidth > widthAvailableForElements)
                    NumOfElementsPerRow = 0;

                if (IsFixedNumOfElementsPerRow)
                {
                    if (m_elementWidth * NumOfElementsPerRow > widthAvailableForElements)
                        NumOfElementsPerRow = Convert.ToInt32(Math.Floor(widthAvailableForElements / m_elementWidth)); // The max number of elements with the given width, which can fit in the given area
                }
                else
                {
                    if (widthAvailableForElements <= 0)
                        NumOfElementsPerRow = 0;
                    else
                        NumOfElementsPerRow = Convert.ToInt32(Math.Floor(widthAvailableForElements / m_elementWidth)); // The max number of elements with the given width, which can fit in the given area
                }
            }

            if (ElementSizeY.m_valueType == eValueType02.RelativeToAnotherSide)
            {
                m_elementHeight = ((m_elementWidth * m_rectTransformWidth) * ElementSizeY.m_value) / m_rectTransformHeight;

                float heightAvailableForElements = 1 - m_totalPadding.y;

                if (IsFixedNumOfElementsPerColumn)
                {
                    if (m_elementHeight * NumOfElementsPerColumn > heightAvailableForElements)
                        NumOfElementsPerColumn = Convert.ToInt32(Math.Floor(heightAvailableForElements / m_elementHeight)); // The max number of elements with the given height, which can fit in the given area
                }
                else
                {
                    if (heightAvailableForElements <= 0)
                        NumOfElementsPerColumn = 0;
                    else
                        NumOfElementsPerColumn = Convert.ToInt32(Math.Floor(heightAvailableForElements / m_elementHeight)); // The max number of elements with the given height, which can fit in the given area
                }
            }

            //Calculate padding for the case where elements must be centered
            if (ElementHorizontalAlignment != 0)
            {
                float widthAvailableForPadding = 1 - m_elementWidth;

                if (ElementHorizontalAlignment == 1)
                    m_padding.xMax = widthAvailableForPadding;
                else if (ElementHorizontalAlignment == 2)
                    m_padding.xMin = m_padding.xMax = widthAvailableForPadding / 2;
                else // if (ElementHorizontalAlignment == 3)
                    m_padding.xMin = widthAvailableForPadding;
            }
            else
            {
                //Calculate horizontal spacing
                if (NumOfElementsPerRow > 1)
                    m_spacing.x = (1 - (m_totalPadding.x + m_elementWidth * NumOfElementsPerRow)) / (NumOfElementsPerRow - 1);

                //Adjust element width if the rect transform is expansive
                if (IsHorizontallyExpansive)
                    m_spacing.x /= 1 + m_numberOfTimesExpanded;
            }

            if (ElementVerticalAlignment != 0)
            {
                float heightAvailableForPadding = 1 - m_elementHeight;

                if (ElementVerticalAlignment == 1)
                    m_padding.yMax = heightAvailableForPadding;
                else if (ElementVerticalAlignment == 2)
                    m_padding.yMin = m_padding.yMax = heightAvailableForPadding / 2;
                else // if (ElementVerticalAlignment == 3)
                    m_padding.yMin = heightAvailableForPadding;
            }
            else
            {
                //Calculate vertical spacing
                if (NumOfElementsPerColumn > 1)
                    m_spacing.y = (1 - (m_totalPadding.y + m_elementHeight * NumOfElementsPerColumn)) / (NumOfElementsPerColumn - 1);

                //Adjust element height if the rect transform is expansive
                if (IsVerticallyExpansive)
                    m_spacing.y /= 1 + m_numberOfTimesExpanded;
            }

            //Update m_totalPadding if elements must be centered
            if (ElementHorizontalAlignment != 0 || ElementVerticalAlignment != 0)
                m_totalPadding = new Vector2(m_padding.xMin + m_padding.xMax, m_padding.yMin + m_padding.yMax);

            //Set size and position of each cell within the grid
            //Do not modify Rect Information
            for (int i = 0; i < this.transform.childCount; i++) //...instead, modify anchor
            {
                RectTransform rt = this.transform.GetChild(i).GetComponent<RectTransform>();

                //Prevent undesired movement of the rect transform
                rt.SetPosition(0, 0, 0, 0);

                if (i >= NumOfElementsPerRow * NumOfElementsPerColumn)//...if there are more elements that what can fit in the given area
                {
                    if (!IsHorizontallyExpansive && !IsVerticallyExpansive)//...if the area is not expansive, destroy the element
                        Destroy(rt.gameObject);
                    else
                    {
                        m_numberOfTimesExpanded++;

                        Vector2 expansionVector;

                        if (IsHorizontallyExpansive)
                        {
                            expansionVector = new Vector2(m_numberOfTimesExpanded, 0);
                            if (StartCorner == GridLayoutGroup.Corner.LowerLeft || StartCorner == GridLayoutGroup.Corner.UpperLeft)
                                m_rectTransform.anchorMin += expansionVector;
                            else
                                m_rectTransform.anchorMax -= expansionVector;
                        }
                        else if (IsVerticallyExpansive && StartAxis == GridLayoutGroup.Axis.Horizontal)
                        {
                            m_numberOfTimesExpanded++;

                            expansionVector = new Vector2(0, m_numberOfTimesExpanded);
                            if (StartCorner == GridLayoutGroup.Corner.UpperLeft || StartCorner == GridLayoutGroup.Corner.UpperRight)
                                m_rectTransform.anchorMin -= expansionVector;
                            else
                                m_rectTransform.anchorMax += expansionVector;
                        }

                        RefreshGridLayout();
                        return false; //Terminate the function
                    }
                }

                int cellRow = 0;
                int cellColumn = 0;

                if (StartAxis == GridLayoutGroup.Axis.Horizontal)
                {
                    cellRow = i / NumOfElementsPerRow;
                    cellColumn = i % NumOfElementsPerRow;
                }
                else
                {
                    cellRow = i % NumOfElementsPerColumn;
                    cellColumn = i / NumOfElementsPerColumn;
                }

                switch (StartCorner)
                {
                    default: //GridLayoutGroup.Corner.UpperLeft
                        rt.anchorMin = new Vector2(m_padding.xMin + cellColumn * (m_elementWidth + m_spacing.x), 1 - (m_padding.yMax + m_elementHeight + cellRow * (m_elementHeight + m_spacing.y)));
                        break;
                    case GridLayoutGroup.Corner.UpperRight:
                        rt.anchorMin = new Vector2(1 - (m_padding.xMax + m_elementWidth + cellColumn * (m_elementWidth + m_spacing.x)), 1 - (m_padding.yMax + m_elementHeight + cellRow * (m_elementHeight + m_spacing.y)));
                        break;
                    case GridLayoutGroup.Corner.LowerLeft:
                        rt.anchorMin = new Vector2(m_padding.xMin + cellColumn * (m_elementWidth + m_spacing.x), m_padding.yMin + cellRow * (m_elementHeight + m_spacing.y));
                        break;
                    case GridLayoutGroup.Corner.LowerRight:
                        rt.anchorMin = new Vector2(1 - (m_padding.xMax + m_elementWidth + cellColumn * (m_elementWidth + m_spacing.x)), m_padding.yMin + cellRow * (m_elementHeight + m_spacing.y));
                        break;
                }

                rt.anchorMax = new Vector2(rt.anchorMin.x + m_elementWidth, rt.anchorMin.y + m_elementHeight);
            }

            return true;
        }
        catch (Exception ex)
        {
            Debug.Log("DynamicGridLayoutGroup.RefreshGridLayout() : " + ex.Message);
            return false;
        }
    }
}
