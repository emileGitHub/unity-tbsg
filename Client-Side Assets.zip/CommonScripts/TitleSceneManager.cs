﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class TitleSceneManager : MonoBehaviour {

    // Use this for initialization
    void Awake()
    {
        GameObject lobbyManager = GameObject.Find("LobbyManager");

        if (lobbyManager != null)
            Destroy(lobbyManager);

        //To be implemented
    }
}
