﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class TitleSceneManager : MonoBehaviour {

    // Awake is called before Update for the first frame
    void Awake()
    {
        GameObject lobbyManager = GameObject.Find("LobbyManager");

        if (lobbyManager != null)
            Destroy(lobbyManager);

        //To be implemented
    }
}
