﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnityEngine;

namespace EEANGames.UnityEngine
{
    [Serializable]
    public class Vector3IntPair : SerializableKeyValuePair<Vector3, int>
    {
        public Vector3IntPair(Vector3 _key, int _value) : base(_key, _value) { }
    }

    [Serializable]
    public class SerializableKeyValuePair<K, V>
    {
        public K Key;
        public V Value;

        public SerializableKeyValuePair(K _key, V _value)
        {
            Key = _key;
            Value = _value;
        }
        public SerializableKeyValuePair(SerializableKeyValuePair<K, V> _keyValuePair)
        {
            Key = _keyValuePair.Key;
            Value = _keyValuePair.Value;
        }
    }
}
