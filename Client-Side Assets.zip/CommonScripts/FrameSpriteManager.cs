﻿using EEANGames.TBSG._01.CommonEnums;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FrameSpriteManager : MonoBehaviour {

    private static FrameSpriteManager m_instance;

    // Sprite for each rarity
    public Sprite CommonFrame;
    public Sprite UncommonFrame;
    public Sprite RareFrame;
    public Sprite EpicFrame;
    public Sprite LegendaryFrame;

    //Sprites to be referenced across the scenes
    public static Sprite CommonFrameSprite;
    public static Sprite UncommonFrameSprite;
    public static Sprite RareFrameSprite;
    public static Sprite EpicFrameSprite;
    public static Sprite LegendaryFrameSprite;

    void Awake()
    {
        if (m_instance == null)
        {
            m_instance = this;

            //Set sprites to static properties
            CommonFrameSprite = CommonFrame;
            UncommonFrameSprite = UncommonFrame;
            RareFrameSprite = RareFrame;
            EpicFrameSprite = EpicFrame;
            LegendaryFrameSprite = LegendaryFrame;

            DontDestroyOnLoad(this.gameObject);
        }
        else if (m_instance != this)
        {
            Destroy(this.gameObject); // Avoid having multiple components of the same type
        }
    }

    /// <summary>
    /// Precondition: None.
    /// PostCondition: Will return a Sprite that corresponds to the _rarity.
    /// </summary>
    /// <param name="_rarity"></param>
    public static Sprite FrameSpriteForCorrespondingRarity(eRarity _rarity)
    {
        switch (_rarity)
        {
            default: //case eRarity.NORMAL
                return CommonFrameSprite;
            case eRarity.Uncommon:
                return UncommonFrameSprite;
            case eRarity.Rare:
                return RareFrameSprite;
            case eRarity.Epic:
                return EpicFrameSprite;
            case eRarity.Legendary:
                return LegendaryFrameSprite;
        }
    }
}
