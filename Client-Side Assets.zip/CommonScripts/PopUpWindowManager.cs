﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.UI;

namespace EEANGames.TBSG._01.Unity
{
    public sealed class PopUpWindowManager
    {
        private static PopUpWindowManager m_instance;

        public static PopUpWindowManager Instance { get { return m_instance ?? (m_instance = new PopUpWindowManager()); } }

        private PopUpWindowManager() { }

        #region Private Member Variables
        private GameObject m_popUpWindowPrefab;
        private GameObject m_buttonPrefab;

        private List<GameObject> m_popUpWindows;
        #endregion


        #region Public Functions
        public void Initialize(GameObject _popUpWindowPrefab, GameObject _buttonPrefab)
        {
            m_popUpWindowPrefab = _popUpWindowPrefab;
            m_buttonPrefab = _buttonPrefab;

            m_popUpWindows = new List<GameObject>();
        }

        public void CreatePopUp(string _title, string _message, string _ok, UnityAction _method, ePopUpWindowType _popUpWindowType)
        {
            GameObject canvas = GameObject.FindGameObjectWithTag("Canvas");

            GameObject popUpWindow = GameObject.Instantiate(m_popUpWindowPrefab, canvas.transform);

            Transform window = popUpWindow.transform.Find("Panel@Mask").Find("Panel@Window");
            Text title = window.Find("Image@Title").Find("Text").GetComponent<Text>();
            Text message = window.Find("Panel@Message").Find("ScrollMenu").Find("Contents").Find("Text@Message").GetComponent<Text>();
            Transform buttonPanel = window.Find("Panel@Buttons");
            DynamicGridLayoutGroup buttonPanelGridLayout = buttonPanel.GetComponent<DynamicGridLayoutGroup>();

            title.text = _title;
            message.text = _message.Replace("\\n", "\n");

            switch(_popUpWindowType)
            {
                default: //_popUpWindowType.Simple
                    buttonPanelGridLayout.ElementSizeX.m_value = 0.5f;
                    buttonPanelGridLayout.PaddingLeft.m_valueType = eValueType01.RelativeToParent;
                    buttonPanelGridLayout.PaddingLeft.m_value = 0.25f;

                    GameObject okButton = GameObject.Instantiate(m_buttonPrefab, buttonPanel);
                    if (_method != null)
                        okButton.GetComponent<Button>().onClick.AddListener(_method);
                    okButton.GetComponent<Button>().onClick.AddListener(() => ClosePopUp(popUpWindow));
                    okButton.transform.Find("Text").GetComponent<Text>().text = _ok;
                    break;

                //case ePopUpWindowType.Bool:
                //    GameObject yesButton = GameObject.Instantiate(m_buttonPrefab, buttonPanel);
                //    GameObject cancelButton = GameObject.Instantiate(m_buttonPrefab, buttonPanel);
                //    yesButton.GetComponent<Button>().onClick.AddListener(() => )
            }

            m_popUpWindows.Add(popUpWindow);
        }
        #endregion

        #region Private Functions
        private void ClosePopUp(GameObject _popUpWindow)
        {
            if (m_popUpWindows.Contains(_popUpWindow))
                m_popUpWindows.Remove(_popUpWindow);

            GameObject.Destroy(_popUpWindow);
        }
        #endregion
    }

    public enum ePopUpWindowType
    {
        Simple,
        //Bool,
    }
}
