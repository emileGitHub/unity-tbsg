﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.UI;

namespace EEANGames.TBSG._01.Unity
{
    public sealed class PopUpWindowManager
    {
        private static PopUpWindowManager m_instance;

        public static PopUpWindowManager Instance { get { return m_instance ?? (m_instance = new PopUpWindowManager()); } }

        private PopUpWindowManager() { }

        #region Private Member Variables
        private GameObject m_popUpWindowPrefab;
        private GameObject m_buttonPrefab;

        private List<GameObject> m_popUpWindows;
        #endregion


        #region Public Functions
        public void Initialize(GameObject _popUpWindowPrefab, GameObject _buttonPrefab)
        {
            m_popUpWindowPrefab = _popUpWindowPrefab;
            m_buttonPrefab = _buttonPrefab;

            m_popUpWindows = new List<GameObject>();
        }

        public void CreateSimplePopUp(string _title, string _message, string _ok, UnityAction _method = null)
        {
            GameObject popUpWindow = null;
            Transform buttonPanel = null;
            DynamicGridLayoutGroup buttonPanelGridLayout = null;

            CreatePopUp(_title, _message, ref popUpWindow, ref buttonPanel, ref buttonPanelGridLayout);

            buttonPanelGridLayout.NumOfElementsPerRow = 1;
            buttonPanelGridLayout.ElementHorizontalAlignment = 2; // Center
            buttonPanelGridLayout.ElementSizeX = new ValueSet_Float02 { m_valueType = eValueType02.RelativeToParent, m_value = 0.5f };
            buttonPanelGridLayout.PaddingBottom.m_value = 0;
            buttonPanelGridLayout.PaddingTop.m_value = 0;

            GameObject okButton = GameObject.Instantiate(m_buttonPrefab, buttonPanel);
            if (_method != null)
                okButton.GetComponent<Button>().onClick.AddListener(_method);
            else
                okButton.GetComponent<Button>().onClick.AddListener(() => ClosePopUp(popUpWindow));
            okButton.transform.Find("Text").GetComponent<Text>().text = _ok;
        }

        public void CreateYesNoPopUp(string _title, string _message, string _yes, string _no, UnityAction _yesMethod, UnityAction _noMethod = null)
        {
            GameObject popUpWindow = null;
            Transform buttonsPanel = null;
            DynamicGridLayoutGroup buttonPanelGridLayout = null;

            CreatePopUp(_title, _message, ref popUpWindow, ref buttonsPanel, ref buttonPanelGridLayout);

            buttonPanelGridLayout.NumOfElementsPerRow = 2;
            buttonPanelGridLayout.ElementSizeX = new ValueSet_Float02 { m_valueType = eValueType02.RelativeToParent, m_value = 0.35f };
            buttonPanelGridLayout.PaddingLeft = new ValueSet_Float01 { m_valueType = eValueType01.RelativeToParent, m_value = 0.1f };
            buttonPanelGridLayout.PaddingRight = new ValueSet_Float01 { m_valueType = eValueType01.RelativeToParent, m_value = 0.1f };
            buttonPanelGridLayout.PaddingBottom.m_value = 0;
            buttonPanelGridLayout.PaddingTop.m_value = 0;

            GameObject yesButton = GameObject.Instantiate(m_buttonPrefab, buttonsPanel);
            if (_yesMethod != null)
                yesButton.GetComponent<Button>().onClick.AddListener(_yesMethod);
            yesButton.transform.Find("Text").GetComponent<Text>().text = _yes;

            GameObject noButton = GameObject.Instantiate(m_buttonPrefab, buttonsPanel);
            if (_noMethod != null)
                noButton.GetComponent<Button>().onClick.AddListener(_noMethod);
            else
                noButton.GetComponent<Button>().onClick.AddListener(() => ClosePopUp(popUpWindow));
            noButton.transform.Find("Text").GetComponent<Text>().text = _no;
        }
        #endregion

        #region Private Functions
        private void CreatePopUp(string _title, string _message, ref GameObject _popUpWindow, ref Transform _buttonsPanel, ref DynamicGridLayoutGroup _buttonsPanelGridLayout)
        {
            GameObject canvas = GameObject.FindGameObjectWithTag("Canvas");

            _popUpWindow = GameObject.Instantiate(m_popUpWindowPrefab, canvas.transform);

            Transform window = _popUpWindow.transform.Find("Panel@Mask").Find("Panel@Window");

            Transform closeButtonPanel = window.Find("Panel@Close");
            closeButtonPanel.GetComponent<DynamicGridLayoutGroup>().ScriptExecutionPriorityLevel = 1;
            Button closeButton = closeButtonPanel.Find("Button@Close").GetComponent<Button>();
            GameObject popUpWindow = _popUpWindow; //Put the reference into another variable in order to use it within the lambda expression below
            closeButton.onClick.AddListener(() => ClosePopUp(popUpWindow));

            Text title = window.Find("Image@Title").Find("Text").GetComponent<Text>();
            title.text = _title;

            Text message = window.Find("Panel@Message").Find("ScrollMenu").Find("Contents").Find("Text@Message").GetComponent<Text>();
            message.text = _message.Replace("\\n", "\n");

            _buttonsPanel = window.Find("Panel@Buttons");
            _buttonsPanelGridLayout = _buttonsPanel.GetComponent<DynamicGridLayoutGroup>();
            _buttonsPanelGridLayout.ScriptExecutionPriorityLevel = 1; // It will always be instantiated as child of canvas

            m_popUpWindows.Add(_popUpWindow);
        }

        private void ClosePopUp(GameObject _popUpWindow)
        {
            if (m_popUpWindows.Contains(_popUpWindow))
                m_popUpWindows.Remove(_popUpWindow);

            GameObject.Destroy(_popUpWindow);
        }
        #endregion
    }
}
