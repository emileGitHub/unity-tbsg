﻿using EEANGames.TBSG._01.MainClassLib;
using EEANGames.TBSG._01.Unity;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.VR;

public class ApplicationInitializer : MonoBehaviour
{
    #region Serialized Fields
    public List<Sprite> ElementIcons;
    public List<Sprite> RaritySprites;
    public List<Sprite> CapsuleSprites;
    public List<Material> RarityMaterials;
    public GameObject PopUpWindowPrefab;
    public GameObject PopUpWindowButtonPrefab;
    #endregion

    // Awake is called before Update for the first frame
    void Awake()
    {
        //UnityEngine.XR.XRSettings.eyeTextureResolutionScale = 1.2f;
        GameDataContainer.Instance.ResetInitializationFlag();

        SpriteContainer.Instance.Initialize(ElementIcons, RaritySprites, CapsuleSprites);
        MaterialContainer.Instance.Initialize(RarityMaterials);
        PopUpWindowManager.Instance.Initialize(PopUpWindowPrefab, PopUpWindowButtonPrefab);

        Debug.Log("Application's resources have been initialized!");
    }
}
