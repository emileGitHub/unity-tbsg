﻿using EEANGames.TBSG._01.Unity;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.VR;

public class ApplicationInitializer : MonoBehaviour
{

    #region Serialized Fields
    public List<Sprite> ElementIcons;
    public List<Sprite> SmallRarityFrameIcons;
    public List<Sprite> LargeRarityFrameIcons;
    public List<Material> RarityMaterials;
    public GameObject PopUpWindowPrefab;
    public GameObject PopUpWindowButtonPrefab;
    #endregion

    // Use this for initialization
    void Awake()
    {
        //UnityEngine.XR.XRSettings.eyeTextureResolutionScale = 1.2f;

        SpriteContainer.Instance.Initialize(ElementIcons, SmallRarityFrameIcons, LargeRarityFrameIcons);
        MaterialContainer.Instance.Initialize(RarityMaterials);
        PopUpWindowManager.Instance.Initialize(PopUpWindowPrefab, PopUpWindowButtonPrefab);
    }
}
