﻿using EEANGames.TBSG._01.CommonEnums;
using EEANGames.ExtensionMethods;
using EEANGames.TBSG._01.ExtensionMethods;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace EEANGames.TBSG._01.MainClassLib
{
    #region Data
    public abstract class StatusEffectData : IDeepCopyable<StatusEffectData>
    {
        public StatusEffectData(int _id, DurationData _duration, ComplexCondition _activationCondition, byte[] _iconAsBytes)
        {
            Id = _id;

            Duration = _duration.CoalesceNullAndReturnDeepCopyOptionally(true);

            ActivationCondition = _activationCondition.CoalesceNullAndReturnDeepCopyOptionally(true);

            m_iconAsBytes = _iconAsBytes.CoalesceNullAndReturnCopyOptionally(eCopyType.Deep);
        }

        #region Properties
        public int Id { get; }

        public DurationData Duration { get; private set; }
        public ComplexCondition ActivationCondition { get; private set; }

        public IList<byte> IconAsBytes { get { return Array.AsReadOnly(m_iconAsBytes); } }
        #endregion

        #region Private Fields
        private byte[] m_iconAsBytes;
        #endregion

        #region Public Methods
        StatusEffectData IDeepCopyable<StatusEffectData>.DeepCopy() { return (StatusEffectData)DeepCopyInternally(); }
        #endregion

        #region Protected Methods
        protected virtual object DeepCopyInternally()
        {
            StatusEffectData copy = (StatusEffectData)this.MemberwiseClone();

            copy.Duration = Duration.DeepCopy();
            copy.ActivationCondition = ActivationCondition.DeepCopy();

            copy.m_iconAsBytes = m_iconAsBytes.DeepCopy();

            return copy;
        }
        #endregion
    }

    #region Background
    public abstract class BackgroundStatusEffectData : StatusEffectData, IDeepCopyable<BackgroundStatusEffectData>
    {
        public BackgroundStatusEffectData(int _id, DurationData _duration, ComplexCondition _activationCondition, byte[] _iconAsBytes,
            eActivationTurnClassification _activationTurnClassification) : base(_id, _duration, _activationCondition, _iconAsBytes)
        {
            ActivationTurnClassification = _activationTurnClassification;
        }

        #region Properties
        public eActivationTurnClassification ActivationTurnClassification { get; }
        #endregion

        #region Public Methods
        BackgroundStatusEffectData IDeepCopyable<BackgroundStatusEffectData>.DeepCopy() { return (BackgroundStatusEffectData)DeepCopyInternally(); }
        #endregion

        #region Protected Methods
        protected override object DeepCopyInternally() { return (BackgroundStatusEffectData)base.DeepCopyInternally(); }
        #endregion
    }

    public class BuffStatusEffectData : BackgroundStatusEffectData, IDeepCopyable<BuffStatusEffectData>
    {
        public BuffStatusEffectData(int _id, DurationData _duration, eActivationTurnClassification _activationTurnClassification, ComplexCondition _activationCondition, byte[] _iconAsBytes,
            eStatusType _targetStatusType, Tag _value, bool _isSum) : base(_id, _duration, _activationCondition, _iconAsBytes, _activationTurnClassification)
        {
            TargetStatusType = _targetStatusType;

            Value = _value.CoalesceNullAndReturnDeepCopyOptionally(true);

            IsSum = _isSum;
        }

        #region Properties
        public eStatusType TargetStatusType { get; }
        public Tag Value { get; private set; }
        public bool IsSum { get; }
        #endregion

        #region Public Methods
        BuffStatusEffectData IDeepCopyable<BuffStatusEffectData>.DeepCopy() { return (BuffStatusEffectData)DeepCopyInternally(); }
        #endregion

        #region Protected Methods
        protected override object DeepCopyInternally()
        {
            BuffStatusEffectData copy = (BuffStatusEffectData)base.DeepCopyInternally();

            copy.Value = Value.DeepCopy();

            return copy;
        }
        #endregion
    }

    public class DebuffStatusEffectData : BackgroundStatusEffectData, IDeepCopyable<DebuffStatusEffectData>
    {
        public DebuffStatusEffectData(int _id, DurationData _duration, eActivationTurnClassification _activationTurnClassification, ComplexCondition _activationCondition, byte[] _iconAsBytes,
            eStatusType _targetStatusType, Tag _value, bool _isSum) : base(_id, _duration, _activationCondition, _iconAsBytes, _activationTurnClassification)
        {
            TargetStatusType = _targetStatusType;

            Value = _value.CoalesceNullAndReturnDeepCopyOptionally(true);

            IsSum = _isSum;
        }

        #region Properties
        public eStatusType TargetStatusType { get; }
        public Tag Value { get; private set; }
        public bool IsSum { get; }
        #endregion

        #region Public Methods
        DebuffStatusEffectData IDeepCopyable<DebuffStatusEffectData>.DeepCopy() { return (DebuffStatusEffectData)DeepCopyInternally(); }
        #endregion

        #region Protected Methods
        protected override object DeepCopyInternally()
        {
            DebuffStatusEffectData copy = (DebuffStatusEffectData)base.DeepCopyInternally();

            copy.Value = Value.DeepCopy();

            return copy;
        }
        #endregion
    }

    public class TargetRangeModStatusEffectData : BackgroundStatusEffectData, IDeepCopyable<TargetRangeModStatusEffectData>
    {
        public TargetRangeModStatusEffectData(int _id, DurationData _duration, eActivationTurnClassification _activationTurnClassification, ComplexCondition _activationCondition, byte[] _iconAsBytes,
            bool _isMovementRangeClassification, eTargetRangeClassification _targetRangeClassification, eModificationMethod _modificationMethod) : base(_id, _duration, _activationCondition, _iconAsBytes, _activationTurnClassification)
        {
            IsMovementRangeClassification = _isMovementRangeClassification;
            TargetRangeClassification = _targetRangeClassification;
            ModificationMethod = _modificationMethod;
        }

        #region Properties
        public bool IsMovementRangeClassification { get; }
        public eTargetRangeClassification TargetRangeClassification { get; }
        public eModificationMethod ModificationMethod { get; }
        #endregion

        #region Public Methods
        TargetRangeModStatusEffectData IDeepCopyable<TargetRangeModStatusEffectData>.DeepCopy() { return (TargetRangeModStatusEffectData)DeepCopyInternally(); }
        #endregion

        #region Protected Methods
        protected override object DeepCopyInternally() { return (TargetRangeModStatusEffectData)base.DeepCopyInternally(); }
        #endregion
    }
    #endregion

    #region Foreground
    public abstract class ForegroundStatusEffectData : StatusEffectData, IDeepCopyable<ForegroundStatusEffectData>
    {
        public ForegroundStatusEffectData(int _id, DurationData _duration, ComplexCondition _activationCondition, byte[] _iconAsBytes,
            eActivationTurnClassification _activationTurnClassification, eEventTriggerTiming _eventTriggerTiming, int _animationId) : base(_id, _duration, _activationCondition, _iconAsBytes)
        {
            ActivationTurnClassification = _activationTurnClassification;
            EventTriggerTiming = _eventTriggerTiming;
            AnimationId = _animationId;
        }

        #region Properties
        public eActivationTurnClassification ActivationTurnClassification { get; }
        public eEventTriggerTiming EventTriggerTiming { get; }
        public int AnimationId { get; }
        #endregion

        #region Public Methods
        ForegroundStatusEffectData IDeepCopyable<ForegroundStatusEffectData>.DeepCopy() { return (ForegroundStatusEffectData)DeepCopyInternally(); }
        #endregion

        #region Protected Methods
        protected override object DeepCopyInternally() { return (ForegroundStatusEffectData)base.DeepCopyInternally(); }
        #endregion
    }

    public class DamageStatusEffectData : ForegroundStatusEffectData, IDeepCopyable<DamageStatusEffectData>
    {
        public DamageStatusEffectData(int _id, DurationData _duration, eActivationTurnClassification _activationTurnClassification, eEventTriggerTiming _eventTriggerTiming, ComplexCondition _activationCondition, byte[] _iconAsBytes, int _animationId,
            Tag _value) : base(_id, _duration, _activationCondition, _iconAsBytes, _activationTurnClassification, _eventTriggerTiming, _animationId)
        {
            Value = _value.CoalesceNullAndReturnDeepCopyOptionally(true);
        }

        #region Properties
        public Tag Value { get; private set; }
        #endregion

        #region Public Methods
        DamageStatusEffectData IDeepCopyable<DamageStatusEffectData>.DeepCopy() { return (DamageStatusEffectData)DeepCopyInternally(); }
        #endregion

        #region Protected Methods
        protected override object DeepCopyInternally()
        {
            DamageStatusEffectData copy = (DamageStatusEffectData)base.DeepCopyInternally();

            copy.Value = Value.DeepCopy();

            return copy;
        }
        #endregion
    }

    public class HealStatusEffectData : ForegroundStatusEffectData, IDeepCopyable<HealStatusEffectData>
    {
        public HealStatusEffectData(int _id, DurationData _duration, eActivationTurnClassification _activationTurnClassification, eEventTriggerTiming _eventTriggerTiming, ComplexCondition _activationCondition, byte[] _iconAsBytes, int _animationId,
            Tag _value) : base(_id, _duration, _activationCondition, _iconAsBytes, _activationTurnClassification, _eventTriggerTiming, _animationId)
        {
            Value = _value.CoalesceNullAndReturnDeepCopyOptionally(true);
        }

        #region Properties
        public Tag Value { get; private set; }
        #endregion

        #region Public Methods
        HealStatusEffectData IDeepCopyable<HealStatusEffectData>.DeepCopy() { return (HealStatusEffectData)DeepCopyInternally(); }
        #endregion

        #region Protected Methods
        protected override object DeepCopyInternally()
        {
            HealStatusEffectData copy = (HealStatusEffectData)base.DeepCopyInternally();

            copy.Value = Value.DeepCopy();

            return copy;
        }
        #endregion
    }
    #endregion

    public sealed class DurationData : IDeepCopyable<DurationData>
    {
        public DurationData(Tag _activationTimes, Tag _turns, ComplexCondition _whileConditions)
        {
            ActivationTimes = _activationTimes.CoalesceNullAndReturnDeepCopyOptionally(true);
            Turns = _turns.CoalesceNullAndReturnDeepCopyOptionally(true);
            WhileCondition = _whileConditions.CoalesceNullAndReturnDeepCopyOptionally(true);
        }

        //Can use either one or combine properties
        #region Properties
        public Tag ActivationTimes { get; private set; }
        public Tag Turns { get; private set; } //Decimal number. 0.5 represents a player turn. 1 represents a turn of each player.
        public ComplexCondition WhileCondition { get; private set; }
        #endregion

        #region Public Methods
        public DurationData DeepCopy()
        {
            DurationData copy = (DurationData)this.MemberwiseClone();

            copy.ActivationTimes = ActivationTimes.DeepCopy();
            copy.Turns = Turns.DeepCopy();
            copy.WhileCondition = WhileCondition.DeepCopy();

            return copy;
        }
        #endregion
    }
    #endregion

    #region Actual Status Effects
    public abstract class StatusEffect : IDeepCopyable<StatusEffect> //Poison, Confusion, Strength down, etc. This will be attached directly to Units
    {
        public StatusEffect(Duration _duration, ComplexCondition _activationCondition, UnitInstance _effectUser, int _originSkillLevel, int _equipmentLevel)
        {
            Duration = _duration.CoalesceNullAndReturnDeepCopyOptionally(true);
            ActivationCondition = _activationCondition.CoalesceNullAndReturnDeepCopyOptionally(true);
            EffectApplier = _effectUser.CoalesceNullAndReturnDeepCopyOptionally();

            OriginSkillLevel = _originSkillLevel;
            EquipmentLevel = _equipmentLevel;
        }

        public StatusEffect(StatusEffectData _data, UnitInstance _effectApplier, int _originSkillLevel, int _equipmentLevel, BattleSystemCore _system, UnitInstance _effectUser, ActiveSkill _skill, Effect _effect, List<_2DCoord> _effectRange, List<object> _targets, object _target, object _target2ForComplexTargetSelectionEffect, bool _isTarget2CurrentTarget)
        {
            ActivationCondition = _data.ActivationCondition.CoalesceNullAndReturnDeepCopyOptionally(true);
            EffectApplier = _effectApplier.CoalesceNullAndReturnDeepCopyOptionally();

            OriginSkillLevel = _originSkillLevel;
            EquipmentLevel = _equipmentLevel;

            Duration = new Duration(_data.Duration, _system, this, _effectUser, _skill, _effect, _effectRange, _targets, _target, _target2ForComplexTargetSelectionEffect, _isTarget2CurrentTarget);
        }

        #region Properties
        public Duration Duration { get; private set; }
        public ComplexCondition ActivationCondition { get; private set; }
        public UnitInstance EffectApplier { get; } //Store reference to original instance
        public int OriginSkillLevel { get; } // Level of the skill that generated or that contains this status effect
        public int EquipmentLevel { get; } // Level of the equipment that contains this status effect
        #endregion

        #region Public Methods
        StatusEffect IDeepCopyable<StatusEffect>.DeepCopy() { return (StatusEffect)DeepCopyInternally(); }
        #endregion

        #region Protected Methods
        protected virtual object DeepCopyInternally()
        {
            StatusEffect copy = (StatusEffect)this.MemberwiseClone();
            copy.Duration = Duration.DeepCopy();
            copy.ActivationCondition = ActivationCondition.DeepCopy();

            return copy;
        }
        #endregion
    }

    #region Background
    public abstract class BackgroundStatusEffect : StatusEffect, IDeepCopyable<BackgroundStatusEffect>
    {
        public BackgroundStatusEffect(Duration _duration, ComplexCondition _activateCondition, UnitInstance _effectUser,
            eActivationTurnClassification _activationTurnClassification, int _originSkillLevel, int _equipmentLevel) : base(_duration, _activateCondition, _effectUser, _originSkillLevel, _equipmentLevel)
        {
            ActivationTurnClassification = _activationTurnClassification;
        }

        public BackgroundStatusEffect(BackgroundStatusEffectData _data, UnitInstance _effectApplier, int _originSkillLevel, int _equipmentLevel, BattleSystemCore _system, UnitInstance _effectUser, ActiveSkill _skill, Effect _effect, List<_2DCoord> _effectRange, List<object> _targets, object _target, object _target2ForComplexTargetSelectionEffect, bool _isTarget2CurrentTarget) : base(_data, _effectApplier, _originSkillLevel, _equipmentLevel, _system, _effectUser, _skill, _effect, _effectRange, _targets, _target, _target2ForComplexTargetSelectionEffect, _isTarget2CurrentTarget)
        {
            ActivationTurnClassification = _data.ActivationTurnClassification;
        }

        #region Properties
        public eActivationTurnClassification ActivationTurnClassification { get; }
        #endregion

        #region Public Methods
        BackgroundStatusEffect IDeepCopyable<BackgroundStatusEffect>.DeepCopy() { return (BackgroundStatusEffect)DeepCopyInternally(); }
        #endregion

        #region Protected Methods
        protected override object DeepCopyInternally() { return (BackgroundStatusEffect)base.DeepCopyInternally(); }
        #endregion
    }

    public class BuffStatusEffect : BackgroundStatusEffect, IDeepCopyable<BuffStatusEffect>
    {
        public BuffStatusEffect(Duration _duration, eActivationTurnClassification _activationTurnClassification, ComplexCondition _activateCondition, UnitInstance _effectUser,
            eStatusType _targetStatusType, Tag _value, bool _isSum, int _originSkillLevel = 0, int _equipmentLevel = 0) : base(_duration, _activateCondition, _effectUser, _activationTurnClassification, _originSkillLevel, _equipmentLevel)
        {
            TargetStatusType = _targetStatusType;
            Value = _value.CoalesceNullAndReturnDeepCopyOptionally(true);
            IsSum = _isSum;
        }

        public BuffStatusEffect(BuffStatusEffectData _data, UnitInstance _effectApplier = null, int _originSkillLevel = 0, int _equipmentLevel = 0) : base(_data, _effectApplier, _originSkillLevel, _equipmentLevel, null, null, null, null, null, null, null, null, default)
        {
            TargetStatusType = _data.TargetStatusType;
            Value = _data.Value.CoalesceNullAndReturnDeepCopyOptionally(true);
            IsSum = _data.IsSum;
        }

        public BuffStatusEffect(BuffStatusEffectData _data, UnitInstance _effectApplier, BattleSystemCore _system, UnitInstance _effectUser, ActiveSkill _skill, Effect _effect, List<_2DCoord> _effectRange, List<object> _targets, object _target, int _originSkillLevel, object _target2ForComplexTargetSelectionEffect = null, bool _isTarget2CurrentTarget = false) : base(_data, _effectApplier, _originSkillLevel, 0, _system, _effectUser, _skill, _effect, _effectRange, _targets, _target, _target2ForComplexTargetSelectionEffect, _isTarget2CurrentTarget)
        {
            TargetStatusType = _data.TargetStatusType;
            Value = _data.Value.CoalesceNullAndReturnDeepCopyOptionally(true);
            IsSum = _data.IsSum;
        }

        #region Properties
        public eStatusType TargetStatusType { get; }
        public Tag Value { get; private set; }
        public bool IsSum { get; }
        #endregion

        #region Public Methods
        BuffStatusEffect IDeepCopyable<BuffStatusEffect>.DeepCopy() { return (BuffStatusEffect)DeepCopyInternally(); }
        #endregion

        #region Protected Methods
        protected override object DeepCopyInternally()
        {
            BuffStatusEffect copy = (BuffStatusEffect)base.DeepCopyInternally();

            copy.Value = Value.DeepCopy();

            return copy;
        }
        #endregion
    }

    public class DebuffStatusEffect : BackgroundStatusEffect, IDeepCopyable<DebuffStatusEffect>
    {
        public DebuffStatusEffect(Duration _duration, eActivationTurnClassification _activationTurnClassification, ComplexCondition _activateCondition, UnitInstance _effectUser,
    eStatusType _targetStatusType, Tag _value, bool _isSum, int _originSkillLevel = 0, int _equipmentLevel = 0) : base(_duration, _activateCondition, _effectUser, _activationTurnClassification, _originSkillLevel, _equipmentLevel)
        {
            TargetStatusType = _targetStatusType;
            Value = _value.CoalesceNullAndReturnDeepCopyOptionally(true);
            IsSum = _isSum;
        }

        public DebuffStatusEffect(DebuffStatusEffectData _data, UnitInstance _effectApplier = null, int _originSkillLevel = 0, int _equipmentLevel = 0) : base(_data, _effectApplier, _originSkillLevel, _equipmentLevel, null, null, null, null, null, null, null, null, default)
        {
            TargetStatusType = _data.TargetStatusType;
            Value = _data.Value.CoalesceNullAndReturnDeepCopyOptionally(true);
            IsSum = _data.IsSum;
        }

        public DebuffStatusEffect(DebuffStatusEffectData _data, UnitInstance _effectApplier, BattleSystemCore _system, UnitInstance _effectUser, ActiveSkill _skill, Effect _effect, List<_2DCoord> _effectRange, List<object> _targets, object _target, int _originSkillLevel, object _target2ForComplexTargetSelectionEffect = null, bool _isTarget2CurrentTarget = false) : base(_data, _effectApplier, _originSkillLevel, 0, _system, _effectUser, _skill, _effect, _effectRange, _targets, _target, _target2ForComplexTargetSelectionEffect, _isTarget2CurrentTarget)
        {
            TargetStatusType = _data.TargetStatusType;
            Value = _data.Value.CoalesceNullAndReturnDeepCopyOptionally(true);
            IsSum = _data.IsSum;
        }

        #region Properties
        public eStatusType TargetStatusType { get; }
        public Tag Value { get; private set; }
        public bool IsSum { get; }
        #endregion

        #region Public Methods
        DebuffStatusEffect IDeepCopyable<DebuffStatusEffect>.DeepCopy() { return (DebuffStatusEffect)DeepCopyInternally(); }
        #endregion

        #region Protected Methods
        protected override object DeepCopyInternally()
        {
            DebuffStatusEffect copy = (DebuffStatusEffect)base.DeepCopyInternally();

            copy.Value = Value.DeepCopy();

            return copy;
        }
        #endregion
    }

    public class TargetRangeModStatusEffect : BackgroundStatusEffect, IDeepCopyable<TargetRangeModStatusEffect>
    {
        public TargetRangeModStatusEffect(Duration _duration, eActivationTurnClassification _activationTurnClassification, ComplexCondition _activateCondition, UnitInstance _effectUser,
            bool _isMovementRangeClassification, eTargetRangeClassification _targetRangeClassification, eModificationMethod _modificationMethod, int _originSkillLevel = 0, int _equipmentLevel = 0) : base(_duration, _activateCondition, _effectUser, _activationTurnClassification, _originSkillLevel, _equipmentLevel)
        {
            IsMovementRangeClassification = _isMovementRangeClassification;
            TargetRangeClassification = _targetRangeClassification;
            ModificationMethod = _modificationMethod;
        }

        public TargetRangeModStatusEffect(TargetRangeModStatusEffectData _data, UnitInstance _effectApplier = null, int _originSkillLevel = 0, int _equipmentLevel = 0) : base(_data, _effectApplier, _originSkillLevel, _equipmentLevel, null, null, null, null, null, null, null, null, default)
        {
            IsMovementRangeClassification = _data.IsMovementRangeClassification;
            TargetRangeClassification = _data.TargetRangeClassification;
            ModificationMethod = _data.ModificationMethod;
        }

        public TargetRangeModStatusEffect(TargetRangeModStatusEffectData _data, UnitInstance _effectApplier, BattleSystemCore _system, UnitInstance _effectUser, ActiveSkill _skill, Effect _effect, List<_2DCoord> _effectRange, List<object> _targets, object _target, int _originSkillLevel, object _target2ForComplexTargetSelectionEffect = null, bool _isTarget2CurrentTarget = false) : base(_data, _effectApplier, _originSkillLevel, 0, _system, _effectUser, _skill, _effect, _effectRange, _targets, _target, _target2ForComplexTargetSelectionEffect, _isTarget2CurrentTarget)
        {
            IsMovementRangeClassification = _data.IsMovementRangeClassification;
            TargetRangeClassification = _data.TargetRangeClassification;
            ModificationMethod = _data.ModificationMethod;
        }

        #region Properties
        public bool IsMovementRangeClassification { get; }
        public eTargetRangeClassification TargetRangeClassification { get; }
        public eModificationMethod ModificationMethod { get; }
        #endregion

        #region Public Methods
        TargetRangeModStatusEffect IDeepCopyable<TargetRangeModStatusEffect>.DeepCopy() { return (TargetRangeModStatusEffect)DeepCopyInternally(); }
        #endregion

        #region Protected Methods
        protected override object DeepCopyInternally() { return (TargetRangeModStatusEffect)base.DeepCopyInternally(); }
        #endregion
    }
    #endregion

    #region Foreground
    public abstract class ForegroundStatusEffect : StatusEffect, IDeepCopyable<ForegroundStatusEffect>
    {
        public ForegroundStatusEffect(Duration _duration, ComplexCondition _activateCondition, UnitInstance _effectUser,
            eActivationTurnClassification _activationTurnClassification, eEventTriggerTiming _eventTriggerTiming, int _animationId, int _originSkillLevel, int _equipmentLevel) : base(_duration, _activateCondition, _effectUser, _originSkillLevel, _equipmentLevel)
        {
            ActivationTurnClassification = _activationTurnClassification;
            EventTriggerTiming = _eventTriggerTiming;
            AnimationId = _animationId;
        }

        public ForegroundStatusEffect(ForegroundStatusEffectData _data, UnitInstance _effectApplier, int _originSkillLevel, int _equipmentLevel, BattleSystemCore _system, UnitInstance _effectUser, ActiveSkill _skill, Effect _effect, List<_2DCoord> _effectRange, List<object> _targets, object _target, object _target2ForComplexTargetSelectionEffect, bool _isTarget2CurrentTarget) : base(_data, _effectApplier, _originSkillLevel, _equipmentLevel, _system, _effectUser, _skill, _effect, _effectRange, _targets, _target, _target2ForComplexTargetSelectionEffect, _isTarget2CurrentTarget)
        {
            ActivationTurnClassification = _data.ActivationTurnClassification;
            EventTriggerTiming = _data.EventTriggerTiming;
            AnimationId = _data.AnimationId;
        }

        #region Properties
        public eActivationTurnClassification ActivationTurnClassification { get; }
        public eEventTriggerTiming EventTriggerTiming { get; }
        public int AnimationId { get; }
        #endregion

        #region Public Methods
        ForegroundStatusEffect IDeepCopyable<ForegroundStatusEffect>.DeepCopy() { return (ForegroundStatusEffect)DeepCopyInternally(); }
        #endregion

        #region Protected Methods
        protected override object DeepCopyInternally() { return (ForegroundStatusEffect)base.DeepCopyInternally(); }
        #endregion
    }

    public class DamageStatusEffect : ForegroundStatusEffect, IDeepCopyable<DamageStatusEffect>
    {
        public DamageStatusEffect(Duration _duration, eActivationTurnClassification _activationTurnClassification, eEventTriggerTiming _eventTriggerTiming, ComplexCondition _activateCondition, UnitInstance _effectUser, int _animationId,
            Tag _damage, int _originSkillLevel = 0, int _equipmentLevel = 0) : base(_duration, _activateCondition, _effectUser, _activationTurnClassification, _eventTriggerTiming, _animationId, _originSkillLevel, _equipmentLevel)
        {
            Damage = _damage.CoalesceNullAndReturnDeepCopyOptionally(true);
        }

        public DamageStatusEffect(DamageStatusEffectData _data, UnitInstance _effectApplier, int _originSkillLevel = 0, int _equipmentLevel = 0) : base(_data, _effectApplier, _originSkillLevel, _equipmentLevel, null, null, null, null, null, null, null, null, default)
        {
            Damage = _data.Value.CoalesceNullAndReturnDeepCopyOptionally(true);
        }

        public DamageStatusEffect(DamageStatusEffectData _data, UnitInstance _effectApplier, BattleSystemCore _system, UnitInstance _effectUser, ActiveSkill _skill, Effect _effect, List<_2DCoord> _effectRange, List<object> _targets, object _target, int _originSkillLevel, object _target2ForComplexTargetSelectionEffect = null, bool _isTarget2CurrentTarget = false) : base(_data, _effectApplier, _originSkillLevel, 0, _system, _effectUser, _skill, _effect, _effectRange, _targets, _target, _target2ForComplexTargetSelectionEffect, _isTarget2CurrentTarget)
        {
            Damage = _data.Value.CoalesceNullAndReturnDeepCopyOptionally(true);
        }

        #region Properties
        public Tag Damage { get; private set; }
        #endregion

        #region Public Methods
        DamageStatusEffect IDeepCopyable<DamageStatusEffect>.DeepCopy() { return (DamageStatusEffect)DeepCopyInternally(); }
        #endregion

        #region Protected Methods
        protected override object DeepCopyInternally()
        {
            DamageStatusEffect copy = (DamageStatusEffect)base.DeepCopyInternally();

            copy.Damage = Damage.DeepCopy();

            return copy;
        }
        #endregion
    }

    public class HealStatusEffect : ForegroundStatusEffect, IDeepCopyable<HealStatusEffect>
    {
        public HealStatusEffect(Duration _duration, eActivationTurnClassification _activationTurnClassification, eEventTriggerTiming _eventTriggerTiming, ComplexCondition _activateCondition, UnitInstance _effectUser, int _animationId,
            Tag _hpAmount, int _originSkillLevel = 0, int _equipmentLevel = 0) : base(_duration, _activateCondition, _effectUser, _activationTurnClassification, _eventTriggerTiming, _animationId, _originSkillLevel, _equipmentLevel)
        {
            HPAmount = _hpAmount.CoalesceNullAndReturnDeepCopyOptionally(true);
        }

        public HealStatusEffect(HealStatusEffectData _data, UnitInstance _effectApplier, int _originSkillLevel = 0, int _equipmentLevel = 0) : base(_data, _effectApplier, _originSkillLevel, _equipmentLevel, null, null, null, null, null, null, null, null, default)
        {
            HPAmount = _data.Value.CoalesceNullAndReturnDeepCopyOptionally(true);
        }

        public HealStatusEffect(HealStatusEffectData _data, UnitInstance _effectApplier, BattleSystemCore _system, UnitInstance _effectUser, ActiveSkill _skill, Effect _effect, List<_2DCoord> _effectRange, List<object> _targets, object _target, int _originSkillLevel, object _target2ForComplexTargetSelectionEffect = null, bool _isTarget2CurrentTarget = false) : base(_data, _effectApplier, _originSkillLevel, 0, _system, _effectUser, _skill, _effect, _effectRange, _targets, _target, _target2ForComplexTargetSelectionEffect, _isTarget2CurrentTarget)
        {
            HPAmount = _data.Value.CoalesceNullAndReturnDeepCopyOptionally(true);
        }

        #region Properties
        public Tag HPAmount { get; private set; }
        #endregion

        #region Public Methods
        HealStatusEffect IDeepCopyable<HealStatusEffect>.DeepCopy() { return (HealStatusEffect)DeepCopyInternally(); }
        #endregion

        #region Protected Methods
        protected override object DeepCopyInternally()
        {
            HealStatusEffect copy = (HealStatusEffect)base.DeepCopyInternally();

            copy.HPAmount = HPAmount.DeepCopy();

            return copy;
        }
        #endregion
    }

    public sealed class Duration : IDeepCopyable<Duration>
    {
        public Duration(int _activationTimes, decimal _turns, ComplexCondition _whileConditions)
        {
            ActivationTimes = _activationTimes;
            Turns = _turns;
            WhileCondition = _whileConditions.CoalesceNullAndReturnDeepCopyOptionally(true);
        }

        public Duration(DurationData _data, BattleSystemCore _system, StatusEffect _statusEffect, UnitInstance _effectUser, ActiveSkill _skill, Effect _effect, List<_2DCoord> _effectRange, List<object> _targets, object _target, object _target2ForComplexTargetSelectionEffect, bool _isTarget2CurrentTarget)
        {
            DurationData tmp_data = _data.CoalesceNullAndReturnDeepCopyOptionally();

            ActivationTimes = tmp_data.ActivationTimes.ToValue<int>(_system, null, _statusEffect, _effectUser, _skill, _effect, _effectRange, _targets, _target, _target2ForComplexTargetSelectionEffect, _isTarget2CurrentTarget);
            Turns = tmp_data.Turns.ToValue<decimal>(_system, null, _statusEffect, _effectUser, _skill, _effect, _effectRange, _targets, _target, _target2ForComplexTargetSelectionEffect, _isTarget2CurrentTarget);
            WhileCondition = _data.WhileCondition.CoalesceNullAndReturnDeepCopyOptionally(true);
        }

        //Can use either one or combine properties
        #region Properties
        public int ActivationTimes { get; set; }
        public decimal Turns { get; set; } //Decimal number. 0.5 represents a player turn. 1 represents a turn of each player.
        public ComplexCondition WhileCondition { get; private set; }
        #endregion

        #region Public Mmethods
        public Duration DeepCopy()
        {
            Duration copy = (Duration)this.MemberwiseClone();

            copy.WhileCondition = WhileCondition.DeepCopy();

            return copy;
        }
        #endregion
    }
    #endregion
    #endregion
}
