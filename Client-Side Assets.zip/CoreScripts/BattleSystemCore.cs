﻿using EEANGames.ExtensionMethods;
using EEANGames.TBSG._01.CommonEnums;
using EEANGames.TBSG._01.ExtensionMethods;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using UnityEngine;

namespace EEANGames.TBSG._01.MainClassLib
{
    public class BattleSystemCore
    {
        public BattleSystemCore(Field _field)
        {
            Field = _field;

            CurrentTurnPlayer = Field.Players[0]; // Players[0] Starts the Game

            CurrentPlayerTurns = new int[2] { 1, 0 };

            CurrentPhase = eGamePhase.BeginningOfMatch;

            UpdateSP(CurrentTurnPlayer);

            m_eventLogs = new List<EventLog>();
        }

        #region Properties
        public Field Field { get; }

        public bool IsMatchEnd { get; private set; }
        public bool IsPlayer1Winner { get; private set; }

        public decimal CurrentFullTurns { get {
                decimal result = 0.0m;
                foreach (int playerTurn in CurrentPlayerTurns)
                {
                    result += Convert.ToDecimal(playerTurn) / CurrentPlayerTurns.Length;
                }
                return result;
            } } //0.5 per player turn (2 Players).
        public int[] CurrentPlayerTurns { get; private set; }

        public PlayerOnBoard CurrentTurnPlayer { get; private set; }

        public eGamePhase CurrentPhase { get; private set; }

        public IList<EventLog> EventLogs { get { return m_eventLogs.AsReadOnly(); } }
        #endregion

        #region Private Fields
        private List<EventLog> m_eventLogs;
        #endregion

        #region Public Methods
        //public List<UnitInstance> SortCharacters(eCharacterPropertyType _property)
        //{
        //    List<UnitInstance> sortedList = new List<UnitInstance>();

        //    foreach (UnitInstance c in Units)
        //    {
        //        sortedList.Add(c);
        //    }

        //    switch (_property)
        //    {
        //        case eCharacterPropertyType.NAME:
        //            for(int i = 1; i <= sortedList.Count; i++)
        //            {
        //                if(sortedList.Sort())
        //            }
        //    }
        //}

        /// <summary>
        /// The bool value of the dictionary returned represents whether the coord is selectable.
        /// </summary>
        public Dictionary<_2DCoord, bool> GetMovableAndSelectableArea(UnitInstance _unit)
        {
            Dictionary<_2DCoord, bool> targetArea = new Dictionary<_2DCoord, bool>();

            foreach (_2DCoord coord in GetMovableArea(_unit))
            {
                if (_unit.OwnerInstance.Moved
                    // || _unit.moveBinded
                    || Field.Board.Sockets[coord.X, coord.Y].Unit != null)
                    targetArea.Add(coord, false);
                else
                    targetArea.Add(coord, true);
            }

            return targetArea;
        }
        public List<_2DCoord> GetMovableArea(UnitInstance _unit)
        {
            List<_2DCoord> targetArea = new List<_2DCoord>();

            List<_2DCoord> relativeTargetArea = Calculator.RelativeTargetArea(_unit, true, this);

            foreach (_2DCoord relativeCoord in relativeTargetArea)
            {
                _2DCoord realTargetAreaCoord = Field.ToRealCoord(Field.UnitLocation(_unit), Field.RelativeCoordToCorrectDirection(_unit.OwnerInstance, relativeCoord));

                if (Field.IsCoordWithinBoard(realTargetAreaCoord))
                    targetArea.Add(realTargetAreaCoord);
                //else the value(s) of realTargetAreaCoord is(are) out of the board 
            }

            return targetArea;
        }

        /// <summary>
        /// The bool value of the dictionary returned represents whether the coord is selectable.
        /// </summary>
        public Dictionary<_2DCoord, bool> GetAttackTargetableAndSelectableArea(UnitInstance _attacker)
        {
            Dictionary<_2DCoord, bool> targetArea = new Dictionary<_2DCoord, bool>();

            foreach (_2DCoord coord in GetAttackTargetableArea(_attacker))
            {
                UnitInstance unitAtCoordXY = Field.Board.Sockets[coord.X, coord.Y].Unit;

                if (!_attacker.OwnerInstance.Attacked
                    // && !_attacker.attackBinded
                    && (unitAtCoordXY != null) ? (unitAtCoordXY.OwnerInstance != _attacker.OwnerInstance) : false)
                    targetArea.Add(coord, true);
                else
                    targetArea.Add(coord, false);
            }

            return targetArea;
        }
        public List<_2DCoord> GetAttackTargetableArea(UnitInstance _attacker)
        {
            List<_2DCoord> targetArea = new List<_2DCoord>();

            List<_2DCoord> relativeTargetArea = Calculator.RelativeTargetArea(_attacker, false, this);

            foreach (_2DCoord relativeCoord in relativeTargetArea)
            {
                _2DCoord realTargetAreaCoord = Field.ToRealCoord(Field.UnitLocation(_attacker), Field.RelativeCoordToCorrectDirection(_attacker.OwnerInstance, relativeCoord));

                if (Field.IsCoordWithinBoard(realTargetAreaCoord))
                    targetArea.Add(realTargetAreaCoord);
                //else the value(s) of realTargetAreaCoord is(are) out of the board 
            }

            return targetArea;
        }

        public Dictionary<_2DCoord, bool> GetSkillTargetableAndSelectableArea(UnitInstance _skillUser, CostRequiringSkill _skill)
        {
            if (_skillUser == null || _skill == null)
                return null;

            Dictionary<_2DCoord, bool> targetArea = new Dictionary<_2DCoord, bool>();

            List<_2DCoord> realTargetArea = GetSkillTargetableArea(_skillUser, _skill);

            if (_skillUser.AreResourcesEnoughForSkillExecution(_skill))
            {
                List<_2DCoord> selectableCoords = GetEffectSelectableCoords(_skillUser, _skill, _skill.BaseInfo.Effect, realTargetArea);
                foreach (_2DCoord coord in realTargetArea)
                {
                    if (selectableCoords.Contains(coord))
                        targetArea.Add(coord, true);
                    else
                        targetArea.Add(coord, false);
                }
            }
            else
                foreach (_2DCoord coord in realTargetArea) { targetArea.Add(coord, false); }

            return targetArea;
        }
        public Dictionary<_2DCoord, bool> GetSkillTargetableAndSelectableArea(UnitInstance _skillUser, UltimateSkill _skill)
        {
            if (_skillUser == null || _skill == null)
                return null;

            Dictionary<_2DCoord, bool> targetArea = new Dictionary<_2DCoord, bool>();

            List<_2DCoord> realTargetArea = GetSkillTargetableArea(_skillUser, _skill);

            List<_2DCoord> selectableCoords = GetEffectSelectableCoords(_skillUser, _skill, _skill.BaseInfo.Effect, realTargetArea);
            foreach (_2DCoord coord in realTargetArea)
            {
                if (selectableCoords.Contains(coord))
                    targetArea.Add(coord, true);
                else
                    targetArea.Add(coord, false);
            }

            return targetArea;
        }
        public List<_2DCoord> GetSkillTargetableArea(UnitInstance _skillUser, ActiveSkill _skill)
        {
            List<_2DCoord> targetArea = new List<_2DCoord>();

            List<_2DCoord> relativeTargetArea = Calculator.RelativeTargetArea(_skillUser, false, this, _skill);

            foreach (_2DCoord relativeCoord in relativeTargetArea)
            {
                _2DCoord realTargetAreaCoord = Field.ToRealCoord(Field.UnitLocation(_skillUser), Field.RelativeCoordToCorrectDirection(_skillUser.OwnerInstance, relativeCoord));

                if (Field.IsCoordWithinBoard(realTargetAreaCoord))
                    targetArea.Add(realTargetAreaCoord);
            }

            return targetArea;
        }

        // Information required for UI
        private List<_2DCoord> GetEffectSelectableCoords(UnitInstance _effectUser, Skill _skill, Effect _effect, List<_2DCoord> _targetableCoords)
        {
            List<_2DCoord> candidateCoords = new List<_2DCoord>();

            try
            {
                if (_effect is UnitTargetingEffect) //--------------------------------------------UnitTargetingEffect-------------------------------------
                {
                    List<UnitInstance> targetPreCandidates = new List<UnitInstance>();
                    UnitTargetingEffect detailedEffect = _effect as UnitTargetingEffect;

                    targetPreCandidates = FindUnitsByTargetClassification(_effectUser, detailedEffect.TargetClassification, _targetableCoords);
                    foreach (UnitInstance targetPreCandidate in targetPreCandidates)
                    {
                        if (!(_effect is HealEffect && targetPreCandidate.RemainingHP >= Calculator.MaxHP(targetPreCandidate))) // If the remaining HP of the precandidate unit is not full at the same time that the _effect is heal effect
                        {
                            if (detailedEffect.ActivationCondition.IsTrue(this, null, null, _effectUser, _skill, _effect, _targetableCoords, null, targetPreCandidate)) // If activation conditions against the unit is true
                                candidateCoords.Add(Field.UnitLocation(targetPreCandidate)); // Add unit to the list of target candidates
                        }
                    }
                }
                else if (_effect is TileTrapEffect) //-----------------------------------------------TileTargetingEffects------------------------------------------
                {
                    var detailedEffect = _effect as TileTrapEffect;

                    //More code to return selectable area
                }

                return candidateCoords;
            }
            catch(Exception ex)
            {
                candidateCoords.Clear();
                return candidateCoords;
            }
        }

        /// <summary>
        /// [Action Method] 
        /// PreCondition: _unit has been initialized successfully; _unit is assigned to a Socket of the Board;
        /// PostCondition: If the destination is not occupied by other Unit, _unit will be moved to destination and SP will be spent.
        /// </summary>
        /// <param name="_unit"></param>
        /// <param name="_direction"></param>
        /// <returns></returns>
        public bool MoveUnit(UnitInstance _unit, _2DCoord _destination)
        {
            if (ChangeUnitLocation(_unit, _destination)) // If moved successfully
            {
                _unit.OwnerInstance.Moved = true;
                return true;
            }

            return false;
        }

        // Chekck for any unexpected/wrong information before actually executing the skill.
        // No error shoud be returned if available SP and Item costs have been checked. _taretCoords must be coords included in the set of coords returned by the GetSkillTargetableAndSelectableArea() function.
        public void RequestAttack(UnitInstance _attacker, List<_2DCoord> _targetCoords)
        {
            if (!_attacker.OwnerInstance.Attacked)
            {
                List<UnitInstance> targets = new List<UnitInstance>();

                foreach (_2DCoord _targetCoord in _targetCoords)
                {
                    targets.Add(Field.Board.Sockets[_targetCoord.X, _targetCoord.Y].Unit);
                }

                foreach (UnitInstance target in targets)
                {
                    ActiveSkill skill = GameDataContainer.Instance.BasicAttackSkill;

                    List<_2DCoord> attackTargetableArea = GetAttackTargetableArea(_attacker);

                    ProcessStatusEffects(eEventTriggerTiming.OnActionExecuted, _attacker);
                    ProcessStatusEffects(eEventTriggerTiming.OnActiveSkillExecuted, _attacker, skill, attackTargetableArea, targets);

                    ExecuteEffect(_attacker, skill, skill.BaseInfo.Effect, attackTargetableArea, targets.Cast<object>().ToList(), target);
                }

                _attacker.OwnerInstance.Attacked = true;
            }
        }

        // Chekck for any unexpected/wrong information before actually executing the skill.
        // No error shoud be returned if available SP and Item costs have been checked. _taretCoords must be coords included in the set of coords returned by the GetSkillTargetableAndSelectableArea() function.
        // If working correctly, all targetCandidates must be eventual targets.
        public void RequestSkillUse(UnitInstance _skillUser, ActiveSkill _skill, List<_2DCoord> _targetCoords, _2DCoord _target2Coord = null, bool _isTarget2CurrentTarget = false)
        {
            if (_skillUser == null
                || _skill == null
                || _targetCoords == null)
            {
                return;
            }

            if (_skill is CostRequiringSkill)
            {
                var skill = _skill as CostRequiringSkill;
                if (!_skillUser.AreResourcesEnoughForSkillExecution(skill))
                    return;
            }

            int tileIndex_skillUser = Field.UnitLocation(_skillUser).ToIndex();

            IEnumerable<object> targetCandidates = new List<object>();

            if (_skill.BaseInfo.Effect is UnitTargetingEffect) //----------------------------------UnitTargetingEffect-----------------
            {
                var tmp_targetCandidates = Field.GetUnitsInCoords(_targetCoords);

                List<Tuple<string, string, string>> targetsName_Nickname_OwnerName = new List<Tuple<string, string, string>>();
                foreach (var targetCandidate in tmp_targetCandidates) { targetsName_Nickname_OwnerName.Add(new Tuple<string, string, string>(targetCandidate.BaseInfo.Name, targetCandidate.Nickname, targetCandidate.OwnerInstance.Name)); }

                m_eventLogs.Add(new ActionLog_UnitTargetingSkill(CurrentFullTurns, Field.GetUnitIndex(_skillUser), _skillUser.BaseInfo.Name, _skillUser.Nickname, _skill.BaseInfo.Name, tileIndex_skillUser, _skill.BaseInfo.AnimationId, targetsName_Nickname_OwnerName));
                targetCandidates = tmp_targetCandidates.Cast<object>();
            }
            else if (_skill.BaseInfo.Effect is TileTrapEffect) //----------------------------------TileTargetingEffect-------------------
            {
                m_eventLogs.Add(new ActionLog_TileTargetingSkill(CurrentFullTurns, Field.GetUnitIndex(_skillUser), _skillUser.BaseInfo.Name, _skillUser.Nickname, _skill.BaseInfo.Name, tileIndex_skillUser, _skill.BaseInfo.AnimationId, _targetCoords));
                targetCandidates = Field.GetSocketsInCoords(_targetCoords).Cast<object>();
            }

            List<_2DCoord> skillTargetableArea = GetSkillTargetableArea(_skillUser, _skill);

            ProcessStatusEffects(eEventTriggerTiming.OnActionExecuted, _skillUser);
            ProcessStatusEffects(eEventTriggerTiming.OnActiveSkillExecuted, _skillUser, _skill, skillTargetableArea, targetCandidates);

            object target2 = null;
            if (_target2Coord != null)
                target2 = Field.Board.Sockets[_target2Coord.X, _target2Coord.Y].Unit;

            RequestEffectUse(_skillUser, _skill, _skill.BaseInfo.Effect, GetSkillTargetableArea(_skillUser, _skill), targetCandidates, target2, _isTarget2CurrentTarget);

            if (_skill is CostRequiringSkill)
                _skillUser.OwnerInstance.RemainingSP -= (_skill as CostRequiringSkill).BaseInfo.SPCost;
        }

        private void RequestEffectUse(UnitInstance _effectUser, ActiveSkill _skill, Effect _effect, List<_2DCoord> _effectRange, IEnumerable<object> _targetCandidates, object _target2ForComplexTargetSelectionEffect = null, bool _isTarget2CurrentTarget = false)
        {
            if (_effectUser == null
                || _skill == null
                || _effect == null
                || _effectRange == null
                || _targetCandidates == null)
            {
                return;
            }

            if (_targetCandidates.Count() > 0)
            {
                var targets = _targetCandidates.Where(x => _effect.ActivationCondition.IsTrue(this, null, null, _effectUser, _skill, _effect, _effectRange, null, x)).ToList();

                if (targets.Count() > 0)
                {
                    foreach (object target in targets)
                    {
                        if (_effect is IComplexTargetSelectionEffect)
                            ExecuteEffect(_effectUser, _skill, _effect, _effectRange, targets, target, _target2ForComplexTargetSelectionEffect, _isTarget2CurrentTarget);
                        else
                            ExecuteEffect(_effectUser, _skill, _effect, _effectRange, targets, target);
                    }
                }
            }
        }

        /// <summary>
        /// Attempts to ExecuteEffect. Effects might fail if target protects itself, dodges the effect, etc.
        /// PreCondition: _effectUser, _effect, _target, and _effectResults have been initialized successfully; _effectUser.isAlive == true; _effectUser is assigned to a Socket of the Board;
        /// PostCondition: Actions corresponding to _effect will be executed.
        /// </summary>
        /// <param name="_effectUser"></param>
        /// <param name="_effect"></param>
        /// <param name="_target"></param>
        /// <param name="_effectResults"></param>
        private void ExecuteEffect(UnitInstance _effectUser, ActiveSkill _skill, Effect _effect, List<_2DCoord> _effectRange, List<object> _targets, object _target, object _target2ForComplexTargetSelectionEffect = null, bool _isTarget2CurrentTarget = false)
        {
            if (_effectUser == null
                || _skill == null
                || _effect == null
                || _effectRange == null
                || _target == null)
            {
                return;
            }

            int timesToApply = _effect.TimesToApply.ToValue<int>(this, null, null, _effectUser, _skill, _effect, _effectRange, _targets, _target, _target2ForComplexTargetSelectionEffect, _isTarget2CurrentTarget);

            if (_effect is UnitTargetingEffect) //------------------------------------------------------------------UnitTargetingEffects----------------------------------------------------
            {
                var target = _target as UnitInstance;
                var target2ForComplexTargetSelectionEffect = (_target2ForComplexTargetSelectionEffect != null) ? _target2ForComplexTargetSelectionEffect as UnitInstance : null;
                var targets = _targets.Cast<UnitInstance>().ToList();

                _2DCoord _effectUserLocation = Field.UnitLocation(_effectUser);

                int tileIndex_targetLocation = Field.UnitLocation(target).ToIndex();

                if (_effect is DamageEffect) //---------------------------------------------Damage--------------------------------------------
                {
                    var effect = _effect as DamageEffect;

                    for (int i = 1; i <= timesToApply; i++)
                    {
                        if (Calculator.DoesSucceed(this, _effectUser, _skill, effect, _effectRange, _targets, target, _target2ForComplexTargetSelectionEffect, _isTarget2CurrentTarget)) // If the effect succeeded
                        {
                            bool isCritical = false; // Pass this variable into Calculator.Damage() to get desired value
                            eEffectiveness effectiveness = eEffectiveness.Neutral; // Pass this variable into Calculator.Damage() to get desired value
                            int damage = Calculator.Damage(this, _effectUser, _effectUserLocation, _skill, effect, _effectRange, targets, target, ref isCritical, ref effectiveness, target2ForComplexTargetSelectionEffect, _isTarget2CurrentTarget);
                            DealDamage(damage, target);

                            m_eventLogs.Add(new EffectTrialLog_DamageEffect(CurrentFullTurns, _effect.AnimationId, true, Field.GetUnitIndex(target), target.BaseInfo.Name, target.Nickname, tileIndex_targetLocation, false, isCritical, effectiveness, damage, target.RemainingHP));
                        }
                        else // If the effect failed
                            m_eventLogs.Add(new EffectTrialLog_DamageEffect(CurrentFullTurns, _effect.AnimationId, false, Field.GetUnitIndex(target), target.BaseInfo.Name, target.Nickname, tileIndex_targetLocation, false, false, eEffectiveness.Neutral, default(int), target.RemainingHP)); // _wasImmune, _wasCritical, _effectiveness, and _value would not be used.

                        if (_effect.SecondaryEffects.Count > 0)
                        {
                            foreach (Effect secondaryEffect in _effect.SecondaryEffects)
                            {
                                ExecuteEffect(_effectUser, _skill, secondaryEffect, _effectRange, _targets, _target, _target2ForComplexTargetSelectionEffect, _isTarget2CurrentTarget);
                            }
                        }
                    }
                }
                else if (_effect is HealEffect) //-------------------------------------------Heal---------------------------------------------
                {
                    var effect = _effect as HealEffect;

                    if (Calculator.DoesSucceed(this, _effectUser, _skill, effect, _effectRange, _targets, target, _target2ForComplexTargetSelectionEffect, _isTarget2CurrentTarget)) // If the effect succeeded
                    {
                        bool isCritical = false; // Pass this variable into Calculator.HealValue() to get desired value
                        int restoringAmount = Calculator.HealValue(this, _effectUser, _effectUserLocation, _skill, effect, _effectRange, targets, target, ref isCritical, target2ForComplexTargetSelectionEffect, _isTarget2CurrentTarget);
                        RestoreHP(restoringAmount, target);

                        m_eventLogs.Add(new EffectTrialLog_HealEffect(CurrentFullTurns, _effect.AnimationId, true, Field.GetUnitIndex(target), target.BaseInfo.Name, target.Nickname, tileIndex_targetLocation, isCritical, restoringAmount, target.RemainingHP));
                    }
                    else
                        m_eventLogs.Add(new EffectTrialLog_HealEffect(CurrentFullTurns, _effect.AnimationId, false, Field.GetUnitIndex(target), target.BaseInfo.Name, target.Nickname, tileIndex_targetLocation, false, default(int), target.RemainingHP)); // _wasCritical and _value would not be used.

                    if (_effect.SecondaryEffects.Count > 0)
                    {
                        foreach (Effect secondaryEffect in _effect.SecondaryEffects)
                        {
                            ExecuteEffect(_effectUser, _skill, secondaryEffect, _effectRange, _targets, _target, _target2ForComplexTargetSelectionEffect, _isTarget2CurrentTarget);
                        }
                    }
                }
                else if (_effect is StatusEffectAttachmentEffect) //-------------------------------------StatusEffectAttachment--------------------------------------------
                {
                    var effect = _effect as StatusEffectAttachmentEffect;

                    if (Calculator.DoesSucceed(this, _effectUser, _skill, effect, _effectRange, _targets, target, _target2ForComplexTargetSelectionEffect, _isTarget2CurrentTarget)) // If the effect succeeded
                    {
                        StatusEffect statusEffect = null;
                        if (effect.DataOfStatusEffectToAttach is BuffStatusEffectData)
                        {
                            var data = effect.DataOfStatusEffectToAttach as BuffStatusEffectData;
                            statusEffect = new BuffStatusEffect(data, _effectUser, this, _effectUser, _skill, effect, _effectRange, _targets, target, _skill.Level, _target2ForComplexTargetSelectionEffect, _isTarget2CurrentTarget);
                            AttachEffect(statusEffect, target);
                        }
                        else if (effect.DataOfStatusEffectToAttach is DebuffStatusEffectData)
                        {
                            var data = effect.DataOfStatusEffectToAttach as DebuffStatusEffectData;
                            statusEffect = new DebuffStatusEffect(data, _effectUser, this, _effectUser, _skill, effect, _effectRange, _targets, target, _skill.Level, _target2ForComplexTargetSelectionEffect, _isTarget2CurrentTarget);
                            AttachEffect(statusEffect, target);
                        }
                        else if (effect.DataOfStatusEffectToAttach is TargetRangeModStatusEffectData)
                        {
                            var data = effect.DataOfStatusEffectToAttach as TargetRangeModStatusEffectData;
                            statusEffect = new TargetRangeModStatusEffect(data, _effectUser, this, _effectUser, _skill, effect, _effectRange, _targets, target, _skill.Level, _target2ForComplexTargetSelectionEffect, _isTarget2CurrentTarget);
                            AttachEffect(statusEffect, target);
                        }
                        else if (effect.DataOfStatusEffectToAttach is DamageStatusEffectData)
                        {
                            var data = effect.DataOfStatusEffectToAttach as DamageStatusEffectData;
                            statusEffect = new DamageStatusEffect(data, _effectUser, this, _effectUser, _skill, effect, _effectRange, _targets, target, _skill.Level, _target2ForComplexTargetSelectionEffect, _isTarget2CurrentTarget);
                            AttachEffect(statusEffect, target);
                        }
                        else if (effect.DataOfStatusEffectToAttach is HealStatusEffectData)
                        {
                            var data = effect.DataOfStatusEffectToAttach as HealStatusEffectData;
                            statusEffect = new HealStatusEffect(data, _effectUser, this, _effectUser, _skill, effect, _effectRange, _targets, target, _skill.Level, _target2ForComplexTargetSelectionEffect, _isTarget2CurrentTarget);
                            AttachEffect(statusEffect, target);
                        }

                        m_eventLogs.Add(new EffectTrialLog_StatusEffectAttachmentEffect(CurrentFullTurns, _effect.AnimationId, true, Field.GetUnitIndex(target), target.BaseInfo.Name, target.Nickname, tileIndex_targetLocation, effect.DataOfStatusEffectToAttach.Id));
                    }
                    else // If the effect failed
                        m_eventLogs.Add(new EffectTrialLog_StatusEffectAttachmentEffect(CurrentFullTurns, _effect.AnimationId, false, Field.GetUnitIndex(target), target.BaseInfo.Name, target.Nickname, tileIndex_targetLocation, default(int)));

                    if (_effect.SecondaryEffects.Count > 0)
                    {
                        foreach (Effect secondaryEffect in _effect.SecondaryEffects)
                        {
                            ExecuteEffect(_effectUser, _skill, secondaryEffect, _effectRange, _targets, _target, _target2ForComplexTargetSelectionEffect, _isTarget2CurrentTarget);
                        }
                    }
                }
            }
            else if (_effect is TileTrapEffect) //-------------------------------------------TileTrap------------------------------------------------
            {
                var effect = _effect as TileTrapEffect;
                var target = (Socket)_target;

                if (Calculator.DoesSucceed(this, _effectUser, _skill, effect, _effectRange, _targets, target, _target2ForComplexTargetSelectionEffect, _isTarget2CurrentTarget))
                {

                }
            }
        }

        private bool DoesActivationTurnClassificationMatch(PlayerOnBoard _player, eActivationTurnClassification _actionTurnClassification)
        {
            switch (_actionTurnClassification)
            {
                default: //case eBackgroundActivationTiming.Always
                    return true;
                case eActivationTurnClassification.OnMyTurn:
                    return _player == CurrentTurnPlayer;
                case eActivationTurnClassification.OnOpponentTurn:
                    return _player != CurrentTurnPlayer;
            }
        }

        private bool DoesEventTriggerTimingMatchGamePhase(PlayerOnBoard _player, eEventTriggerTiming _eventTriggerTiming)
        {
            switch (_eventTriggerTiming)
            {
                case eEventTriggerTiming.OnStatusEffectActivated:
                    return true; // It can be triggered at any game phase

                case eEventTriggerTiming.BeginningOfMatch:
                    return CurrentPhase == eGamePhase.BeginningOfMatch;

                case eEventTriggerTiming.BeginningOfTurn:
                    return CurrentPhase == eGamePhase.BeginningOfTurn;

                default: // Any value other than the ones listed above or below is considered as DuringTurn
                    return CurrentPhase == eGamePhase.DuringTurn;

                case eEventTriggerTiming.EndOfTurn:
                    return CurrentPhase == eGamePhase.EndOfTurn;
            }
        }

        private void ExecuteStatusEffectsIfExecutable(eEventTriggerTiming _eventTriggerTiming, UnitInstance _effectHolder, ForegroundStatusEffect _statusEffect, params object[] _params)
        {
            try
            {
                switch (_eventTriggerTiming)
                {
                    case eEventTriggerTiming.OnActionExecuted:
                        {
                            UnitInstance actor = _params[0] as UnitInstance;

                            if (_statusEffect.ActivationCondition.IsTrue(this, _effectHolder, _statusEffect, actor))
                                ExecuteStatusEffect(_effectHolder, _statusEffect, actor);
                        }
                        break;

                    case eEventTriggerTiming.OnMoved:
                        {
                            UnitInstance actor = _params[0] as UnitInstance;
                            int actor_previousLocationTileIndex = Convert.ToInt32(_params[1]);

                            if (_statusEffect.ActivationCondition.IsTrue(this, _effectHolder, _statusEffect, actor, null, null, null, null, null, null, default(bool), 0, actor_previousLocationTileIndex))
                                ExecuteStatusEffect(_effectHolder, _statusEffect, actor, null, null, null, null, null, null, default(bool), 0, actor_previousLocationTileIndex);
                        }
                        break;

                    case eEventTriggerTiming.OnAttackExecuted:
                    case eEventTriggerTiming.OnTargetedByAction:
                    case eEventTriggerTiming.OnTargetedByAttack:
                        {
                            UnitInstance actor = _params[0] as UnitInstance;
                            ActiveSkill skill = _params[1] as ActiveSkill;
                            List<_2DCoord> effectRange = _params[2].ToList<_2DCoord>();
                            List<object> targets = _params[3].ToList<object>();

                            if (_statusEffect.ActivationCondition.IsTrue(this, _effectHolder, _statusEffect, actor, skill, null, effectRange, targets))
                                ExecuteStatusEffect(_effectHolder, _statusEffect, actor, skill, null, effectRange, targets);
                        }
                        break;

                    case eEventTriggerTiming.OnActiveSkillExecuted:
                    case eEventTriggerTiming.OnItemUsed:
                        {
                            UnitInstance actor = _params[0] as UnitInstance;
                            ActiveSkill skill = _params[1] as ActiveSkill;
                            List<_2DCoord> effectRange = _params[2].ToList<_2DCoord>();
                            List<object> targets = _params[3].ToList<object>();
                            object target2ForComplexTargetSelectionEffect = _params[6];
                            bool isTarget2CurrentTarget = Convert.ToBoolean(_params[7]);

                            if (_statusEffect.ActivationCondition.IsTrue(this, _effectHolder, _statusEffect, actor, skill, null, effectRange, targets, null, target2ForComplexTargetSelectionEffect, isTarget2CurrentTarget))
                                ExecuteStatusEffect(_effectHolder, _statusEffect, actor, skill, null, effectRange, targets, null, target2ForComplexTargetSelectionEffect, isTarget2CurrentTarget);
                        }
                        break;

                    case eEventTriggerTiming.OnTargetedBySkill:
                    case eEventTriggerTiming.OnTargetedByItemSkill:
                        {
                            UnitInstance actor = _params[0] as UnitInstance;
                            ActiveSkill skill = _params[1] as ActiveSkill;
                            List<_2DCoord> effectRange = _params[2].ToList<_2DCoord>();
                            List<object> targets = _params[3].ToList<object>();
                            object target = _params[5];
                            object target2ForComplexTargetSelectionEffect = _params[6];
                            bool isTarget2CurrentTarget = Convert.ToBoolean(_params[7]);

                            if (_statusEffect.ActivationCondition.IsTrue(this, _effectHolder, _statusEffect, actor, skill, null, effectRange, targets, target, target2ForComplexTargetSelectionEffect, isTarget2CurrentTarget))
                                ExecuteStatusEffect(_effectHolder, _statusEffect, actor, skill, null, effectRange, targets, target, target2ForComplexTargetSelectionEffect, isTarget2CurrentTarget);
                        }
                        break;

                    case eEventTriggerTiming.OnEffectSuccess:
                    case eEventTriggerTiming.OnHitByEffect:
                        {
                            UnitInstance actor = _params[0] as UnitInstance;
                            ActiveSkill skill = _params[1] as ActiveSkill;
                            Effect effect = _params[2] as Effect;
                            List<_2DCoord> effectRange = _params[3].ToList<_2DCoord>();
                            List<object> targets = _params[4]?.ToList<object>();
                            object target = _params[5];
                            object target2ForComplexTargetSelectionEffect = _params[6];
                            bool isTarget2CurrentTarget = Convert.ToBoolean(_params[7]);
                            int target_previousRemainingHP = Convert.ToInt32(_params[8]);
                            int target_previousLocationTileIndex = Convert.ToInt32(_params[9]);
                            int target2_previousRemainingHP = Convert.ToInt32(_params[10]);
                            List<StatusEffect> statusEffects = _params[11].ToList<StatusEffect>();
                            eTileType previousTileType = (eTileType)_params[12];

                            if (_statusEffect.ActivationCondition.IsTrue(this, _effectHolder, _statusEffect, actor, skill, effect, effectRange, targets, target, target2ForComplexTargetSelectionEffect, isTarget2CurrentTarget, target_previousRemainingHP, target_previousLocationTileIndex, target2_previousRemainingHP, statusEffects, null, null, previousTileType))
                                ExecuteStatusEffect(_effectHolder, _statusEffect, actor, skill, effect, effectRange, targets, target, target2ForComplexTargetSelectionEffect, isTarget2CurrentTarget, target_previousRemainingHP, target_previousLocationTileIndex, target2_previousRemainingHP, statusEffects, null, null, previousTileType);
                        }
                        break;

                    case eEventTriggerTiming.OnEffectFailure:
                    case eEventTriggerTiming.OnEvadedEffect:
                        {
                            UnitInstance actor = _params[0] as UnitInstance;
                            ActiveSkill skill = _params[1] as ActiveSkill;
                            Effect effect = _params[2] as Effect;
                            List<_2DCoord> effectRange = _params[3].ToList<_2DCoord>();
                            List<object> targets = _params[4]?.ToList<object>();
                            object target = _params[5];
                            object target2ForComplexTargetSelectionEffect = _params[6];
                            bool isTarget2CurrentTarget = Convert.ToBoolean(_params[7]);

                            if (_statusEffect.ActivationCondition.IsTrue(this, _effectHolder, _statusEffect, actor, skill, effect, effectRange, targets, target, target2ForComplexTargetSelectionEffect, isTarget2CurrentTarget))
                                ExecuteStatusEffect(_effectHolder, _statusEffect, actor, skill, effect, effectRange, targets, target, target2ForComplexTargetSelectionEffect, isTarget2CurrentTarget);
                        }
                        break;

                    case eEventTriggerTiming.OnStatusEffectActivated:
                        {
                            UnitInstance effectHolderOfActivatedEffect = _params[0] as UnitInstance;
                            StatusEffect activatedStatusEffect = _params[1] as StatusEffect; // The StatusEffect that triggered OnStatusEffectActivated

                            if (_statusEffect.ActivationCondition.IsTrue(this, _effectHolder, _statusEffect, null, null, null, null, null, null, null, default(bool), 0, 0, 0, null, effectHolderOfActivatedEffect, activatedStatusEffect))
                                ExecuteStatusEffect(_effectHolder, _statusEffect, null, null, null, null, null, null, null, default(bool), 0, 0, 0, null, effectHolderOfActivatedEffect, activatedStatusEffect);
                        }
                        break;

                    default: // BeginningOfMatch, BeginningOfTurn, and EndOfTurn
                        {
                            if (_statusEffect.ActivationCondition.IsTrue(this, _effectHolder, _statusEffect))
                                ExecuteStatusEffect(_effectHolder, _statusEffect);
                        }
                        break;
                }
            }
            catch(Exception ex)
            {

            }
        }

        private void ExecuteStatusEffect(UnitInstance _effectHolder, ForegroundStatusEffect _statusEffect, UnitInstance _actor = null, ActiveSkill _skill = null, Effect _effect = null, List<_2DCoord> _effectRange = null, List<object> _targets = null, object _target = null, object _target2ForComplexTargetSelectionEffect = null, bool _isTarget2CurrentTarget = false, int _targetPreviousHP = 0, int _targetPreviousLocationTileIndex = 0, int _target2PreviousHP = 0, List<StatusEffect> _statusEffects = null, UnitInstance _effectHolderOfActivatedEffect = null, StatusEffect _statusEffectActivated = null, eTileType _previousTileType = default(eTileType))
        {
            if (_statusEffect is DamageStatusEffect)
            {
                DamageStatusEffect damageStatusEffect = _statusEffect as DamageStatusEffect;

                decimal damage = damageStatusEffect.Damage.ToValue<decimal>(this, _effectHolder, damageStatusEffect, _actor, _skill, _effect, _effectRange, _targets, _target, _target2ForComplexTargetSelectionEffect, _isTarget2CurrentTarget, _targetPreviousHP, _targetPreviousLocationTileIndex, _target2PreviousHP, _statusEffects, _effectHolderOfActivatedEffect, _statusEffectActivated, _previousTileType);

                Calculator.ApplyBuffAndDebuffStatusEffects_Simple(ref damage, this, _effectHolder, eStatusType.DamageResistance, _actor, _skill, _effect, _effectRange, _targets, _target, _target2ForComplexTargetSelectionEffect, _isTarget2CurrentTarget);

                DealDamage(Convert.ToInt32(damage), _effectHolder);

                m_eventLogs.Add(new StatusEffectLog_HPModification(CurrentFullTurns, Field.GetUnitIndex(_effectHolder), _effectHolder.BaseInfo.Name, _effectHolder.Nickname, false, Convert.ToInt32(damage), _effectHolder.RemainingHP));
            }
            else if (_statusEffect is HealStatusEffect)
            {
                HealStatusEffect healStatusEffect = _statusEffect as HealStatusEffect;

                decimal hpAmount = healStatusEffect.HPAmount.ToValue<decimal>(this, _effectHolder, healStatusEffect, _actor, _skill, _effect, _effectRange, _targets, _target, _target2ForComplexTargetSelectionEffect, _isTarget2CurrentTarget, _targetPreviousHP, _targetPreviousLocationTileIndex, _target2PreviousHP, _statusEffects, _effectHolderOfActivatedEffect, _statusEffectActivated, _previousTileType);

                Calculator.ApplyBuffAndDebuffStatusEffects_Simple(ref hpAmount, this, _effectHolder, eStatusType.FixedHeal_Self, _actor, _skill, _effect, _effectRange, _targets, _target, _target2ForComplexTargetSelectionEffect, _isTarget2CurrentTarget);

                RestoreHP(Convert.ToInt32(hpAmount), _effectHolder);

                m_eventLogs.Add(new StatusEffectLog_HPModification(CurrentFullTurns, Field.GetUnitIndex(_effectHolder), _effectHolder.BaseInfo.Name, _effectHolder.Nickname, true, Convert.ToInt32(hpAmount), _effectHolder.RemainingHP));
            }
        }

        public bool DoesStatusEffectActivationPhaseMatch(BackgroundStatusEffectData _statusEffectData, UnitInstance _effectHolder)
        {
            return DoesActivationTurnClassificationMatch(_effectHolder.OwnerInstance, _statusEffectData.ActivationTurnClassification);
        }
        public bool DoesStatusEffectActivationPhaseMatch(ForegroundStatusEffectData _statusEffectData, UnitInstance _effectHolder, eEventTriggerTiming _eventTriggerTiming)
        {
            return DoesActivationTurnClassificationMatch(_effectHolder.OwnerInstance, _statusEffectData.ActivationTurnClassification)
                    && _statusEffectData.EventTriggerTiming == _eventTriggerTiming
                    && DoesEventTriggerTimingMatchGamePhase(_effectHolder.OwnerInstance, _statusEffectData.EventTriggerTiming);
        }
        private bool DoesStatusEffectActivationPhaseMatch(ForegroundStatusEffect _statusEffect, UnitInstance _effectHolder, eEventTriggerTiming _eventTriggerTiming)
        {
            return DoesActivationTurnClassificationMatch(_effectHolder.OwnerInstance, _statusEffect.ActivationTurnClassification)
                    && _statusEffect.EventTriggerTiming == _eventTriggerTiming
                    && DoesEventTriggerTimingMatchGamePhase(_effectHolder.OwnerInstance, _statusEffect.EventTriggerTiming);
        }

        // To be used in order to execute ForegroundStatusEffects
        private void ProcessStatusEffects(eEventTriggerTiming _eventTriggerTiming, params object[] _params)
        {
            foreach (UnitInstance u in Field.Units)
            {
                if (u.StatusEffects.Count > 0)
                {
                    List<ForegroundStatusEffect> statusEffects = u.StatusEffects.OfType<ForegroundStatusEffect>()
                        .Where(x => DoesStatusEffectActivationPhaseMatch(x, u, _eventTriggerTiming)).ToList();

                    Calculator.AddPassiveSkillForegroundStatusEffects(statusEffects, this, u, _eventTriggerTiming);
                    Calculator.AddEquipmentForegroundStatusEffects(statusEffects, this, u, _eventTriggerTiming);

                    foreach (ForegroundStatusEffect se in statusEffects)
                    {
                        ExecuteStatusEffectsIfExecutable(_eventTriggerTiming, u, se, _params);

                        if (se.Duration.ActivationTimes > 0)
                            se.Duration.ActivationTimes--; // Subtract one from the remaining activation times
                    }

                    DecreaseStatusEffectsDuration(u);
                    RemoveExpiredStatusEffect(u);
                }
            }
        }

        public void ProcessStatusEffects()
        {
            foreach (UnitInstance u in Field.Units)
            {
                if (u.StatusEffects.Count > 0)
                {
                    DecreaseStatusEffectsDuration(u);
                    RemoveExpiredStatusEffect(u);
                }
            }
        }

        private void DecreaseStatusEffectsDuration(UnitInstance _unit)
        {
            if (CurrentPhase == eGamePhase.EndOfTurn)
            {
                foreach (StatusEffect se in _unit.StatusEffects.Where(x => x.Duration.Turns > 0)) // For each status effect that could be activated during more than one player turn
                {
                    se.Duration.Turns -= 0.5m; // Subtract one player turn
                }
            }
        }

        private void RemoveExpiredStatusEffect(UnitInstance _unit)
        {
            foreach (StatusEffect se in _unit.StatusEffects)
            {
                if (se.Duration.ActivationTimes <= 0
                    && se.Duration.Turns <= 0
                    && !se.Duration.WhileCondition.IsTrue(this, _unit, se))
                {
                    _unit.StatusEffects.Remove(se); // Lifetime of the status effect has ended and, thus, remove it
                }
            }
        }

        /// <summary>
        /// PreCondition: _player has been initialized successfully; At least one of the units in _player.AlliedUnits isAlive; _unitIndex matches the index of a unit in _player.AlliedUnits and the unit isAlive;
        /// PostCondtion: If succeeded, assigns _unitIndex to _player.Id_SelectedUnit. Calls EndMatch() in case no units owned by _player isAlive.
        /// </summary>
        /// <param name="_player"></param>
        /// <param name="_alliedUnitIndex"></param>
        public void ChangeSelectedUnit(PlayerOnBoard _player, int _alliedUnitIndex)
        {
            if (_alliedUnitIndex >= _player.AlliedUnits.Count
                || _alliedUnitIndex < 0)
            {
                UnselectUnits(_player);
                return;
            }

            if (_player.AlliedUnits[_alliedUnitIndex].IsAlive)
            {
                _player.SelectedUnitIndex = _alliedUnitIndex;
                return;
            }

            List<UnitInstance> unitsAlive = _player.AlliedUnits.Where(x => x.IsAlive == true).ToList();

            if (unitsAlive.Count == 0)
            {
                EndMatch(_player);
                return;
            }
        }

        public void ChangeTurn()
        {
            CurrentPhase = eGamePhase.EndOfTurn;
            ProcessStatusEffects();

            m_eventLogs.Add(new TurnChangeEventLog(CurrentFullTurns, CurrentTurnPlayer.IsPlayer1 ? 1 : 2, CurrentTurnPlayer.IsPlayer1 ? 2 : 1)); // Log to indicate turn transition

            if (CurrentTurnPlayer == Field.Players[0])
            {
                CurrentTurnPlayer = Field.Players[1];
                CurrentPlayerTurns[1]++;
            }
            else
            {
                CurrentTurnPlayer = Field.Players[0];
                CurrentPlayerTurns[0]++;
            }

            UpdateActionSelectionStatus(CurrentTurnPlayer);
            UpdateSP(CurrentTurnPlayer);

            CurrentPhase = eGamePhase.BeginningOfTurn;
            ProcessStatusEffects();
        }

        public void EndMatch(PlayerOnBoard _loser)
        {
            IsMatchEnd = true;

            if (Field.Players[0] == _loser)
                IsPlayer1Winner = false;
            else
                IsPlayer1Winner = true;
        }
        #endregion

        #region Public Methods (Command)
        public List<UnitInstance> FindUnitsByName(string _name, bool _negateStringMatchType, eStringMatchType _stringMatchType, List<UnitInstance> _units = null)
        {
            List<UnitInstance> tmp_units;

            if (_units == null)
                tmp_units = Field.Units;
            else
                tmp_units = _units;

            switch (_stringMatchType)
            {
                default: //ExactMatch
                    if (_negateStringMatchType)
                        return tmp_units.FindAll(x => !x.BaseInfo.Name.Equals(_name));
                    else return tmp_units.FindAll(x => x.BaseInfo.Name.Equals(_name));
                case eStringMatchType.Contains:
                    if (_negateStringMatchType)
                        return tmp_units.FindAll(x => !x.BaseInfo.Name.Contains(_name));
                    else return tmp_units.FindAll(x => x.BaseInfo.Name.Contains(_name));
                case eStringMatchType.StartsWith:
                    if (_negateStringMatchType)
                        return tmp_units.FindAll(x => !x.BaseInfo.Name.StartsWith(_name));
                    else return tmp_units.FindAll(x => x.BaseInfo.Name.StartsWith(_name));
                case eStringMatchType.EndsWith:
                    if (_negateStringMatchType)
                        return tmp_units.FindAll(x => !x.BaseInfo.Name.EndsWith(_name));
                    else return tmp_units.FindAll(x => x.BaseInfo.Name.EndsWith(_name));
            }
        }

        public List<UnitInstance> FindUnitsByLabel(string _label, bool _excludeLabel, List<UnitInstance> _units = null)
        {
            List<UnitInstance> tmp_units;

            if (_units == null)
                tmp_units = Field.Units;
            else
                tmp_units = _units;

            if (_excludeLabel)
                return tmp_units.FindAll(x => !x.BaseInfo.Labels.Contains(_label));
            else return tmp_units.FindAll(x => x.BaseInfo.Labels.Contains(_label));
        }

        public List<UnitInstance> FindUnitsByGender(eGender _gender, bool _excludeGender, List<UnitInstance> _units = null)
        {
            List<UnitInstance> tmp_units;

            if (_units == null)
                tmp_units = Field.Units;
            else
                tmp_units = _units;

            if (_excludeGender)
                return tmp_units.FindAll(x => x.BaseInfo.Gender != _gender);
            else return tmp_units.FindAll(x => x.BaseInfo.Gender == _gender);
        }

        public List<UnitInstance> FindUnitsByElement(eElement _element1, bool _excludeElement, eElement _element2 = eElement.None, List<UnitInstance> _units = null)
        {
            List<UnitInstance> tmp_units;

            if (_units == null)
                tmp_units = Field.Units;
            else
                tmp_units = _units;

            if (_element2 == eElement.None)
            {
                if (_excludeElement)
                    return tmp_units.FindAll(x => x.BaseInfo.Elements[0] != _element1 && x.BaseInfo.Elements[1] != _element1);
                else return tmp_units.FindAll(x => x.BaseInfo.Elements[0] == _element1 || x.BaseInfo.Elements[1] == _element1);
            }
            else
            {
                if (_excludeElement)
                    return tmp_units.FindAll(x => (x.BaseInfo.Elements[0] != _element1 && x.BaseInfo.Elements[1] != _element2)
                                            || (x.BaseInfo.Elements[0] != _element2 && x.BaseInfo.Elements[1] != _element1));
                else
                    return tmp_units.FindAll(x => (x.BaseInfo.Elements[0] == _element1 && x.BaseInfo.Elements[1] == _element2)
                                            || (x.BaseInfo.Elements[0] == _element2 && x.BaseInfo.Elements[1] == _element1));
            }
        }

        public List<UnitInstance> FindUnitsByAttributeValue(eUnitAttributeType _attributeType, eRelationType _relation, int _value, List<UnitInstance> _units = null)
        {
            List<UnitInstance> tmp_units;

            if (_units == null)
                tmp_units = Field.Units;
            else
                tmp_units = _units;

            switch (_attributeType)
            {
                default: //Level
                    return tmp_units.FindAll(x => Core.Compare(Calculator.Level(x), _relation, _value));
                case eUnitAttributeType.MaxHP:
                    return tmp_units.FindAll(x => Core.Compare(Calculator.MaxHP(x), _relation, _value));
                case eUnitAttributeType.RemainingHP:
                    return tmp_units.FindAll(x => Core.Compare(x.RemainingHP, _relation, _value));
                case eUnitAttributeType.PhyStr:
                    return tmp_units.FindAll(x => Core.Compare(Calculator.PhysicalStrength(x), _relation, _value));
                case eUnitAttributeType.PhyRes:
                    return tmp_units.FindAll(x => Core.Compare(Calculator.PhysicalResistance(x), _relation, _value));
                case eUnitAttributeType.MagStr:
                    return tmp_units.FindAll(x => Core.Compare(Calculator.MagicalStrength(x), _relation, _value));
                case eUnitAttributeType.MagRes:
                    return tmp_units.FindAll(x => Core.Compare(Calculator.MagicalResistance(x), _relation, _value));
                case eUnitAttributeType.Vitality:
                    return tmp_units.FindAll(x => Core.Compare(Calculator.Vitality(x), _relation, _value));
            }
        }

        public List<UnitInstance> FindUnitsByAttributeValueRanking(eUnitAttributeType _attributeType, eSortType _sortType, int _ranking, List<UnitInstance> _units = null)
        {
            try
            {
                List<UnitInstance> tmp_units;

                if (_units == null)
                    tmp_units = Field.Units;
                else
                    tmp_units = _units;

                tmp_units = SortUnitsByAttributeValue(_attributeType, _sortType, tmp_units);

                List<int> rankedValues = SetAttributeValueRanking(tmp_units, _attributeType);

                int rankingIndex = _ranking - 1;
                if (rankingIndex < 0 || rankingIndex >= rankedValues.Count)
                    rankingIndex = 0;

                switch (_attributeType)
                {
                    default: //Level
                        return tmp_units.FindAll(x => Calculator.Level(x) == rankedValues[rankingIndex]);
                    case eUnitAttributeType.MaxHP:
                        return tmp_units.FindAll(x => Calculator.MaxHP(x) == rankedValues[rankingIndex]);
                    case eUnitAttributeType.RemainingHP:
                        return tmp_units.FindAll(x => x.RemainingHP == rankedValues[rankingIndex]);
                    case eUnitAttributeType.PhyStr:
                        return tmp_units.FindAll(x => Calculator.PhysicalStrength(x) == rankedValues[rankingIndex]);
                    case eUnitAttributeType.PhyRes:
                        return tmp_units.FindAll(x => Calculator.PhysicalResistance(x) == rankedValues[rankingIndex]);
                    case eUnitAttributeType.MagStr:
                        return tmp_units.FindAll(x => Calculator.MagicalStrength(x) == rankedValues[rankingIndex]);
                    case eUnitAttributeType.MagRes:
                        return tmp_units.FindAll(x => Calculator.MagicalResistance(x) == rankedValues[rankingIndex]);
                    case eUnitAttributeType.Vitality:
                        return tmp_units.FindAll(x => Calculator.Vitality(x) == rankedValues[rankingIndex]);
                }
            }
            catch (Exception ex)
            {
                Debug.Log("Field.FindUnitsByAttributeValueRanking() : " + ex.Message);
                return null;
            }
        }

        public List<UnitInstance> FindUnitsByTargetClassification(UnitInstance _referenceUnit, eTargetUnitClassification _targetClassification, List<_2DCoord> _targetRange = null)
        {
            List<UnitInstance> targets = new List<UnitInstance>();

            if (_targetClassification == eTargetUnitClassification.Self
                || _targetClassification == eTargetUnitClassification.SelfAndAlly
                || _targetClassification == eTargetUnitClassification.SelfAndEnemy
                || _targetClassification == eTargetUnitClassification.Any
                || _targetClassification == eTargetUnitClassification.SelfAndAllyInRange
                || _targetClassification == eTargetUnitClassification.SelfAndEnemyInRange
                || _targetClassification == eTargetUnitClassification.UnitInRange
                || _targetClassification == eTargetUnitClassification.SelfAndAllyOnBoard
                || _targetClassification == eTargetUnitClassification.SelfAndEnemyOnBoard
                || _targetClassification == eTargetUnitClassification.UnitOnBoard)
            {
                targets.Add(_referenceUnit);
            }

            switch (_targetClassification)
            {
                case eTargetUnitClassification.Self:
                    break;
                case eTargetUnitClassification.Ally:
                case eTargetUnitClassification.SelfAndAlly:
                    targets.AddRange(_referenceUnit.OwnerInstance.AlliedUnits);
                    break;
                case eTargetUnitClassification.Enemy:
                case eTargetUnitClassification.SelfAndEnemy:
                    targets.AddRange(Field.Units.Where(x => x.OwnerInstance != _referenceUnit.OwnerInstance));
                    break;
                case eTargetUnitClassification.AllyAndEnemy:
                case eTargetUnitClassification.Any:
                    targets.AddRange(_referenceUnit.OwnerInstance.AlliedUnits);
                    targets.AddRange(Field.Units.Where(x => x.OwnerInstance != _referenceUnit.OwnerInstance));
                    break;
                case eTargetUnitClassification.AllyOnBoard:
                case eTargetUnitClassification.SelfAndAllyOnBoard:
                    targets.AddRange(_referenceUnit.OwnerInstance.AlliedUnits.Where(x => x.IsAlive));
                    break;
                case eTargetUnitClassification.EnemyOnBoard:
                case eTargetUnitClassification.SelfAndEnemyOnBoard:
                    targets.AddRange(Field.Units.Where(x => x.OwnerInstance != _referenceUnit.OwnerInstance && x.IsAlive));
                    break;
                case eTargetUnitClassification.AllyAndEnemyOnBoard:
                case eTargetUnitClassification.UnitOnBoard:
                    targets.AddRange(_referenceUnit.OwnerInstance.AlliedUnits.Where(x => x.IsAlive));
                    targets.AddRange(Field.Units.Where(x => x.OwnerInstance != _referenceUnit.OwnerInstance && x.IsAlive));
                    break;
                case eTargetUnitClassification.AllyDefeated:
                    targets.AddRange(_referenceUnit.OwnerInstance.AlliedUnits.Where(x => !x.IsAlive));
                    break;
                case eTargetUnitClassification.EnemyDefeated:
                    targets.AddRange(Field.Units.Where(x => x.OwnerInstance != _referenceUnit.OwnerInstance && !x.IsAlive));
                    break;
                case eTargetUnitClassification.AllyAndEnemyDefeated:
                    targets.AddRange(_referenceUnit.OwnerInstance.AlliedUnits.Where(x => !x.IsAlive));
                    targets.AddRange(Field.Units.Where(x => x.OwnerInstance != _referenceUnit.OwnerInstance && !x.IsAlive));
                    break;
                default: // InRange
                    {
                        if (_targetRange != null) // If the target range is null, then it is not possible to lookup any unit.
                        {
                            foreach (_2DCoord coord in _targetRange)
                            {
                                if (coord.X >= 0 && coord.X <= CoreValues.SIZE_OF_A_SIDE_OF_BOARD - 1
                                    && coord.Y >= 0 && coord.Y <= CoreValues.SIZE_OF_A_SIDE_OF_BOARD - 1) //it will search inside of the board
                                {
                                    if (Field.Board.Sockets[coord.X, coord.Y].Unit != null)
                                    {
                                        if (_targetClassification == eTargetUnitClassification.AllyInRange
                                            || _targetClassification == eTargetUnitClassification.SelfAndAllyInRange
                                            || _targetClassification == eTargetUnitClassification.AllyAndEnemyInRange
                                            || _targetClassification == eTargetUnitClassification.UnitInRange)
                                        {
                                            if (Field.Board.Sockets[coord.X, coord.Y].Unit.OwnerInstance == _referenceUnit.OwnerInstance)
                                                targets.Add(Field.Board.Sockets[coord.X, coord.Y].Unit);
                                        }

                                        if (_targetClassification == eTargetUnitClassification.EnemyInRange
                                            || _targetClassification == eTargetUnitClassification.SelfAndEnemyInRange
                                            || _targetClassification == eTargetUnitClassification.AllyAndEnemyInRange
                                            || _targetClassification == eTargetUnitClassification.UnitInRange)
                                        {
                                            if (Field.Board.Sockets[coord.X, coord.Y].Unit.OwnerInstance != _referenceUnit.OwnerInstance)
                                                targets.Add(Field.Board.Sockets[coord.X, coord.Y].Unit);
                                        }
                                    }
                                }
                            }
                        }
                    }
                    break;
            }

            return targets;
        }
        #endregion

        #region Private Methods
        /// <summary>
        /// PreCondition: _unit has been initialized successfully; _unit is assigned to a Socket of the Board; _destination is a valid coord within the Board;
        /// PostCondition: _unit will be assigned to Board.Socket[_destination.X, _destination.Y] if not already occupied; If moved successfully, true will be returned;
        /// </summary>
        private bool ChangeUnitLocation(UnitInstance _unit, _2DCoord _destination)
        {
            _2DCoord currentLocation = Field.UnitLocation(_unit);

            try
            {
                if (_destination.X < 0 || Field.Board.Sockets.GetLength(0) <= _destination.X
                    || _destination.Y < 0 || Field.Board.Sockets.GetLength(1) <= _destination.Y)
                    return false;

                if (Field.Board.Sockets[_destination.X, _destination.Y].Unit == null) // if there is no Unit assigned to the destination Socket
                {
                    Field.Board.Sockets[currentLocation.X, currentLocation.Y].Unit = null; // remove _unit from the current Socket
                    Field.Board.Sockets[_destination.X, _destination.Y].Unit = _unit; // assign _unit to the destination Socket

                    return true;
                }
                //else if destination Socket is occupied
                return false;
            }
            catch (Exception ex)
            {
                Debug.Log("Field: at ChangeUnitLocation() " + ex.Message);
                return false;
            }
        }

        /// <summary>
        /// PreCondition: _damage is positive value or 0; _target has been initialized successfully and _target.isAlive is true;
        /// PostCondition: _damage will be subtracted from _target.RemainingHP; If _damage > _target.RemainingHP, _target.RemainingHP will be set to 0;
        /// </summary>
        /// <param name="_damage"></param>
        /// <param name="_target"></param>
        private void DealDamage(int _damage, UnitInstance _target)
        {
            if (_target.RemainingHP - _damage > 0)
                _target.RemainingHP -= _damage;
            else
            {
                _target.RemainingHP = 0;
                UpdateUnitLiveStatus(_target);
                Field.RemoveNonAliveUnitFromBoard(_target);
            }
        }

        /// <summary>
        /// PreCondition: _hpValueToRestore is positive value or 0; _target has been initialized successfully and _target.isAlive is true;
        /// PostCondition: _hpValueToRestore will be added to _target.RemainingHP; If _hpValueToRestore + _target.RemainingHP > MaxHP, _target.RemainingHP will be set to MaxHP;
        /// </summary>
        /// <param name="_hpValueToRestore"></param>
        /// <param name="_target"></param>
        private void RestoreHP(int _hpValueToRestore, UnitInstance _target)
        {
            int maxHP = Calculator.MaxHP(_target);

            if (_target.RemainingHP + _hpValueToRestore < maxHP)
                _target.RemainingHP += _hpValueToRestore;
            else
                _target.RemainingHP = maxHP;
        }

        /// <summary>
        /// PreCondition: _effectToAttach and _target have been initialized successfully.
        /// PostCondition: A cloned instance of _effectToAttach will be added to _target.ContinuousEffects;
        /// </summary>
        /// <param name="_effectToAttach"></param>
        /// <param name="_target"></param>
        private void AttachEffect(StatusEffect _effectToAttach, UnitInstance _target)
        {
            _target.StatusEffects.Add((_effectToAttach as IDeepCopyable<StatusEffect>).DeepCopy()); // Add a cloned instance not to modify data in original instance
        }

        private List<UnitInstance> SortUnitsByAttributeValue(eUnitAttributeType _attributeType, eSortType _sortType, List<UnitInstance> _units)
        {
            List<UnitInstance> tmp_units;

            switch (_attributeType)
            {
                default: //Level
                    tmp_units = _units.OrderByDescending(x => Calculator.Level(x)).ToList();
                    break;
                case eUnitAttributeType.MaxHP:
                    tmp_units = _units.OrderByDescending(x => Calculator.MaxHP(x)).ToList();
                    break;
                case eUnitAttributeType.RemainingHP:
                    tmp_units = _units.OrderByDescending(x => x.RemainingHP).ToList();
                    break;
                case eUnitAttributeType.PhyStr:
                    tmp_units = _units.OrderByDescending(x => Calculator.PhysicalStrength(x)).ToList();
                    break;
                case eUnitAttributeType.PhyRes:
                    tmp_units = _units.OrderByDescending(x => Calculator.PhysicalResistance(x)).ToList();
                    break;
                case eUnitAttributeType.MagStr:
                    tmp_units = _units.OrderByDescending(x => Calculator.MagicalStrength(x)).ToList();
                    break;
                case eUnitAttributeType.MagRes:
                    tmp_units = _units.OrderByDescending(x => Calculator.MagicalResistance(x)).ToList();
                    break;
                case eUnitAttributeType.Vitality:
                    tmp_units = _units.OrderByDescending(x => Calculator.Vitality(x)).ToList();
                    break;
            }

            if (_sortType == eSortType.Ascending)
                tmp_units.Reverse();

            return tmp_units;
        }

        private List<int> SetAttributeValueRanking(List<UnitInstance> _sortedUnits, eUnitAttributeType _attributeType)
        {
            List<int> tmp_values = new List<int>();

            foreach (UnitInstance unit in _sortedUnits)
            {
                int tmp_value;

                switch (_attributeType)
                {
                    default: //Level
                        tmp_value = Calculator.Level(unit);
                        break;
                    case eUnitAttributeType.MaxHP:
                        tmp_value = Calculator.MaxHP(unit);
                        break;
                    case eUnitAttributeType.RemainingHP:
                        tmp_value = unit.RemainingHP;
                        break;
                    case eUnitAttributeType.PhyStr:
                        tmp_value = Calculator.PhysicalStrength(unit);
                        break;
                    case eUnitAttributeType.PhyRes:
                        tmp_value = Calculator.PhysicalResistance(unit);
                        break;
                    case eUnitAttributeType.MagStr:
                        tmp_value = Calculator.MagicalStrength(unit);
                        break;
                    case eUnitAttributeType.MagRes:
                        tmp_value = Calculator.MagicalResistance(unit);
                        break;
                    case eUnitAttributeType.Vitality:
                        tmp_value = Calculator.Vitality(unit);
                        break;
                }

                if (!tmp_values.Contains(tmp_value))
                    tmp_values.Add(tmp_value);
            }

            return tmp_values;
        }

        private void UpdateSP(PlayerOnBoard _player)
        {
            if (Field.Players[0] == _player)
                _player.MaxSP = (CurrentPlayerTurns[0] > CoreValues.MAX_SP) ? CoreValues.MAX_SP : CurrentPlayerTurns[0];
            else
                _player.MaxSP = (CurrentPlayerTurns[1] > CoreValues.MAX_SP) ? CoreValues.MAX_SP : CurrentPlayerTurns[1];

            _player.RemainingSP = _player.MaxSP;
        }

        private void UpdateActionSelectionStatus(PlayerOnBoard _player)
        {
            _player.Moved = false;
            _player.Attacked = false;
        }

        private void UnselectUnits(PlayerOnBoard _player)
        {
            _player.SelectedUnitIndex = -1;
        }

        private void UpdateUnitLiveStatus(UnitInstance _unit)
        {
            if (_unit.RemainingHP <= 0 && _unit.IsAlive)
            {
                _unit.IsAlive = false;

                PlayerOnBoard owner = _unit.OwnerInstance;
                if (owner.SelectedUnitIndex >= 0 
                    && owner.SelectedUnitIndex < owner.AlliedUnits.Count()
                    && _unit == owner.AlliedUnits[owner.SelectedUnitIndex])
                {
                    UnselectUnits(owner);
                }

                if (!owner.AlliedUnits.Any(x => x.IsAlive)) // If no unit of the specific player is alive
                    EndMatch(owner); // The player has lost
            }
            else if (_unit.RemainingHP > 0 && !_unit.IsAlive)
                _unit.IsAlive = true;
        }

        //private void UpdateUnitsLiveStatus()
        //{
        //    foreach (PlayerOnBoard p in Field.Players)
        //    {
        //        foreach (UnitInstance u in p.AlliedUnits)
        //        {
        //            if (u.RemainingHP <= 0 && u.IsAlive)
        //            {
        //                u.IsAlive = false;
        //                if (p.SelectedUnitIndex >= 0 && u == p.AlliedUnits[p.SelectedUnitIndex])
        //                    UnselectUnits(p);
        //            }
        //        }
        //    }

        //    Field.RemoveNonAliveUnitsFromBoard();
        //}
        #endregion
    }
}
