﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using EEANGames.TBSG._01.MainClassLib;
//using EEANGames.TBSG._01.MainClassLib.DBDataHandler.ForUnity;
using EEANGames.TBSG._01.CommonEnums;
using System.Collections.ObjectModel;
using EEANGames.ExtensionMethods;
using System.Linq;

namespace EEANGames.TBSG._01.MainClassLib
{
    public sealed class GameDataContainer
    {
        private static GameDataContainer m_instance;

        public static GameDataContainer Instance { get { return m_instance ?? (m_instance = new GameDataContainer()); } }

        private GameDataContainer()
        {
        }

        #region Properties
        public Player Player { get; private set; }
        public Player CPU { get; set; } //Used in single player mode

        //public ReadOnlyDictionary<bool, UnitData> UnitEncyclopedia { get { return m_unitEncyclopedia.AsReadOnly(); } }
        //public ReadOnlyDictionary<bool, WeaponData> WeaponEncyclopedia { get { return m_weaponEncyclopedia.AsReadOnly(); } }
        //public ReadOnlyDictionary<bool, ArmourData> ArmourEncyclopedia { get { return m_armourEncyclopedia.AsReadOnly(); } }
        //public ReadOnlyDictionary<bool, AccessoryData> AccessoryEncyclopedia { get { return m_accessoryEncyclopedia.AsReadOnly(); } }

        public IList<UnitData> UnitEncyclopedia { get { return m_unitEncyclopedia.AsReadOnly(); } }
        public IList<Item> ItemEncyclopedia { get { return m_itemEncyclopedia.AsReadOnly(); } }
        public IList<WeaponData> WeaponEncyclopedia { get { return m_weaponEncyclopedia.AsReadOnly(); } }
        public IList<ArmourData> ArmourEncyclopedia { get { return m_armourEncyclopedia.AsReadOnly(); } }
        public IList<AccessoryData> AccessoryEncyclopedia { get { return m_accessoryEncyclopedia.AsReadOnly(); } }

        public IList<SkillData> Skills { get { return m_skills.AsReadOnly(); } }
        public IList<Effect> Effects { get { return m_effects.AsReadOnly(); } }
        public IList<StatusEffectData> StatusEffects { get { return m_statusEffects.AsReadOnly(); } }

        public OrdinarySkill BasicAttackSkill { get; private set; }

        private bool m_isInitialized = false;
        #endregion

        #region Private Fields
        //private Dictionary<bool, UnitData> m_unitEncyclopedia;
        //private Dictionary<bool, WeaponData> m_weaponEncyclopedia;
        //private Dictionary<bool, ArmourData> m_armourEncyclopedia;
        //private Dictionary<bool, AccessoryData> m_accessoryEncyclopedia;

        private List<UnitData> m_unitEncyclopedia;
        private List<Item> m_itemEncyclopedia;
        private List<WeaponData> m_weaponEncyclopedia;
        private List<ArmourData> m_armourEncyclopedia;
        private List<AccessoryData> m_accessoryEncyclopedia;

        private List<SkillData> m_skills;
        private List<Effect> m_effects;
        private List<StatusEffectData> m_statusEffects;
        #endregion

        #region Public Functions
        public bool Initialize(Player _player, List<StatusEffectData> _statusEffects, List<Effect> _effects, List<SkillData> _skills, List<AccessoryData> _accessories, List<ArmourData> _armours, List<WeaponData> _weapons, List<Item> _items, List<UnitData> _units)
        {
            //DamageEffect baseAttackEffect = new DamageEffect(
            //    null, Tag.NewTag("<#1/>"), Tag.NewTag("<#1.0/>"), Tag.NewTag("<#1/>"), null, 0,
            //    eTargetUnitClassification.AllyInRange, eAttackClassification.Physic, Tag.NewTag("<#1/>"), false, eElement.None);
            //OrdinarySkillData baseAttackSkillData = new OrdinarySkillData(0, "Base Attack", null, null, 1, Tag.NewTag("<#1/>"), baseAttackEffect, 0, null);
            //OrdinarySkill baseAttackSkill = new OrdinarySkill(baseAttackSkillData, 1);

            //m_effects.Add(baseAttackEffect);
            //m_skills.Add(baseAttackSkill);

            if (_player == null
                || _statusEffects == null
                || _effects == null
                || _skills == null
                || _accessories == null
                || _armours == null
                || _weapons == null
                || _items == null
                || _units == null)
            {
                return false;
            }

            if (!m_isInitialized)
            {
                Player = _player;

                m_statusEffects = new List<StatusEffectData>(_statusEffects);
                m_effects = new List<Effect>(_effects);
                m_skills = new List<SkillData>(_skills);

                m_accessoryEncyclopedia = new List<AccessoryData>(_accessories);
                m_armourEncyclopedia = new List<ArmourData>(_armours);
                m_weaponEncyclopedia = new List<WeaponData>(_weapons);
                m_itemEncyclopedia = new List<Item>(_items);
                m_unitEncyclopedia = new List<UnitData>(_units);

                BasicAttackSkill = new OrdinarySkill(m_skills.First(x => x.Id == -1) as OrdinarySkillData, 0);

                CPU = _player;

                m_isInitialized = true;
            }

            return m_isInitialized;
        }
        #endregion
    }

}