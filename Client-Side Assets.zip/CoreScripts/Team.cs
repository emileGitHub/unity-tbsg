﻿using System;
using System.Collections;
using System.Collections.Generic;
using EEANGames.ExtensionMethods;

namespace EEANGames.TBSG._01.MainClassLib
{
    public class Team
    {
        /// <summary>
        /// Ctor
        /// PreCondition: _memberSets.Count smaller of equal to Rule.MAX_MEMBERS_PER_TEAM
        /// PostCondition: Will be initialized successfully.
        /// </summary>
        /// <param name="_memberSets"></param>
        public Team(List<MemberSet> _memberSets, ItemSet _itemSet)
        {
            //Assign sets of members and equipments
            if (_memberSets == null)
                MemberSets = new MemberSet[0];
            else
            {
                if (_memberSets.Count >= CoreValues.MAX_MEMBERS_PER_TEAM)
                    MemberSets = new MemberSet[CoreValues.MAX_MEMBERS_PER_TEAM];
                else
                    MemberSets = new MemberSet[_memberSets.Count];

                for (int i = 1; i <= MemberSets.Length; i++)
                {
                    MemberSets[i - 1] = _memberSets[i - 1];
                }
            }

            //Assign sets of items
            if (_itemSet == null)
                ItemSet = null;
            else
                ItemSet = new ItemSet { Id = _itemSet.Id, QuantityPerItem = _itemSet.QuantityPerItem.CoalesceNullAndReturnCopyOptionally(eCopyType.Shallow) };
        }

        #region Properties
        public MemberSet[] MemberSets { get; }
        public ItemSet ItemSet { get; }
        #endregion

    }

    public struct MemberSet
    {
        public int Id;
        public Unit Member;
        public Weapon MainWeapon;
        public Weapon SubWeapon;
        public Armour Armour;
        public Accessory Accessory;
    }

    public class ItemSet
    {
        public int Id;
        public Dictionary<Item, int> QuantityPerItem;
    }
}
