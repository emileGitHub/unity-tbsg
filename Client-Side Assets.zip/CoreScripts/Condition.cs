﻿using EEANGames.ExtensionMethods;
using EEANGames.TBSG._01.CommonEnums;
using EEANGames.TBSG._01.ExtensionMethods;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;

namespace EEANGames.TBSG._01.MainClassLib
{
    public sealed class ComplexCondition : IDeepCopyable<ComplexCondition>
    {
        public ComplexCondition(List<List<Condition>> _conditionSets)
        {
            m_conditionSets = _conditionSets.CoalesceNullAndReturnCopyOptionally(eCopyType.Deep);
        }

        #region Properties
        public IList<ReadOnlyCollection<Condition>> ConditionSets { get { return m_conditionSets.Select(x => x.AsReadOnly()).ToList().AsReadOnly(); } }
        //List<Condition> represents the AND relationship between each Condition, and the List<Condition> instances have an OR relation in between.
        //Example:
        //A && (B || C)  (Where A, B, C are instances of Condition class)
        //which means (A and B) or (A and C)
        //may be stored as
        //ConditionSets[0][0] == A
        //ConditionSets[0][1] == B
        //ConditionSets[1][0] == A
        //ConditionSets[1][1] == C

        public string HierarchyString { get { return HierarchizeString(); } } //Method Wrapper
        #endregion

        #region Private Fields
        private List<List<Condition>> m_conditionSets;
        #endregion

        #region Public Methods
        public bool IsTrue(BattleSystemCore _system, UnitInstance _effectHolder = null, StatusEffect _statusEffect = null, UnitInstance _actor = null, Skill _skill = null, Effect _effect = null, List<_2DCoord> _effectRange = null, List<object> _targets = null, object _target = null, object _target2ForComplexTargetSelectionEffect = null, bool _isTarget2CurrentTarget = false, int _targetPreviousHP = 0, int _targetPreviousLocationTileIndex = 0, int _target2PreviousHP = 0, List<StatusEffect> _statusEffects = null, UnitInstance _effectHolderOfActivatedEffect = null, StatusEffect _statusEffectActivated = null, eTileType _previousTileType = default(eTileType))
        {
            if (ConditionSets.Count > 0)
            {
                for (int i = 0; i < ConditionSets.Count; i++)
                {
                    if (InnerIsTrue(i, _system, _effectHolder, _statusEffect, _actor, _skill, _effect, _effectRange, _targets, _target, _target2ForComplexTargetSelectionEffect, _isTarget2CurrentTarget, _targetPreviousHP, _targetPreviousLocationTileIndex, _target2PreviousHP, _statusEffects, _effectHolderOfActivatedEffect, _statusEffectActivated, _previousTileType))
                        return true;
                }

                return false;
            }
            else
                return true;

        }

        public ComplexCondition DeepCopy()
        {
            ComplexCondition copy = (ComplexCondition)this.MemberwiseClone();

            copy.m_conditionSets = m_conditionSets.DeepCopy();

            return copy;
        }
        #endregion

        #region Private Methods
        private bool InnerIsTrue(int _innerListIndex, BattleSystemCore _system, UnitInstance _effectHolder, StatusEffect _statusEffect, UnitInstance _actor, Skill _skill, Effect _effect, List<_2DCoord> _effectRange, List<object> _targets, object _target, object _target2ForComplexTargetSelectionEffect, bool _isTarget2CurrentTarget, int _targetPreviousHP, int _targetPreviousLocationTileIndex, int _target2PreviousHP, List<StatusEffect> _statusEffects, UnitInstance _effectHolderOfActivatedEffect, StatusEffect _statusEffectActivated, eTileType _previousTileType)
        {
            foreach (Condition condition in ConditionSets[_innerListIndex])
            {
                if (!condition.IsTrue(_system, _effectHolder, _statusEffect, _actor, _skill, _effect, _effectRange, _targets, _target, _target2ForComplexTargetSelectionEffect, _isTarget2CurrentTarget, _targetPreviousHP, _targetPreviousLocationTileIndex, _target2PreviousHP, _statusEffects, _effectHolderOfActivatedEffect, _statusEffectActivated, _previousTileType))
                    return false;
            }

            return true;
        }

        private string HierarchizeString()
        {
            string result = string.Empty;

            for (int i = 0; i < m_conditionSets.Count; i++)
            {
                if (i > 1)
                    result += "OR ";

                result += "[Condition " + (i + 1).ToString() + "]\n";

                foreach (Condition compositeCondition in m_conditionSets[i])
                {
                    result += compositeCondition.A.HierarchyString + "\n";
                    result += compositeCondition.RelationType.ToString();
                    result += compositeCondition.B.HierarchyString + "\n";

                    if (!compositeCondition.Equals(m_conditionSets[i].Last()))
                        result += "*AND*";
                }
            }

            return result;
        }
        #endregion
    }

    public sealed class Condition : IDeepCopyable<Condition>
    {
        public Condition(Tag _a, eRelationType _relationType, Tag _b)
        {
            A = _a.CoalesceNullAndReturnDeepCopyOptionally(true);

            RelationType = _relationType;

            B = _b.CoalesceNullAndReturnDeepCopyOptionally(true);
        }

        #region Properties
        public Tag A { get; private set; }
        public eRelationType RelationType { get; }
        public Tag B { get; private set; }
        #endregion

        #region Public Methods
        public bool IsTrue(BattleSystemCore _system, UnitInstance _effectHolder = null, StatusEffect _statusEffect = null, UnitInstance _actor = null, Skill _skill = null, Effect _effect = null, List<_2DCoord> _effectRange = null, List<object> _targets = null, object _target = null, object _target2ForComplexTargetSelectionEffect = null, bool _isTarget2CurrentTarget = false, int _targetPreviousHP = 0, int _targetPreviousLocationTileIndex = 0, int _target2PreviousHP = 0, List<StatusEffect> _statusEffects = null, UnitInstance _effectHolderOfActivatedEffect = null, StatusEffect _statusEffectActivated = null, eTileType _previousTileType = default(eTileType))
        {
            try
            {
                var valueA = A.ToValue<object>(_system, _effectHolder, _statusEffect, _actor, _skill, _effect, _effectRange, _targets, _target, _target2ForComplexTargetSelectionEffect, _isTarget2CurrentTarget, _targetPreviousHP, _targetPreviousLocationTileIndex, _target2PreviousHP, _statusEffects, _effectHolderOfActivatedEffect, _statusEffectActivated, _previousTileType);
                var valueB = B.ToValue<object>(_system, _effectHolder, _statusEffect, _actor, _skill, _effect, _effectRange, _targets, _target, _target2ForComplexTargetSelectionEffect, _isTarget2CurrentTarget, _targetPreviousHP, _targetPreviousLocationTileIndex, _target2PreviousHP, _statusEffects, _effectHolderOfActivatedEffect, _statusEffectActivated, _previousTileType);

                return Core.Compare(valueA, RelationType, valueB);
            }
            catch (Exception ex)
            {
                return false;
            }
        }

        public Condition DeepCopy()
        {
            Condition copy = (Condition)this.MemberwiseClone();

            copy.A = A.DeepCopy();
            copy.B = B.DeepCopy();

            return copy;
        }
        #endregion
    }
}
