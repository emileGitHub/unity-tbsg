﻿using EEANGames.ExtensionMethods;
using EEANGames.TBSG._01.CommonEnums;
using EEANGames.TBSG._01.ExtensionMethods;
using System.Collections.Generic;

namespace EEANGames.TBSG._01.MainClassLib
{
    public interface IComplexTargetSelectionEffect
    {
        bool FromTargetToTarget2 { get; }
    }

    public abstract class Effect : IDeepCopyable<Effect>
    {
        public Effect(int _id, ComplexCondition _activationCondition, Tag _timesToApply, Tag _successRate, Tag _diffusionDistance, List<Effect> _secondaryEffects, int _animationId)
        {
            Id = _id;

            ActivationCondition = _activationCondition.CoalesceNullAndReturnDeepCopyOptionally(true);

            TimesToApply = _timesToApply.CoalesceNullAndReturnDeepCopyOptionally(true);

            SuccessRate = _successRate.CoalesceNullAndReturnDeepCopyOptionally(true);

            DiffusionDistance = _diffusionDistance.CoalesceNullAndReturnDeepCopyOptionally(true);

            m_secondaryEffects = _secondaryEffects.CoalesceNullAndReturnCopyOptionally(eCopyType.Shallow);

            AnimationId = _animationId;

            m_isSecondaryEffectListModifiable = true;
        }

        #region Properties
        public int Id { get; }

        public ComplexCondition ActivationCondition { get; private set; }

        public Tag TimesToApply { get; private set; } //Tag value must be positive integer
        public Tag SuccessRate { get; private set; } //Tag value must be between 0 and 1

        public Tag DiffusionDistance { get; private set; } //Tag value must be 0 or a positive integer

        public IList<Effect> SecondaryEffects
        {
            get
            {
                if (m_isSecondaryEffectListModifiable)
                    return m_secondaryEffects;
                else
                    return m_secondaryEffects.AsReadOnly();
            }
        }

        public int AnimationId { get; }
        #endregion

        #region Private Fields
        private List<Effect> m_secondaryEffects;

        private bool m_isSecondaryEffectListModifiable;
        #endregion

        #region Public Methods
        public void DisableModification() { m_isSecondaryEffectListModifiable = false; }

        Effect IDeepCopyable<Effect>.DeepCopy() { return (Effect)DeepCopyInternally(); }
        #endregion

        #region Protected Methods
        protected virtual object DeepCopyInternally()
        {
            Effect copy = (Effect)this.MemberwiseClone();

            copy.ActivationCondition = ActivationCondition.DeepCopy();

            copy.TimesToApply = TimesToApply.DeepCopy();
            copy.SuccessRate = SuccessRate.DeepCopy();

            copy.DiffusionDistance = SuccessRate.DeepCopy();

            copy.m_secondaryEffects = m_secondaryEffects.DeepCopy();

            return copy;
        }
        #endregion
    }

    public abstract class UnitTargetingEffect : Effect, IDeepCopyable<UnitTargetingEffect>
    {
        public UnitTargetingEffect(int _id, ComplexCondition _activationCondition, Tag _timesToApply, Tag _successRate, Tag _diffusionDistance, List<Effect> _secondaryEffects, int _animationId,
            eTargetUnitClassification _targetClassification) : base(_id, _activationCondition, _timesToApply, _successRate, _diffusionDistance, _secondaryEffects, _animationId)
        {
            TargetClassification = _targetClassification;
        }

        #region Properties
        public eTargetUnitClassification TargetClassification { get; }
        #endregion

        #region Public Methods
        UnitTargetingEffect IDeepCopyable<UnitTargetingEffect>.DeepCopy() { return (UnitTargetingEffect)DeepCopyInternally(); }
        #endregion

        #region Protected Methods
        protected override object DeepCopyInternally() { return (UnitTargetingEffect)base.DeepCopyInternally(); }
        #endregion
    }

    public class DamageEffect : UnitTargetingEffect, IDeepCopyable<DamageEffect>
    {
        public DamageEffect(int _id, ComplexCondition _activationCondition, Tag _timesToApply, Tag _successRate, Tag _diffusionDistance, List<Effect> _secondaryEffects, int _animationId, eTargetUnitClassification _targetClassification,
            eAttackClassification _attackClassification, Tag _value, bool _isFixedValue, eElement _element) : base(_id, _activationCondition, _timesToApply, _successRate, _diffusionDistance, _secondaryEffects, _animationId, _targetClassification)
        {
            AttackClassification = _attackClassification;

            Value = _value.CoalesceNullAndReturnDeepCopyOptionally(true);

            IsFixedValue = _isFixedValue;
            Element = _element;
        }

        #region Properties
        public eAttackClassification AttackClassification { get; }
        public Tag Value { get; private set; }
        public bool IsFixedValue { get; }
        public eElement Element { get; }
        #endregion

        #region Public Methods
        DamageEffect IDeepCopyable<DamageEffect>.DeepCopy() { return (DamageEffect)DeepCopyInternally(); }
        #endregion

        #region Protected Methods
        protected override object DeepCopyInternally()
        {
            DamageEffect copy = (DamageEffect)base.DeepCopyInternally();

            copy.Value = Value.DeepCopy();

            return copy;
        }
        #endregion
    }

    //public class Move : Effect
    //{
    //    public int NumberOfTiles { get; set; }
    //}

    //public class Summon : Effect
    //{
    //    //    public string ServantName { get; set; }
    //    //    public int AmountToSummon { get; set; }
    //}

    //public class Transform : Effect
    //{
    //    //    public string CharacterName { get; set; }
    //    //    public int Duration { get; set; }
    //}

    public class HealEffect : UnitTargetingEffect, IDeepCopyable<HealEffect>
    {
        /// <summary>
        /// Ctor
        /// PreCondition: _targetArea.Count > 0; _timesToApply > 0; _successProbability > 0; _secondaryEffects.Count > 0; _animationId > 0; _power > 0;
        /// PostCondition: Will be initialized successfully.
        /// </summary>
        /// <param name="_targetArea"></param>
        /// <param name="_timesToApply"></param>
        /// <param name="_successRate"></param>
        /// <param name="_secondaryEffects"></param>
        /// <param name="_animationId"></param>
        /// <param name="_targetClassification"></param>
        /// <param name="_power"></param>
        /// <param name="_doesPreservePower"></param>
        public HealEffect(int _id, ComplexCondition _activationCondition, Tag _timesToApply, Tag _successRate, Tag _diffusionDistance, List<Effect> _secondaryEffects, int _animationId, eTargetUnitClassification _targetClassification,
            Tag _value, bool _isFixedValue) : base(_id, _activationCondition, _timesToApply, _successRate, _diffusionDistance, _secondaryEffects, _animationId, _targetClassification)
        {
            Value = _value.CoalesceNullAndReturnDeepCopyOptionally(true);

            IsFixedValue = _isFixedValue;
        }

        #region Properties
        public Tag Value { get; private set; }
        public bool IsFixedValue { get; }
        #endregion

        #region Public Methods
        HealEffect IDeepCopyable<HealEffect>.DeepCopy() { return (HealEffect)DeepCopyInternally(); }
        #endregion

        #region Protected Methods
        protected override object DeepCopyInternally()
        {
            HealEffect copy = (HealEffect)base.DeepCopyInternally();

            copy.Value = Value.DeepCopy();

            return copy;
        }
        #endregion
    }

    public class StatusEffectAttachmentEffect : UnitTargetingEffect, IDeepCopyable<StatusEffectAttachmentEffect>
    {
        /// <summary>
        /// Ctor
        /// PreCondition: _targetArea.Count > 0; _timesToApply > 0; _successProbability > 0; _secondaryEffects.Count > 0; _animationId > 0; _effectToAttach has been initialized successfully;
        /// PostCondition: Will be initialized successfully.
        /// </summary>
        /// <param name="_targetArea"></param>
        /// <param name="_timesToApply"></param>
        /// <param name="_successRate"></param>
        /// <param name="_secondaryEffects"></param>
        /// <param name="_animationId"></param>
        /// <param name="_targetClassification"></param>
        /// <param name="_dataOfStatusEffectToAttach"></param>
        public StatusEffectAttachmentEffect(int _id, ComplexCondition _activationCondition, Tag _timesToApply, Tag _successRate, Tag _diffusionDistance, List<Effect> _secondaryEffects, int _animationId, eTargetUnitClassification _targetClassification,
            StatusEffectData _dataOfStatusEffectToAttach) : base(_id, _activationCondition, _timesToApply, _successRate, _diffusionDistance, _secondaryEffects, _animationId, _targetClassification)
        {
            DataOfStatusEffectToAttach = _dataOfStatusEffectToAttach.CoalesceNullAndReturnDeepCopyOptionally();
        }

        #region Properties
        public StatusEffectData DataOfStatusEffectToAttach { get; private set; }
        #endregion

        #region Public Methods
        StatusEffectAttachmentEffect IDeepCopyable<StatusEffectAttachmentEffect>.DeepCopy() { return (StatusEffectAttachmentEffect)DeepCopyInternally(); }
        #endregion

        #region Protected Methods
        protected override object DeepCopyInternally()
        {
            StatusEffectAttachmentEffect copy = (StatusEffectAttachmentEffect)base.DeepCopyInternally();

            copy.DataOfStatusEffectToAttach = (DataOfStatusEffectToAttach as IDeepCopyable<StatusEffectData>).DeepCopy();

            return copy;
        }
        #endregion
    }

    public class UnitSwapEffect : UnitTargetingEffect, IDeepCopyable<UnitSwapEffect>
    {
        public UnitSwapEffect(int _id, ComplexCondition _activationCondition, Tag _successRate, List<Effect> _secondaryEffects, int _animationId, eTargetUnitClassification _targetClassification) : base(_id, _activationCondition, Tag.NewTag("<#1/>"), _successRate, null, _secondaryEffects, _animationId, _targetClassification)
        {
        }

        #region Properties
        #endregion

        #region Public Methods
        UnitSwapEffect IDeepCopyable<UnitSwapEffect>.DeepCopy() { return (UnitSwapEffect)DeepCopyInternally(); }
        #endregion

        #region Protected Methods
        protected override object DeepCopyInternally()
        {
            UnitSwapEffect copy = (UnitSwapEffect)base.DeepCopyInternally();

            return copy;
        }
        #endregion
    }

    public class DrainEffect : UnitTargetingEffect, IDeepCopyable<DrainEffect>, IComplexTargetSelectionEffect
    {
        public DrainEffect(int _id, ComplexCondition _activationCondition, Tag _timesToApply, Tag _successRate, Tag _diffusionDistance, List<Effect> _secondaryEffects, int _animationId, eTargetUnitClassification _targetClassification,
            eAttackClassification _attackClassification, Tag _value, bool _isFixedValue, eElement _element) : base(_id, _activationCondition, _timesToApply, _successRate, _diffusionDistance, _secondaryEffects, _animationId, _targetClassification)
        {
            AttackClassification = _attackClassification;

            Value = _value.CoalesceNullAndReturnDeepCopyOptionally(true);

            IsFixedValue = _isFixedValue;
            Element = _element;
        }

        #region Properties
        public eAttackClassification AttackClassification { get; }
        public Tag Value { get; private set; }
        public bool IsFixedValue { get; }
        public eElement Element { get; }

        public Tag DrainingEfficiency { get; private set; }

        public bool FromTargetToTarget2 { get; } // If true, target will be damaged and target2 will be healed; and vice versa.
        #endregion

        #region Public Methods
        DrainEffect IDeepCopyable<DrainEffect>.DeepCopy() { return (DrainEffect)DeepCopyInternally(); }
        #endregion

        #region Protected Methods
        protected override object DeepCopyInternally()
        {
            DrainEffect copy = (DrainEffect)base.DeepCopyInternally();

            copy.Value = Value.DeepCopy();

            copy.DrainingEfficiency = DrainingEfficiency.DeepCopy();

            return copy;
        }
        #endregion
    }

    public abstract class TileTargetingEffect : Effect, IDeepCopyable<TileTargetingEffect>
    {
        public TileTargetingEffect(int _id, ComplexCondition _activationCondition, Tag _timesToApply, Tag _successRate, Tag _diffusionDistance, List<Effect> _secondaryEffects, int _animationId) : base(_id, _activationCondition, _timesToApply, _successRate, _diffusionDistance, _secondaryEffects, _animationId)
        {
        }

        #region Properties
        #endregion

        #region Public Methods
        TileTargetingEffect IDeepCopyable<TileTargetingEffect>.DeepCopy() { return (TileTargetingEffect)DeepCopyInternally(); }
        #endregion

        #region Protected Methods
        protected override object DeepCopyInternally() { return (TileTargetingEffect)base.DeepCopyInternally(); }
        #endregion
    }

    public class TileTrapEffect : TileTargetingEffect, IDeepCopyable<TileTrapEffect>
    {
        public TileTrapEffect(int _id, ComplexCondition _activationCondition, Tag _timesToApply, Tag _successRate, Tag _diffusionDistance, List<Effect> _secondaryEffects, int _animationId,
            List<Effect> _effectsToAttach) : base(_id, _activationCondition, _timesToApply, _successRate, _diffusionDistance, _secondaryEffects, _animationId)
        {
            m_effectsToAttach = _effectsToAttach.CoalesceNullAndReturnCopyOptionally(eCopyType.Shallow);
        }

        #region Properties
        public IList<Effect> EffectsToAttach { get { return m_effectsToAttach.AsReadOnly(); } }
        #endregion

        #region Private Fields
        private List<Effect> m_effectsToAttach;
        #endregion

        #region Public Methods
        TileTrapEffect IDeepCopyable<TileTrapEffect>.DeepCopy() { return (TileTrapEffect)DeepCopyInternally(); }
        #endregion

        #region Protected Methods
        protected override object DeepCopyInternally()
        {
            TileTrapEffect copy = (TileTrapEffect)base.DeepCopyInternally();

            copy.m_effectsToAttach = m_effectsToAttach.DeepCopy();

            return copy;
        }
        #endregion
    }

    public class TileSwapEffect : TileTargetingEffect, IDeepCopyable<TileSwapEffect>
    {
        public TileSwapEffect(int _id, ComplexCondition _activationCondition, Tag _timesToApply, Tag _successRate, Tag _diffusionDistance, List<Effect> _secondaryEffects, int _animationId) : base(_id, _activationCondition, _timesToApply, _successRate, _diffusionDistance, _secondaryEffects, _animationId)
        {
        }

        #region Properties
        #endregion

        #region Private Fields
        #endregion

        #region Public Methods
        TileSwapEffect IDeepCopyable<TileSwapEffect>.DeepCopy() { return (TileSwapEffect)DeepCopyInternally(); }
        #endregion

        #region Protected Methods
        protected override object DeepCopyInternally()
        {
            TileSwapEffect copy = (TileSwapEffect)base.DeepCopyInternally();

            return copy;
        }
        #endregion
    }

    public abstract class TargetlessEffect : Effect, IDeepCopyable<TargetlessEffect>
    {
        public TargetlessEffect(int _id, ComplexCondition _activationCondition, Tag _timesToApply, Tag _successRate, Tag _diffusionDistance, List<Effect> _secondaryEffects, int _animationId) : base(_id, _activationCondition, _timesToApply, _successRate, _diffusionDistance, _secondaryEffects, _animationId)
        {
        }

        #region Public Methods
        TargetlessEffect IDeepCopyable<TargetlessEffect>.DeepCopy() { return (TargetlessEffect)DeepCopyInternally(); }
        #endregion

        #region Protected Methods
        protected override object DeepCopyInternally()
        {
            TargetlessEffect copy = (TargetlessEffect)base.DeepCopyInternally();

            return copy;
        }
        #endregion
    }

    public class ItemCreationEffect : TargetlessEffect, IDeepCopyable<ItemCreationEffect>
    {
        public ItemCreationEffect(int _id, ComplexCondition _activationCondition, Tag _timesToApply, Tag _successRate, Tag _diffusionDistance, List<Effect> _secondaryEffects, int _animationId) : base(_id, _activationCondition, _timesToApply, _successRate, _diffusionDistance, _secondaryEffects, _animationId)
        {
        }

        #region Public Methods
        ItemCreationEffect IDeepCopyable<ItemCreationEffect>.DeepCopy() { return (ItemCreationEffect)DeepCopyInternally(); }
        #endregion

        #region Protected Methods
        protected override object DeepCopyInternally()
        {
            ItemCreationEffect copy = (ItemCreationEffect)base.DeepCopyInternally();

            return copy;
        }
        #endregion

        //    public eItemType ProductType { get; set; }
        //    public string ProductName { get; set; }
        //    public int AmountToCreate { get; set; }
    }

    //public class Cure : Effect
    //{
    //    public eAilmentType TargetAilment { get; set; }
    //    public int Value { get; set; }
    //}
}
