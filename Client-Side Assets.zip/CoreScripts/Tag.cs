﻿using EEANGames.TBSG._01.CommonEnums;
using EEANGames.ExtensionMethods;
using EEANGames.TBSG._01.ExtensionMethods;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using UnityEngine;

namespace EEANGames.TBSG._01.MainClassLib
{
    public sealed class Tag : IDeepCopyable<Tag>
    {
        private Tag(string _string, Tag _parent = null)
        {
            String = _string.CoalesceNullAndReturnCopyOptionally(true);

            m_childrenTags = new List<Tag>();

            ParentTag = _parent;
        }

        #region Properties
        public Tag ParentTag { get; }

        public string String { get; }

        public IList<Tag> ChildrenTags { get { return m_childrenTags.AsReadOnly(); } }

        public string HierarchyString { get { return HierarchizeString(); } } //Method Wrapper

        #endregion

        #region Private Fields
        private List<Tag> m_childrenTags;
        #endregion

        #region Public Methods
        public static Tag NewTag(string _tagString)
        {
            if (_tagString == null)
                return new Tag(null);

            List<string> tagStrings = DivideIntoTagStrings(_tagString);

            if (tagStrings.Count < 1)
                return new Tag(null);

            Tag t = new Tag(tagStrings[0]); //First tag will always be the root tag

            Tag currentTag = t;

            for (int i = 2; i <= tagStrings.Count; i++)
            {
                if (!tagStrings[i - 1].StartsWith("</"))
                {
                    if (tagStrings[i - 1].EndsWith("/>"))
                        currentTag.m_childrenTags.Add(new Tag(tagStrings[i - 1].Substring(0, tagStrings[i - 1].Length - 2) + ">", currentTag)); //Remove the "/"
                    else
                        currentTag.m_childrenTags.Add(new Tag(tagStrings[i - 1], currentTag));

                    if (!tagStrings[i - 1].EndsWith("/>"))
                        currentTag = currentTag.m_childrenTags.Last();
                }
                else
                    currentTag = currentTag.ParentTag;
            }

            return t;
        }

        public T ToValue<T>(BattleSystemCore _system, UnitInstance _effectHolder = null, StatusEffect _statusEffect = null, UnitInstance _actor = null, Skill _skill = null, Effect _effect = null, List<_2DCoord> _effectRange = null, List<object> _targets = null, object _target = null, object _target2ForComplexTargetSelectionEffect = null, bool _isTarget2CurrentTarget = false, int _targetPreviousHP = 0, int _targetPreviousLocationTileIndex = 0, int _target2PreviousHP = 0, List<StatusEffect> _statusEffects = null, UnitInstance _effectHolderOfActivatedEffect = null, StatusEffect _statusEffectActivated = null, eTileType _previousTileType = default(eTileType))
        {
            try
            {
                object result;

                if (m_childrenTags.Count != 0)
                    result = TranslateFunctionTagToValue(_system);
                else
                    result = TranslateSimpleValueTagToValue(_effectHolder, _statusEffect, _actor, _skill, _effect, _effectRange, _targets, _target, _target2ForComplexTargetSelectionEffect, _isTarget2CurrentTarget, _targetPreviousHP, _targetPreviousLocationTileIndex, _target2PreviousHP, _statusEffects, _effectHolderOfActivatedEffect, _statusEffectActivated, _previousTileType);

                if (result == null)
                    return default;

                if (result is T)
                    return (T)result;
                else if (result.GetType().IsClass)
                    return (T)(result as object);
                else
                    return (T)Convert.ChangeType(result, typeof(T), CultureInfo.InvariantCulture);
            }
            catch (Exception ex)
            {
                Debug.Log("At Tag.ToValue<T>(): " + ex.Message);
                return default;
            }
        }

        /// <summary>
        /// The returned Tag will be treated as the root Tag. Will not have any parent Tag.
        /// </summary>
        public Tag DeepCopy()
        {
            return DeepCopyInternally();
        }
        #endregion

        #region Private Methods
        private static List<string> DivideIntoTagStrings(string _tagString)
        {
            if (_tagString == null)
                return new List<string>();

            string tagStringCopy = string.Copy(_tagString); //copy value to not accidentally modify the original string

            List<string> tagStrings = new List<string>();

            while (tagStringCopy != "")
            {
                int countCharsInTag = 1; //the first character '<'

                for (int i = 2; i <= tagStringCopy.Length; i++)
                {
                    //ignore the first character in commandCopy which should be '<'
                    if (tagStringCopy[i - 1] != '<')
                        countCharsInTag++;
                    else
                        break;
                }

                tagStrings.Add(tagStringCopy.Substring(0, countCharsInTag));
                tagStringCopy = tagStringCopy.Substring(countCharsInTag);
            }

            return tagStrings;
        }

        private object TranslateFunctionTagToValue(BattleSystemCore _system)
        {
            List<object> tagValues = new List<object>();

            foreach (Tag tag in m_childrenTags)
            {
                tagValues.Add(tag.ToValue<object>(_system));
            }

            object result;

            try
            {
                switch (String)
                {
                    #region return object
                    case "<$GetFirstOrDefault>":
                        {
                            if (tagValues[0] is IEnumerable)
                                result = ((IEnumerable)tagValues[0]).Cast<object>().FirstOrDefault();
                            else
                                result = null;
                        }
                        break;
                    case "<$MergeListsWithoutDuplicates>":
                        {
                            List<object> list = new List<object>();
                            foreach (object tagValue in tagValues)
                            {
                                if (!(tagValue is IEnumerable))
                                {
                                    list.Clear();
                                    break;
                                }

                                list.AddRange(((IEnumerable)tagValues[0]).Cast<object>());
                            }

                            result = list.Distinct().ToList();
                        }
                        break;
                    #endregion

                    #region return decimal
                    case "<$Sum>":
                        {
                            result = tagValues[0];
                            for (int i = 1; i < tagValues.Count; i++)
                            {
                                result = Core.Sum(result, tagValues[i]);
                            }
                            result = Convert.ToDecimal(result);
                        }
                        break;
                    case "<$Subtract>":
                        {
                            result = tagValues[0];
                            for (int i = 1; i < tagValues.Count; i++)
                            {
                                result = Core.Subtract(result, tagValues[i]);
                            }
                            result = Convert.ToDecimal(result);
                        }
                        break;
                    case "<$Multiply>":
                        {
                            result = tagValues[0];
                            for (int i = 1; i < tagValues.Count; i++)
                            {
                                result = Core.Multiply(result, tagValues[i]);
                            }
                            result = Convert.ToDecimal(result);
                        }
                        break;
                    case "<$Divide>":
                        {
                            result = tagValues[0];
                            for (int i = 1; i < tagValues.Count; i++)
                            {
                                result = Core.Divide(result, tagValues[i]);
                            }
                            result = Convert.ToDecimal(result);
                        }
                        break;
                    #endregion

                    #region return int
                    case "<$Count>":
                        result = (tagValues[0] as List<object>).Count;
                        break;
                    case "<$GetLevel>":
                        result = Calculator.Level(tagValues[0] as Unit);
                        break;
                    case "<$GetMaxHP>":
                        result = Calculator.MaxHP(tagValues[0] as Unit);
                        break;
                    case "<$GetPhyStr>":
                        result = Calculator.PhysicalStrength(tagValues[0] as Unit);
                        break;
                    case "<$GetPhyRes>":
                        result = Calculator.PhysicalResistance(tagValues[0] as Unit);
                        break;
                    case "<$GetMagStr>":
                        result = Calculator.MagicalStrength(tagValues[0] as Unit);
                        break;
                    case "<$GetMagRes>":
                        result = Calculator.MagicalResistance(tagValues[0] as Unit);
                        break;
                    case "<$GetVit>":
                        result = Calculator.Vitality(tagValues[0] as Unit);
                        break;
                    #endregion

                    #region return List<UnitInstance>
                    case "<$FindUnitsByName>":
                        {
                            if (tagValues.Count < 3)
                                result = null;
                            else if (tagValues.Count == 3)
                                result = _system.FindUnitsByName(tagValues[0] as string, (bool)tagValues[1], (eStringMatchType)tagValues[2]);
                            else
                                result = _system.FindUnitsByName(tagValues[0] as string, (bool)tagValues[1], (eStringMatchType)tagValues[2], tagValues[3] as List<UnitInstance>);
                        }
                        break;
                    case "<$FindUnitsByLabel>":
                        {
                            if (tagValues.Count < 2)
                                result = null;
                            else if (tagValues.Count == 2)
                                result = _system.FindUnitsByLabel(tagValues[0] as string, (bool)tagValues[1]);
                            else
                                result = _system.FindUnitsByLabel(tagValues[0] as string, (bool)tagValues[1], tagValues[2] as List<UnitInstance>);
                        }
                        break;
                    case "<$FindUnitsByGender>":
                        {
                            if (tagValues.Count < 3)
                                result = null;
                            else if (tagValues.Count == 3)
                                result = _system.FindUnitsByGender((eGender)tagValues[0], (bool)tagValues[1]);
                            else
                                result = _system.FindUnitsByGender((eGender)tagValues[0], (bool)tagValues[1], tagValues[2] as List<UnitInstance>);
                        }
                        break;
                    case "<$FindUnitsByElement>":
                        {
                            if (tagValues.Count < 2)
                                result = null;
                            else if (tagValues.Count == 2)
                                result = _system.FindUnitsByElement((eElement)tagValues[0], (bool)tagValues[1]);
                            else if (tagValues.Count == 3)
                                result = _system.FindUnitsByElement((eElement)tagValues[0], (bool)tagValues[1], (eElement)tagValues[2]);
                            else
                                result = _system.FindUnitsByElement((eElement)tagValues[0], (bool)tagValues[1], (eElement)tagValues[2], tagValues[3] as List<UnitInstance>);
                        }
                        break;
                    case "<$FindUnitsByAttributeValue>":
                        {
                            if (tagValues.Count < 3)
                                result = null;
                            else if (tagValues.Count == 3)
                                result = _system.FindUnitsByAttributeValue((eUnitAttributeType)tagValues[0], (eRelationType)tagValues[1], (int)tagValues[2]);
                            else
                                result = _system.FindUnitsByAttributeValue((eUnitAttributeType)tagValues[0], (eRelationType)tagValues[1], (int)tagValues[2], tagValues[3] as List<UnitInstance>);
                        }
                        break;
                    case "<$FindUnitsByAttributeValueRanking>":
                        {
                            if (tagValues.Count < 3)
                                result = null;
                            else if (tagValues.Count == 3)
                                result = _system.FindUnitsByAttributeValueRanking((eUnitAttributeType)tagValues[0], (eSortType)tagValues[1], (int)tagValues[2]);
                            else
                                result = _system.FindUnitsByAttributeValueRanking((eUnitAttributeType)tagValues[0], (eSortType)tagValues[1], (int)tagValues[2], tagValues[3] as List<UnitInstance>);
                        }
                        break;
                    case "<$FindUnitsByTargetClassification>":
                        {
                            if (tagValues.Count < 2)
                                result = null;
                            else if (tagValues.Count == 2)
                                result = _system.FindUnitsByTargetClassification(tagValues[0] as UnitInstance, (eTargetUnitClassification)tagValues[1]);
                            else
                                result = _system.FindUnitsByTargetClassification(tagValues[0] as UnitInstance, (eTargetUnitClassification)tagValues[1], tagValues[2] as List<_2DCoord>);
                        }
                        break;
                    #endregion

                    default:
                        result = null;
                        break;
                }
            }
            catch (Exception ex)
            {
                return null;
            }

            return result;
        }

        private object TranslateSimpleValueTagToValue(UnitInstance _effectHolder, StatusEffect _statusEffect, UnitInstance _actor, Skill _skill, Effect _effect, List<_2DCoord> _effectRange, List<object> _targets, object _target, object _target2ForComplexTargetSelectionEffect, bool _isTarget2CurrentTarget, int _targetPreviousHP, int _targetPreviousLocationTileIndex, int _target2PreviousHP, List<StatusEffect> _statusEffects, UnitInstance _effectHolderOfActivatedEffect, StatusEffect _statusEffectActivated, eTileType _previousTileType)
        {
            try
            {
                if (String.StartsWith("<#")) //Number
                {
                    string tagStringCopy = string.Copy(String);

                    tagStringCopy = tagStringCopy.Substring(2, tagStringCopy.Length - 4); //Remove "<#" and "/>"

                    return Convert.ToDecimal(tagStringCopy);
                }
                else if (String.StartsWith("<S=")) //String
                {
                    string tagStringCopy = string.Copy(String);

                    tagStringCopy = tagStringCopy.Substring(3, tagStringCopy.Length - 5); //Remove "<S=" and "/>"

                    return tagStringCopy;
                }
                else if (String.StartsWith("<E=")) //Enum
                {
                    string tagStringCopy = string.Copy(String);

                    tagStringCopy = tagStringCopy.Substring(3, tagStringCopy.Length - 5); //Remove "<E=" and "/>"

                    string[] enumTypeAndValueString = tagStringCopy.Split('.'); // Will be separated into enum type and enum value.

                    return enumTypeAndValueString[1].ToCorrespondingEnumValue(enumTypeAndValueString[0]);
                }
                else if (String == "<True/>") return true;
                else if (String == "<False/>") return false;
                else if (String == "<EffectUser/>") return _actor;
                else if (String == "<StatusEffectOriginSkillLevel/>") return _statusEffects[0].OriginSkillLevel;
                else if (String == "<StatusEffectEquipmentLevel/>") return _statusEffects[0].EquipmentLevel;
                else if (String == "<Skill/>") return _skill;
                else if (String == "<SkillName/>") return _skill.BaseInfo.Name;
                else if (String == "<SkillLevel/>") return _skill.Level;
                else if (String == "<Effect/>") return _effect;
                else if (String == "<EffectRange/>") return _effectRange;
                else if (String == "<Target/>") return _target;
                else if (String == "<Target2/>") return _target2ForComplexTargetSelectionEffect;
                else if (String == "<CurrentTarget/>") return _isTarget2CurrentTarget ? _target2ForComplexTargetSelectionEffect : _target;
                else
                    return null;
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        private string HierarchizeString(string _s = "", int _counter = 0)
        {
            if (_counter != 0)
            {
                _s += "\n";
                for (int i = 0; i < _counter; i++)
                {
                    _s += "\t";
                }
            }

            _s += this.String;

            _counter++;
            foreach (Tag t in this.ChildrenTags) { _s += HierarchizeString(_s, _counter); }

            return _s;
        }

        private Tag DeepCopyInternally(Tag _parentTag = null)
        {
            string stringCopy = string.Copy(String);

            List<Tag> childrenTagCopies = new List<Tag>();
            foreach (Tag childTag in m_childrenTags)
            {
                childrenTagCopies.Add(childTag.DeepCopyInternally(this));
            }

            return new Tag(stringCopy, _parentTag);
        }
        #endregion
    }
}
