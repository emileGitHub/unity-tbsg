﻿using System.Collections.Generic;
using System;
using UnityEngine;
using EEANGames.TBSG._01.ExtensionMethods;
using EEANGames.ExtensionMethods;
using System.Linq;
using System.Collections.ObjectModel;

namespace EEANGames.TBSG._01.MainClassLib
{
    public class Player
    {
        /// <summary>
        /// Ctor
        /// PreCondition: _id > 0; _teams.Count > 0; _unitData.Count > 0;
        /// PostCondition: All Properties will be initialized properly.
        /// </summary>
        /// <param name="_id"></param>
        /// <param name="_name"></param>
        /// <param name="_unitsOwned"></param>
        /// <param name="_weaponsOwned"></param>
        /// <param name="_armoursOwned"></param>
        /// <param name="_accessoriesOwned"></param>
        /// <param name="_teams"></param>
        public Player(int _id, string _name, List<Unit> _unitsOwned, List<Weapon> _weaponsOwned, List<Armour> _armoursOwned, List<Accessory> _accessoriesOwned, Dictionary<Item, int> _itemsOwned, List<MemberSet> _memberSets, List<ItemSet> _itemSets, List<Team> _teams, int _gemsOwned, int _goldOwned)
        {
            //Assign Id
            Id = _id;

            //Assign Name
            Name = _name.CoalesceNullAndReturnCopyOptionally(true);

            //Assign Playable Units Owned
            UnitsOwned = _unitsOwned.CoalesceNullAndReturnCopyOptionally(eCopyType.Shallow);

            //Assign Weapons Owned
            WeaponsOwned = _weaponsOwned.CoalesceNullAndReturnCopyOptionally(eCopyType.Shallow);

            //Assign Armours Owned
            ArmoursOwned = _armoursOwned.CoalesceNullAndReturnCopyOptionally(eCopyType.Shallow);

            //Assign Accessories Owned
            AccessoriesOwned = _accessoriesOwned.CoalesceNullAndReturnCopyOptionally(eCopyType.Shallow);

            //Assign Items Owned
            ItemsOwned = _itemsOwned.CoalesceNullAndReturnCopyOptionally(eCopyType.Shallow);

            //Assign MemberSets Owned
            MemberSets = _memberSets.CoalesceNullAndReturnCopyOptionally(eCopyType.Shallow);
            //Assign ItemSets Owned
            ItemSets = _itemSets.CoalesceNullAndReturnCopyOptionally(eCopyType.Shallow);

            //Assign Teams Owned
            Teams = _teams.CoalesceNullAndReturnCopyOptionally(eCopyType.Shallow);

            GemsOwned = _gemsOwned;
            GoldOwned = _goldOwned;
         }

        /*--------------------------------------------
        Properties
        --------------------------------------------*/

        //Base Properties
        public int Id { get; }
        public string Name { get; }

        //Playable Units Owned
        public List<Unit> UnitsOwned { get; set; } //Will Store References

        //Equipments Owned
        public List<Weapon> WeaponsOwned { get; set; } //Will Store References
        public List<Armour> ArmoursOwned { get; set; } //Will Store References
        public List<Accessory> AccessoriesOwned { get; set; } //Will Store References

        //Items Owned
        public Dictionary<Item, int> ItemsOwned { get; set; } //Will Store References

        //Sets of Playable Units Owned
        public List<MemberSet> MemberSets { get; set; } //Will Store References
        public List<ItemSet> ItemSets { get; set; } //Will Store References
        public List<Team> Teams { get; set; } //Will Store References

        public int GemsOwned { get; set; }
        public int GoldOwned { get;  set; }
    }

    public sealed class PlayerOnBoard
    {
        public PlayerOnBoard(string _name, Team _team, bool _isPlayer1)
        {
            try
            {
                Name = _name.CoalesceNullAndReturnCopyOptionally(true);

                IsPlayer1 = _isPlayer1;

                Moved = false;
                Attacked = false;

                UsedUltimateSkill = false;

                //Assign Allied Units
                AlliedUnits = new List<UnitInstance>();
                //Assign Items
                Items = new List<Item>();

                if (_team != null)
                {
                    if (_team.MemberSets.Length > 0)
                    {
                        foreach (MemberSet ms in _team.MemberSets)
                        {
                            AlliedUnits.Add(new UnitInstance(ms.Member, ms.MainWeapon, ms.SubWeapon, ms.Armour, ms.Accessory, this));
                        }
                    }
                    else
                        Debug.Log("No units in team!");

                    if (_team.ItemSet != null)
                    {
                        foreach (var itemQuantity in _team.ItemSet.QuantityPerItem)
                        {
                            for (int i = 0; i < itemQuantity.Value; i++)
                            {
                                Items.Add((itemQuantity.Key as IDeepCopyable<Item>).DeepCopy());
                            }
                        }
                    }
                }
                else
                    Debug.Log("Null Team object!");

                //ID of Unit Currently Selected
                SelectedUnitIndex = -1; //Meaning none of the characters is selected

                MaxSP = 0;
                RemainingSP = 0;
            }
            catch (Exception ex)
            {
                Debug.Log("PlayerOnBoard: at Ctor1() " + ex.Message);
            }
        }

        public PlayerOnBoard(Player _player, int _teamIndex, bool _isPlayer1)
        {
            try
            {
                Name = string.Empty;

                IsPlayer1 = _isPlayer1;

                Moved = false;
                Attacked = false;

                UsedUltimateSkill = false;

                //Assign Allied Units
                AlliedUnits = new List<UnitInstance>();
                //Assign Items
                Items = new List<Item>();

                if (_player != null)
                {
                    Name = string.Copy(_player.Name);

                    IList<Team> tmp_teams = _player.Teams.AsReadOnly();

                    if (tmp_teams.Count > _teamIndex && _teamIndex >= 0)
                    {
                        if (tmp_teams[_teamIndex].MemberSets.Length <= 0)
                            Debug.Log("No units in team!");
                        else
                        {
                            foreach (MemberSet ms in tmp_teams[_teamIndex].MemberSets)
                            {
                                AlliedUnits.Add(new UnitInstance(ms.Member, ms.MainWeapon, ms.SubWeapon, ms.Armour, ms.Accessory, this));
                            }
                        }

                        if (tmp_teams[_teamIndex].ItemSet != null)
                        {
                            foreach (var itemQuantity in tmp_teams[_teamIndex].ItemSet.QuantityPerItem)
                            {
                                foreach (var itemOwned in _player.ItemsOwned)
                                {
                                    int quantity = (itemOwned.Value >= itemQuantity.Value) ? itemQuantity.Value : itemOwned.Value;
                                    for (int i = 0; i < quantity; i++)
                                    {
                                        Items.Add((itemOwned.Key as IDeepCopyable<Item>).DeepCopy());
                                    }
                                }
                            }
                        }
                    }
                    else if (tmp_teams.Count > 0)
                    {
                        if (tmp_teams[0].MemberSets.Length <= 0)
                            Debug.Log("No units in team!");
                        else
                        {
                            foreach (MemberSet ms in tmp_teams[0].MemberSets)
                            {
                                AlliedUnits.Add(new UnitInstance(ms.Member, ms.MainWeapon, ms.SubWeapon, ms.Armour, ms.Accessory, this));
                            }
                        }

                        Dictionary<Item, int> tmp_itemsOwned = _player.ItemsOwned.DeepCopy();
                        foreach (var itemQuantity in tmp_teams[0].ItemSet.QuantityPerItem)
                        {
                            foreach (var itemOwned in tmp_itemsOwned)
                            {
                                int quantity = (itemOwned.Value >= itemQuantity.Value) ? itemQuantity.Value : itemOwned.Value;
                                for (int i = 0; i < quantity; i++)
                                {
                                    Items.Add((itemOwned.Key as IDeepCopyable<Item>).DeepCopy());
                                }
                            }
                        }
                    }
                    else
                        Debug.Log("No teams found!");
                }

                //ID of Unit Currently Selected
                SelectedUnitIndex = -1; //Meaning none of the characters is selected

                MaxSP = 0;
                RemainingSP = 0;
            }
            catch (Exception ex)
            {
                Debug.Log("PlayerOnBoard: at Ctor2() " + ex.Message);
            }
        }

        #region Properties
        public string Name { get; }

        public bool IsPlayer1 { get; set; }

        public bool Moved { get; set; }
        public bool Attacked { get; set; }
        public bool UsedUltimateSkill { get; private set; }

        public List<UnitInstance> AlliedUnits { get; }

        public List<Item> Items { get; }

        public int SelectedUnitIndex { get; set; } //Id of the unit in AlliedUnits 

        public int MaxSP { get; set; }
        public int RemainingSP { get; set; }
        #endregion

        #region Public Methods
        public bool HasRequiredItems(ReadOnlyDictionary<int, int> _itemCosts)
        {
            List<int> availableItemIds = new List<int>();

            foreach (Item item in Items.AsReadOnly())
            {
                availableItemIds.Add(item.Id);
            }

            foreach (var itemCost in _itemCosts)
            {
                for (int i = 0; i < itemCost.Value; i++)
                {
                    if (availableItemIds.Contains(itemCost.Key))
                        availableItemIds.Remove(itemCost.Key);
                    else
                        return false;
                }
            }

            return true;
        }

        public void SetUsedUltimateSkillToTrue() { UsedUltimateSkill = true; }
        #endregion
    }
}
