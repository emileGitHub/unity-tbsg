﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace EEANGames.TBSG._01.MainClassLib
{
    public static class CoreValues
    {
        public const string SERVER_URL = "http://eeangames:8080/tbsg-01-game-server/MainServlet";
        //public const string SERVER_URL = "http://192.168.1.104:8080/tbsg-01-game-server/MainServlet";

        public const decimal DEFAULT_CRITICAL_RATE = 0.05m;
        public const int MIN_SP_COST = 1;
        public const int MAX_SP = 7;
        //public const int MIN_BASE_ATTRIBUTE_VALUE = 1;
        //public const int MAX_BASE_VIT_VALUE = 99;
        public const int MAX_BASE_STR_AND_RES_VALUE = 999;
        //public const int MAX_BASE_HP_VALUE = 9999;
        public const int REQUIRED_EXPERIENCE_FOR_FIRST_LEVEL_UP = 9;
        public const int SIZE_OF_A_SIDE_OF_BOARD = 7;
        public const int MAX_MEMBERS_PER_TEAM = 5;
        public const int MAX_ITEMS_PER_TEAM = 10;
        public const int DAMAGE_BASE_VALUE = 50;
        public const int MAX_NUM_OF_ELEMENTS_IN_RECIPE = 5;
        public const decimal MULTIPLIER_FOR_ELEMENT_MATCH = 2.0m;
        public const decimal MULTIPLIER_FOR_EFFECTIVE_ELEMENT = 2.0m;
        public const decimal MULTIPLIER_FOR_INEFFECTIVE_ELEMENT = 0.5m;
        public const decimal MULTIPLIER_FOR_CRITICALHIT = 2.0m;
        public const decimal MULTIPLIER_FOR_TILETYPEMATCH = 2.0m;
        public const double MULTIPLIER_FOR_ANGLE_TO_RADIAN = (Math.PI / 180);
        public const decimal MAX_EQUIPABLE_WEAPON_TOTAL_COST = 3;
        public const decimal LEVEL_EXPERIENCE_MULTIPLIER = 1.03m;
        public const int SP_AT_INITIALIZATION = 7;
        public const decimal POW_ADJUSTMENT_CONST_A = 19m / 9999m;
        public const decimal POW_ADJUSTMENT_CONST_B = 1.0m - POW_ADJUSTMENT_CONST_A;
    }   
}
