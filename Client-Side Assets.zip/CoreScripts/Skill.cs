﻿using EEANGames.ExtensionMethods;
using EEANGames.TBSG._01.CommonEnums;
using EEANGames.TBSG._01.ExtensionMethods;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;

namespace EEANGames.TBSG._01.MainClassLib
{
    #region Data
    public abstract class SkillData : IDeepCopyable<SkillData>
    {
        public SkillData(int _id, string _name, byte[] _iconAsBytes, List<StatusEffectData> _statusEffectsData, int _animationId)
        {
            Id = _id;

            Name = _name.CoalesceNullAndReturnCopyOptionally(true);

            m_iconAsBytes = _iconAsBytes.CoalesceNullAndReturnCopyOptionally(eCopyType.Deep);

            m_statusEffectsData = _statusEffectsData.CoalesceNullAndReturnCopyOptionally(eCopyType.Deep);

            AnimationId = _animationId;
        }

        #region Properties
        public int Id { get; }
        public string Name { get; private set; }

        public IList<byte> IconAsBytes { get { return Array.AsReadOnly(m_iconAsBytes); } }

        public virtual IList<StatusEffectData> StatusEffectsData { get { return m_statusEffectsData.AsReadOnly(); } }

        public int AnimationId { get; }
        #endregion

        #region Private Fields
        private byte[] m_iconAsBytes;
        private List<StatusEffectData> m_statusEffectsData;
        #endregion

        #region Public Methods
        SkillData IDeepCopyable<SkillData>.DeepCopy() { return (SkillData)DeepCopyInternally(); }
        #endregion

        #region Protected Methods
        protected virtual object DeepCopyInternally()
        {
            SkillData copy = (SkillData)this.MemberwiseClone();

            copy.Name = string.Copy(Name);

            copy.m_iconAsBytes = m_iconAsBytes.DeepCopy();

            copy.m_statusEffectsData = m_statusEffectsData.DeepCopy();

            return copy;
        }
        #endregion
    }

    public abstract class ActiveSkillData : SkillData, IDeepCopyable<ActiveSkillData>
    {
        public ActiveSkillData(int _id, string _name, byte[] _iconAsBytes, List<BackgroundStatusEffectData> _temporalStatusEffectsData, int _animationId,
            Tag _maxNumberOfTargets, Effect _effect) : base(_id, _name, _iconAsBytes, _temporalStatusEffectsData.CoalesceNullAndReturnCopyOptionally(eCopyType.None).Cast<StatusEffectData>().ToList(), _animationId)
        {
            MaxNumberOfTargets = _maxNumberOfTargets.CoalesceNullAndReturnDeepCopyOptionally(true);

            Effect = _effect; // Get the reference to the original instance
        }

        #region Properties
        public Tag MaxNumberOfTargets { get; private set; } //Tag value must be positive integer

        public Effect Effect { get; private set; }
        #endregion

        #region Public Methods
        ActiveSkillData IDeepCopyable<ActiveSkillData>.DeepCopy() { return (ActiveSkillData)DeepCopyInternally(); }
        #endregion

        #region Protected Methods
        protected override object DeepCopyInternally()
        {
            ActiveSkillData copy = (ActiveSkillData)base.DeepCopyInternally();

            copy.MaxNumberOfTargets = MaxNumberOfTargets.DeepCopy();

            copy.Effect = Effect;

            return copy;
        }
        #endregion
    }

    public abstract class CostRequiringSkillData : ActiveSkillData, IDeepCopyable<CostRequiringSkillData>
    {
        public CostRequiringSkillData(int _id, string _name, byte[] _iconAsBytes, List<BackgroundStatusEffectData> _temporalStatusEffectsData, int _animationId, Tag _maxNumberOfTargets, Effect _effect,
            int _spCost, Dictionary<int, int> _itemCosts) : base(_id, _name, _iconAsBytes, _temporalStatusEffectsData, _animationId, _maxNumberOfTargets, _effect)
        {
            if (_spCost < CoreValues.MIN_SP_COST)
                _spCost = CoreValues.MIN_SP_COST;
            else if (_spCost > CoreValues.MAX_SP)
                _spCost = CoreValues.MAX_SP;

            SPCost = _spCost;

            m_itemCosts = _itemCosts.CoalesceNullAndReturnCopyOptionally(eCopyType.Deep);
        }

        #region Properties
        public int SPCost { get; }
        public ReadOnlyDictionary<int, int> ItemCosts { get { return m_itemCosts.AsReadOnly(); } } //string => Item Name, int => Quantity
        #endregion

        #region Private Fields
        private Dictionary<int, int> m_itemCosts;
        #endregion

        #region Public Methods
        CostRequiringSkillData IDeepCopyable<CostRequiringSkillData>.DeepCopy() { return (CostRequiringSkillData)DeepCopyInternally(); }
        #endregion

        #region Protected Methods
        protected override object DeepCopyInternally()
        {
            CostRequiringSkillData copy = (CostRequiringSkillData)base.DeepCopyInternally();

            copy.m_itemCosts = new Dictionary<int, int>(m_itemCosts); //Shallow Copy

            return copy;
        }
        #endregion
    }

    public class OrdinarySkillData : CostRequiringSkillData, IDeepCopyable<OrdinarySkillData>
    {
        public OrdinarySkillData(int _id, string _name, byte[] _iconAsBytes, List<BackgroundStatusEffectData> _temporalStatusEffectsData, int _animationId, Tag _maxNumberOfTargets, Effect _effect, int _spCost, Dictionary<int, int> _itemCosts) : base(_id, _name, _iconAsBytes, _temporalStatusEffectsData, _animationId, _maxNumberOfTargets, _effect, _spCost, _itemCosts)
        {
        }

        #region Public Methods
        OrdinarySkillData IDeepCopyable<OrdinarySkillData>.DeepCopy() { return (OrdinarySkillData)DeepCopyInternally(); }
        #endregion

        #region Protected Methods
        protected override object DeepCopyInternally() { return (OrdinarySkillData)base.DeepCopyInternally(); }
        #endregion
    }

    public class CounterSkillData : CostRequiringSkillData, IDeepCopyable<CounterSkillData>
    {
        public CounterSkillData(int _id, string _name, byte[] _iconAsBytes, List<BackgroundStatusEffectData> _temporalStatusEffectsData, int _animationId, Tag _maxNumberOfTargets, Effect _effect, int _spCost, Dictionary<int, int> _itemCosts,
            eEventTriggerTiming _activationTiming, ComplexCondition _activationCondition) : base(_id, _name, _iconAsBytes, _temporalStatusEffectsData, _animationId, _maxNumberOfTargets, _effect, _spCost, _itemCosts)
        {
            ActivationTiming = _activationTiming;
            ActivationCondition = _activationCondition.CoalesceNullAndReturnDeepCopyOptionally(true);
        }

        #region Properties
        public eEventTriggerTiming ActivationTiming { get; }
        public ComplexCondition ActivationCondition { get; private set; }
        #endregion

        #region Public Methods
        CounterSkillData IDeepCopyable<CounterSkillData>.DeepCopy() { return (CounterSkillData)DeepCopyInternally(); }
        #endregion

        #region Protected Methods
        protected override object DeepCopyInternally()
        {
            CounterSkillData copy = (CounterSkillData)base.DeepCopyInternally();

            copy.ActivationCondition = ActivationCondition.DeepCopy();

            return copy;
        }
        #endregion
    }

    public class UltimateSkillData : ActiveSkillData, IDeepCopyable<UltimateSkillData>
    {
        public UltimateSkillData(int _id, string _name, byte[] _iconAsBytes, List<BackgroundStatusEffectData> _temporalStatusEffectsData, int _animationId, Tag _maxNumberOfTargets, Effect _effect) : base(_id, _name, _iconAsBytes, _temporalStatusEffectsData, _animationId, _maxNumberOfTargets, _effect)
        {
        }

        #region Public Methods
        UltimateSkillData IDeepCopyable<UltimateSkillData>.DeepCopy() { return (UltimateSkillData)DeepCopyInternally(); }
        #endregion

        #region Protected Methods
        protected override object DeepCopyInternally() { return (UltimateSkillData)base.DeepCopyInternally(); }
        #endregion
    }

    public class PassiveSkillData : SkillData, IDeepCopyable<PassiveSkillData>
    {
        public PassiveSkillData(int _id, string _name, byte[] _iconAsBytes, List<StatusEffectData> _statusEffectsData, int _animationId,
            eTargetUnitClassification _targetClassification, ComplexCondition _activationCondition) : base(_id, _name, _iconAsBytes, _statusEffectsData, _animationId)
        {
            TargetClassification = _targetClassification;
            ActivationCondition = _activationCondition.CoalesceNullAndReturnDeepCopyOptionally(true);
        }

        #region Properties
        public eTargetUnitClassification TargetClassification { get; }
        public ComplexCondition ActivationCondition { get; private set; }
        #endregion

        #region Public Methods
        PassiveSkillData IDeepCopyable<PassiveSkillData>.DeepCopy() { return (PassiveSkillData)DeepCopyInternally(); }
        #endregion

        #region Protected Methods
        protected override object DeepCopyInternally()
        {
            PassiveSkillData copy = (PassiveSkillData)base.DeepCopyInternally();

            copy.ActivationCondition = ActivationCondition.DeepCopy();

            return copy;
        }
        #endregion
    }
    #endregion

    #region Actual Skills
    public abstract class Skill : IDeepCopyable<Skill>
    {
        public Skill(SkillData _skillData, int _level)
        {
            BaseInfo = _skillData.CoalesceNullAndReturnDeepCopyOptionally();

            Level = _level;
        }

        #region Properties
        public SkillData BaseInfo { get; } // Store the reference to the original instance

        public int Level { get; set; } // To be updated externally
        #endregion

        #region Public Methods
        Skill IDeepCopyable<Skill>.DeepCopy() { return (Skill)DeepCopyInternally(); }
        #endregion

        #region Protected Methods
        protected virtual object DeepCopyInternally() { return (Skill)this.MemberwiseClone(); }
        #endregion
    }

    public abstract class ActiveSkill : Skill, IDeepCopyable<ActiveSkill>
    {
        public ActiveSkill(ActiveSkillData _skillData, int _level) : base(_skillData, _level)
        {
        }

        #region Properties
        public new ActiveSkillData BaseInfo => base.BaseInfo as ActiveSkillData;
        #endregion

        #region Public Methods
        ActiveSkill IDeepCopyable<ActiveSkill>.DeepCopy() { return (ActiveSkill)DeepCopyInternally(); }
        #endregion

        #region Protected Methods
        protected override object DeepCopyInternally() { return (ActiveSkill)base.DeepCopyInternally(); }
        #endregion
    }

    public abstract class CostRequiringSkill : ActiveSkill, IDeepCopyable<CostRequiringSkill>
    {
        public CostRequiringSkill(CostRequiringSkillData _skillData, int _level) : base(_skillData, _level)
        {
        }

        #region Properties
        public new CostRequiringSkillData BaseInfo => base.BaseInfo as CostRequiringSkillData;
        #endregion

        #region Public Methods
        CostRequiringSkill IDeepCopyable<CostRequiringSkill>.DeepCopy() { return (CostRequiringSkill)DeepCopyInternally(); }
        #endregion

        #region Protected Methods
        protected override object DeepCopyInternally() { return (CostRequiringSkill)base.DeepCopyInternally(); }
        #endregion
    }

    public class OrdinarySkill : CostRequiringSkill, IDeepCopyable<OrdinarySkill>
    {
        public OrdinarySkill(OrdinarySkillData _skillData, int _level) : base(_skillData, _level)
        {
        }

        #region Properties
        public new OrdinarySkillData BaseInfo => base.BaseInfo as OrdinarySkillData;
        #endregion

        #region Public Methods
        OrdinarySkill IDeepCopyable<OrdinarySkill>.DeepCopy() { return (OrdinarySkill)DeepCopyInternally(); }
        #endregion

        #region Protected Methods
        protected override object DeepCopyInternally() { return (OrdinarySkill)base.DeepCopyInternally(); }
        #endregion
    }

    public class CounterSkill : CostRequiringSkill, IDeepCopyable<CounterSkill>
    {
        public CounterSkill(CounterSkillData _skillData, int _level) : base(_skillData, _level)
        {
        }

        #region Properties
        public new CounterSkillData BaseInfo => base.BaseInfo as CounterSkillData;
        #endregion

        #region Public Methods
        CounterSkill IDeepCopyable<CounterSkill>.DeepCopy() { return (CounterSkill)DeepCopyInternally(); }
        #endregion

        #region Protected Methods
        protected override object DeepCopyInternally() { return (CounterSkill)base.DeepCopyInternally(); }
        #endregion
    }

    public class UltimateSkill : ActiveSkill, IDeepCopyable<UltimateSkill>
    {
        public UltimateSkill(UltimateSkillData _skillData, int _level) : base(_skillData, _level)
        {
        }

        #region Properties
        public new UltimateSkillData BaseInfo => base.BaseInfo as UltimateSkillData;
        #endregion

        #region Public Methods
        UltimateSkill IDeepCopyable<UltimateSkill>.DeepCopy() { return (UltimateSkill)DeepCopyInternally(); }
        #endregion

        #region Protected Methods
        protected override object DeepCopyInternally() { return (UltimateSkill)base.DeepCopyInternally(); }
        #endregion
    }

    public class PassiveSkill : Skill, IDeepCopyable<PassiveSkill>
    {
        public PassiveSkill(PassiveSkillData _skillData, int _level) : base(_skillData, _level)
        {
        }

        #region Properties
        public new PassiveSkillData BaseInfo => base.BaseInfo as PassiveSkillData;
        #endregion

        #region Public Methods
        PassiveSkill IDeepCopyable<PassiveSkill>.DeepCopy() { return (PassiveSkill)DeepCopyInternally(); }
        #endregion

        #region Protected Methods
        protected override object DeepCopyInternally() { return (PassiveSkill)base.DeepCopyInternally(); }
        #endregion
    }
    #endregion
}
