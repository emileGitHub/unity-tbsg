﻿using EEANGames.ExtensionMethods;
using EEANGames.TBSG._01.CommonEnums;
using EEANGames.TBSG._01.ExtensionMethods;
using System;
using System.Collections.Generic;

namespace EEANGames.TBSG._01.MainClassLib
{
    public abstract class Item : IDeepCopyable<Item>, IRarityMeasurable
    {
        public Item(int _id, string _name, byte[] _iconAsBytes, eRarity _rarity, int _sellingPrice)
        {
            Id = _id;

            Name = _name.CoalesceNullAndReturnCopyOptionally(true);

            IconAsBytes = _iconAsBytes.CoalesceNullAndReturnCopyOptionally(eCopyType.Deep);

            Rarity = _rarity;

            SellingPrice = _sellingPrice;
        }

        #region Properties
        public int Id { get; }
        public string Name { get; private set; }
        public byte[] IconAsBytes { get; private set; }

        public eRarity Rarity { get; }

        public int SellingPrice { get; }
        #endregion

        #region Public Methods
        Item IDeepCopyable<Item>.DeepCopy() { return (Item)DeepCopyInternally(); }
        #endregion

        #region Protected Methods
        protected virtual object DeepCopyInternally()
        {
            Item copy = (Item)this.MemberwiseClone();

            copy.Name = string.Copy(Name);

            copy.IconAsBytes = IconAsBytes.DeepCopy();

            return copy;
        }
        #endregion
    }

    // Used during battle
    public class SkillItem : Item, IDeepCopyable<SkillItem>, IRarityMeasurable
    {
        public SkillItem(int _id, string _name, byte[] _iconAsByteArray, eRarity _rarity, int _sellingPrice,
            Skill _skill) : base(_id, _name, _iconAsByteArray, _rarity, _sellingPrice)
        {
            Skill = _skill.CoalesceNullAndReturnDeepCopyOptionally(true);
        }

        public SkillItem(Item _itemBase,
            Skill _skill) : base(_itemBase.Id, _itemBase.Name, _itemBase.IconAsBytes, _itemBase.Rarity, _itemBase.SellingPrice)
        {
            Skill = _skill.CoalesceNullAndReturnDeepCopyOptionally(true);
        }

        #region Properties
        public Skill Skill { get; private set; }
        #endregion

        #region Public Methods
        SkillItem IDeepCopyable<SkillItem>.DeepCopy() { return (SkillItem)DeepCopyInternally(); }
        #endregion

        #region Protected Methods
        protected override object DeepCopyInternally()
        {
            SkillItem copy = (SkillItem)base.DeepCopyInternally();

            copy.Skill = (Skill as IDeepCopyable<Skill>).DeepCopy();

            return copy;
        }
        #endregion
    }

    // Required for Skills' item cost
    public class SkillMaterial : Item, IDeepCopyable<SkillMaterial>, IRarityMeasurable
    {
        public SkillMaterial(int _id, string _name, byte[] _iconAsBytes, eRarity _rarity, int _sellingPrice) : base(_id, _name, _iconAsBytes, _rarity, _sellingPrice)
        {
        }

        #region Public Methods
        SkillMaterial IDeepCopyable<SkillMaterial>.DeepCopy() { return (SkillMaterial)DeepCopyInternally(); }
        #endregion

        #region Protected Methods
        protected override object DeepCopyInternally() { return (SkillMaterial)base.DeepCopyInternally(); }
        #endregion
    }

    // Required to craft Items
    public class ItemMaterial : Item, IDeepCopyable<ItemMaterial>, IRarityMeasurable
    {
        public ItemMaterial(int _id, string _name, byte[] _iconAsBytes, eRarity _rarity, int _sellingPrice) : base(_id, _name, _iconAsBytes, _rarity, _sellingPrice)
        {
        }

        #region Public Methods
        ItemMaterial IDeepCopyable<ItemMaterial>.DeepCopy() { return (ItemMaterial)DeepCopyInternally(); }
        #endregion

        #region Protected Methods
        protected override object DeepCopyInternally() { return (ItemMaterial)base.DeepCopyInternally(); }
        #endregion
    }

    // Required to forge Equipments
    public class EquipmentMaterial : Item, IDeepCopyable<EquipmentMaterial>, IRarityMeasurable
    {
        public EquipmentMaterial(int _id, string _name, byte[] _iconAsBytes, eRarity _rarity, int _sellingPrice) : base(_id, _name, _iconAsBytes, _rarity, _sellingPrice)
        {
        }

        #region Public Methods
        EquipmentMaterial IDeepCopyable<EquipmentMaterial>.DeepCopy() { return (EquipmentMaterial)DeepCopyInternally(); }
        #endregion

        #region Protected Methods
        protected override object DeepCopyInternally() { return (EquipmentMaterial)base.DeepCopyInternally(); }
        #endregion
    }

    // Required to evolve Units
    public class EvolutionMaterial : Item, IDeepCopyable<EvolutionMaterial>, IRarityMeasurable
    {
        public EvolutionMaterial(int _id, string _name, byte[] _iconAsBytes, eRarity _rarity, int _sellingPrice) : base(_id, _name, _iconAsBytes, _rarity, _sellingPrice)
        {
        }

        #region Public Methods
        EvolutionMaterial IDeepCopyable<EvolutionMaterial>.DeepCopy() { return (EvolutionMaterial)DeepCopyInternally(); }
        #endregion

        #region Protected Methods
        protected override object DeepCopyInternally() { return (EvolutionMaterial)base.DeepCopyInternally(); }
        #endregion
    }
}
