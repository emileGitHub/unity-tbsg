﻿using System.Collections;
using System.Collections.Generic;
using System;
using EEANGames.TBSG._01.MainClassLib;
using EEANGames.TBSG._01.CommonEnums;

namespace EEANGames.TBSG._01.MainClassLib
{
    public struct Socket
    {
        public Socket(eTileType _tileType)
        {
            TileType = _tileType;
            Unit = null;
            TrapEffects = new List<Effect>();
        }

        public eTileType TileType;
        public UnitInstance Unit;
        public List<Effect> TrapEffects;
    }

    public class Board
    {
        /// <summary>
        /// Ctor
        /// PreCondition: _tileSet.Count > 0;
        /// PostCondition: All eTileType properties of Sockets in the Board will have an eTileType value assigned. The eTileType value for each socket will be randomly selected from those in _tileSet.
        /// </summary>
        /// <param name="_tileSet"></param>
        public Board(List<eTileType> _tileSet)
        {
            Sockets = new Socket[CoreValues.SIZE_OF_A_SIDE_OF_BOARD, CoreValues.SIZE_OF_A_SIDE_OF_BOARD];

            List<eTileType> tileTypes = TileFunctions.GetRandomTileType(CoreValues.SIZE_OF_A_SIDE_OF_BOARD * CoreValues.SIZE_OF_A_SIDE_OF_BOARD, _tileSet);

            for (int x = 1; x <= CoreValues.SIZE_OF_A_SIDE_OF_BOARD; x++)
            {
                for(int y = 1; y <= CoreValues.SIZE_OF_A_SIDE_OF_BOARD; y++)
                {
                    Sockets[x - 1, y - 1].TileType = tileTypes[CoreValues.SIZE_OF_A_SIDE_OF_BOARD * (x - 1) + (y - 1)];
                }
            }
        }

        #region Properties
        public Socket[,] Sockets { get; set; }
        #endregion
    } 
}
