﻿using EEANGames.ExtensionMethods;
using EEANGames.TBSG._01.CommonEnums;
using EEANGames.TBSG._01.MainClassLib;
using System;
using System.Collections;
using System.Collections.ObjectModel;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;

namespace EEANGames.ExtensionMethods
{
    public static class ObjectExtension
    {
        public static bool IsNumeric(this object _object)
        {
            Type type = _object.GetType();
            return type.IsNumeric();
        }

        public static bool Is_struct(this object _object)
        {
            Type type = _object.GetType();
            return type.Is_struct();
        }

        public static bool IsArray(this object _object)
        {
            Type type = _object.GetType();
            return type.IsArray;
        }

        public static bool IsList(this object _object)
        {
            Type type = _object.GetType();
            return type.IsList();
        }

        public static bool IsDictionary(this object _object)
        {
            Type type = _object.GetType();
            return type.IsDictionary();
        }

        public static bool IsIDeepCopyable(this object _object)
        {
            Type type = _object.GetType();
            return type.IsIDeepCopyable();
        }

        public static T ToT<T>(this object _object)
        {
            if (_object is T)
                return (T)_object;
            else if (_object.IsArray())
            {
                Type tType = typeof(T).GetInternalTypesOfCollection()[0];

                MethodInfo methodInfo_ToArray = typeof(ObjectExtension).GetMethod("ToArray").MakeGenericMethod(tType);

                return methodInfo_ToArray.Invoke(null, new[] { _object }).ToT<T>();
            }
            else if (_object.IsList())
            {
                Type tType = typeof(T).GetInternalTypesOfCollection()[0];

                MethodInfo methodInfo_ToList = typeof(ObjectExtension).GetMethod("ToList").MakeGenericMethod(tType);

                return methodInfo_ToList.Invoke(null, new[] { _object }).ToT<T>();
            }
            else if (_object.IsDictionary())
            {
                List<Type> internalTypes = typeof(T).GetInternalTypesOfCollection(); //Gets the types of the elements in the dictionary. For instance, int and List<string> will be returned for Dictionary<int, List<string>>
                Type keyType = internalTypes[0];
                Type valueType = internalTypes[1];

                MethodInfo methodInfo_ToDictionary = typeof(ObjectExtension).GetMethod("ToDictionary").MakeGenericMethod(keyType, valueType);

                return methodInfo_ToDictionary.Invoke(null, new[] { _object }).ToT<T>();
            }

            return default(T);
        }

        public static T[] ToArray<T>(this object _object)
        {
            if (!_object.IsArray())
                return null;

            T[] tmp_array = (T[])_object;

            T[] result = new T[tmp_array.Length];

            //Type tType = typeof(T);

            for (int i = 0; i < result.Length; i++)
            {
                result[i] = tmp_array[i].ToT<T>();
            }

            return result;
        }

        public static List<T> ToList<T>(this object _object)
        {
            List<T> result = new List<T>();

            if (!_object.IsList())
                return null;

            IList tmp_list = (IList)_object;

            //Type tType = typeof(T);

            foreach (var item in tmp_list)
            {
                result.Add(item.ToT<T>());
            }

            return result;
        }

        public static Dictionary<T, U> ToDictionary<T, U>(this object _object)
        {
            Dictionary<T, U> result = new Dictionary<T, U>();

            if (!_object.IsDictionary())
                return null;

            IDictionary tmp_dic = (IDictionary)_object;

            //Type tType = typeof(T);
            //Type uType = typeof(U);

            foreach (DictionaryEntry entry in tmp_dic)
            {
                result.Add(entry.Key.ToT<T>(), entry.Value.ToT<U>());
            }

            return result;
        }

        /// <summary>
        /// Checkes whether _value implements IDeepCopyable<>. Returns the results of _value.DeepCopy() if true. Returns null if false.
        /// </summary>
        public static object DeepCopy(this object _value)
        {
            Type type = _value.GetType();
            if (_value.IsIDeepCopyable())
                return type.GetInterfaces().First(x => x.IsGenericType && x.GetGenericTypeDefinition() == typeof(IDeepCopyable<>)).GetMethod("DeepCopy").Invoke(_value, null);

            return null;
        }
    }

    public static class TypeExtension
    {
        public static bool IsNumeric(this Type _type)
        {
            switch(Type.GetTypeCode(_type))
            {
                case TypeCode.Byte:
                case TypeCode.Decimal:
                case TypeCode.Double:
                case TypeCode.Int16:
                case TypeCode.Int32:
                case TypeCode.Int64:
                case TypeCode.SByte:
                case TypeCode.Single:
                case TypeCode.UInt16:
                case TypeCode.UInt32:
                case TypeCode.UInt64:
                    return true;
                default:
                    return false;
            }
        }

        public static bool Is_struct(this Type _type) { return (_type.IsValueType && !_type.IsNumeric() && !_type.IsEnum && !(Type.GetTypeCode(_type) == TypeCode.Boolean) && !(Type.GetTypeCode(_type) == TypeCode.Char)); }

        public static bool IsList(this Type _type) { return ((_type.IsGenericType) ? _type.GetGenericTypeDefinition() == typeof(List<>) : false); }

        public static bool IsDictionary(this Type _type) { return ((_type.IsGenericType) ? _type.GetGenericTypeDefinition() == typeof(Dictionary<,>) : false); }

        public static bool IsIDeepCopyable(this Type _type) { return _type.GetInterfaces().Any(x => x.IsGenericType && x.GetGenericTypeDefinition() == typeof(IDeepCopyable<>)); }

        public static List<Type> GetInternalTypesOfCollection(this Type _someCollectionType)
        {
            List<Type> result = new List<Type>();

            List<string> internalTypeStrings = new List<string>();

            string typeString = string.Copy(_someCollectionType.ToString());

            if (typeString.EndsWith("[]")) //It is an array which has a different string format
                typeString = typeString.Remove(typeString.Length - 2);
            else
            {
                // Remove string from index 0 to the index with the first occurnce of '['
                for (int i = 0; i < typeString.Length; i++)
                {
                    if (typeString[i] == '[')
                    {
                        typeString = typeString.Remove(0, i + 1);
                        break;
                    }
                }

                // Remove the last string which should be ']'
                typeString = typeString.Remove(typeString.Length - 1);
            }

            while (typeString != string.Empty)
            {
                int openBracketsCount = 0;
                for (int i = 0; i < typeString.Length; i++)
                {
                    if (openBracketsCount == 0)
                    {
                        if (typeString[i] == ',')
                        {
                            internalTypeStrings.Add(typeString.Substring(0, i));
                            typeString = typeString.Remove(0, i + 1);
                            break;
                        }

                        if (typeString[i] == '[')
                            openBracketsCount++;
                    }
                    else
                    {
                        if (typeString[i] == '[')
                            openBracketsCount++;

                        if (typeString[i] == ']')
                            openBracketsCount--;
                    }

                    if (i == typeString.Length - 1)
                    {
                        internalTypeStrings.Add(typeString);
                        typeString = string.Empty;
                    }
                }
            }

            foreach (string internalTypeString in internalTypeStrings)
            {
                result.Add(Type.GetType(internalTypeString));
            }

            return result;
        }
    }

    public static class StringExtension
    {
        public static string Remove(this String _string, string _targetString)
        {
            return _string.Replace(_targetString, "");
        }

        public static string RemoveEscapeSequences(this String _string)
        {
            string result = _string;

            string[] escapeSequences = { "\a", "\b", "\f", "\n", "\r", "\t", "\v", "\'", "\"", "\\" };

            while (result.ContainsAny(escapeSequences))
            {
                foreach(string escapeSequence in escapeSequences)
                {
                    result = result.Remove(escapeSequence);
                }
            }

            return result;
        }

        public static bool ContainsAny(this String _string, string[] _strings)
        {
            foreach(string s in _strings)
            {
                if (_string.Contains(s))
                    return true;
            }

            return false;
        }

        public static bool ContainsAll(this String _string, string[] _strings)
        {
            foreach(string s in _strings)
            {
                if (!_string.Contains(s))
                    return false;
            }

            return true;
        }

        public static string DettachPortionFromString(this string _string, string _beginning, string _ending, ref string _dettachedPortion)
        {
            string copy = String.Copy(_string);

            int beginningIndex = copy.IndexOf(_beginning);
            int endingIndex = copy.IndexOfLastChar(_ending);
            int portionLength = endingIndex - beginningIndex + 1;

            _dettachedPortion = copy.Substring(beginningIndex, portionLength);

            return copy.Remove(beginningIndex, portionLength);
        }

        public static int IndexOfLastChar(this string _string, string _target)
        {
            return _string.IndexOf(_target) + _target.Length - 1;
        }

        public static object ToCorrespondingEnumValue(this string _string, Type _enumType)
        {
            if (_enumType.IsEnum)
            {
                foreach (var e in Enum.GetValues(_enumType))
                {
                    if (String.Compare(_string, e.ToString(), StringComparison.OrdinalIgnoreCase) == 0) //...if both strings are equal (ignoring the case)
                        return e;
                }
            }

            return null;
        }

        public static object ToCorrespondingEnumValue(this string _string, string _enumTypeString, string _nameSpaceWhereEnumsAreDefined)
        {
            try
            {
                Type enumType = Type.GetType(_nameSpaceWhereEnumsAreDefined + "." + _string);

                if (enumType.IsEnum)
                {
                    foreach (var e in Enum.GetValues(enumType))
                    {
                        if (String.Compare(_string, e.ToString(), StringComparison.OrdinalIgnoreCase) == 0) //...if both strings are equal (ignoring the case)
                            return e;
                    }
                }

                return null;
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        public static T ToCorrespondingEnumValue<T>(this string _string)
        {
            if (typeof(T).IsEnum)
            {
                foreach (T e in Enum.GetValues(typeof(T)))
                {
                    if (String.Compare(_string, e.ToString(), StringComparison.OrdinalIgnoreCase) == 0) //...if both strings are equal (ignoring the case)
                        return e;
                }
            }

            return default(T);
        }
    }

    public static class DecimalExtension
    {
        public static int Ceiling(this decimal _decimal) { return Convert.ToInt32(decimal.Ceiling(_decimal)); }

        public static int Floor(this decimal _decimal) { return Convert.ToInt32(decimal.Floor(_decimal)); }

        public static decimal Pow(this decimal _decimal, decimal _y)
        {
            decimal result = 1.0m;

            for (int i = 0; i < _y; i++)
            {
                result *= _decimal;
            }

            return result;
        }

        public static decimal Reciprocal(this decimal _decimal)
        {
            decimal result = _decimal;

            result = 1.0m / result;

            return result;
        }
    }

    public static class ArrayExtension
    {
        /// <summary>
        /// Returns empty Array if T is a non-IDeepCopyable class or a struct
        /// </summary>
        public static T[] DeepCopy<T>(this T[] _array)
        {
            T[] copy = new T[0];

            object[] tmp_copy = new object[0];

            if (_array != null && _array.Length != 0)
            {
                copy = new T[_array.Length];

                Type type = _array[0].GetType();

                if (type.IsArray)
                {
                    for (int i = 0; i < _array.Length; i++) { tmp_copy[i] = (_array[i].ToArray<object>()).DeepCopy(); }
                }
                else if (type.IsList())
                {
                    for (int i = 0; i < _array.Length; i++) { tmp_copy[i] = (_array[i].ToList<object>()).DeepCopy(); }
                }
                else if (type.IsDictionary())
                {
                    for (int i = 0; i < _array.Length; i++) { tmp_copy[i] = _array[i].ToDictionary<object, object>().DeepCopy(); ; }
                }
                else if (type == typeof(string))
                {
                    for (int i = 0; i < _array.Length; i++) { tmp_copy[i] = string.Copy(_array[i] as string); }
                }
                else if (type.IsIDeepCopyable())
                {
                    for (int i = 0; i < _array.Length; i++) { tmp_copy[i] = _array[i].DeepCopy(); }
                }
                else if (type.IsValueType) //It actually is a shallow copy
                {
                    copy = (T[])_array.Clone(); //Set value directly to copy variable, instead of tmp_copy variable
                }
            }

            if (tmp_copy.Count() > 0)
                copy = tmp_copy.ToArray<T>();

            return copy;
        }
    }

    public static class ListExtension
    {
        /// <summary>
        /// Returns empty List if T is a non-IDeepCopyable class or a struct
        /// </summary>
        public static List<T> DeepCopy<T>(this List<T> _list)
        {
            List<object> copy = new List<object>();

            if (_list != null && _list.Count != 0)
            {
                Type type = _list[0].GetType();

                if (type.IsList())
                    _list.ForEach(x => copy.Add((x.ToList<object>()).DeepCopy()));
                else if (type.IsArray)
                    _list.ForEach(x => copy.Add((x.ToArray<object>()).DeepCopy()));
                else if (type.IsDictionary())
                    _list.ForEach(x => copy.Add(x.ToDictionary<object, object>().DeepCopy()));
                else if (type == typeof(string))
                    _list.ForEach(x => copy.Add(string.Copy((x as string))));
                else if (type.IsIDeepCopyable())
                    _list.ForEach(x => copy.Add(x.DeepCopy()));
                else if (type.IsValueType && !type.Is_struct())
                    _list.ForEach(x => copy.Add(x)); //It actually is a shallow copy
            }

            return copy.ToList<T>();
        }
    }

    public static class DictionaryExtension
    {
        public static ReadOnlyDictionary<T, U> AsReadOnly<T, U>(this Dictionary<T, U> _this) { return new ReadOnlyDictionary<T, U>(_this); }

        public static List<T> GetKeysWithValue<T, U>(this Dictionary<T, U> _this, U _value)
        {
            List<T> keys = new List<T>();
            foreach (var entry in _this)
            {
                if (entry.Value.Equals(_value))
                    keys.Add(entry.Key);
            }

            return keys;
        }

        /// <summary>
        /// Returns empty Dictionary if T or U is a non-IDeepCopyable class or a struct
        /// </summary>
        public static Dictionary<T, U> DeepCopy<T, U>(this Dictionary<T, U> _dictionary)
        {
            Dictionary<object, object> copy = new Dictionary<object, object>();

            if (_dictionary != null && _dictionary.Count != 0)
            {
                // In case T and U are object, T and U might not be the actual types.
                // Therefore, get directly the types from _dictionary's key and value
                Type tType = _dictionary.Keys.First().GetType();
                Type uType = _dictionary.Values.First().GetType();

                foreach (var entry in _dictionary)
                {
                    object key = null;
                    object value = null;

                    if (tType.IsDictionary())
                        key = entry.Key.ToDictionary<object, object>().DeepCopy();
                    else if (tType.IsArray)
                        key = (entry.Key.ToArray<object>()).DeepCopy();
                    else if (tType.IsList())
                        key = (entry.Key.ToList<object>()).DeepCopy();
                    else if (tType == typeof(string))
                        key = String.Copy(entry.Key as string);
                    else if (tType.IsIDeepCopyable())
                        key = entry.Key.DeepCopy();
                    else if (tType.IsValueType && !tType.Is_struct())
                        key = entry.Key; //It actually is a shallow copy

                    if (uType.IsDictionary())
                        value = entry.Value.ToDictionary<object, object>().DeepCopy();
                    else if (uType.IsArray)
                        value = (entry.Value.ToArray<object>()).DeepCopy();
                    else if (uType.IsList())
                        value = (entry.Value.ToList<object>()).DeepCopy();
                    else if (uType == typeof(string))
                        value = String.Copy(entry.Value as string);
                    else if (uType.IsIDeepCopyable())
                        value = entry.Value.DeepCopy();
                    else if (uType.IsValueType && !uType.Is_struct())
                        value = entry.Value; //It actually is a shallow copy

                    copy.Add(key, value);
                }
            }

            return copy.ToDictionary(x => x.Key.ToT<T>(), x => x.Value.ToT<U>());
        }
    }

    public static class NullPreventionAssignmentMethods
    {
        public static string CoalesceNullAndReturnCopyOptionally(this string _this, bool _returnCopyInstead = false)
        {
            if (_this != null)
            {
                if (_returnCopyInstead)
                    return string.Copy(_this);
                else
                    return _this;
            }
            else
                return string.Empty;
        }

        public static T[] CoalesceNullAndReturnCopyOptionally<T>(this T[] _this, eCopyType _copyType = eCopyType.None)
        {
            if (_this != null)
            {
                switch (_copyType)
                {
                    case eCopyType.Shallow:
                        return (T[])_this.Clone();
                    case eCopyType.Deep:
                        return _this.DeepCopy();
                    default:
                        return _this;
                }
            }
            else
                return new T[0];
        }

        public static List<T> CoalesceNullAndReturnCopyOptionally<T>(this List<T> _this, eCopyType _copyType = eCopyType.None)
        {
            if (_this != null)
            {
                switch (_copyType)
                {
                    case eCopyType.Shallow:
                        return new List<T>(_this);
                    case eCopyType.Deep:
                        return _this.DeepCopy();
                    default:
                        return _this;
                }
            }
            else
                return new List<T>();
        }

        public static Dictionary<T, U> CoalesceNullAndReturnCopyOptionally<T, U>(this Dictionary<T, U> _this, eCopyType _copyType = eCopyType.None)
        {
            if (_this != null)
            {
                switch (_copyType)
                {
                    case eCopyType.Shallow:
                        return new Dictionary<T, U>(_this);
                    case eCopyType.Deep:
                        return _this.DeepCopy();
                    default:
                        return _this;
                }
            }
            else
                return new Dictionary<T, U>();
        }
    }

    public enum eCopyType
    {
        None,
        Shallow,
        Deep
    }
}

namespace EEANGames.TBSG._01.ExtensionMethods
{
    public static class StringExtension
    {
        public static Type ToCorrespondingEnumType(this string _string)
        {
            try
            {
                string nameSpace = "EEANGames.TBSG._01.CommonEnums";

                return Type.GetType(nameSpace + "." + _string);
            }
            catch (Exception ex)
            {
                return default(Type);
            }
        }

        public static object ToCorrespondingEnumValue(this string _string, string _enumTypeString)
        {
            try
            {
                Type enumType = _enumTypeString.ToCorrespondingEnumType();

                if (enumType.IsEnum)
                {
                    foreach (var e in Enum.GetValues(enumType))
                    {
                        if (String.Compare(_string, e.ToString(), StringComparison.OrdinalIgnoreCase) == 0) //...if both strings are equal (ignoring the case)
                            return e;
                    }
                }

                return null;
            }
            catch (Exception ex)
            {
                return null;
            }
        }
    }

    public static class IntExtension
    {
        public static _2DCoord To2DCoord(this int _index)
        {
            if (_index < 0)
                return null;

            return new _2DCoord(_index % CoreValues.SIZE_OF_A_SIDE_OF_BOARD, _index / CoreValues.SIZE_OF_A_SIDE_OF_BOARD);
        }
    }

    public static class _2DCoordExtension
    {
        public static int ToIndex(this _2DCoord _coord) { return CoreValues.SIZE_OF_A_SIDE_OF_BOARD * _coord.Y + _coord.X; }
    }

    public static class NullPreventionAssignmentMethods
    {
        public static _2DCoord CoalesceNullAndReturnCopyOptionally(this _2DCoord _this, bool _returnCopyInstead = false)
        {
            if (_this != null)
            {
                if (_returnCopyInstead)
                    return _this.DeepCopy();
                else
                    return _this;
            }
            else
                return new _2DCoord(default(int), default(int));
        }

        public static PlayerOnBoard CoalesceNull(this PlayerOnBoard _this)
        {
            if (_this != null)
                return _this;
            else
                return new PlayerOnBoard(null, default(int), default(bool));
        }

        public static UnitData CoalesceNullAndReturnDeepCopyOptionally(this UnitData _this, bool _returnDeepCopyInstead = false)
        {
            if (_this != null)
            {
                if (_returnDeepCopyInstead)
                    return _this.DeepCopy();
                else
                    return _this;
            }
            else
                return new UnitData(default(int), string.Empty, null, default(eGender), default(eRarity), default(eTargetRangeClassification), default(eTargetRangeClassification), null, null, null, null, default(int), default(int), default(int), default(int), default(int), default(int), null, null, string.Empty);
        }

        public static Unit CoalesceNullAndReturnDeepCopyOptionally(this Unit _this, bool _returnDeepCopyInstead = false)
        {
            if (_this != null)
            {
                if (_returnDeepCopyInstead)
                    return (_this as IDeepCopyable<Unit>).DeepCopy();
                else
                    return _this;
            }
            else
                return new Unit(null, default(int), string.Empty, default(int), default(List<Skill>));
        }

        public static UnitInstance CoalesceNullAndReturnDeepCopyOptionally(this UnitInstance _this, bool _returnDeepCopyInstead = false)
        {
            if (_this != null)
            {
                if (_returnDeepCopyInstead)
                    return (_this as IDeepCopyable<UnitInstance>).DeepCopy();
                else
                    return _this;
            }
            else
                return new UnitInstance(new Unit(null, default(int), string.Empty, default(int), default(List<Skill>)), null, null, null, null, null);
        }

        public static WeaponData CoalesceNullAndReturnDeepCopyOptionally(this WeaponData _this, bool _returnDeepCopyInstead = false)
        {
            if (_this != null)
            {
                if (_returnDeepCopyInstead)
                    return (_this as IDeepCopyable<WeaponData>).DeepCopy();
                else
                    return _this;
            }
            else
                return new WeaponData(default(int), string.Empty, null, default(eRarity), null, default(eWeaponType), null, null);
        }

        public static ArmourData CoalesceNullAndReturnDeepCopyOptionally(this ArmourData _this, bool _returnDeepCopyInstead = false)
        {
            if (_this != null)
            {
                if (_returnDeepCopyInstead)
                    return (_this as IDeepCopyable<ArmourData>).DeepCopy();
                else
                    return _this;
            }
            else
                return new ArmourData(default(int), string.Empty, null, default(eRarity), null, default(eArmourClassification), default(eGender));
        }

        public static AccessoryData CoalesceNullAndReturnDeepCopyOptionally(this AccessoryData _this, bool _returnDeepCopyInstead = false)
        {
            if (_this != null)
            {
                if (_returnDeepCopyInstead)
                    return (_this as IDeepCopyable<AccessoryData>).DeepCopy();
                else
                    return _this;
            }
            else
                return new AccessoryData(default(int), string.Empty, null, default(eRarity), null, default(eAccessoryClassification), default(eGender));
        }

        //public static Weapon DeepCopy(this Weapon _this)
        //{
        //    if (_this is OrdinaryWeapon) return (_this as IDeepCopyable<OrdinaryWeapon>).DeepCopy();
        //    else if (_this is LevelableWeapon) return (_this as IDeepCopyable<LevelableWeapon>).DeepCopy();
        //    else if (_this is TransformableWeapon) return (_this as IDeepCopyable<TransformableWeapon>).DeepCopy();
        //    else /*(_this is LevelableTransformableWeapon)*/ return (_this as IDeepCopyable<LevelableTransformableWeapon>).DeepCopy();
        //}

        //public static Item DeepCopy(this Item _this)
        //{
        //    if (_this is SkillItem) return (_this as IDeepCopyable<SkillItem>).DeepCopy();
        //    else if (_this is SkillMaterial) return (_this as IDeepCopyable<SkillMaterial>).DeepCopy();
        //    else if (_this is ItemMaterial) return (_this as IDeepCopyable<ItemMaterial>).DeepCopy();
        //    else if (_this is EquipmentMaterial) return (_this as IDeepCopyable<EquipmentMaterial>).DeepCopy();
        //    else /*(_this is EvolutionMaterial)*/ return (_this as IDeepCopyable<EvolutionMaterial>).DeepCopy();
        //}

        //public static Armour CoalesceNullAndReturnDeepCopyOptionally(this Armour _this, bool _returnDeepCopyInstead = false)
        //{
        //    if (_this != null)
        //    {
        //        if (_returnDeepCopyInstead)
        //            return _this.DeepCopy();
        //        else
        //            return _this;
        //    }
        //    else
        //        return new Armour(null, -1);
        //}

        //public static Accessory CoalesceNullAndReturnDeepCopyOptionally(this Accessory _this, bool _returnDeepCopyInstead = false)
        //{
        //    if (_this != null)
        //    {
        //        if (_returnDeepCopyInstead)
        //            return _this.DeepCopy();
        //        else
        //            return _this;
        //    }
        //    else
        //        return new Accessory(null, -1);
        //}

        public static SkillData CoalesceNullAndReturnDeepCopyOptionally(this SkillData _this, bool _returnDeepCopyInstead = false)
        {
            if (_this != null)
            {
                if (_returnDeepCopyInstead)
                    return (_this as IDeepCopyable<SkillData>).DeepCopy();

                return _this;
            }
            else
            {
                if (_this is OrdinarySkillData) { return new OrdinarySkillData(default(int), string.Empty, null, null, default(int), null, null, default(int), null); }
                else if (_this is CounterSkillData) { return new CounterSkillData(default(int), string.Empty, null, null, default(int), null, null, default(int), null, default(eEventTriggerTiming), null); }
                else if (_this is UltimateSkillData) { return new UltimateSkillData(default(int), string.Empty, null, null, default(int), null, null); }
                else /*(_this is PassiveSkillData)*/ { return new PassiveSkillData(default(int), string.Empty, null, null, default(int), default(eTargetUnitClassification), null); }
            }
        }

        public static Skill CoalesceNullAndReturnDeepCopyOptionally(this Skill _this, bool _returnDeepCopyInstead = false)
        {
            if (_this != null)
            {
                if (_returnDeepCopyInstead)
                    return (_this as IDeepCopyable<Skill>).DeepCopy();

                return _this;
            }
            else
            {
                if (_this is OrdinarySkill) { return new OrdinarySkill(null, default(int)); }
                else if (_this is CounterSkill) { return new CounterSkill(null, default(int)); }
                else if (_this is UltimateSkill) { return new UltimateSkill(null, default(int)); }
                else /*(_this is 
                )*/ { return new PassiveSkill(null, default(int)); }
            }
        }

        //public static Skill DeepCopy(this Skill _this)
        //{
        //    if (_this is OrdinarySkill) return (_this as IDeepCopyable<OrdinarySkill>).DeepCopy();
        //    else if (_this is CounterSkill) return (_this as IDeepCopyable<CounterSkill>).DeepCopy();
        //    else if (_this is UltimateSkill) return (_this as IDeepCopyable<UltimateSkill>).DeepCopy();
        //    else /*(_this is PassiveSkill)*/ return (_this as IDeepCopyable<PassiveSkill>).DeepCopy();
        //}

        public static Effect CoalesceNullAndReturnDeepCopyOptionally(this Effect _this, bool _returnDeepCopyInstead = false)
        {
            if (_this != null)
            {
                if (_returnDeepCopyInstead)
                    return (_this as IDeepCopyable<Effect>).DeepCopy();

                return _this;
            }
            else
            {
                if (_this is DamageEffect) { return new DamageEffect(default(int), null, null, null, null, null, default(int), default(eTargetUnitClassification), default(eAttackClassification), null, default(bool), default(eElement)); }
                else if (_this is HealEffect) { return new HealEffect(default(int), null, null, null, null, null, default(int), default(eTargetUnitClassification), null, default(bool)); }
                else if (_this is StatusEffectAttachmentEffect) { return new StatusEffectAttachmentEffect(default(int), null, null, null, null, null, default(int), default(eTargetUnitClassification), null); }
                else if (_this is UnitSwapEffect) { return new UnitSwapEffect(default(int), null, null, null, default(int), default(eTargetUnitClassification)); }
                else if (_this is DrainEffect) { return new DrainEffect(default(int), null, null, null, null, null, default(int), default(eTargetUnitClassification), default(eAttackClassification), null, default(bool), default(eElement)); }
                else if (_this is TileTrapEffect) { return new TileTrapEffect(default(int), null, null, null, null, null, default(int), null); }
                else /*(_this is TileSwapEffect)*/ { return new TileSwapEffect(default(int), null, null, null, null, null, default(int)); }
            }
        }

        public static StatusEffectData CoalesceNullAndReturnDeepCopyOptionally(this StatusEffectData _this, bool _returnDeepCopyInstead = false)
        {
            if (_this != null)
            {
                if (_returnDeepCopyInstead)
                    return (_this as IDeepCopyable<StatusEffectData>).DeepCopy();

                return _this;
            }
            else
            {
                if (_this is BuffStatusEffectData) { return new BuffStatusEffectData(default(int), null, default(eActivationTurnClassification), null, null, default(eStatusType), null, default(bool)); }
                else if (_this is DebuffStatusEffectData) { return new DebuffStatusEffectData(default(int), null, default(eActivationTurnClassification), null, null, default(eStatusType), null, default(bool)); }
                else if (_this is TargetRangeModStatusEffectData) { return new TargetRangeModStatusEffectData(default(int), null, default(eActivationTurnClassification), null, null, default(bool), default(eTargetRangeClassification), default(eModificationMethod)); }
                else if (_this is DamageStatusEffectData) { return new DamageStatusEffectData(default(int), null, default(eActivationTurnClassification), default(eEventTriggerTiming), null, null, default(int), null); }
                else /*(_this is HealStatusEffectData)*/ { return new HealStatusEffectData(default(int), null, default(eActivationTurnClassification), default(eEventTriggerTiming), null, null, default(int), null); }
            }
        }

        public static StatusEffect CoalesceNullAndReturnDeepCopyOptionally(this StatusEffect _this, bool _returnDeepCopyInstead = false)
        {
            if (_this != null)
            {
                if (_returnDeepCopyInstead)
                    return (_this as IDeepCopyable<StatusEffect>).DeepCopy();

                return _this;
            }
            else
            {
                if (_this is BuffStatusEffect) { return new BuffStatusEffect(null, default(eActivationTurnClassification), null, null, default(eStatusType), null, default(bool)); }
                else if (_this is DebuffStatusEffect) { return new DebuffStatusEffect(null, default(eActivationTurnClassification), null, null, default(eStatusType), null, default(bool)); }
                else if (_this is TargetRangeModStatusEffect) { return new TargetRangeModStatusEffect(null, default(eActivationTurnClassification), null, null, default(bool), default(eTargetRangeClassification), default(eModificationMethod)); }
                else if (_this is DamageStatusEffect) { return new DamageStatusEffect(null, default(eActivationTurnClassification), default(eEventTriggerTiming), null, null, default(int), null); }
                else /*(_this is HealStatusEffect)*/ { return new HealStatusEffect(null, default(eActivationTurnClassification), default(eEventTriggerTiming), null, null, default(int), null); }
            }
        }

        //public static StatusEffect DeepCopy(this StatusEffect _this)
        //{
        //    if (_this is BuffStatusEffect) return (_this as IDeepCopyable<BuffStatusEffect>).DeepCopy();
        //    else if (_this is DebuffStatusEffect) return (_this as IDeepCopyable<DebuffStatusEffect>).DeepCopy();
        //    else if (_this is TargetRangeModStatusEffect) return (_this as IDeepCopyable<TargetRangeModStatusEffect>).DeepCopy();
        //    else if (_this is DamageStatusEffect) return (_this as IDeepCopyable<DamageStatusEffect>).DeepCopy();
        //    else /*(_this is HealStatusEffect)*/ return (_this as IDeepCopyable<HealStatusEffect>).DeepCopy();
        //}

        public static DurationData CoalesceNullAndReturnDeepCopyOptionally(this DurationData _this, bool _returnDeepCopyInstead = false)
        {
            if (_this != null)
            {
                if (_returnDeepCopyInstead)
                    return _this.DeepCopy();
                else
                    return _this;
            }
            else
                return new DurationData(null, null, null);
        }

        public static Duration CoalesceNullAndReturnDeepCopyOptionally(this Duration _this, bool _returnDeepCopyInstead = false)
        {
            if (_this != null)
            {
                if (_returnDeepCopyInstead)
                    return _this.DeepCopy();
                else
                    return _this;
            }
            else
                return new Duration(default(int), default(int), null);
        }

        public static Tag CoalesceNullAndReturnDeepCopyOptionally(this Tag _this, bool _returnDeepCopyInstead = false)
        {
            if (_this != null)
            {
                if (_returnDeepCopyInstead)
                    return _this.DeepCopy();
                else
                    return _this;
            }
            else
                return Tag.NewTag(string.Empty);
        }

        public static ComplexCondition CoalesceNullAndReturnDeepCopyOptionally(this ComplexCondition _this, bool _returnDeepCopyInstead = false)
        {
            if (_this != null)
            {
                if (_returnDeepCopyInstead)
                    return _this.DeepCopy();
                else
                    return _this;
            }
            else
                return new ComplexCondition(null);
        }
    }
}
