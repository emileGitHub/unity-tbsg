﻿using EEANGames.ExtensionMethods;
using EEANGames.TBSG._01.CommonEnums;
using EEANGames.TBSG._01.ExtensionMethods;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;

namespace EEANGames.TBSG._01.MainClassLib
{
    public abstract class EventLog
    {
        public EventLog(decimal _eventTurn)
        {
            EventTurn = _eventTurn;
        }

        #region Properties
        public decimal EventTurn { get; }
        #endregion
    }

    public abstract class ActionLog : EventLog
    {
        public ActionLog(decimal _actionTurn, int _actorId, string _actorName, string _actorNickname) : base(_actionTurn)
        {
            ActorId = _actorId;
            ActorName = _actorName.CoalesceNullAndReturnCopyOptionally(true);
            ActorNickname = _actorNickname.CoalesceNullAndReturnCopyOptionally(true);
        }

        #region Properties
        public int ActorId { get; }
        public string ActorName { get; }
        public string ActorNickname { get; }
        #endregion
    }

    public abstract class AutomaticEventLog : EventLog
    {
        public AutomaticEventLog(decimal _eventTurn) : base(_eventTurn)
        {
        }
    }

    public class TurnChangeEventLog : AutomaticEventLog
    {
        public TurnChangeEventLog(decimal _eventTurn,
            int _turnEndingPlayerId, int _turnInitiatingPlayerId) : base(_eventTurn)
        {
            TurnEndingPlayerId = _turnEndingPlayerId;
            TurnInitiatingPlayerId = _turnInitiatingPlayerId;
        }

        #region Properties
        public int TurnEndingPlayerId { get; }
        public int TurnInitiatingPlayerId { get; }
        #endregion
    }

    //public class PassiveSkillLog : AutomaticEventLog
    //{


    //    #region Properties
    //    public UnitInstance SkillOwner { get; private set; }
    //    #endregion
    //}

    //public class TileTrapLog : AutomaticEventLog
    //{

    //}

    public abstract class StatusEffectLog : AutomaticEventLog
    {
        public StatusEffectLog(decimal _eventTurn,
            int _effectHolderId, string _effectHolderName, string _effectHolderNickname) : base(_eventTurn)
        {
            EffectHolderId = _effectHolderId;
            EffectHolderName = _effectHolderName.CoalesceNullAndReturnCopyOptionally(true);
            EffectHolderNickname = _effectHolderNickname.CoalesceNullAndReturnCopyOptionally(true);
        }

        #region Properties
        public int EffectHolderId { get; }
        public string EffectHolderName { get; }
        public string EffectHolderNickname { get; }
        #endregion
    }

    public class StatusEffectLog_HPModification : StatusEffectLog
    {
        public StatusEffectLog_HPModification(decimal _eventTurn, int _effectHolderId, string _effectHolderName, string _effectHolderNickname,
            bool _isPositive, int _value, int _remainingHPAfterModification) : base(_eventTurn, _effectHolderId, _effectHolderName, _effectHolderNickname)
        {
            IsPositive = _isPositive;
            Value = _value;
            RemainingHPAfterModification = _remainingHPAfterModification;
        }

        #region Properties
        public bool IsPositive { get; } // If true, Value represents the amout healed. If false, Value represents the damage dealt. Both healing and damaging value can be zero.
        public int Value { get; }
        public int RemainingHPAfterModification { get; }
        #endregion
    }

    public class ActionLog_Move : ActionLog
    {
        public ActionLog_Move(decimal _actionTurn, int _actorId, string _actorName, string _actorNickname,
            _2DCoord _initialCoord, _2DCoord _eventualCoord) : base(_actionTurn, _actorId, _actorName, _actorNickname)
        {
            InitialCoord = _initialCoord.CoalesceNullAndReturnCopyOptionally(true);
            EventualCoord = _eventualCoord.CoalesceNullAndReturnCopyOptionally(true);
        }

        #region Properties
        public _2DCoord InitialCoord { get; }
        public _2DCoord EventualCoord { get; }
        #endregion
    }

    public class ActionLog_Attack : ActionLog
    {
        public ActionLog_Attack(decimal _actionTurn, int _actorId, string _actorName, string _actorNickname,
            int _actorLocationTileIndex, int _targetId, int _targetLocationTileIndex) : base(_actionTurn, _actorId, _actorName, _actorNickname)
        {
            ActorLocationTileIndex = _actorLocationTileIndex;
            TargetId = _targetId;
            TargetLocationTileIndex = _targetLocationTileIndex;
        }

        #region Properties
        public int ActorLocationTileIndex { get; }
        public int TargetId { get; }
        public int TargetLocationTileIndex { get; }
        #endregion
    }

    public abstract class ActionLog_Skill : ActionLog
    {
        public ActionLog_Skill(decimal _actionTurn, int _actorId, string _actorName, string _actorNickname,
            string _skillName, int _actorLocationTileIndex, int _animationId) : base(_actionTurn, _actorId, _actorName, _actorNickname)
        {
            SkillName = _skillName.CoalesceNullAndReturnCopyOptionally(true);

            ActorLocationTileIndex = _actorLocationTileIndex;

            AnimationId = _animationId;
        }

        #region Properties
        public string SkillName { get; }

        public int ActorLocationTileIndex { get; }

        public int AnimationId { get; }
        #endregion
    }

    public class ActionLog_UnitTargetingSkill : ActionLog_Skill
    {
        public ActionLog_UnitTargetingSkill(decimal _actionTurn, int _actorId, string _actorName, string _actorNickname, string _skillName, int _actorLocationTileIndex, int _animationId,
            List<Tuple<string, string, string>> _targetsName_Nickname_OwnerName) : base(_actionTurn, _actorId, _actorName, _actorNickname, _skillName, _actorLocationTileIndex, _animationId)
        {
            m_targetsName_Nickname_OwnerName = _targetsName_Nickname_OwnerName.CoalesceNullAndReturnCopyOptionally(eCopyType.Deep);
        }

        #region Properties
        public IList<Tuple<string, string, string>> TargetsName_Nickname_OwnerName { get { return m_targetsName_Nickname_OwnerName.AsReadOnly(); } }
        #endregion

        #region Private Fields
        private List<Tuple<string, string, string>> m_targetsName_Nickname_OwnerName;
        #endregion
    }

    public class ActionLog_TileTargetingSkill : ActionLog_Skill
    {
        public ActionLog_TileTargetingSkill(decimal _actionTurn, int _actorId, string _actorName, string _actorNickname, string _skillName, int _actorLocationTileIndex, int _animationId,
            List<_2DCoord> _targetCoords) : base(_actionTurn, _actorId, _actorName, _actorNickname, _skillName, _actorLocationTileIndex, _animationId)
        {
            m_targetCoords = _targetCoords.CoalesceNullAndReturnCopyOptionally(eCopyType.Deep);
        }

        #region Properties
        public IList<_2DCoord> TargetCoords { get { return m_targetCoords.AsReadOnly(); } }
        #endregion

        #region Private Fields
        private List<_2DCoord> m_targetCoords;
        #endregion
    }

    public abstract class EffectTrialLog : AutomaticEventLog
    {
        public EffectTrialLog(decimal _eventTurn,
            int _animationId, bool _didSucceed) : base(_eventTurn)
        {
            AnimationId = _animationId;

            DidSucceed = _didSucceed;
        }

        #region Properties
        public int AnimationId { get; }

        public bool DidSucceed { get; }
        #endregion
    }

    public abstract class EffectTrialLog_UnitTargetingEffect : EffectTrialLog
    {
        public EffectTrialLog_UnitTargetingEffect(decimal _eventTurn, int _animationId, bool _didSucceed,
            int _targetId, string _targetName, string _targetNickname, int _targetLocationTileIndex) : base(_eventTurn, _animationId, _didSucceed)
        {
            TargetId = _targetId;
            TargetName = _targetName.CoalesceNullAndReturnCopyOptionally(true);
            TargetNickname = _targetNickname.CoalesceNullAndReturnCopyOptionally(true);
            TargetLocationTileIndex = _targetLocationTileIndex;
        }

        #region Properties
        public int TargetId { get; }
        public string TargetName { get; }
        public string TargetNickname { get; }
        public int TargetLocationTileIndex { get; }
        #endregion
    }

    public class EffectTrialLog_DamageEffect : EffectTrialLog_UnitTargetingEffect
    {
        public EffectTrialLog_DamageEffect(decimal _eventTurn, int _animationId, bool _didSucceed, int _targetId, string _targetName, string _targetNickname, int _targetLocationTileIndex,
            bool _wasImmune, bool _wasCritical, eEffectiveness _effectiveness, int _value, int _remainingHPAfterModification) : base(_eventTurn, _animationId, _didSucceed, _targetId, _targetName, _targetNickname, _targetLocationTileIndex)
        {
            WasImmune = _wasImmune;
            WasCritical = _wasCritical;
            Effectiveness = _effectiveness;

            Value = _value;
            RemainingHPAfterModification = _remainingHPAfterModification;
        }

        #region Properties
        public bool WasImmune { get; }
        public bool WasCritical { get; }
        public eEffectiveness Effectiveness { get; }

        public int Value { get; }
        public int RemainingHPAfterModification { get; }
        #endregion
    }

    public class EffectTrialLog_HealEffect : EffectTrialLog_UnitTargetingEffect
    {
        public EffectTrialLog_HealEffect(decimal _eventTurn, int _animationId, bool _didSucceed, int _targetId, string _targetName, string _targetNickname, int _targetLocationTileIndex,
            bool _wasCritical, int _value, int _remainingHPAfterModification) : base(_eventTurn, _animationId, _didSucceed, _targetId, _targetName, _targetNickname, _targetLocationTileIndex)
        {
            WasCritical = _wasCritical;

            Value = _value;
            RemainingHPAfterModification = _remainingHPAfterModification;
        }

        #region Properties
        public bool WasCritical { get; }

        public int Value { get; }
        public int RemainingHPAfterModification { get; }
        #endregion
    }

    public class EffectTrialLog_StatusEffectAttachmentEffect : EffectTrialLog_UnitTargetingEffect
    {
        public EffectTrialLog_StatusEffectAttachmentEffect(decimal _eventTurn, int _animationId, bool _didSucceed, int _targetId, string _targetName, string _targetNickname, int _targetLocationTileIndex,
            int _attachedStatusEffectId) : base(_eventTurn, _animationId, _didSucceed, _targetId, _targetName, _targetNickname, _targetLocationTileIndex)
        {
            AttachedStatusEffectId = _attachedStatusEffectId;
        }

        #region Properties
        public int AttachedStatusEffectId { get; }
        #endregion
    }
}
