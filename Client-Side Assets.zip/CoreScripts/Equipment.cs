﻿using EEANGames.ExtensionMethods;
using EEANGames.TBSG._01.CommonEnums;
using EEANGames.TBSG._01.ExtensionMethods;
using System;
using System.Collections.Generic;
using System.Linq;

namespace EEANGames.TBSG._01.MainClassLib
{
    public abstract class EquipmentData : IDeepCopyable<EquipmentData>, IRarityMeasurable
    {
        /// <summary>
        /// Ctor
        /// PreCondition: None.
        /// PostCondition: Will be initialized successfully.
        /// </summary>
        /// <param name="_id"></param>
        /// <param name="_name"></param>
        /// <param name="_rarity"></param>
        /// <param name="_statusEffectsData"></param>
        public EquipmentData(int _id, string _name, byte[] _iconAsBytes, eRarity _rarity, List<StatusEffectData> _statusEffectsData)
        {
            Id = _id;

            Name = _name.CoalesceNullAndReturnCopyOptionally(true);

            m_iconAsBytes = _iconAsBytes.CoalesceNullAndReturnCopyOptionally(eCopyType.Deep);

            Rarity = _rarity;

            m_statusEffectsData = _statusEffectsData.CoalesceNullAndReturnCopyOptionally(eCopyType.Deep);
        }

        #region Properties
        public int Id { get; }
        public string Name { get; private set; }

        public IList<byte> IconAsBytes { get { return Array.AsReadOnly(m_iconAsBytes); } }

        public eRarity Rarity { get; }

        public IList<StatusEffectData> StatusEffectsData { get { return m_statusEffectsData.AsReadOnly(); } }
        #endregion

        #region Private Fields
        private byte[] m_iconAsBytes;

        private List<StatusEffectData> m_statusEffectsData;
        #endregion

        #region Public Methods
        EquipmentData IDeepCopyable<EquipmentData>.DeepCopy() { return (EquipmentData)DeepCopyInternally(); }
        #endregion

        #region Protected Methods
        protected virtual object DeepCopyInternally()
        {
            EquipmentData copy = (EquipmentData)this.MemberwiseClone();

            copy.Name = string.Copy(Name);

            copy.m_iconAsBytes = m_iconAsBytes.DeepCopy();

            copy.m_statusEffectsData = m_statusEffectsData.DeepCopy();

            return copy;
        }
        #endregion
    }

    public class WeaponData : EquipmentData, IDeepCopyable<WeaponData>, IRarityMeasurable
    {
        /// <summary>
        /// Ctor
        /// PreCondition: _weaponClassifications.Count > 0; _mainWeaponSkills.Count > 0; _cost > 0;
        /// PostCondition: Will be initialized successfully.
        /// </summary>
        /// <param name="_id"></param>
        /// <param name="_name"></param>
        /// <param name="_rarity"></param>
        /// <param name="_statusEffectsData"></param>
        /// <param name="_weaponType"></param>
        /// <param name="_weaponClassifications"></param>
        /// <param name="_mainWeaponSkill"></param>
        /// <param name="_cost"></param>
        /// <param name="_targetWeaponInCaseTypeIsTransformable"></param>
        public WeaponData(int _id, string _name, byte[] _iconAsBytes, eRarity _rarity, List<StatusEffectData> _statusEffectsData,
                eWeaponType _weaponType, List<eWeaponClassification> _weaponClassifications, Skill _mainWeaponSkill,
                    List<WeaponData> _targetWeaponInCaseTypeIsTransformable = null) : base(_id, _name, _iconAsBytes, _rarity, _statusEffectsData)
        {
            WeaponType = _weaponType;

            m_weaponClassifications = _weaponClassifications.CoalesceNullAndReturnCopyOptionally(eCopyType.Deep);

            MainWeaponSkill = _mainWeaponSkill;

            m_transformableWeapons = _targetWeaponInCaseTypeIsTransformable.CoalesceNullAndReturnCopyOptionally(eCopyType.Shallow);

            m_isTransformableWeaponsListModifiable = true;
        }

        #region Properties
        public eWeaponType WeaponType { get; }

        public IList<eWeaponClassification> WeaponClassifications { get { return m_weaponClassifications.AsReadOnly(); } }

        public Skill MainWeaponSkill { get; } // Can be null.

        //used if WeaponType == eWeaponType.TRANSFORMABLE
        public IList<WeaponData> TransformableWeapons
        {
            get
            {
                if (m_isTransformableWeaponsListModifiable)
                    return m_transformableWeapons;
                else
                    return m_transformableWeapons.AsReadOnly();
            }
        }
        #endregion

        #region Private Fields
        private List<eWeaponClassification> m_weaponClassifications;

        private List<WeaponData> m_transformableWeapons; //Store the reference to the original object

        private bool m_isTransformableWeaponsListModifiable;
        #endregion

        #region Public Methods
        public void DisableModification() { m_isTransformableWeaponsListModifiable = false; }

        WeaponData IDeepCopyable<WeaponData>.DeepCopy() { return (WeaponData)DeepCopyInternally(); }
        #endregion

        #region Protected Methods
        protected override object DeepCopyInternally()
        {
            WeaponData copy = (WeaponData)base.DeepCopyInternally();

            copy.m_weaponClassifications = m_weaponClassifications.DeepCopy();

            return copy;
        }
        #endregion
    }

    public abstract class Weapon : IDeepCopyable<Weapon>
    {
        public Weapon(int _id, string _name, byte[] _iconAsBytes, eRarity _rarity, List<StatusEffectData> _statusEffectsData, eWeaponType _weaponType, List<eWeaponClassification> _weaponClassifications, Skill _mainWeaponSkill,
                        int _uniqueId)
        {
            BaseInfo = new WeaponData(_id, _name, _iconAsBytes, _rarity, _statusEffectsData, _weaponType, _weaponClassifications, _mainWeaponSkill);

            UniqueId = _uniqueId;
        }

        /// <summary>
        /// Ctor 2
        /// PreCondition: _baseWeapon has been initialized successfully;
        /// PostCondition: Will be initialized successfully.
        /// </summary>
        /// <param name="_weaponData"></param>
        /// <param name="_uniqueId"></param>
        /// <param name="_accumulatedExpInCaseTypeIsLevelable"></param>
        public Weapon(WeaponData _weaponData, int _uniqueId)
        {
            BaseInfo = _weaponData.CoalesceNullAndReturnDeepCopyOptionally();

            UniqueId = _uniqueId;
        }

        #region Properties
        public WeaponData BaseInfo { get; } //Store reference to original instance

        public int UniqueId { get; }
        #endregion

        #region Public Methods
        Weapon IDeepCopyable<Weapon>.DeepCopy() { return (Weapon)DeepCopyInternally(); }
        #endregion

        #region Protected Methods
        protected virtual object DeepCopyInternally() { return (Weapon)this.MemberwiseClone(); }
        #endregion
    }

    public class OrdinaryWeapon : Weapon, IDeepCopyable<OrdinaryWeapon>
    {
        public OrdinaryWeapon(int _id, string _name, byte[] _iconAsBytes, eRarity _rarity, List<StatusEffectData> _statusEffectsData, List<eWeaponClassification> _weaponClassifications, Skill _mainWeaponSkill, int _uniqueId) : base(_id, _name, _iconAsBytes, _rarity, _statusEffectsData, eWeaponType.Ordinary, _weaponClassifications, _mainWeaponSkill, _uniqueId)
        {
        }

        public OrdinaryWeapon(WeaponData _weaponData, int _uniqueId) : base(_weaponData, _uniqueId)
        {
        }

        #region Public Methods
        OrdinaryWeapon IDeepCopyable<OrdinaryWeapon>.DeepCopy() { return (OrdinaryWeapon)DeepCopyInternally(); }
        #endregion

        #region Protected Methods
        protected override object DeepCopyInternally() { return (OrdinaryWeapon)base.DeepCopyInternally(); }
        #endregion
    }

    public class LevelableWeapon : Weapon, IDeepCopyable<LevelableWeapon>
    {
        public LevelableWeapon(int _id, string _name, byte[] _iconAsBytes, eRarity _rarity, List<StatusEffectData> _statusEffectsData, List<eWeaponClassification> _weaponClassifications, Skill _mainWeaponSkill, int _uniqueId,
            int _accumulatedExperience) : base(_id, _name, _iconAsBytes, _rarity, _statusEffectsData, eWeaponType.Levelable, _weaponClassifications, _mainWeaponSkill, _uniqueId)
        {
            if (_accumulatedExperience > 0)
                AccumulatedExperience = _accumulatedExperience;
            else
                AccumulatedExperience = 0;
        }

        public LevelableWeapon(WeaponData _weaponData, int _uniqueId, int _accumulatedExperience) : base(_weaponData, _uniqueId)
        {
            if (_accumulatedExperience > 0)
                AccumulatedExperience = _accumulatedExperience;
            else
                AccumulatedExperience = 0;
        }

        #region Properties
        public int AccumulatedExperience { get; private set; }
        #endregion

        #region Public Methods
        public void GainExperience(int _exp)
        {
            if (_exp <= 0 || AccumulatedExperience == int.MaxValue)
                return;

            if (AccumulatedExperience + _exp >= int.MaxValue)
                AccumulatedExperience = int.MaxValue;
            else
                AccumulatedExperience += _exp;
        }

        LevelableWeapon IDeepCopyable<LevelableWeapon>.DeepCopy() { return (LevelableWeapon)DeepCopyInternally(); }
        #endregion

        #region Protected Methods
        protected override object DeepCopyInternally() { return (LevelableWeapon)base.DeepCopyInternally(); }
        #endregion
    }

    public class TransformableWeapon : Weapon, IDeepCopyable<TransformableWeapon>
    {
        public TransformableWeapon(int _id, string _name, byte[] _iconAsBytes, eRarity _rarity, List<StatusEffectData> _statusEffectsData, List<eWeaponClassification> _weaponClassifications, Skill _mainWeaponSkill, int _uniqueId, 
            List<TransformableWeapon> _targetWeapons) : base(_id, _name, _iconAsBytes, _rarity, _statusEffectsData, eWeaponType.Transformable, _weaponClassifications, _mainWeaponSkill, _uniqueId)
        {
            m_transformableWeapons = _targetWeapons.CoalesceNullAndReturnCopyOptionally(eCopyType.Shallow);
        }

        public TransformableWeapon(WeaponData _weaponData, int _uniqueId) : base(_weaponData, _uniqueId)
        {
            List<TransformableWeapon> tmp_weaponPool = new List<TransformableWeapon>();
            tmp_weaponPool.Add(this);

            m_transformableWeapons = new List<TransformableWeapon>();
            foreach (WeaponData weaponData in _weaponData.TransformableWeapons)
            {
                m_transformableWeapons.Add(new TransformableWeapon(weaponData, UniqueId, tmp_weaponPool));
            }
        }

        private TransformableWeapon(WeaponData _weaponData, int _uniqueId,
            List<TransformableWeapon> _weaponsGenerated) : base(_weaponData, _uniqueId)
        {
            m_transformableWeapons = new List<TransformableWeapon>();
            foreach (WeaponData weaponData in _weaponData.TransformableWeapons)
            {
                if (!_weaponsGenerated.Any(x => x.BaseInfo.Id == weaponData.Id))
                    m_transformableWeapons.Add(new TransformableWeapon(weaponData, UniqueId, _weaponsGenerated));
                else
                    m_transformableWeapons.Add(_weaponsGenerated.First(x => x.BaseInfo.Id == weaponData.Id));
            }
        }

        #region Properties
        public IList<TransformableWeapon> TransformableWeapons { get { return m_transformableWeapons.AsReadOnly(); } }
        #endregion

        #region Private Fields
        private List<TransformableWeapon> m_transformableWeapons;
        #endregion

        #region Public Methods
        TransformableWeapon IDeepCopyable<TransformableWeapon>.DeepCopy() { return (TransformableWeapon)DeepCopyInternally(); }
        #endregion

        #region Protected Methods
        protected override object DeepCopyInternally()
        {
            TransformableWeapon copy = (TransformableWeapon)base.DeepCopyInternally();

            copy.m_transformableWeapons = m_transformableWeapons.DeepCopy();

            return copy;
        }
        #endregion
    }

    public class LevelableTransformableWeapon : Weapon, IDeepCopyable<LevelableTransformableWeapon>
    {
        public LevelableTransformableWeapon(int _id, string _name, byte[] _iconAsBytes, eRarity _rarity, List<StatusEffectData> _statusEffectsData, List<eWeaponClassification> _weaponClassifications, Skill _mainWeaponSkill, int _uniqueId,
            int _accumulatedExperience, List<LevelableTransformableWeapon> _targetWeapons) : base(_id, _name, _iconAsBytes, _rarity, _statusEffectsData, eWeaponType.Levelable, _weaponClassifications, _mainWeaponSkill, _uniqueId)
        {
            if (_accumulatedExperience > 0)
                AccumulatedExperience = _accumulatedExperience;
            else
                AccumulatedExperience = 0;

            m_transformableWeapons = _targetWeapons.CoalesceNullAndReturnCopyOptionally(eCopyType.Shallow);
        }

        public LevelableTransformableWeapon(WeaponData _weaponData, int _uniqueId,
            int _accumulatedExperience) : base(_weaponData, _uniqueId)
        {
            if (_accumulatedExperience > 0)
                AccumulatedExperience = _accumulatedExperience;
            else
                AccumulatedExperience = 0;

            List<LevelableTransformableWeapon> tmp_weaponPool = new List<LevelableTransformableWeapon>();
            tmp_weaponPool.Add(this);

            m_transformableWeapons = new List<LevelableTransformableWeapon>();
            foreach (WeaponData weaponData in _weaponData.TransformableWeapons)
            {
                m_transformableWeapons.Add(new LevelableTransformableWeapon(weaponData, UniqueId, _accumulatedExperience, tmp_weaponPool));
            }
        }

        private LevelableTransformableWeapon(WeaponData _weaponData, int _uniqueId,
            int _accumulatedExperience, List<LevelableTransformableWeapon> _weaponsGenerated) : base(_weaponData, _uniqueId)
        {
            if (_accumulatedExperience > 0)
                AccumulatedExperience = _accumulatedExperience;
            else
                AccumulatedExperience = 0;

            m_transformableWeapons = new List<LevelableTransformableWeapon>();
            foreach (WeaponData weaponData in _weaponData.TransformableWeapons)
            {
                if (!_weaponsGenerated.Any(x => x.BaseInfo.Id == weaponData.Id))
                    m_transformableWeapons.Add(new LevelableTransformableWeapon(weaponData, UniqueId, _accumulatedExperience, _weaponsGenerated));
                else
                    m_transformableWeapons.Add(_weaponsGenerated.First(x => x.BaseInfo.Id == weaponData.Id));
            }
        }

        #region Properties
        public int AccumulatedExperience { get; private set; }

        public IList<LevelableTransformableWeapon> TransformableWeapons { get { return m_transformableWeapons.AsReadOnly(); } }
        #endregion

        #region Private Fields
        private List<LevelableTransformableWeapon> m_transformableWeapons;
        #endregion

        #region Public Methods
        public void GainExperience(int _exp)
        {
            if (_exp <= 0 || AccumulatedExperience == int.MaxValue)
                return;

            if (AccumulatedExperience + _exp >= int.MaxValue)
                AccumulatedExperience = int.MaxValue;
            else
                AccumulatedExperience += _exp;
        }

        LevelableTransformableWeapon IDeepCopyable<LevelableTransformableWeapon>.DeepCopy() { return (LevelableTransformableWeapon)DeepCopyInternally(); }
        #endregion

        #region Protected Methods
        protected override object DeepCopyInternally() { return (LevelableTransformableWeapon)base.DeepCopyInternally(); }
        #endregion
    }

    public class ArmourData : EquipmentData, IDeepCopyable<ArmourData>, IRarityMeasurable
    {
        /// <summary>
        /// Ctor
        /// PreCondition: _skills.Count > 0.        
        /// PostCondition: Will be initialized successfully.
        /// </summary>
        /// <param name="_id"></param>
        /// <param name="_name"></param>
        /// <param name="_rarity"></param>
        /// <param name="_statusEffectsData"></param>
        /// <param name="_armourClassification"></param>
        /// <param name="_targetGender"></param>
        public ArmourData(int _id, string _name, byte[] _iconAsBytes, eRarity _rarity, List<StatusEffectData> _statusEffectsData,
            eArmourClassification _armourClassification, eGender _targetGender) : base(_id, _name, _iconAsBytes, _rarity, _statusEffectsData)
        {
            ArmourClassification = _armourClassification;
            TargetGender = _targetGender;
        }

        #region Properties
        public eArmourClassification ArmourClassification { get; }

        public eGender TargetGender { get; }
        #endregion

        #region Public Methods
        ArmourData IDeepCopyable<ArmourData>.DeepCopy() { return (ArmourData)DeepCopyInternally(); }
        #endregion

        #region Protected Methods
        protected override object DeepCopyInternally() { return (ArmourData)base.DeepCopyInternally(); }
        #endregion
    }

    public class Armour : IDeepCopyable<Armour>
    {
        /// <summary>
        /// Ctor 1
        /// PreCondition: _skills.Count > 0;
        /// PostCondition: Will be initialized successfully.
        /// </summary>
        /// <param name="_id"></param>
        /// <param name="_name"></param>
        /// <param name="_rarity"></param>
        /// <param name="_statusEffectsData"></param>
        /// <param name="_armourClassification"></param>
        /// <param name="_targetGender"></param>
        /// <param name="_uniqueId"></param>
        public Armour(int _id, string _name, byte[] _iconAsBytes, eRarity _rarity, List<StatusEffectData> _statusEffectsData, eArmourClassification _armourClassification, eGender _targetGender,
                        int _uniqueId)
        {
            BaseInfo = new ArmourData(_id, _name, _iconAsBytes, _rarity, _statusEffectsData, _armourClassification, _targetGender);

            UniqueId = _uniqueId;
        }

        /// <summary>
        /// Ctor 2
        /// PreCondition: _baseArmour has been initialized successfully.
        /// PostCondition: Will be initialized successfully.
        /// </summary>
        /// <param name="_armourData"></param>
        /// <param name="_uniqueId"></param>
        public Armour(ArmourData _armourData, int _uniqueId)
        {
            BaseInfo = _armourData.CoalesceNullAndReturnDeepCopyOptionally();

            UniqueId = _uniqueId;
        }

        #region Properties
        public ArmourData BaseInfo { get; } //Store reference to original instance

        public int UniqueId { get; }
        #endregion

        #region Public Methods
        public Armour DeepCopy() { return (Armour)this.MemberwiseClone(); }
        #endregion
    }

    public class AccessoryData : EquipmentData, IDeepCopyable<AccessoryData>, IRarityMeasurable
    {
        /// <summary>
        /// Ctor
        /// PreCondition: _skills.Count > 0.
        /// PostCondition: Will be initialized successfully.
        /// </summary>
        /// <param name="_id"></param>
        /// <param name="_name"></param>
        /// <param name="_rarity"></param>
        /// <param name="_statusEffectsData"></param>
        /// <param name="_accessoryType"></param>
        /// <param name="_targetGender"></param>
        public AccessoryData(int _id, string _name, byte[] _iconAsBytes, eRarity _rarity, List<StatusEffectData> _statusEffectsData,
            eAccessoryClassification _accessoryType, eGender _targetGender) : base(_id, _name, _iconAsBytes, _rarity, _statusEffectsData)
        {
            AccessoryType = _accessoryType;
            TargetGender = _targetGender;
        }

        #region Properties
        public eAccessoryClassification AccessoryType { get; }

        public eGender TargetGender { get; }
        #endregion

        #region Public Methods
        AccessoryData IDeepCopyable<AccessoryData>.DeepCopy() { return (AccessoryData)DeepCopyInternally(); }
        #endregion

        #region Protected Methods
        protected override object DeepCopyInternally() { return (AccessoryData)base.DeepCopyInternally(); }
        #endregion
    }

    public class Accessory : IDeepCopyable<Accessory>
    {
        /// <summary>
        /// Ctor 1
        /// PreCondition: _skills.Count > 0;
        /// PostCondition: Will be initialized successfully.
        /// </summary>
        /// <param name="_id"></param>
        /// <param name="_name"></param>
        /// <param name="_rarity"></param>
        /// <param name="_statusEffectsData"></param>
        /// <param name="_accessoryClassification"></param>
        /// <param name="_targetGender"></param>
        /// <param name="_uniqueId"></param>
        public Accessory(int _id, string _name, byte[] _iconAsBytes, eRarity _rarity, List<StatusEffectData> _statusEffectsData, eAccessoryClassification _accessoryClassification, eGender _targetGender,
                         int _uniqueId)
        {
            BaseInfo = new AccessoryData(_id, _name, _iconAsBytes, _rarity, _statusEffectsData, _accessoryClassification, _targetGender);

            UniqueId = _uniqueId;
        }

        /// <summary>
        /// Ctor 2
        /// PreCondition: _baseAccessory has been initialized successfully.
        /// PostCondition: Will be initialized successfully.
        /// </summary>
        /// <param name="_accessoryData"></param>
        /// <param name="_uniqueId"></param>
        public Accessory(AccessoryData _accessoryData, int _uniqueId)
        {
            BaseInfo = _accessoryData.CoalesceNullAndReturnDeepCopyOptionally();

            UniqueId = _uniqueId;
        }

        #region Properties
        public AccessoryData BaseInfo { get; } //Store reference to original instance

        public int UniqueId { get; }
        #endregion

        #region Public Methods
        public Accessory DeepCopy() { return (Accessory)this.MemberwiseClone(); }
        #endregion
    }
}
