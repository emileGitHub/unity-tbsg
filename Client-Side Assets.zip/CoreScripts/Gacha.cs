﻿using EEANGames.TBSG._01.CommonEnums;
using EEANGames.ExtensionMethods;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EEANGames.TBSG._01.MainClassLib
{
    public class Gacha
    {
        public Gacha(int _id, string _title, eGachaClassification _gachaClassification, List<GachaObjectInfo> _gachaObjectInfos, ValuePerRarity _defaultDispensationValues, AlternativeDispensationInfo _alternativeDispensationInfo, eCostType _costType, int _costValue, byte[] _bannerImageAsBytes, byte[] _gachaSceneBackgroundImageAsBytes, int _levelOfObjects = MIN_LEVEL_OF_OBJECTS)
        {
            Id = _id;
            Title = _title.CoalesceNullAndReturnCopyOptionally(true);

            GachaClassification = _gachaClassification;

            m_gachaObjectInfos = _gachaObjectInfos.CoalesceNullAndReturnCopyOptionally(eCopyType.Shallow);

            DefaultDispensationValues = _defaultDispensationValues;

            AlternativeDispensationInfo = _alternativeDispensationInfo;

            CostType = _costType;
            CostValue = _costValue;

            BannerImageAsBytes = _bannerImageAsBytes.CoalesceNullAndReturnCopyOptionally(eCopyType.Deep);
            BackgroundImageAsBytes = _gachaSceneBackgroundImageAsBytes.CoalesceNullAndReturnCopyOptionally(eCopyType.Deep);

            LevelOfObjects = _levelOfObjects;
        }

        #region Properties
        public int Id { get; }
        public string Title { get; }

        public eGachaClassification GachaClassification { get; }
        public IList<GachaObjectInfo> GachaObjectInfos { get { return m_gachaObjectInfos.AsReadOnly(); } }

        public ValuePerRarity DefaultDispensationValues { get; }
        public AlternativeDispensationInfo AlternativeDispensationInfo { get; }

        public eCostType CostType { get; }
        public int CostValue { get; }

        public byte[] BannerImageAsBytes { get; }
        public byte[] BackgroundImageAsBytes { get; }

        public int LevelOfObjects { get; }
        #endregion

        #region Private Fields
        private const int MIN_LEVEL_OF_OBJECTS = 1;
        private const int MAX_LEVEL_OF_OBJECTS = 100;

        private List<GachaObjectInfo> m_gachaObjectInfos;
        #endregion

        #region public Methods
        /*
        public List<object> DispenseObjects(int _timesToDispense)
        {
            List<object> results = new List<object>();

            for (int i = 1; i <= _timesToDispense; i++)
            {
                ValuePerRarity dispensationValues = (AlternativeDispensationInfo.ApplyAtXthDispension != i) ? DefaultDispensationValues : AlternativeDispensationInfo.RatioPerRarity;

                int referenceNumber = dispensationValues.TotalValue; //Initialize referenceNumber for rarity selection.

                Random.Random.randInit();
                int occurencePosition = Random.Random.getRand(1, referenceNumber); //Get the number used to select the rarity of the object.

                eRarity targetRarity = dispensationValues.OccurenceValueToRarity(occurencePosition);

                referenceNumber = 0; //Re-set referenceNumber for unit selection.
                List<GachaObjectInfo> gachaObjectInfosOfGivenRarity = m_gachaObjectInfos.Where(x => x.Object.Rarity == targetRarity).ToList();
                foreach (GachaObjectInfo goInfo in gachaObjectInfosOfGivenRarity)
                {
                    referenceNumber += goInfo.RelativeOccurenceValue;
                }
                occurencePosition = Random.Random.getRand(1, referenceNumber); //Get the number used to select the object.

                object obj = new object();
                int accumulatedRelativeOccurenceValue = 0;
                foreach (GachaObjectInfo goInfo in gachaObjectInfosOfGivenRarity)
                {
                    accumulatedRelativeOccurenceValue += goInfo.RelativeOccurenceValue;

                    if (occurencePosition <= accumulatedRelativeOccurenceValue)
                        obj = GenerateObject(goInfo.Object);

                    if (obj == null)
                        return null;

                    results.Add(obj);

                    break;
                }
            }

            return results;
        }
        */
        #endregion

        #region Private Methods
        /*
        public object GenerateObject(object _objectBase)
        {
            object result = new object();

            switch (GachaType)
            {
                default: // case eGachaClassification.Unit
                    // Code to try adding a new unit to the database and pass its data to the client.
                    break;
            }

            return result;
        }
        */
        #endregion
    }

    public struct GachaObjectInfo
    {
        public IRarityMeasurable Object;
        public int RelativeOccurenceValue;
    }

    public struct ValuePerRarity
    {
        public int Legendary;
        public int Epic;
        public int Rare;
        public int Uncommon;
        public int Common;

        public int TotalValue { get { return Common + Uncommon + Rare + Epic + Legendary; } }
        public eRarity OccurrenceValueToRarity(int _value)
        {
            if (_value < 1 || _value > TotalValue)
                return default;

            if (_value > TotalValue - Legendary)
                return eRarity.Legendary;
            else if (_value > TotalValue - Legendary - Epic)
                return eRarity.Epic;
            else if (_value > Common + Uncommon)
                return eRarity.Rare;
            else if (_value > Common)
                return eRarity.Uncommon;
            else
                return eRarity.Common;
        }
    }

    public struct AlternativeDispensationInfo
    {
        public int ApplyAtXthDispensation;
        public ValuePerRarity RatioPerRarity;
    }

    public enum eGachaClassification
    {
        Unit,
        Weapon,
        Armour,
        Accessory,
        SkillItem,
        SkillMaterial,
        ItemMaterial,
        EquipmentMaterial,
        EvolutionMaterial
    }

    public enum eCostType
    {
        Gem,
        Gold
    }
}
