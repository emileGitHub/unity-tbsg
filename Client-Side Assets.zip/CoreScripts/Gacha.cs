﻿using EEANGames.TBSG._01.CommonEnums;
using EEANGames.ExtensionMethods;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EEANGames.TBSG._01.MainClassLib
{
    public class Gacha
    {
        public Gacha(int _id, string _title, eGachaClassification _gachaType, List<GachaObjectInfo> _gachaObjectInfos, ValuePerRarity _defaultDispensationValues, List<AlternativeDispensationInfo> _alternativeDispensationInfos, eCostType _costType, int _costValue, byte[] _bannerImageAsBytes, byte[] _gachaSceneBackgroundImageAsBytes)
        {
            Id = _id;
            Title = _title.CoalesceNullAndReturnCopyOptionally(true);

            GachaType = _gachaType;

            m_gachaObjectInfos = _gachaObjectInfos.CoalesceNullAndReturnCopyOptionally(eCopyType.Shallow);

            DefaultDispensationValues = _defaultDispensationValues;

            m_alternativeDispensationInfos = _alternativeDispensationInfos.CoalesceNullAndReturnCopyOptionally(eCopyType.Shallow);

            CostType = _costType;
            CostValue = _costValue;

            m_bannerImageAsBytes = _bannerImageAsBytes.CoalesceNullAndReturnCopyOptionally(eCopyType.Deep);
            m_gachaSceneBackgroundImageAsBytes = _gachaSceneBackgroundImageAsBytes.CoalesceNullAndReturnCopyOptionally(eCopyType.Deep);
        }

        #region Properties
        public int Id { get; }
        public string Title { get; }

        public eGachaClassification GachaType { get; }
        public IList<GachaObjectInfo> GachaObjectInfos { get { return m_gachaObjectInfos.AsReadOnly(); } }

        public ValuePerRarity DefaultDispensationValues { get; }
        public IList<AlternativeDispensationInfo> AlternativeDispensationInfos { get { return m_alternativeDispensationInfos.AsReadOnly(); } }

        public eCostType CostType { get; }
        public int CostValue { get; }

        public IList<byte> BannerImageAsBytes { get { return Array.AsReadOnly(m_bannerImageAsBytes); } }
        public IList<byte> GachaSceneBackgroundImageAsBytes { get { return Array.AsReadOnly(m_gachaSceneBackgroundImageAsBytes); } }
        #endregion

        #region Private Fields
        private List<GachaObjectInfo> m_gachaObjectInfos;
        private List<AlternativeDispensationInfo> m_alternativeDispensationInfos;

        private readonly byte[] m_bannerImageAsBytes;
        private readonly byte[] m_gachaSceneBackgroundImageAsBytes;
        #endregion

        #region public Methods
        public List<object> DispenseObjects(int _timesToDispense)
        {
            List<object> results = new List<object>();

            for (int i = 1; i <= _timesToDispense; i++)
            {
                ValuePerRarity dispensationValues = (!AlternativeDispensationInfos.Any(x => x.ApplyAtXthDispension == i)) ? DefaultDispensationValues : AlternativeDispensationInfos.First(x => x.ApplyAtXthDispension == i).RatioPerRarity;

                int referenceNumber = dispensationValues.TotalValue; //Initialize referenceNumber for rarity selection.

                Random.Random.randInit();
                int occurencePosition = Random.Random.getRand(1, referenceNumber); //Get the number used to select the rarity of the object.

                eRarity targetRarity = dispensationValues.OccurenceValueToRarity(occurencePosition);

                referenceNumber = 0; //Re-set referenceNumber for unit selection.
                List<GachaObjectInfo> gachaObjectInfosOfGivenRarity = m_gachaObjectInfos.Where(x => x.Object.Rarity == targetRarity).ToList();
                foreach (GachaObjectInfo goInfo in gachaObjectInfosOfGivenRarity)
                {
                    referenceNumber += goInfo.RelativeOccurenceValue;
                }
                occurencePosition = Random.Random.getRand(1, referenceNumber); //Get the number used to select the object.

                object obj = new object();
                int accumulatedRelativeOccurenceValue = 0;
                foreach (GachaObjectInfo goInfo in gachaObjectInfosOfGivenRarity)
                {
                    accumulatedRelativeOccurenceValue += goInfo.RelativeOccurenceValue;

                    if (occurencePosition <= accumulatedRelativeOccurenceValue)
                        obj = GenerateObject(goInfo.Object);

                    if (obj == null)
                        return null;

                    results.Add(obj);

                    break;
                }
            }

            return results;
        }
        #endregion

        #region Private Methods
        public object GenerateObject(object _objectBase)
        {
            object result = new object();

            switch (GachaType)
            {
                default: // case eGachaClassification.Unit
                    // Code to try adding a new unit to the database and pass its data to the client.
                    break;
            }

            return result;
        }
        #endregion
    }

    public struct GachaObjectInfo
    {
        public IRarityMeasurable Object;
        public int RelativeOccurenceValue;
    }

    public struct ValuePerRarity
    {
        public int Platinum;
        public int Gold;
        public int Silver;
        public int Bronze;
        public int Normal;

        public int TotalValue { get { return Normal + Bronze + Silver + Gold + Platinum; } }
        public eRarity OccurenceValueToRarity(int _value)
        {
            if (_value < 1 || _value > TotalValue)
                return default(eRarity);

            if (_value > TotalValue - Platinum)
                return eRarity.Platinum;
            else if (_value > TotalValue - Platinum - Gold)
                return eRarity.Gold;
            else if (_value > Normal + Bronze)
                return eRarity.Silver;
            else if (_value > Normal)
                return eRarity.Bronze;
            else
                return eRarity.Normal;
        }
    }

    public struct AlternativeDispensationInfo
    {
        public int ApplyAtXthDispension;
        public ValuePerRarity RatioPerRarity;
    }

    public enum eGachaClassification
    {
        Unit,
        Weapon,
        Armour,
        Accessory,
        SkillItem,
        SkillMaterial,
        ItemMaterial,
        EquipmentMaterial,
        EvolutionMaterial
    }

    public enum eCostType
    {
        Money,
        Gem
    }
}
