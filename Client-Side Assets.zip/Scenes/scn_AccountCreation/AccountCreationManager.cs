﻿using EEANGames.TBSG._01.MainClassLib;
using EEANGames.TBSG._01.Unity;
using System.Collections;
using System.Collections.Generic;
using UnityEditor;
using UnityEngine;
using UnityEngine.Networking;
using UnityEngine.UI;

public class AccountCreationManager : MonoBehaviour
{
    #region Serialized Fields
    public InputField PlayerNameInputField;
    public InputField UserNameInputField;
    public InputField PasswordInputField;
    public InputField PasswordConfirmationInputField;
    public InputField SecurityQuestionInputField;
    public InputField AnswerInputField;

    public Text PlayerNameStatusText;
    public Text UserNameStatusText;
    public Text PasswordStatusText;
    public Text PasswordConfirmationStatusText;
    public Text SecurityQuestionStatusText;
    public Text AnswerStatusText;

    public Text ValidityMessageText;
    #endregion

    private bool m_isUserNameValid;

    private bool m_areAllInputValuesValid;

    //Use this for initialization
    void Awake()
    {
        m_isUserNameValid = false;

        m_areAllInputValuesValid = false;
    }

    public void Request_CreateAccount()
    {
        StartCoroutine(CreateAccount());
    }

    IEnumerator CreateAccount()
    {
        yield return StartCoroutine(ValidateInputs());

        if (m_areAllInputValuesValid)
            yield return StartCoroutine(Post_CreateAccount());
    }

    IEnumerator Post_CreateAccount()
    {
        Dictionary<string, string> values = new Dictionary<string, string>
        {
            {"subject", "CreateAccount"},
            {"playerName", PlayerNameInputField.text},
            {"userName", UserNameInputField.text},
            {"password", PasswordInputField.text},
            {"securityQuestion", SecurityQuestionInputField.text},
            {"answer", AnswerInputField.text}
        };

        UnityWebRequest uwr = UnityWebRequest.Post(CoreValues.SERVER_URL, values);
        yield return uwr.SendWebRequest();

        if (uwr.isNetworkError)
        {
            PopUpWindowManager.Instance.CreateSimplePopUp("Failed!", "Connection Error: " + uwr.error + "\nPlease check your Internet connection.", "OK");
        }
        else
        {
            string response = uwr.downloadHandler.text;
            string[] responseValues = response.Split('\n');

            if (responseValues[0] == "success")
            {
                PopUpWindowManager.Instance.CreateSimplePopUp("Success!", "A new account has been created for you.", "Return to Title Menu", () => SceneConnector.GoToScene("scn_Title"));
            }
            else
            {
                PopUpWindowManager.Instance.CreateSimplePopUp("Error!", "Something went wrong!", "OK");
                m_areAllInputValuesValid = false;
            }
        }
    }

    IEnumerator Post_CheckUserNameValidity()
    {
        Dictionary<string, string> values = new Dictionary<string, string>
        {
            {"subject", "CheckUserNameValidity"},
            {"userName", UserNameInputField.text}
        };

        UnityWebRequest uwr = UnityWebRequest.Post(CoreValues.SERVER_URL, values);
        yield return uwr.SendWebRequest();

        if (uwr.isNetworkError)
        {
            PopUpWindowManager.Instance.CreateSimplePopUp("Error!", "Connection Error: " + uwr.error + "\nPlease check your Internet connection.", "OK");
        }
        else
        {
            string response = uwr.downloadHandler.text;
            string[] responseValues = response.Split('\n');

            if (responseValues[0] == "valid")
                m_isUserNameValid = true;
            else if (responseValues[0] == "invalid")
                m_isUserNameValid = false;
            else
                PopUpWindowManager.Instance.CreateSimplePopUp("Error!", "Something went wrong!", "OK");
        }
    }

    private IEnumerator ValidateInputs()
    {
        bool isPlayerNameValid = false;
        if (PlayerNameInputField.text.Length < 2)
            PlayerNameStatusText.text = "<color=red>Player Name must contain at least 2 characters!</color>";
        else
        {
            isPlayerNameValid = true;
            PlayerNameStatusText.text = "<color=green>OK!</color>";
        }

        if (UserNameInputField.text.Length < 8)
            UserNameStatusText.text = "<color=red>User Name must contain at least 8 characters!</color>";
        else
        {
            yield return StartCoroutine(Post_CheckUserNameValidity());
            if (!m_isUserNameValid)
                UserNameStatusText.text = "<color=red>User Name is already used!</color>";
            else
                UserNameStatusText.text = "<color=green>OK!</color>";
        }

        bool isPasswordValid = false;
        if (PasswordInputField.text.Length < 8)
            PasswordStatusText.text = "<color=red>Password must contain at least 8 characters!</color>";
        else
        {
            isPasswordValid = true;
            PasswordStatusText.text = "<color=green>OK!</color>";
        }

        bool doesConfirmationMatchPassword = false;
        if (PasswordConfirmationInputField.text != PasswordInputField.text)
            PasswordConfirmationStatusText.text = "<color=red>It must match the above password!</color>";
        else
        {
            doesConfirmationMatchPassword = true;
            PasswordConfirmationStatusText.text = "<color=green>OK!</color>";
        }

        if (isPlayerNameValid && m_isUserNameValid && isPasswordValid && doesConfirmationMatchPassword)
        {
            m_areAllInputValuesValid = true;
            ValidityMessageText.text = "";
        }
        else
            ValidityMessageText.text = "<color=red>There are some invalid values! Please check your input again.</color>";
    }
}
