﻿using EEANGames.TBSG._01.MainClassLib;
using EEANGames.TBSG._01.Unity;
using System.Collections;
using System.Collections.Generic;
using UnityEditor;
using UnityEngine;
using UnityEngine.Networking;
using UnityEngine.UI;

public class AccountCreationManager : MonoBehaviour
{
    #region Serialized Fields
    public Text PlayerNameText;
    public Text UserNameText;
    public Text PasswordText;
    public Text PasswordConfirmationText;
    public Text SecurityQuestionText;
    public Text AnswerText;

    public Text PlayerNameStatusText;
    public Text UserNameStatusText;
    public Text PasswordStatusText;
    public Text PasswordConfirmationStatusText;
    public Text SecurityQuestionStatusText;
    public Text AnswerStatusText;
    #endregion

    private bool m_isUserNameValid;

    private bool m_areAllInputValuesValid;

    //Use this for initialization
    void Awake()
    {
        m_isUserNameValid = false;

        m_areAllInputValuesValid = false;
    }

    public void Request_CreateAccount()
    {
        StartCoroutine(CreateAccount());
    }

    IEnumerator CreateAccount()
    {
        yield return StartCoroutine(ValidateInputs());

        if (m_areAllInputValuesValid)
            yield return StartCoroutine(Post_CreateAccount());
    }

    IEnumerator Post_CreateAccount()
    {
        Dictionary<string, string> values = new Dictionary<string, string>
        {
            {"subject", "CreateAccount"},
            {"playerName", PlayerNameText.text},
            {"userName", UserNameText.text},
            {"password", PasswordText.text},
            {"securityQuestion", SecurityQuestionText.text},
            {"answer", AnswerText.text}
        };

        UnityWebRequest uwr = UnityWebRequest.Post(CoreValues.SERVER_URL, values);
        yield return uwr.SendWebRequest();

        if (uwr.isNetworkError)
        {
            PopUpWindowManager.Instance.CreatePopUp("Failed!", "Connection Error: " + uwr.error + "\nPlease check your Internet connection.", "OK", null, ePopUpWindowType.Simple);
        }
        else
        {
            string response = uwr.downloadHandler.text;
            string[] responseValues = response.Split('\n');

            if (responseValues[0] == "success")
            {
                PopUpWindowManager.Instance.CreatePopUp("Success!", "A new account has been created for you.", "Return to Title Menu", () => SceneConnector.GoToScene("scn_Title"), ePopUpWindowType.Simple);
            }
            else
                PopUpWindowManager.Instance.CreatePopUp("Failed!", "Something when wrong!", "OK", null, ePopUpWindowType.Simple);
        }
    }

    IEnumerator Post_CheckUserNameValidity()
    {
        Dictionary<string, string> values = new Dictionary<string, string>
        {
            {"subject", "CheckUserNameValidity"},
            {"userName", UserNameText.text}
        };

        UnityWebRequest uwr = UnityWebRequest.Post(CoreValues.SERVER_URL, values);
        yield return uwr.SendWebRequest();

        if (uwr.isNetworkError)
        {
            PopUpWindowManager.Instance.CreatePopUp("Error!", "Connection Error: " + uwr.error + "\nPlease check your Internet connection.", "OK", null, ePopUpWindowType.Simple);
        }
        else
        {
            string response = uwr.downloadHandler.text;
            string[] responseValues = response.Split('\n');

            if (responseValues[0] == "valid")
                m_isUserNameValid = true;
            else if (responseValues[0] == "invalid")
                m_isUserNameValid = false;
            else
                PopUpWindowManager.Instance.CreatePopUp("Error!", "Something when wrong!", "OK", null, ePopUpWindowType.Simple);
        }
    }

    private IEnumerator ValidateInputs()
    {
        bool isPlayerNameValid = false;
        if (PlayerNameText.text.Length < 2)
            PlayerNameStatusText.text = "<color=red>Player Name must contain at least 2 characters!</color>";
        else
        {
            isPlayerNameValid = true;
            PlayerNameStatusText.text = "<color=green>OK!</color>";
        }

        if (UserNameText.text.Length < 8)
            UserNameStatusText.text = "<color=red>User Name must contain at least 8 characters!</color>";
        else
        {
            yield return StartCoroutine(Post_CheckUserNameValidity());
            if (!m_isUserNameValid)
                UserNameStatusText.text = "<color=red>User Name is already used!</color>";
            else
                UserNameStatusText.text = "<color=green>OK!</color>";
        }

        bool isPasswordValid = false;
        if (PasswordText.text.Length < 8)
            PasswordStatusText.text = "<color=red>Password must contain at least 8 characters!</color>";
        else
        {
            isPasswordValid = true;
            PasswordStatusText.text = "<color=green>OK!</color>";
        }

        bool doesConfirmationMatchPassword = false;
        if (PasswordConfirmationText.text != PasswordText.text)
            PasswordConfirmationStatusText.text = "<color=red>It must match the above password!</color>";
        else
        {
            doesConfirmationMatchPassword = true;
            PasswordConfirmationStatusText.text = "<color=green>OK!</color>";
        }

        if (isPlayerNameValid && m_isUserNameValid && isPasswordValid && doesConfirmationMatchPassword)
            m_areAllInputValuesValid = true;
    }
}
