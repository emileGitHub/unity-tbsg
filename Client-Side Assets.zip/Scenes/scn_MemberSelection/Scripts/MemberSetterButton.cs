﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using System;
using System.Linq;
using UnityEngine.SceneManagement;
using EEANGames.TBSG._01.MainClassLib;

public class MemberSetterButton : MonoBehaviour
{
    private Button m_button;

    private void Awake()
    {
        m_button = this.GetComponent<Button>();
        m_button.onClick = new Button.ButtonClickedEvent();

    }

    public void SetMember()
    {
        GameDataContainer.Instance.Player.Teams[MemberSelectionIntermediary.TeamNum - 1].MemberSets[MemberSelectionIntermediary.MemberNum - 1].Member = GameDataContainer.Instance.Player.UnitsOwned.First(c => c.UniqueId == Convert.ToInt32(this.name));
        SceneManager.LoadScene("TeamCustomization");
    }
}
