﻿using EEANGames.TBSG._01.MainClassLib;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using UnityEngine.UI;

[RequireComponent(typeof(InfoPanelManager))]
public class InfoPanelManager_Gacha : MonoBehaviour
{

    [SerializeField]
    public GameObject GachaInfoPanelPrefab;

    private InfoPanelManager m_mainInformationPanelManager;

    private List<GameObject> m_infoPanels;
    private Transform m_canvas;

    // Awake is called before Update for the first frame
    void Awake()
    {
        m_mainInformationPanelManager = this.transform.GetComponent<InfoPanelManager>();
        m_infoPanels = new List<GameObject>();
        m_canvas = GameObject.FindGameObjectWithTag("Canvas").transform;
    }

    public void InstantiateInfoPanel(int _gachaPageNumber)
    {
        GameObject infoPanel = Instantiate(GachaInfoPanelPrefab, m_canvas, false);
        infoPanel.transform.Find("BackGround").Find("CloseButton").GetComponent<Button>().onClick.AddListener(() => RemoveInfoPanel());
        //RectTransform rt = infoPanel.GetComponent<RectTransform>();
        m_infoPanels.Add(infoPanel);
        m_mainInformationPanelManager.AddInfoPanel(infoPanel);

        Unit unitData = GameDataContainer.Instance.Player.UnitsOwned.First(x => x.UniqueId == _gachaPageNumber);

        UpdateInfoPanel(infoPanel, unitData);
    }

    private void UpdateInfoPanel(GameObject _infoPanel, Unit _unitData)
    {
        Transform infoPanelBG = _infoPanel.transform.Find("BackGround");

        //infoPanelBG.Find("UnitNickname").GetComponent<Text>().text = _unitData.Nickname;
    }

    //Remove newest info panel
    public void RemoveInfoPanel()
    {
        GameObject infoPanel = m_infoPanels[m_infoPanels.Count - 1];
        m_mainInformationPanelManager.RemoveInfoPanel(infoPanel);
        m_infoPanels.Remove(infoPanel);
        Destroy(infoPanel);
    }
}
