﻿//using System;
//using System.Collections;
//using System.Collections.Generic;
//using UnityEngine;
//using UnityEngine.Networking;
//using UnityEngine.UI;

///// <summary>
///// For test use. Use to count existing instances of units and display some properties of each unit.
///// </summary>
//[RequireComponent(typeof(Text))]
//public class Test_UnitCounter : NetworkBehaviour {

//    Text textScript;
//    private UnityBattleSystem mainScript;

//	// Awake is called before Update for the first frame
//	void Awake () {
//        textScript = this.GetComponent<Text>();
//	}
	
//	// Update is called once per frame
//    [Client]
//	void FixedUpdate () {
//        try
//        {
//            GameObject[] units = GameObject.FindGameObjectsWithTag("Unit");

//            if(units.Length > 0)
//            {
//                if(mainScript == null)
//                    mainScript = GameObject.Find("BattleSystemController").GetComponent<UnityBattleSystem>();

//                if (mainScript.isInitialized)
//                {
//                    textScript.text = units.Length.ToString() + "\n";

//                    LocalPlayerIdentifier LocalPlayerIdentifier = GameObject.Find("LocalPlayerIdentifier").GetComponent<LocalPlayerIdentifier>();

//                    if (LocalPlayerIdentifier.isInitialized)
//                        textScript.text += "LocalPlayerId: " + LocalPlayerIdentifier.PlayerController.PlayerId.ToString() + "\n";
//                    else
//                        textScript.text += "LocalPlayerIdentifier not yet initiallized.\n";

//                    foreach (GameObject unit in units)
//                    {
//                        UnitController_SinglePlayer unitController = unit.GetComponent<UnitController_SinglePlayer>();

//                        if (unitController.IsInitializedInternally)
//                        {
//                            textScript.text
//                                += "\n" + unit.activeSelf.ToString() + "\n"
//                                + "ParentPlayerId: " + unit.transform.parent.GetComponent<PlayerController>().PlayerId.ToString() + "\n"
//                                + "OwnerId: " + unitController.OwnerId.ToString() + "\n"
//                                + "Position: (" + unit.transform.position.x + ", " + unit.transform.position.y + ", " + unit.transform.position.z + ")\n"
//                                + "Rotation: (" + unit.transform.rotation.x + ", " + unit.transform.rotation.y + ", " + unit.transform.rotation.z + ")\n"
//                                + "Scale: (" + unit.transform.localScale.x + ", " + unit.transform.localScale.y + ", " + unit.transform.localScale.z + ")\n";
//                        }
//                    }
//                }
//            }
//        }
//        catch(Exception ex)
//        {
//            Debug.Log("Test_UnitCounter: at FixedUpdate() " + ex.Message);
//            textScript.text += "\n" + ex.ToString() + "\n";
//        }
//	}
//}
