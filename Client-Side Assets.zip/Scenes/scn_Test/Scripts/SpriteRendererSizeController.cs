﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
//using UnityEditor;

/// <summary>
/// For test use. Use to see the detailed size of a sprite renderer in editor.
/// </summary>
//[ExecuteInEditMode]
public class SpriteRendererSizeController : MonoBehaviour
{

    public float BaseBoundsSizeX;
    public float BaseBoundsSizeY;
    public float BaseBoundsSizeZ;
    public float SpriteBoundsSizeX;
    public float SpriteBoundsSizeY;
    public float SpriteBoundsSizeZ;
    public bool setUpdateActive;

    private SpriteRenderer mySR;

    // Awake is called before Update for the first frame
    void Start()
    {
        mySR = this.GetComponent<SpriteRenderer>();

        BaseBoundsSizeX = mySR.bounds.size.x;
        BaseBoundsSizeY = mySR.bounds.size.y;
        BaseBoundsSizeZ = mySR.bounds.size.z;
        SpriteBoundsSizeX = mySR.sprite.bounds.size.x;
        SpriteBoundsSizeY = mySR.sprite.bounds.size.y;
        SpriteBoundsSizeZ = mySR.sprite.bounds.size.z;

        setUpdateActive = true;
    }

    // Update is called once per frame
    void Update()
    {
        if (setUpdateActive)
        {
            UpdateIn();
            UpdateOut();
        }
    }

    private void UpdateOut()
    {
        if (BaseBoundsSizeX != mySR.bounds.size.x)
            BaseBoundsSizeX = mySR.bounds.size.x;
        if (BaseBoundsSizeY != mySR.bounds.size.y)
            BaseBoundsSizeY = mySR.bounds.size.y;
        if (BaseBoundsSizeZ != mySR.bounds.size.z)
            BaseBoundsSizeZ = mySR.bounds.size.z;
        if (SpriteBoundsSizeX != mySR.sprite.bounds.size.x)
            SpriteBoundsSizeX = mySR.sprite.bounds.size.x;
        if (SpriteBoundsSizeY != mySR.sprite.bounds.size.y)
            SpriteBoundsSizeY = mySR.sprite.bounds.size.y;
        if (SpriteBoundsSizeZ != mySR.sprite.bounds.size.z)
            SpriteBoundsSizeZ = mySR.sprite.bounds.size.z;
    }

    private void UpdateIn()
    {
        if (BaseBoundsSizeX != mySR.bounds.size.x)
        {
            Debug.Log("BBSX == " + BaseBoundsSizeX + " and CurrentSize == " + mySR.bounds.size.x);
            mySR.bounds.Expand(BaseBoundsSizeX - mySR.bounds.size.x);
            Debug.Log("CurrentSize == " + mySR.bounds.size.x);
        }
        else if (BaseBoundsSizeY != mySR.bounds.size.y)
            mySR.bounds.Expand(BaseBoundsSizeY - mySR.bounds.size.y);
        else if (BaseBoundsSizeZ != mySR.bounds.size.z)
            mySR.bounds.Expand(BaseBoundsSizeZ - mySR.bounds.size.z);

        if (SpriteBoundsSizeX != mySR.sprite.bounds.size.x)
        {
            Debug.Log("BBSX == " + BaseBoundsSizeX + " and CurrentSize == " + mySR.bounds.size.x);
            mySR.sprite.bounds.Expand(SpriteBoundsSizeX - mySR.sprite.bounds.size.x);
            Debug.Log("CurrentSize == " + mySR.bounds.size.x);
        }
        else if (SpriteBoundsSizeY != mySR.sprite.bounds.size.y)
            mySR.sprite.bounds.Expand(SpriteBoundsSizeY - mySR.sprite.bounds.size.y);
        else if (SpriteBoundsSizeZ != mySR.sprite.bounds.size.z)
            mySR.sprite.bounds.Expand(SpriteBoundsSizeZ - mySR.sprite.bounds.size.z);
    }
}
