﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ParticleTester : MonoBehaviour {

    public GameObject ParticlePrefab;

    private Vector3 m_position;

	// Use this for initialization
	void Start () {
        m_position = GameObject.FindGameObjectWithTag("GameBoard").transform.position;
	}
	
	// Update is called once per frame
	void Update () {
        if (Input.GetMouseButtonDown(0))
            GameObject.Instantiate(ParticlePrefab, m_position, Quaternion.identity);
    }
}
