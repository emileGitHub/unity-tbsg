﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
//using UnityEditor;


/// <summary>
/// For test use. Use to see the detailed size of a mesh renderer in editor.
/// </summary>
//[ExecuteInEditMode]
public class MeshRendererSizeViewer : MonoBehaviour
{

    public float BaseBoundsSizeX;
    public float BaseBoundsSizeY;
    public float BaseBoundsSizeZ;

    public bool setUpdateActive;

    private MeshRenderer myMR;

    // Awake is called before Update for the first frame
    void Start()
    {
        myMR = this.GetComponent<MeshRenderer>();

        BaseBoundsSizeX = myMR.bounds.size.x;
        BaseBoundsSizeY = myMR.bounds.size.y;
        BaseBoundsSizeZ = myMR.bounds.size.z;


        setUpdateActive = true;
    }

    // Update is called once per frame
    void Update()
    {
        if (setUpdateActive)
        {
            UpdateIn();
            UpdateOut();
        }
    }

    private void UpdateOut()
    {
        if (BaseBoundsSizeX != myMR.bounds.size.x)
            BaseBoundsSizeX = myMR.bounds.size.x;
        if (BaseBoundsSizeY != myMR.bounds.size.y)
            BaseBoundsSizeY = myMR.bounds.size.y;
        if (BaseBoundsSizeZ != myMR.bounds.size.z)
            BaseBoundsSizeZ = myMR.bounds.size.z;
    }

    private void UpdateIn()
    {
        if (BaseBoundsSizeX != myMR.bounds.size.x)
        {
            Debug.Log("BBSX == " + BaseBoundsSizeX + " and CurrentSize == " + myMR.bounds.size.x);
            myMR.bounds.Expand(BaseBoundsSizeX - myMR.bounds.size.x);
            Debug.Log("CurrentSize == " + myMR.bounds.size.x);
        }
        else if (BaseBoundsSizeY != myMR.bounds.size.y)
            myMR.bounds.Expand(BaseBoundsSizeY - myMR.bounds.size.y);
        else if (BaseBoundsSizeZ != myMR.bounds.size.z)
            myMR.bounds.Expand(BaseBoundsSizeZ - myMR.bounds.size.z);
    }
}

