﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

namespace EEANGames.TBSG._01.Unity
{
    //This code is a modified versions of "      "
    //The original code can be found at >>> 
    public class SceneLoader : MonoBehaviour
    {
        #region Serialized Fields
        public Text LoadingText;
        public string Text;
        #endregion

        #region Private Member Variables
        private bool m_isSceneLoaded;
        #endregion

        // Use this for initialization
        void Awake()
        {
            m_isSceneLoaded = false;
        }

        // Updates once per frame
        void FixedUpdate()
        {

            // If the player has pressed the space bar and a new scene is not loading yet...
            if (!m_isSceneLoaded)
            {

                // ...set the loadScene boolean to true to prevent loading a new scene more than once...
                m_isSceneLoaded = true;

                // ...change the instruction text to read "Loading..."
                LoadingText.text = Text;

                // ...and start a coroutine that will load the desired scene.
                StartCoroutine(LoadNewScene());

            }

            // If the new scene has started loading...
            if (m_isSceneLoaded)
            {

                // ...then pulse the transparency of the loading text to let the player know that the computer is still working.
                LoadingText.color = new Color(LoadingText.color.r, LoadingText.color.g, LoadingText.color.b, Mathf.PingPong(Time.time, 1));

            }

        }


        #region Coroutines

        // The coroutine runs on its own at the same time as Update() and takes an integer indicating which scene to load.
        IEnumerator LoadNewScene()
        {
            yield return new WaitForSeconds(3);

            // Start an asynchronous operation to load the scene that was passed to the LoadNewScene coroutine.
            AsyncOperation async = SceneManager.LoadSceneAsync(SceneConnector.m_nextScene);

            // While the asynchronous operation to load the new scene is not yet complete, continue waiting until it's done.
            while (!async.isDone)
            {
                yield return null;
            }
        }
        #endregion
    }
}