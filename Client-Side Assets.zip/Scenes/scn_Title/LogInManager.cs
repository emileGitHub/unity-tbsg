﻿//using EEANGames.TBSG._01.MainClassLib.DBDataHandler.ForUnity;
using Assets.Resources.CommonScripts;
using EEANGames.ExtensionMethods;
using EEANGames.TBSG._01.CommonEnums;
using EEANGames.TBSG._01.MainClassLib;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEditor;
using UnityEngine;
using UnityEngine.Networking;
using UnityEngine.UI;

namespace EEANGames.TBSG._01.Unity
{
    public class LogInManager : MonoBehaviour
    {
        #region Serialized Fields
        public InputField UserNameInputField;
        public InputField PasswordInputField;
        #endregion

        #region Private Fields
        private const int m_MINIMUM_USERID_LENGTH = 8;
        private const int m_MINIMUM_PASSWORD_LENGTH = 8;

        private List<StatusEffectData> m_statusEffectDataList;
        private List<Effect> m_effectList;
        private List<SkillData> m_skillList;

        private List<WeaponData> m_weaponDataList;
        private List<ArmourData> m_armourDataList;
        private List<AccessoryData> m_accessoryDataList;
        private List<Item> m_itemList;
        private List<UnitData> m_unitDataList;

        private Player m_player;

        private Dictionary<int, int> m_effectId_secondaryEffectId;
        private Dictionary<int, int> m_weaponId_transformableWeaponId;
        private Dictionary<int, UnitEvolutionRecipeBase> m_unitId_progressiveEvolutionRecipeBase;
        private Dictionary<int, UnitEvolutionRecipeBase> m_unitId_retrogressiveEvolutionRecipeBase;
        private List<Tuple<int, int, int>> m_playableUnitId_inheritorUnitId_inheritingSkillId;
        #endregion

        //Use this for initialization
        void Awake()
        {
            m_statusEffectDataList = new List<StatusEffectData>();
            m_effectList = new List<Effect>();
            m_skillList = new List<SkillData>();

            m_weaponDataList = new List<WeaponData>();
            m_armourDataList = new List<ArmourData>();
            m_accessoryDataList = new List<AccessoryData>();
            m_itemList = new List<Item>();
            m_unitDataList = new List<UnitData>();

            m_effectId_secondaryEffectId = new Dictionary<int, int>();
            m_weaponId_transformableWeaponId = new Dictionary<int, int>();
            m_unitId_progressiveEvolutionRecipeBase = new Dictionary<int, UnitEvolutionRecipeBase>();
            m_unitId_retrogressiveEvolutionRecipeBase = new Dictionary<int, UnitEvolutionRecipeBase>();
            m_playableUnitId_inheritorUnitId_inheritingSkillId = new List<Tuple<int, int, int>>();
        }

        public void Request_CheckCredentialsValidityAndAttemptLogIn()
        {
            StartCoroutine(CheckCredentialsValidityAndAttemptLogIn());
        }

        IEnumerator CheckCredentialsValidityAndAttemptLogIn()
        {
            string userName = UserNameInputField.text;
            string password = PasswordInputField.text;

            string errorMsg = "";

            if (userName.Length < m_MINIMUM_USERID_LENGTH)
                errorMsg = "A User Name contains at least " + m_MINIMUM_USERID_LENGTH.ToString() + " characters!";

            if (password.Length < m_MINIMUM_PASSWORD_LENGTH)
                errorMsg += "A Password contains at least " + m_MINIMUM_PASSWORD_LENGTH.ToString() + " characters!";

            if (errorMsg == "")
            {
                Dictionary<string, string> values = new Dictionary<string, string>
                {
                    {"subject", "CheckPlayerCredentialsValidity"},
                    {"userName", userName},
                    {"password", password}
                };

                UnityWebRequest uwr = UnityWebRequest.Post(CoreValues.SERVER_URL, values);
                yield return uwr.SendWebRequest();

                if (uwr.isNetworkError)
                    PopUpWindowManager.Instance.CreatePopUp("Error!", "Connection Error: " + uwr.error + "\nPlease check your Internet connection.", "OK", null, ePopUpWindowType.Simple);
                else
                {
                    string response = uwr.downloadHandler.text;

                    switch (response)
                    {
                        case "valid":
                            {
                                m_player = null; //Re-set m_player
                                yield return StartCoroutine(RequestGameData(userName, password));

                                if (m_player != null)
                                {
                                    if (GameDataContainer.Instance.Initialize(m_player, m_statusEffectDataList, m_effectList, m_skillList, m_accessoryDataList, m_armourDataList, m_weaponDataList, m_itemList, m_unitDataList))
                                        SceneConnector.GoToScene("scn_Home");
                                }
                                else
                                    errorMsg = "Credentials are valid, but an unexpected issue has occurred while loading data! \nPlease try again.";
                            }
                            break;

                        case "wrongPassword":
                            errorMsg = "The password is wrong!";
                            break;

                        case "noAccount":
                            errorMsg = "There is no account associated to the given user name!";
                            break;

                        default:
                            PopUpWindowManager.Instance.CreatePopUp("Error!", "Something went wrong!", "OK", null, ePopUpWindowType.Simple);
                            break;
                    }
                }
            }

            if (errorMsg != "")
                PopUpWindowManager.Instance.CreatePopUp("Error", errorMsg, "OK", null, ePopUpWindowType.Simple);
        }

        IEnumerator RequestGameData(string _userName, string _password)
        {
            Dictionary<string, string> values = new Dictionary<string, string>
                {
                    {"subject", "LoadCoreGameData"},
                    {"userName", _userName},
                    {"password", _password}
                };

            UnityWebRequest uwr = UnityWebRequest.Post(CoreValues.SERVER_URL, values);
            yield return uwr.SendWebRequest();

            if (uwr.isNetworkError)
                PopUpWindowManager.Instance.CreatePopUp("Error!", "Connection Error: " + uwr.error + "\nPlease check your Internet connection.", "OK", null, ePopUpWindowType.Simple);
            else
            {
                string response = uwr.downloadHandler.text;
                string responseCopy = String.Copy(response);

                string sectionString = string.Empty;

                responseCopy = responseCopy.DettachPortionFromString("<StatusEffects>", "</StatusEffects>", ref sectionString);
                m_statusEffectDataList.Clear();
                m_statusEffectDataList = ResponseStringToStatusEffectDataList(sectionString);

                responseCopy = responseCopy.DettachPortionFromString("<Effects>", "</Effects>", ref sectionString);
                m_effectList.Clear();
                m_effectList = ResponseStringToEffectList(sectionString);
                
                responseCopy = responseCopy.DettachPortionFromString("<Skills>", "</Skills>", ref sectionString);
                m_skillList.Clear();
                m_skillList = ResponseStringToSkillDataList(sectionString);

                responseCopy = responseCopy.DettachPortionFromString("<Weapons>", "</Weapons>", ref sectionString);
                m_weaponDataList.Clear();
                m_weaponDataList = ResponseStringToWeaponDataList(sectionString);

                responseCopy = responseCopy.DettachPortionFromString("<Armours>", "</Armours>", ref sectionString);
                m_armourDataList.Clear();
                m_armourDataList = ResponseStringToArmourDataList(sectionString);

                responseCopy = responseCopy.DettachPortionFromString("<Accessories>", "</Accessories>", ref sectionString);
                m_accessoryDataList.Clear();
                m_accessoryDataList = ResponseStringToAccessoryDataList(sectionString);

                responseCopy = responseCopy.DettachPortionFromString("<Items>", "</Items>", ref sectionString);
                m_itemList.Clear();
                m_itemList = ResponseStringToItemList(sectionString);

                responseCopy = responseCopy.DettachPortionFromString("<Units>", "</Units>", ref sectionString);
                m_unitDataList.Clear();
                m_unitDataList = ResponseStringToUnitDataList(sectionString);

                LoadSecondaryEffects();
                LoadTransformableWeaponsData();
                LoadUnitEvolutionRecipes();

                responseCopy = responseCopy.DettachPortionFromString("<Player>", "</Player>", ref sectionString);
                m_player = ResponseStringToPlayer(sectionString);

                LoadSkillInheritors(m_player.UnitsOwned);
            }
        }

        private Player ResponseStringToPlayer(string _response)
        {
            try
            {
                string sectionString = string.Empty;

                _response.DettachPortionFromString("<Id>", "</Id>", ref sectionString);
                sectionString = DataLoader.RemoveOpeningAndClosingTags(sectionString, "Id");
                int id = Convert.ToInt32(sectionString);

                _response.DettachPortionFromString("<PlayerName>", "</PlayerName>", ref sectionString);
                sectionString = DataLoader.RemoveOpeningAndClosingTags(sectionString, "PlayerName");
                string playerName = sectionString;

                _response.DettachPortionFromString("<GemsOwned>", "</GemsOwned>", ref sectionString);
                sectionString = DataLoader.RemoveOpeningAndClosingTags(sectionString, "GemsOwned");
                int gemsOwned = Convert.ToInt32(sectionString);

                _response.DettachPortionFromString("<GoldOwned>", "</GoldOwned>", ref sectionString);
                sectionString = DataLoader.RemoveOpeningAndClosingTags(sectionString, "GoldOwned");
                int goldOwned = Convert.ToInt32(sectionString);

                _response.DettachPortionFromString("<UnitsOwned>", "</UnitsOwned>", ref sectionString);
                sectionString = DataLoader.RemoveOpeningAndClosingTags(sectionString, "UnitsOwned");
                List<Unit> unitsOwned = new List<Unit>();
                string unitString = "";
                while (sectionString != "")
                {
                    sectionString = sectionString.DettachPortionFromString("<Unit>", "</Unit>", ref unitString);

                    unitsOwned.Add(StringToUnit(unitString));
                }

                _response.DettachPortionFromString("<WeaponsOwned>", "</WeaponsOwned>", ref sectionString);
                sectionString = DataLoader.RemoveOpeningAndClosingTags(sectionString, "WeaponsOwned");
                List<Weapon> weaponsOwned = new List<Weapon>();
                string weaponString = "";
                while (sectionString != "")
                {
                    sectionString = sectionString.DettachPortionFromString("<Weapon>", "</Weapon>", ref weaponString);

                    weaponsOwned.Add(StringToWeapon(weaponString));
                }

                _response.DettachPortionFromString("<ArmoursOwned>", "</ArmoursOwned>", ref sectionString);
                sectionString = DataLoader.RemoveOpeningAndClosingTags(sectionString, "ArmoursOwned");
                List<Armour> armoursOwned = new List<Armour>();
                string armourString = "";
                while (sectionString != "")
                {
                    sectionString = sectionString.DettachPortionFromString("<Armour>", "</Armour>", ref armourString);

                    armoursOwned.Add(StringToArmour(armourString));
                }

                _response.DettachPortionFromString("<AccessoriesOwned>", "</AccessoriesOwned>", ref sectionString);
                sectionString = DataLoader.RemoveOpeningAndClosingTags(sectionString, "AccessoriesOwned");
                List<Accessory> accessoriesOwned = new List<Accessory>();
                string accessoryString = "";
                while (sectionString != "")
                {
                    sectionString = sectionString.DettachPortionFromString("<Accessory>", "</Accessory>", ref accessoryString);

                    accessoriesOwned.Add(StringToAccessory(accessoryString));
                }

                _response.DettachPortionFromString("<ItemsOwned>", "</ItemsOwned>", ref sectionString);
                sectionString = DataLoader.RemoveOpeningAndClosingTags(sectionString, "ItemsOwned");
                Dictionary<Item, int> itemsOwned = new Dictionary<Item, int>();
                string itemString = "";
                while (sectionString != "")
                {
                    sectionString = sectionString.DettachPortionFromString("<Item>", "</Item>", ref itemString);

                    KeyValuePair<Item, int> quantityPerItem = StringToItemOwned(itemString);
                    itemsOwned.Add(quantityPerItem.Key, quantityPerItem.Value);
                }

                _response.DettachPortionFromString("<MemberSets>", "</MemberSets>", ref sectionString);
                sectionString = DataLoader.RemoveOpeningAndClosingTags(sectionString, "MemberSets");
                List<MemberSet> memberSets = new List<MemberSet>();
                string memberSetString = "";
                while (sectionString != "")
                {
                    sectionString = sectionString.DettachPortionFromString("<MemberSet>", "</MemberSet>", ref memberSetString);

                    memberSets.Add(StringToMemberSet(memberSetString, unitsOwned, weaponsOwned, armoursOwned, accessoriesOwned));
                }

                _response.DettachPortionFromString("<ItemSets>", "</ItemSets>", ref sectionString);
                sectionString = DataLoader.RemoveOpeningAndClosingTags(sectionString, "ItemSets");
                List<ItemSet> itemSets = new List<ItemSet>();
                string itemSetString = "";
                while (sectionString != "")
                {
                    sectionString = sectionString.DettachPortionFromString("<ItemSet>", "</ItemSet>", ref itemSetString);

                    itemSets.Add(StringToItemSet(itemSetString));
                }

                _response.DettachPortionFromString("<Teams>", "</Teams>", ref sectionString);
                sectionString = DataLoader.RemoveOpeningAndClosingTags(sectionString, "Teams");
                List<Team> teams = new List<Team>();
                string teamString = "";
                while (sectionString != "")
                {
                    sectionString = sectionString.DettachPortionFromString("<Team>", "</Team>", ref teamString);

                    teams.Add(StringToTeam(teamString, memberSets, itemSets));
                }

                return new Player(id, playerName, unitsOwned, weaponsOwned, armoursOwned, accessoriesOwned, itemsOwned, memberSets, itemSets, teams, gemsOwned, goldOwned);
            }
            catch (Exception ex)
            {
                Debug.Log(ex.Message);
                return null;
            }
        }

        private Unit StringToUnit(string _string)
        {
            try
            {
                string sectionString = string.Empty;

                _string.DettachPortionFromString("<UniqueId>", "</UniqueId>", ref sectionString);
                sectionString = DataLoader.RemoveOpeningAndClosingTags(sectionString, "UniqueId");
                int uniqueId = Convert.ToInt32(sectionString);

                _string.DettachPortionFromString("<BaseUnitId>", "</BaseUnitId>", ref sectionString);
                sectionString = DataLoader.RemoveOpeningAndClosingTags(sectionString, "BaseUnitId");
                int baseUnitId = Convert.ToInt32(sectionString);
                UnitData baseUnitData = m_unitDataList.First(x => x.Id == baseUnitId);

                _string.DettachPortionFromString("<AccumulatedExperience>", "</AccumulatedExperience>", ref sectionString);
                sectionString = DataLoader.RemoveOpeningAndClosingTags(sectionString, "AccumulatedExperience");
                int accumulatedExperience = Convert.ToInt32(sectionString);

                _string.DettachPortionFromString("<Nickname>", "</Nickname>", ref sectionString);
                sectionString = DataLoader.RemoveOpeningAndClosingTags(sectionString, "Nickname");
                string nickname = sectionString;

                _string.DettachPortionFromString("<Skills>", "</Skills>", ref sectionString);
                sectionString = DataLoader.RemoveOpeningAndClosingTags(sectionString, "Skills");
                List<Skill> skills = new List<Skill>();
                string skillString = "";
                while (sectionString != "")
                {
                    sectionString = sectionString.DettachPortionFromString("<Skill>", "</Skill>", ref skillString);

                    string skillIdString = "";
                    skillString.DettachPortionFromString("<SkillId>", "</SkillId>", ref skillIdString);
                    skillIdString = DataLoader.RemoveOpeningAndClosingTags(skillIdString, "SkillId");
                    int skillId = Convert.ToInt32(skillIdString);

                    string skillLevelString = "";
                    skillString.DettachPortionFromString("<SkillLevel>", "</SkillLevel>", ref skillLevelString);
                    skillLevelString = DataLoader.RemoveOpeningAndClosingTags(skillLevelString, "SkillLevel");
                    int skillLevel = Convert.ToInt32(skillLevelString);

                    SkillData skillData = m_skillList.First(x => x.Id == skillId);

                    if (skillData is OrdinarySkillData)
                        skills.Add(new OrdinarySkill(skillData as OrdinarySkillData, skillLevel));
                    else if (skillData is CounterSkillData)
                        skills.Add(new CounterSkill(skillData as CounterSkillData, skillLevel));
                    else if (skillData is UltimateSkillData)
                            skills.Add(new UltimateSkill(skillData as UltimateSkillData, skillLevel));
                    else if (skillData is PassiveSkillData)
                            skills.Add(new PassiveSkill(skillData as PassiveSkillData, skillLevel));
                }

                _string.DettachPortionFromString("<SkillInheritorUnitId>", "</SkillInheritorUnitId>", ref sectionString);
                sectionString = DataLoader.RemoveOpeningAndClosingTags(sectionString, "SkillInheritorUnitId");
                int skillInheritorUnitId = Convert.ToInt32(sectionString);
                _string.DettachPortionFromString("<InheritingSkillId>", "</InheritingSkillId>", ref sectionString);
                sectionString = DataLoader.RemoveOpeningAndClosingTags(sectionString, "InheritingSkillId");
                int inheritingSkillId = Convert.ToInt32(sectionString);
                m_playableUnitId_inheritorUnitId_inheritingSkillId.Add(new Tuple<int, int, int>(uniqueId, skillInheritorUnitId, inheritingSkillId));

                return new Unit(baseUnitData, uniqueId, nickname, accumulatedExperience, skills);
            }
            catch (Exception ex)
            {
                Debug.Log(ex.Message);
                return null;
            }
        }

        private Weapon StringToWeapon(string _string)
        {
            try
            {
                string sectionString = string.Empty;

                _string.DettachPortionFromString("<UniqueId>", "</UniqueId>", ref sectionString);
                sectionString = DataLoader.RemoveOpeningAndClosingTags(sectionString, "UniqueId");
                int uniqueId = Convert.ToInt32(sectionString);

                _string.DettachPortionFromString("<BaseWeaponId>", "</BaseWeaponId>", ref sectionString);
                sectionString = DataLoader.RemoveOpeningAndClosingTags(sectionString, "BaseWeaponId");
                int baseWeaponId = Convert.ToInt32(sectionString);
                WeaponData baseWeaponData = m_weaponDataList.First(x => x.Id == baseWeaponId);

                int accumulatedExperience = 0;
                if (_string.Contains("AccumulatedExperience"))
                {
                    _string.DettachPortionFromString("<AccumulatedExperience>", "</AccumulatedExperience>", ref sectionString);
                    sectionString = DataLoader.RemoveOpeningAndClosingTags(sectionString, "AccumulatedExperience");
                    accumulatedExperience = Convert.ToInt32(sectionString);
                }

                switch (baseWeaponData.WeaponType)
                {
                    default: //case eWeaponType.Ordinary
                        return new OrdinaryWeapon(baseWeaponData, uniqueId);
                    case eWeaponType.Levelable:
                        return new LevelableWeapon(baseWeaponData, uniqueId, accumulatedExperience);
                    case eWeaponType.Transformable:
                        return new TransformableWeapon(baseWeaponData, uniqueId);
                    case eWeaponType.LevelableTransformable:
                        return new LevelableTransformableWeapon(baseWeaponData, uniqueId, accumulatedExperience);
                }
            }
            catch (Exception ex)
            {
                Debug.Log(ex.Message);
                return null;
            }
        }

        private Armour StringToArmour(string _string)
        {
            try
            {
                string sectionString = string.Empty;

                _string.DettachPortionFromString("<UniqueId>", "</UniqueId>", ref sectionString);
                sectionString = DataLoader.RemoveOpeningAndClosingTags(sectionString, "UniqueId");
                int uniqueId = Convert.ToInt32(sectionString);

                _string.DettachPortionFromString("<BaseArmourId>", "</BaseArmourId>", ref sectionString);
                sectionString = DataLoader.RemoveOpeningAndClosingTags(sectionString, "BaseArmourId");
                int baseArmourId = Convert.ToInt32(sectionString);
                ArmourData baseArmourData = m_armourDataList.First(x => x.Id == baseArmourId);

                return new Armour(baseArmourData, uniqueId);
            }
            catch (Exception ex)
            {
                Debug.Log(ex.Message);
                return null;
            }
        }

        private Accessory StringToAccessory(string _string)
        {
            try
            {
                string sectionString = string.Empty;

                _string.DettachPortionFromString("<UniqueId>", "</UniqueId>", ref sectionString);
                sectionString = DataLoader.RemoveOpeningAndClosingTags(sectionString, "UniqueId");
                int uniqueId = Convert.ToInt32(sectionString);

                _string.DettachPortionFromString("<BaseAccessoryId>", "</BaseAccessoryId>", ref sectionString);
                sectionString = DataLoader.RemoveOpeningAndClosingTags(sectionString, "BaseAccessoryId");
                int baseAccessoryId = Convert.ToInt32(sectionString);
                AccessoryData baseAccessoryData = m_accessoryDataList.First(x => x.Id == baseAccessoryId);

                return new Accessory(baseAccessoryData, uniqueId);
            }
            catch (Exception ex)
            {
                Debug.Log(ex.Message);
                return null;
            }
        }

        private KeyValuePair<Item, int> StringToItemOwned(string _string)
        {
            try
            {
                string sectionString = string.Empty;

                _string.DettachPortionFromString("<ItemId>", "</ItemId>", ref sectionString);
                sectionString = DataLoader.RemoveOpeningAndClosingTags(sectionString, "ItemId");
                int id = Convert.ToInt32(sectionString);
                Item item = m_itemList.First(x => x.Id == id);

                _string.DettachPortionFromString("<Quantity>", "</Quantity>", ref sectionString);
                sectionString = DataLoader.RemoveOpeningAndClosingTags(sectionString, "Quantity");
                int quantity = Convert.ToInt32(sectionString);

                return new KeyValuePair<Item, int>(item, quantity);
            }
            catch (Exception ex)
            {
                Debug.Log(ex.Message);
                return new KeyValuePair<Item, int>();
            }
        }

        private MemberSet StringToMemberSet(string _string, List<Unit> _units, List<Weapon> _weapons, List<Armour> _armours, List<Accessory> _accessories)
        {
            try
            {
                string sectionString = string.Empty;

                _string.DettachPortionFromString("<Id>", "</Id>", ref sectionString);
                sectionString = DataLoader.RemoveOpeningAndClosingTags(sectionString, "Id");
                int id = Convert.ToInt32(sectionString);

                _string.DettachPortionFromString("<MemberId>", "</MemberId>", ref sectionString);
                sectionString = DataLoader.RemoveOpeningAndClosingTags(sectionString, "MemberId");
                int memberId = Convert.ToInt32(sectionString);
                Unit member = _units.First(x => x.UniqueId == memberId);

                Weapon mainWeapon = null;
                if (_string.Contains("MainWeaponId"))
                {
                    _string.DettachPortionFromString("<MainWeaponId>", "</MainWeaponId>", ref sectionString);
                    sectionString = DataLoader.RemoveOpeningAndClosingTags(sectionString, "MainWeaponId");
                    int mainWeaponId = Convert.ToInt32(sectionString);
                    mainWeapon = _weapons.First(x => x.UniqueId == mainWeaponId);
                }

                Weapon subWeapon = null;
                if (_string.Contains("SubWeaponId"))
                {
                    _string.DettachPortionFromString("<SubWeaponId>", "</SubWeaponId>", ref sectionString);
                    sectionString = DataLoader.RemoveOpeningAndClosingTags(sectionString, "MemberId");
                    int subWeaponId = Convert.ToInt32(sectionString);
                    subWeapon = _weapons.First(x => x.UniqueId == subWeaponId);
                }

                Armour armour = null;
                if (_string.Contains("ArmourId"))
                {
                    _string.DettachPortionFromString("<ArmourId>", "</ArmourId>", ref sectionString);
                    sectionString = DataLoader.RemoveOpeningAndClosingTags(sectionString, "ArmourId");
                    int armourId = Convert.ToInt32(sectionString);
                    armour = _armours.First(x => x.UniqueId == armourId);
                }

                Accessory accessory = null;
                if (_string.Contains("AccessoryId"))
                {
                    _string.DettachPortionFromString("<AccessoryId>", "</AccessoryId>", ref sectionString);
                    sectionString = DataLoader.RemoveOpeningAndClosingTags(sectionString, "AccessoryId");
                    int accessoryId = Convert.ToInt32(sectionString);
                    accessory = _accessories.First(x => x.UniqueId == accessoryId);
                }

                return new MemberSet { Id = id, Member = member, MainWeapon = mainWeapon, SubWeapon = subWeapon, Armour = armour, Accessory = accessory };
            }
            catch (Exception ex)
            {
                Debug.Log(ex.Message);
                return new MemberSet { Id = 0, Member = null, MainWeapon = null, SubWeapon = null, Armour = null, Accessory = null};
            }
        }

        private ItemSet StringToItemSet(string _string)
        {
            try
            {
                string sectionString = string.Empty;

                _string.DettachPortionFromString("<Id>", "</Id>", ref sectionString);
                sectionString = DataLoader.RemoveOpeningAndClosingTags(sectionString, "Id");
                int id = Convert.ToInt32(sectionString);

                _string.DettachPortionFromString("<Items>", "</Items>", ref sectionString);
                sectionString = DataLoader.RemoveOpeningAndClosingTags(sectionString, "Items");
                Dictionary<Item, int> quantityPerItem = new Dictionary<Item, int>();
                string itemString = "";
                while (sectionString != "")
                {
                    sectionString = sectionString.DettachPortionFromString("<Item>", "</Item>", ref itemString);

                    string itemIdString = "";
                    itemString.DettachPortionFromString("<ItemId>", "</ItemId>", ref itemIdString);
                    itemIdString = DataLoader.RemoveOpeningAndClosingTags(itemIdString, "ItemId");
                    int itemId = Convert.ToInt32(itemIdString);
                    Item item = m_itemList.First(x => x.Id == itemId);

                    string quantityString = "";
                    itemString.DettachPortionFromString("<Quantity>", "</Quantity>", ref quantityString);
                    quantityString = DataLoader.RemoveOpeningAndClosingTags(quantityString, "Quantity");
                    int quantity = Convert.ToInt32(quantityString);

                    quantityPerItem.Add(item, quantity);
                }

                return new ItemSet { Id = id, QuantityPerItem = quantityPerItem };
            }
            catch (Exception ex)
            {
                Debug.Log(ex.Message);
                return new ItemSet { Id = 0, QuantityPerItem = new Dictionary<Item, int>() };
            }
        }

        private Team StringToTeam(string _string, List<MemberSet> _memberSets, List<ItemSet> _itemSets)
        {
            try
            {
                string sectionString = string.Empty;

                _string.DettachPortionFromString("<MemberSetIds>", "</MemberSetIds>", ref sectionString);
                sectionString = DataLoader.RemoveOpeningAndClosingTags(sectionString, "MemberSetIds");
                List<MemberSet> memberSets = new List<MemberSet>();
                string memberSetIdString = "";
                while (sectionString != "")
                {
                    sectionString = sectionString.DettachPortionFromString("<MemberSetId>", "</MemberSetId>", ref memberSetIdString);
                    memberSetIdString = DataLoader.RemoveOpeningAndClosingTags(memberSetIdString, "MemberSetId");
                    int memberSetId = Convert.ToInt32(memberSetIdString);
                    MemberSet memberSet = _memberSets.First(x => x.Id == memberSetId);

                    memberSets.Add(memberSet);
                }

                ItemSet itemSet = null;
                if (_string.Contains("ItemSetId"))
                {
                    _string.DettachPortionFromString("<ItemSetId>", "</ItemSetId>", ref sectionString);
                    sectionString = DataLoader.RemoveOpeningAndClosingTags(sectionString, "ItemSetId");
                    int itemSetId = Convert.ToInt32(sectionString);
                    itemSet = _itemSets.FirstOrDefault(x => x.Id == itemSetId);
                }

                return new Team(memberSets, itemSet);
            }
            catch (Exception ex)
            {
                Debug.Log(ex.Message);
                return null;
            }
        }

        private List<UnitData> ResponseStringToUnitDataList(string _response)
        {
            List<UnitData> result = new List<UnitData>();

            _response = _response.Remove(0, "<Units>".Length);
            _response = _response.Remove(_response.Length - "</Units>".Length, "</Units>".Length);

            string unitDataString = string.Empty;
            while (_response != "")
            {
                _response = _response.DettachPortionFromString("<UnitData>", "</UnitData>", ref unitDataString);

                result.Add(StringToUnitData(unitDataString));
            }

            return result;
        }

        private UnitData StringToUnitData(string _string)
        {
            try
            {
                string sectionString = string.Empty;

                _string.DettachPortionFromString("<Id>", "</Id>", ref sectionString);
                sectionString = DataLoader.RemoveOpeningAndClosingTags(sectionString, "Id");
                int id = Convert.ToInt32(sectionString);

                _string.DettachPortionFromString("<Name>", "</Name>", ref sectionString);
                sectionString = DataLoader.RemoveOpeningAndClosingTags(sectionString, "Name");
                string name = sectionString;

                _string.DettachPortionFromString("<IconAsBytes>", "</IconAsBytes>", ref sectionString);
                sectionString = DataLoader.RemoveOpeningAndClosingTags(sectionString, "IconAsBytes");
                byte[] iconAsBytes = Convert.FromBase64String(sectionString);

                _string.DettachPortionFromString("<Gender>", "</Gender>", ref sectionString);
                sectionString = DataLoader.RemoveOpeningAndClosingTags(sectionString, "Gender");
                eGender gender = sectionString.ToCorrespondingEnumValue<eGender>();

                _string.DettachPortionFromString("<Rarity>", "</Rarity>", ref sectionString);
                sectionString = DataLoader.RemoveOpeningAndClosingTags(sectionString, "Rarity");
                eRarity rarity = sectionString.ToCorrespondingEnumValue<eRarity>();

                _string.DettachPortionFromString("<MovementRangeClassification>", "</MovementRangeClassification>", ref sectionString);
                sectionString = DataLoader.RemoveOpeningAndClosingTags(sectionString, "MovementRangeClassification");
                eTargetRangeClassification movementRangeClassification = sectionString.ToCorrespondingEnumValue<eTargetRangeClassification>();

                _string.DettachPortionFromString("<NonMovementActionRangeClassification>", "</NonMovementActionRangeClassification>", ref sectionString);
                sectionString = DataLoader.RemoveOpeningAndClosingTags(sectionString, "NonMovementActionRangeClassification");
                eTargetRangeClassification nonMovementActionRangeClassification = sectionString.ToCorrespondingEnumValue<eTargetRangeClassification>();

                _string.DettachPortionFromString("<Element1>", "</Element1>", ref sectionString);
                sectionString = DataLoader.RemoveOpeningAndClosingTags(sectionString, "Element1");
                eElement element1 = sectionString.ToCorrespondingEnumValue<eElement>();
                _string.DettachPortionFromString("<Element2>", "</Element2>", ref sectionString);
                sectionString = DataLoader.RemoveOpeningAndClosingTags(sectionString, "Element2");
                eElement element2 = sectionString.ToCorrespondingEnumValue<eElement>();
                List<eElement> elements = new List<eElement>();
                elements.Add(element1);
                elements.Add(element2);

                _string.DettachPortionFromString("<EquipableWeaponClassifications>", "</EquipableWeaponClassifications>", ref sectionString);
                sectionString = DataLoader.RemoveOpeningAndClosingTags(sectionString, "EquipableWeaponClassifications");
                List<eWeaponClassification> equipableWeaponClassifications = new List<eWeaponClassification>();
                string equipableWeaponClassificationString = "";
                while (sectionString != "")
                {
                    sectionString = sectionString.DettachPortionFromString("<WeaponClassification>", "</WeaponClassification>", ref equipableWeaponClassificationString);
                    equipableWeaponClassificationString = DataLoader.RemoveOpeningAndClosingTags(equipableWeaponClassificationString, "WeaponClassification");
                    eWeaponClassification equipableWeaponClassification = equipableWeaponClassificationString.ToCorrespondingEnumValue<eWeaponClassification>();
                    equipableWeaponClassifications.Add(equipableWeaponClassification);
                }

                _string.DettachPortionFromString("<EquipableArmourClassifications>", "</EquipableArmourClassifications>", ref sectionString);
                sectionString = DataLoader.RemoveOpeningAndClosingTags(sectionString, "EquipableArmourClassifications");
                List<eArmourClassification> equipableArmourClassifications = new List<eArmourClassification>();
                string equipableArmourClassificationString = "";
                while (sectionString != "")
                {
                    sectionString = sectionString.DettachPortionFromString("<ArmourClassification>", "</ArmourClassification>", ref equipableArmourClassificationString);
                    equipableArmourClassificationString = DataLoader.RemoveOpeningAndClosingTags(equipableArmourClassificationString, "ArmourClassification");
                    eArmourClassification equipableArmourClassification = equipableArmourClassificationString.ToCorrespondingEnumValue<eArmourClassification>();
                    equipableArmourClassifications.Add(equipableArmourClassification);
                }

                _string.DettachPortionFromString("<EquipableAccessoryClassifications>", "</EquipableAccessoryClassifications>", ref sectionString);
                sectionString = DataLoader.RemoveOpeningAndClosingTags(sectionString, "EquipableAccessoryClassifications");
                List<eAccessoryClassification> equipableAccessoryClassifications = new List<eAccessoryClassification>();
                string equipableAccessoryClassificationString = "";
                while (sectionString != "")
                {
                    sectionString = sectionString.DettachPortionFromString("<AccessoryClassification>", "</AccessoryClassification>", ref equipableAccessoryClassificationString);
                    equipableAccessoryClassificationString = DataLoader.RemoveOpeningAndClosingTags(equipableAccessoryClassificationString, "AccessoryClassification");
                    eAccessoryClassification equipableAccessoryClassification = equipableAccessoryClassificationString.ToCorrespondingEnumValue<eAccessoryClassification>();
                    equipableAccessoryClassifications.Add(equipableAccessoryClassification);
                }

                _string.DettachPortionFromString("<MaxLevelHP>", "</MaxLevelHP>", ref sectionString);
                sectionString = DataLoader.RemoveOpeningAndClosingTags(sectionString, "MaxLevelHP");
                int maxLevelHp = Convert.ToInt32(sectionString);

                _string.DettachPortionFromString("<MaxLevelPhysicalStrength>", "</MaxLevelPhysicalStrength>", ref sectionString);
                sectionString = DataLoader.RemoveOpeningAndClosingTags(sectionString, "MaxLevelPhysicalStrength");
                int maxLevelPhysicalStrength = Convert.ToInt32(sectionString);

                _string.DettachPortionFromString("<MaxLevelPhysicalResistance>", "</MaxLevelPhysicalResistance>", ref sectionString);
                sectionString = DataLoader.RemoveOpeningAndClosingTags(sectionString, "MaxLevelPhysicalResistance");
                int maxLevelPhysicalResistance = Convert.ToInt32(sectionString);

                _string.DettachPortionFromString("<MaxLevelMagicalStrength>", "</MaxLevelMagicalStrength>", ref sectionString);
                sectionString = DataLoader.RemoveOpeningAndClosingTags(sectionString, "MaxLevelMagicalStrength");
                int maxLevelMagicalStrength = Convert.ToInt32(sectionString);

                _string.DettachPortionFromString("<MaxLevelMagicalResistance>", "</MaxLevelMagicalResistance>", ref sectionString);
                sectionString = DataLoader.RemoveOpeningAndClosingTags(sectionString, "MaxLevelMagicalResistance");
                int maxLevelMagicalResistance = Convert.ToInt32(sectionString);

                _string.DettachPortionFromString("<MaxLevelVitality>", "</MaxLevelVitality>", ref sectionString);
                sectionString = DataLoader.RemoveOpeningAndClosingTags(sectionString, "MaxLevelVitality");
                int maxLevelVitality = Convert.ToInt32(sectionString);

                _string.DettachPortionFromString("<SkillIds>", "</SkillIds>", ref sectionString);
                sectionString = DataLoader.RemoveOpeningAndClosingTags(sectionString, "SkillIds");
                List<SkillData> skills = new List<SkillData>();
                string skillIdString = "";
                while (sectionString != "")
                {
                    sectionString = sectionString.DettachPortionFromString("<SkillId>", "</SkillId>", ref skillIdString);
                    skillIdString = DataLoader.RemoveOpeningAndClosingTags(skillIdString, "SkillId");
                    int skillId = Convert.ToInt32(skillIdString);
                    skills.Add(m_skillList.First(x => x.Id == skillId));
                }

                _string.DettachPortionFromString("<Labels>", "</Labels>", ref sectionString);
                sectionString = DataLoader.RemoveOpeningAndClosingTags(sectionString, "Labels");
                List<string> labels = new List<string>();
                string labelString = "";
                while (sectionString != "")
                {
                    sectionString = sectionString.DettachPortionFromString("<Label>", "</Label>", ref labelString);
                    labelString = DataLoader.RemoveOpeningAndClosingTags(labelString, "Label");
                    string label = labelString;
                    labels.Add(label);
                }

                _string.DettachPortionFromString("<Description>", "</Description>", ref sectionString);
                sectionString = DataLoader.RemoveOpeningAndClosingTags(sectionString, "Description");
                string description = sectionString;

                _string.DettachPortionFromString("<ProgressiveEvolutionRecipes>", "</ProgressiveEvolutionRecipes>", ref sectionString);
                sectionString = DataLoader.RemoveOpeningAndClosingTags(sectionString, "ProgressiveEvolutionRecipes");
                string progressiveEvolutionRecipeString = "";
                while (sectionString != "")
                {
                    sectionString = sectionString.DettachPortionFromString("<ProgressiveEvolutionRecipe>", "</ProgressiveEvolutionRecipe>", ref progressiveEvolutionRecipeString);
                    UnitEvolutionRecipeBase progressiveEvolutionRecipeBase = StringToUnitEvolutionRecipeBase(progressiveEvolutionRecipeString);
                    m_unitId_progressiveEvolutionRecipeBase.Add(id, progressiveEvolutionRecipeBase);
                }

                if (_string.Contains("RetrogressiveEvolutionRecipe"))
                {
                    _string.DettachPortionFromString("<RetrogressiveEvolutionRecipe>", "</RetrogressiveEvolutionRecipe>", ref sectionString);
                    UnitEvolutionRecipeBase retrogressiveEvolutionRecipeBase = StringToUnitEvolutionRecipeBase(sectionString);

                    m_unitId_retrogressiveEvolutionRecipeBase.Add(id, retrogressiveEvolutionRecipeBase);
                }

                return new UnitData(id, name, iconAsBytes, gender, rarity, movementRangeClassification, nonMovementActionRangeClassification, elements, equipableWeaponClassifications, equipableArmourClassifications, equipableAccessoryClassifications, maxLevelHp, maxLevelPhysicalStrength, maxLevelPhysicalResistance, maxLevelMagicalStrength, maxLevelMagicalResistance, maxLevelVitality, skills, labels, description);
            }
            catch (Exception ex)
            {
                Debug.Log(ex.Message);
                return null;
            }
        }

        private UnitEvolutionRecipeBase StringToUnitEvolutionRecipeBase(string _string)
        {
            string sectionString = String.Empty;

            _string.DettachPortionFromString("<AfterEvolutionUnitId>", "</AfterEvolutionUnitId>", ref sectionString);
            sectionString = DataLoader.RemoveOpeningAndClosingTags(sectionString, "AfterEvolutionUnitId");
            int afterEvolutionUnitId = Convert.ToInt32(sectionString);

            _string.DettachPortionFromString("<MaterialIds>", "</MaterialIds>", ref sectionString);
            sectionString = DataLoader.RemoveOpeningAndClosingTags(sectionString, "MaterialIds");
            List<int> materialIds = new List<int>();
            string materialIdString = "";
            while (sectionString != "")
            {
                sectionString = sectionString.DettachPortionFromString("<MaterialIds>", "</Label>", ref materialIdString);
                materialIdString = DataLoader.RemoveOpeningAndClosingTags(materialIdString, "Label");
                int materialId = Convert.ToInt32(materialIdString);
                materialIds.Add(materialId);
            }
            if (materialIds.Count != CoreValues.MAX_NUM_OF_ELEMENTS_IN_RECIPE)
                return null;

            _string.DettachPortionFromString("<Cost>", "</Cost>", ref sectionString);
            sectionString = DataLoader.RemoveOpeningAndClosingTags(sectionString, "Cost");
            int cost = Convert.ToInt32(sectionString);

            return new UnitEvolutionRecipeBase(afterEvolutionUnitId, materialIds[0], materialIds[1], materialIds[2], materialIds[4], materialIds[5], cost);
        }

        private List<Item> ResponseStringToItemList(string _response)
        {
            List<Item> result = new List<Item>();

            _response = _response.Remove(0, "<Items>".Length);
            _response = _response.Remove(_response.Length - "</Items>".Length, "</Items>".Length);

            string itemString = string.Empty;
            while (_response != "")
            {
                if (_response.StartsWith("<SkillItem>"))
                    _response = _response.DettachPortionFromString("<SkillItem>", "</SkillItem>", ref itemString);
                else if (_response.StartsWith("<SkillMaterial>"))
                    _response = _response.DettachPortionFromString("<SkillMaterial>", "</SkillMaterial>", ref itemString);
                else if (_response.StartsWith("<ItemMaterial>"))
                    _response = _response.DettachPortionFromString("<ItemMaterial>", "</ItemMaterial>", ref itemString);
                else if (_response.StartsWith("<EquipmentMaterial>"))
                    _response = _response.DettachPortionFromString("<EquipmentMaterial>", "</EquipmentMaterial>", ref itemString);
                else if (_response.StartsWith("<EvolutionMaterial>"))
                    _response = _response.DettachPortionFromString("<EvolutionMaterial>", "</EvolutionMaterial>", ref itemString);

                result.Add(StringToItem(itemString));
            }

            return result;
        }

        private Item StringToItem(string _string)
        {
            try
            {
                string sectionString = string.Empty;

                _string.DettachPortionFromString("<Id>", "</Id>", ref sectionString);
                sectionString = DataLoader.RemoveOpeningAndClosingTags(sectionString, "Id");
                int id = Convert.ToInt32(sectionString);

                _string.DettachPortionFromString("<Name>", "</Name>", ref sectionString);
                sectionString = DataLoader.RemoveOpeningAndClosingTags(sectionString, "Name");
                string name = sectionString;

                _string.DettachPortionFromString("<IconAsBytes>", "</IconAsBytes>", ref sectionString);
                sectionString = DataLoader.RemoveOpeningAndClosingTags(sectionString, "IconAsBytes");
                byte[] iconAsBytes = Convert.FromBase64String(sectionString);

                _string.DettachPortionFromString("<Rarity>", "</Rarity>", ref sectionString);
                sectionString = DataLoader.RemoveOpeningAndClosingTags(sectionString, "Rarity");
                eRarity rarity = sectionString.ToCorrespondingEnumValue<eRarity>();

                _string.DettachPortionFromString("<SellingPrice>", "</SellingPrice>", ref sectionString);
                sectionString = DataLoader.RemoveOpeningAndClosingTags(sectionString, "SellingPrice");
                int sellingPrice = Convert.ToInt32(sectionString);

                if (_string.StartsWith("<SkillItem>"))
                {
                    _string.DettachPortionFromString("<SkillId>", "</SkillId>", ref sectionString);
                    sectionString = DataLoader.RemoveOpeningAndClosingTags(sectionString, "SkillId");
                    int skillId = Convert.ToInt32(sectionString);
                    SkillData skillData = m_skillList.First(x => x.Id == skillId);
                    _string.DettachPortionFromString("<SkillLevel>", "</SkillLevel>", ref sectionString);
                    sectionString = DataLoader.RemoveOpeningAndClosingTags(sectionString, "SkillLevel");
                    int skillLevel = Convert.ToInt32(sectionString);
                    Skill skill = null;
                    if (skillData is OrdinarySkillData)
                        skill = new OrdinarySkill(skillData as OrdinarySkillData, skillLevel);
                    else if (skillData is CounterSkillData)
                        skill = new CounterSkill(skillData as CounterSkillData, skillLevel);
                    else if (skillData is UltimateSkillData)
                        skill = new UltimateSkill(skillData as UltimateSkillData, skillLevel);
                    else if (skillData is PassiveSkillData)
                        skill = new PassiveSkill(skillData as PassiveSkillData, skillLevel);

                    return new SkillItem(id, name, iconAsBytes, rarity, sellingPrice, skill);
                }
                else if (_string.StartsWith("<SkillMaterial>"))
                    return new SkillMaterial(id, name, iconAsBytes, rarity, sellingPrice);
                else if (_string.StartsWith("<ItemMaterial>"))
                    return new ItemMaterial(id, name, iconAsBytes, rarity, sellingPrice);
                else if (_string.StartsWith("<EquipmentMaterial>"))
                    return new EquipmentMaterial(id, name, iconAsBytes, rarity, sellingPrice);
                else if (_string.StartsWith("<EvolutionMaterial>"))
                    return new EvolutionMaterial(id, name, iconAsBytes, rarity, sellingPrice);

                return null;
            }
            catch (Exception ex)
            {
                Debug.Log(ex.Message);
                return null;
            }
        }

        private List<WeaponData> ResponseStringToWeaponDataList(string _response)
        {
            List<WeaponData> result = new List<WeaponData>();

            _response = _response.Remove(0, "<Weapons>".Length);
            _response = _response.Remove(_response.Length - "</Weapons>".Length, "</Weapons>".Length);

            string weaponDataString = string.Empty;
            while (_response != "")
            {
                _response = _response.DettachPortionFromString("<WeaponData>", "</WeaponData>", ref weaponDataString);

                result.Add(StringToWeaponData(weaponDataString));
            }

            return result;
        }

        private WeaponData StringToWeaponData(string _string)
        {
            try
            {
                string sectionString = string.Empty;

                _string.DettachPortionFromString("<Id>", "</Id>", ref sectionString);
                sectionString = DataLoader.RemoveOpeningAndClosingTags(sectionString, "Id");
                int id = Convert.ToInt32(sectionString);

                _string.DettachPortionFromString("<Name>", "</Name>", ref sectionString);
                sectionString = DataLoader.RemoveOpeningAndClosingTags(sectionString, "Name");
                string name = sectionString;

                _string.DettachPortionFromString("<IconAsBytes>", "</IconAsBytes>", ref sectionString);
                sectionString = DataLoader.RemoveOpeningAndClosingTags(sectionString, "IconAsBytes");
                byte[] iconAsBytes = Convert.FromBase64String(sectionString);

                _string.DettachPortionFromString("<Rarity>", "</Rarity>", ref sectionString);
                sectionString = DataLoader.RemoveOpeningAndClosingTags(sectionString, "Rarity");
                eRarity rarity = sectionString.ToCorrespondingEnumValue<eRarity>();

                _string.DettachPortionFromString("<StatusEffectDataIds>", "</StatusEffectDataIds>", ref sectionString);
                sectionString = DataLoader.RemoveOpeningAndClosingTags(sectionString, "StatusEffectDataIds");
                List<StatusEffectData> statusEffectsData = new List<StatusEffectData>();
                string statusEffectDataIdString = "";
                while (sectionString != "")
                {
                    sectionString = sectionString.DettachPortionFromString("<StatusEffectDataId>", "</StatusEffectDataId>", ref statusEffectDataIdString);
                    statusEffectDataIdString = DataLoader.RemoveOpeningAndClosingTags(statusEffectDataIdString, "StatusEffectDataId");
                    int statusEffectDataId = Convert.ToInt32(statusEffectDataIdString);
                    statusEffectsData.Add(m_statusEffectDataList.First(x => x.Id == statusEffectDataId));
                }

                _string.DettachPortionFromString("<WeaponType>", "</WeaponType>", ref sectionString);
                sectionString = DataLoader.RemoveOpeningAndClosingTags(sectionString, "WeaponType");
                eWeaponType weaponType = sectionString.ToCorrespondingEnumValue<eWeaponType>();

                _string.DettachPortionFromString("<WeaponClassifications>", "</WeaponClassifications>", ref sectionString);
                sectionString = DataLoader.RemoveOpeningAndClosingTags(sectionString, "WeaponClassifications");
                List<eWeaponClassification> weaponClassifications = new List<eWeaponClassification>();
                string weaponClassificationString = "";
                while (sectionString != "")
                {
                    sectionString = sectionString.DettachPortionFromString("<WeaponClassification>", "</WeaponClassification>", ref weaponClassificationString);
                    weaponClassificationString = DataLoader.RemoveOpeningAndClosingTags(weaponClassificationString, "WeaponClassification");
                    eWeaponClassification weaponClassification = weaponClassificationString.ToCorrespondingEnumValue<eWeaponClassification>();
                    weaponClassifications.Add(weaponClassification);
                }

                _string.DettachPortionFromString("<MainWeaponSkillId>", "</MainWeaponSkillId>", ref sectionString);
                sectionString = DataLoader.RemoveOpeningAndClosingTags(sectionString, "MainWeaponSkillId");
                int mainWeaponSkillId = Convert.ToInt32(sectionString);
                SkillData mainWeaponSkillData = m_skillList.First(x => x.Id == mainWeaponSkillId);
                _string.DettachPortionFromString("<MainWeaponSkillLevel>", "</MainWeaponSkillLevel>", ref sectionString);
                sectionString = DataLoader.RemoveOpeningAndClosingTags(sectionString, "MainWeaponSkillLevel");
                int mainWeaponSkillLevel = Convert.ToInt32(sectionString);
                Skill mainWeaponSkill = null;
                if (mainWeaponSkillData is OrdinarySkillData)
                    mainWeaponSkill = new OrdinarySkill(mainWeaponSkillData as OrdinarySkillData, mainWeaponSkillLevel);
                else if (mainWeaponSkillData is CounterSkillData)
                    mainWeaponSkill = new CounterSkill(mainWeaponSkillData as CounterSkillData, mainWeaponSkillLevel);
                else if (mainWeaponSkillData is UltimateSkillData)
                    mainWeaponSkill = new UltimateSkill(mainWeaponSkillData as UltimateSkillData, mainWeaponSkillLevel);
                else if (mainWeaponSkillData is PassiveSkillData)
                    mainWeaponSkill = new PassiveSkill(mainWeaponSkillData as PassiveSkillData, mainWeaponSkillLevel);

                if (weaponType == eWeaponType.LevelableTransformable || weaponType == eWeaponType.Transformable)
                {
                    _string.DettachPortionFromString("<TargetWeaponsInCaseTypeIsTransformable>", "</TargetWeaponsInCaseTypeIsTransformable>", ref sectionString);
                    sectionString = DataLoader.RemoveOpeningAndClosingTags(sectionString, "TargetWeaponsInCaseTypeIsTransformable");
                    string targetWeaponDataIdString = "";
                    while (sectionString != "")
                    {
                        sectionString = sectionString.DettachPortionFromString("<WeaponId>", "</WeaponId>", ref targetWeaponDataIdString);
                        targetWeaponDataIdString = DataLoader.RemoveOpeningAndClosingTags(targetWeaponDataIdString, "WeaponId");
                        int targetWeaponDataId = Convert.ToInt32(targetWeaponDataIdString);
                        m_weaponId_transformableWeaponId.Add(id, targetWeaponDataId);
                    }
                }

                return new WeaponData(id, name, iconAsBytes, rarity, statusEffectsData, weaponType, weaponClassifications, mainWeaponSkill, new List<WeaponData>());
            }
            catch (Exception ex)
            {
                Debug.Log(ex.Message);
                return null;
            }
        }

        private List<ArmourData> ResponseStringToArmourDataList(string _response)
        {
            List<ArmourData> result = new List<ArmourData>();

            _response = _response.Remove(0, "<Armours>".Length);
            _response = _response.Remove(_response.Length - "</Armours>".Length, "</Armours>".Length);

            string armourDataString = string.Empty;
            while (_response != "")
            {
                _response = _response.DettachPortionFromString("<ArmourData>", "</ArmourData>", ref armourDataString);

                result.Add(StringToArmourData(armourDataString));
            }

            return result;
        }

        private ArmourData StringToArmourData(string _string)
        {
            try
            {
                string sectionString = string.Empty;

                _string.DettachPortionFromString("<Id>", "</Id>", ref sectionString);
                sectionString = DataLoader.RemoveOpeningAndClosingTags(sectionString, "Id");
                int id = Convert.ToInt32(sectionString);

                _string.DettachPortionFromString("<Name>", "</Name>", ref sectionString);
                sectionString = DataLoader.RemoveOpeningAndClosingTags(sectionString, "Name");
                string name = sectionString;

                _string.DettachPortionFromString("<IconAsBytes>", "</IconAsBytes>", ref sectionString);
                sectionString = DataLoader.RemoveOpeningAndClosingTags(sectionString, "IconAsBytes");
                byte[] iconAsBytes = Convert.FromBase64String(sectionString);

                _string.DettachPortionFromString("<Rarity>", "</Rarity>", ref sectionString);
                sectionString = DataLoader.RemoveOpeningAndClosingTags(sectionString, "Rarity");
                eRarity rarity = sectionString.ToCorrespondingEnumValue<eRarity>();

                _string.DettachPortionFromString("<StatusEffectDataIds>", "</StatusEffectDataIds>", ref sectionString);
                sectionString = DataLoader.RemoveOpeningAndClosingTags(sectionString, "StatusEffectDataIds");
                List<StatusEffectData> statusEffectsData = new List<StatusEffectData>();
                string statusEffectDataIdString = "";
                while (sectionString != "")
                {
                    sectionString = sectionString.DettachPortionFromString("<StatusEffectDataId>", "</StatusEffectDataId>", ref statusEffectDataIdString);
                    statusEffectDataIdString = DataLoader.RemoveOpeningAndClosingTags(statusEffectDataIdString, "StatusEffectDataId");
                    int statusEffectDataId = Convert.ToInt32(statusEffectDataIdString);
                    statusEffectsData.Add(m_statusEffectDataList.First(x => x.Id == statusEffectDataId));
                }

                _string.DettachPortionFromString("<ArmourClassification>", "</ArmourClassification>", ref sectionString);
                sectionString = DataLoader.RemoveOpeningAndClosingTags(sectionString, "ArmourClassification");
                eArmourClassification armourClassification = sectionString.ToCorrespondingEnumValue<eArmourClassification>();

                _string.DettachPortionFromString("<TargetGender>", "</TargetGender>", ref sectionString);
                sectionString = DataLoader.RemoveOpeningAndClosingTags(sectionString, "TargetGender");
                eGender targetGender = sectionString.ToCorrespondingEnumValue<eGender>();

                return new ArmourData(id, name, iconAsBytes, rarity, statusEffectsData, armourClassification, targetGender);
            }
            catch (Exception ex)
            {
                Debug.Log(ex.Message);
                return null;
            }
        }

        private List<AccessoryData> ResponseStringToAccessoryDataList(string _response)
        {
            List<AccessoryData> result = new List<AccessoryData>();

            _response = _response.Remove(0, "<Accessories>".Length);
            _response = _response.Remove(_response.Length - "</Accessories>".Length, "</Accessories>".Length);

            string accessoryDataString = string.Empty;
            while (_response != "")
            {
                _response = _response.DettachPortionFromString("<ArmourData>", "</ArmourData>", ref accessoryDataString);

                result.Add(StringToAccessoryData(accessoryDataString));
            }

            return result;
        }

        private AccessoryData StringToAccessoryData(string _string)
        {
            try
            {
                string sectionString = string.Empty;

                _string.DettachPortionFromString("<Id>", "</Id>", ref sectionString);
                sectionString = DataLoader.RemoveOpeningAndClosingTags(sectionString, "Id");
                int id = Convert.ToInt32(sectionString);

                _string.DettachPortionFromString("<Name>", "</Name>", ref sectionString);
                sectionString = DataLoader.RemoveOpeningAndClosingTags(sectionString, "Name");
                string name = sectionString;

                _string.DettachPortionFromString("<IconAsBytes>", "</IconAsBytes>", ref sectionString);
                sectionString = DataLoader.RemoveOpeningAndClosingTags(sectionString, "IconAsBytes");
                byte[] iconAsBytes = Convert.FromBase64String(sectionString);

                _string.DettachPortionFromString("<Rarity>", "</Rarity>", ref sectionString);
                sectionString = DataLoader.RemoveOpeningAndClosingTags(sectionString, "Rarity");
                eRarity rarity = sectionString.ToCorrespondingEnumValue<eRarity>();

                _string.DettachPortionFromString("<StatusEffectDataIds>", "</StatusEffectDataIds>", ref sectionString);
                sectionString = DataLoader.RemoveOpeningAndClosingTags(sectionString, "StatusEffectDataIds");
                List<StatusEffectData> statusEffectsData = new List<StatusEffectData>();
                string statusEffectDataIdString = "";
                while (sectionString != "")
                {
                    sectionString = sectionString.DettachPortionFromString("<StatusEffectDataId>", "</StatusEffectDataId>", ref statusEffectDataIdString);
                    statusEffectDataIdString = DataLoader.RemoveOpeningAndClosingTags(statusEffectDataIdString, "StatusEffectDataId");
                    int statusEffectDataId = Convert.ToInt32(statusEffectDataIdString);
                    statusEffectsData.Add(m_statusEffectDataList.First(x => x.Id == statusEffectDataId));
                }

                _string.DettachPortionFromString("<AccessoryClassification>", "</AccessoryClassification>", ref sectionString);
                sectionString = DataLoader.RemoveOpeningAndClosingTags(sectionString, "AccessoryClassification");
                eAccessoryClassification accessoryClassification = sectionString.ToCorrespondingEnumValue<eAccessoryClassification>();

                _string.DettachPortionFromString("<TargetGender>", "</TargetGender>", ref sectionString);
                sectionString = DataLoader.RemoveOpeningAndClosingTags(sectionString, "TargetGender");
                eGender targetGender = sectionString.ToCorrespondingEnumValue<eGender>();

                return new AccessoryData(id, name, iconAsBytes, rarity, statusEffectsData, accessoryClassification, targetGender);
            }
            catch (Exception ex)
            {
                Debug.Log(ex.Message);
                return null;
            }
        }

        private List<StatusEffectData> ResponseStringToStatusEffectDataList(string _response)
        {
            try
            {
                List<StatusEffectData> result = new List<StatusEffectData>();

                _response = _response.Remove(0, "<StatusEffects>".Length);
                _response = _response.Remove(_response.Length - "</StatusEffects>".Length, "</StatusEffects>".Length);

                string statusEffectDataString = string.Empty;
                while (_response != "")
                {
                    if (_response.StartsWith("<BuffStatusEffectData>"))
                        _response = _response.DettachPortionFromString("<BuffStatusEffectData>", "</BuffStatusEffectData>", ref statusEffectDataString);
                    else if (_response.StartsWith("<DebuffStatusEffectData>"))
                        _response = _response.DettachPortionFromString("<DebuffStatusEffectData>", "</DebuffStatusEffectData>", ref statusEffectDataString);
                    else if (_response.StartsWith("<TargetRangeModStatusEffectData>"))
                        _response = _response.DettachPortionFromString("<TargetRangeModStatusEffectData>", "</StatusEffectAttachmentEffect>", ref statusEffectDataString);
                    else if (_response.StartsWith("<DamageStatusEffectData>"))
                        _response = _response.DettachPortionFromString("<DamageStatusEffectData>", "</DamageStatusEffectData>", ref statusEffectDataString);
                    else if (_response.StartsWith("<HealStatusEffectData>"))
                        _response = _response.DettachPortionFromString("<HealStatusEffectData>", "</HealStatusEffectData>", ref statusEffectDataString);

                        result.Add(StringToStatusEffectData(statusEffectDataString));
                }

                return result;
            }
            catch (Exception ex)
            {
                Debug.Log(ex.Message);
                return null;
            }
        }

        private StatusEffectData StringToStatusEffectData(string _string)
        {
            try
            {
                string sectionString = string.Empty;

                _string.DettachPortionFromString("<Id>", "</Id>", ref sectionString);
                sectionString = DataLoader.RemoveOpeningAndClosingTags(sectionString, "Id");
                int id = Convert.ToInt32(sectionString); 

                _string.DettachPortionFromString("<Duration>", "</Duration>", ref sectionString);
                DurationData durationData = StringToDurationData(sectionString);

                _string.DettachPortionFromString("<ActivationCondition>", "</ActivationCondition>", ref sectionString);
                ComplexCondition activationCondition = StringToComplexCondition(sectionString, "ActivationCondition");

                _string.DettachPortionFromString("<IconAsBytes>", "</IconAsBytes>", ref sectionString);
                sectionString = DataLoader.RemoveOpeningAndClosingTags(sectionString, "IconAsBytes");
                byte[] iconAsBytes = Convert.FromBase64String(sectionString);

                if (_string.StartsWith("<BuffStatusEffectData>")
                    || _string.StartsWith("<DebuffStatusEffectData>")
                    || _string.StartsWith("<TargetRangeModStatusEffectData>"))
                {
                    return StringToBackgroundStatusEffectData(_string, id, durationData, activationCondition, iconAsBytes);
                }
                else if (_string.StartsWith("<DamageStatusEffectData>")
                    || _string.StartsWith("<HealStatusEffectData>"))
                {
                    return StringToForegroundStatusEffectData(_string, id, durationData, activationCondition, iconAsBytes);
                }

                return null;
            }
            catch (Exception ex)
            {
                Debug.Log(ex.Message);
                return null;
            }
        }

        private BackgroundStatusEffectData StringToBackgroundStatusEffectData(string _string, int _id, DurationData _duration, ComplexCondition _activationCondition, byte[] _iconAsBytes)
        {
            try
            {
                string sectionString = string.Empty;

                _string.DettachPortionFromString("<ActivationTurnClassification>", "</ActivationTurnClassification>", ref sectionString);
                sectionString = DataLoader.RemoveOpeningAndClosingTags(sectionString, "ActivationTurnClassification");
                eActivationTurnClassification activationTurnClassification = sectionString.ToCorrespondingEnumValue<eActivationTurnClassification>();

                if (_string.StartsWith("<BuffStatusEffectData>"))
                    return StringToBuffStatusEffectData(_string, _id, _duration, activationTurnClassification, _activationCondition, _iconAsBytes);
                else if (_string.StartsWith("<DebuffStatusEffectData>"))
                    return StringToDebuffStatusEffectData(_string, _id, _duration, activationTurnClassification, _activationCondition, _iconAsBytes);
                else if (_string.StartsWith("<TargetRangeModStatusEffectData>"))
                    return StringToTargetRangeModStatusEffectData(_string, _id, _duration, activationTurnClassification, _activationCondition, _iconAsBytes);

                return null;
            }
            catch (Exception ex)
            {
                Debug.Log(ex.Message);
                return null;
            }
        }

        private BuffStatusEffectData StringToBuffStatusEffectData(string _string, int _id, DurationData _duration, eActivationTurnClassification _activationTurnClassification, ComplexCondition _activationCondition, byte[] _iconAsBytes)
        {
            try
            {
                string sectionString = string.Empty;

                _string.DettachPortionFromString("<TargetStatusType>", "</TargetStatusType>", ref sectionString);
                sectionString = DataLoader.RemoveOpeningAndClosingTags(sectionString, "TargetStatusType");
                eStatusType targetStatusType = sectionString.ToCorrespondingEnumValue<eStatusType>();

                _string.DettachPortionFromString("<Value>", "</Value>", ref sectionString);
                sectionString = DataLoader.RemoveOpeningAndClosingTags(sectionString, "Value");
                Tag value = Tag.NewTag(sectionString);

                _string.DettachPortionFromString("<IsSum>", "</IsSum>", ref sectionString);
                sectionString = DataLoader.RemoveOpeningAndClosingTags(sectionString, "IsSum");
                bool isSum = Convert.ToBoolean(sectionString);

                return new BuffStatusEffectData(_id, _duration, _activationTurnClassification, _activationCondition, _iconAsBytes, targetStatusType, value, isSum);
            }
            catch (Exception ex)
            {
                Debug.Log(ex.Message);
                return null;
            }
        }

        private DebuffStatusEffectData StringToDebuffStatusEffectData(string _string, int _id, DurationData _duration, eActivationTurnClassification _activationTurnClassification, ComplexCondition _activationCondition, byte[] _iconAsBytes)
        {
            try
            {
                string sectionString = string.Empty;

                _string.DettachPortionFromString("<TargetStatusType>", "</TargetStatusType>", ref sectionString);
                sectionString = DataLoader.RemoveOpeningAndClosingTags(sectionString, "TargetStatusType");
                eStatusType targetStatusType = sectionString.ToCorrespondingEnumValue<eStatusType>();

                _string.DettachPortionFromString("<Value>", "</Value>", ref sectionString);
                sectionString = DataLoader.RemoveOpeningAndClosingTags(sectionString, "Value");
                Tag value = Tag.NewTag(sectionString);

                _string.DettachPortionFromString("<IsSum>", "</IsSum>", ref sectionString);
                sectionString = DataLoader.RemoveOpeningAndClosingTags(sectionString, "IsSum");
                bool isSum = Convert.ToBoolean(sectionString);

                return new DebuffStatusEffectData(_id, _duration, _activationTurnClassification, _activationCondition, _iconAsBytes, targetStatusType, value, isSum);
            }
            catch (Exception ex)
            {
                Debug.Log(ex.Message);
                return null;
            }
        }

        private TargetRangeModStatusEffectData StringToTargetRangeModStatusEffectData(string _string, int _id, DurationData _duration, eActivationTurnClassification _activationTurnClassification, ComplexCondition _activationCondition, byte[] _iconAsBytes)
        {
            try
            {
                string sectionString = string.Empty;

                _string.DettachPortionFromString("<IsMovementRangeClassification>", "</IsMovementRangeClassification>", ref sectionString);
                sectionString = DataLoader.RemoveOpeningAndClosingTags(sectionString, "IsMovementRangeClassification");
                bool isMovementRangeClassification = Convert.ToBoolean(sectionString);

                _string.DettachPortionFromString("<TargetRangeClassification>", "</TargetRangeClassification>", ref sectionString);
                sectionString = DataLoader.RemoveOpeningAndClosingTags(sectionString, "TargetRangeClassification");
                eTargetRangeClassification targetRangeClassification = sectionString.ToCorrespondingEnumValue<eTargetRangeClassification>();

                _string.DettachPortionFromString("<ModificationMethod>", "</ModificationMethod>", ref sectionString);
                sectionString = DataLoader.RemoveOpeningAndClosingTags(sectionString, "ModificationMethod");
                eModificationMethod modificationMethod = sectionString.ToCorrespondingEnumValue<eModificationMethod>();

                return new TargetRangeModStatusEffectData(_id, _duration, _activationTurnClassification, _activationCondition, _iconAsBytes, isMovementRangeClassification, targetRangeClassification, modificationMethod);
            }
            catch (Exception ex)
            {
                Debug.Log(ex.Message);
                return null;
            }
        }

        private ForegroundStatusEffectData StringToForegroundStatusEffectData(string _string, int _id, DurationData _duration, ComplexCondition _activationCondition, byte[] _iconAsBytes)
        {
            try
            {
                string sectionString = string.Empty;

                _string.DettachPortionFromString("<ActivationTurnClassification>", "</ActivationTurnClassification>", ref sectionString);
                sectionString = DataLoader.RemoveOpeningAndClosingTags(sectionString, "ActivationTurnClassification");
                eActivationTurnClassification activationTurnClassification = sectionString.ToCorrespondingEnumValue<eActivationTurnClassification>();

                _string.DettachPortionFromString("<EventTriggerTiming>", "</EventTriggerTiming>", ref sectionString);
                sectionString = DataLoader.RemoveOpeningAndClosingTags(sectionString, "EventTriggerTiming");
                eEventTriggerTiming eventTriggerTiming = sectionString.ToCorrespondingEnumValue<eEventTriggerTiming>();

                _string.DettachPortionFromString("<AnimationId>", "</AnimationId>", ref sectionString);
                sectionString = DataLoader.RemoveOpeningAndClosingTags(sectionString, "AnimationId");
                int animationId = Convert.ToInt32(sectionString);

                if (_string.StartsWith("<DamageStatusEffectData>"))
                    return StringToDamageStatusEffectData(_string, _id, _duration, activationTurnClassification, eventTriggerTiming, _activationCondition, _iconAsBytes, animationId);
                else if (_string.StartsWith("<HealStatusEffectData>"))
                    return StringToHealStatusEffectData(_string, _id, _duration, activationTurnClassification, eventTriggerTiming, _activationCondition, _iconAsBytes, animationId);

                return null;
            }
            catch (Exception ex)
            {
                Debug.Log(ex.Message);
                return null;
            }
        }

        private DamageStatusEffectData StringToDamageStatusEffectData(string _string, int _id, DurationData _duration, eActivationTurnClassification _activationTurnClassification, eEventTriggerTiming _eventTriggerTiming, ComplexCondition _activationCondition, byte[] _iconAsBytes, int _animationId)
        {
            try
            {
                string sectionString = string.Empty;

                _string.DettachPortionFromString("<Value>", "</Value>", ref sectionString);
                sectionString = DataLoader.RemoveOpeningAndClosingTags(sectionString, "Value");
                Tag value = Tag.NewTag(sectionString);

                return new DamageStatusEffectData(_id, _duration, _activationTurnClassification, _eventTriggerTiming, _activationCondition, _iconAsBytes, _animationId, value);
            }
            catch (Exception ex)
            {
                Debug.Log(ex.Message);
                return null;
            }
        }

        private HealStatusEffectData StringToHealStatusEffectData(string _string, int _id, DurationData _duration, eActivationTurnClassification _activationTurnClassification, eEventTriggerTiming _eventTriggerTiming, ComplexCondition _activationCondition, byte[] _iconAsBytes, int _animationId)
        {
            try
            {
                string sectionString = string.Empty;

                _string.DettachPortionFromString("<Value>", "</Value>", ref sectionString);
                sectionString = DataLoader.RemoveOpeningAndClosingTags(sectionString, "Value");
                Tag value = Tag.NewTag(sectionString);

                return new HealStatusEffectData(_id, _duration, _activationTurnClassification, _eventTriggerTiming, _activationCondition, _iconAsBytes, _animationId, value);
            }
            catch (Exception ex)
            {
                Debug.Log(ex.Message);
                return null;
            }
        }

        private DurationData StringToDurationData(string _string)
        {
            try
            {
                string sectionString = string.Empty;

                _string.DettachPortionFromString("<ActivationTimes>", "</ActivationTimes>", ref sectionString);
                sectionString = DataLoader.RemoveOpeningAndClosingTags(sectionString, "ActivationTimes");
                Tag activationTimes = Tag.NewTag(sectionString);

                _string.DettachPortionFromString("<Turns>", "</Turns>", ref sectionString);
                sectionString = DataLoader.RemoveOpeningAndClosingTags(sectionString, "Turns");
                Tag turns = Tag.NewTag(sectionString);

                _string.DettachPortionFromString("<WhileCondition>", "</WhileCondition>", ref sectionString);
                ComplexCondition whileCondition = StringToComplexCondition(sectionString, "WhileCondition");

                return new DurationData(activationTimes, turns, whileCondition);
            }
            catch (Exception ex)
            {
                Debug.Log(ex.Message);
                return null;
            }
        }

        private List<Effect> ResponseStringToEffectList(string _response)
        {
            try
            {
                List<Effect> result = new List<Effect>();

                _response = _response.Remove(0, "<Effects>".Length);
                _response = _response.Remove(_response.Length - "</Effects>".Length, "</Effects>".Length);

                string effectString = string.Empty;
                while (_response != "")
                {
                    if (_response.StartsWith("<DamageEffect>"))
                        _response = _response.DettachPortionFromString("<DamageEffect>", "</DamageEffect>", ref effectString);
                    else if (_response.StartsWith("<HealEffect>"))
                        _response = _response.DettachPortionFromString("<HealEffect>", "</HealEffect>", ref effectString);
                    else if (_response.StartsWith("<StatusEffectAttachmentEffect>"))
                        _response = _response.DettachPortionFromString("<StatusEffectAttachmentEffect>", "</StatusEffectAttachmentEffect>", ref effectString);

                    result.Add(StringToEffect(effectString));
                }

                return result;
            }
            catch (Exception ex)
            {
                Debug.Log(ex.Message);
                return null;
            }
        }

        private Effect StringToEffect(string _string)
        {
            try
            {
                string sectionString = string.Empty;

                _string.DettachPortionFromString("<Id>", "</Id>", ref sectionString);
                sectionString = DataLoader.RemoveOpeningAndClosingTags(sectionString, "Id");
                int id = Convert.ToInt32(sectionString);

                _string.DettachPortionFromString("<ActivationCondition>", "</ActivationCondition>", ref sectionString);
                ComplexCondition activationCondition = StringToComplexCondition(sectionString, "ActivationCondition");

                _string.DettachPortionFromString("<TimesToApply>", "</TimesToApply>", ref sectionString);
                sectionString = DataLoader.RemoveOpeningAndClosingTags(sectionString, "TimesToApply");
                Tag timesToAplly = Tag.NewTag(sectionString);

                _string.DettachPortionFromString("<SuccessRate>", "</SuccessRate>", ref sectionString);
                sectionString = DataLoader.RemoveOpeningAndClosingTags(sectionString, "SuccessRate");
                Tag successRate = Tag.NewTag(sectionString);

                _string.DettachPortionFromString("<DiffusionDistance>", "</DiffusionDistance>", ref sectionString);
                sectionString = DataLoader.RemoveOpeningAndClosingTags(sectionString, "DiffusionDistance");
                Tag diffusionDistance = Tag.NewTag(sectionString);

                _string.DettachPortionFromString("<SecondaryEffectIds>", "</SecondaryEffectIds>", ref sectionString);
                sectionString = DataLoader.RemoveOpeningAndClosingTags(sectionString, "SecondaryEffectIds");
                string secondaryEffectIdString = "";
                while (sectionString != "")
                {
                    sectionString = sectionString.DettachPortionFromString("<SecondaryEffectId>", "</SecondaryEffectId>", ref secondaryEffectIdString);
                    secondaryEffectIdString = DataLoader.RemoveOpeningAndClosingTags(secondaryEffectIdString, "SecondaryEffectId");
                    int secondaryEffectId = Convert.ToInt32(secondaryEffectIdString);
                    m_effectId_secondaryEffectId.Add(id, secondaryEffectId);
                }

                _string.DettachPortionFromString("<AnimationId>", "</AnimationId>", ref sectionString);
                sectionString = DataLoader.RemoveOpeningAndClosingTags(sectionString, "AnimationId");
                int animationId = Convert.ToInt32(sectionString);

                if (_string.StartsWith("<DamageEffect>")
                    || _string.StartsWith("<HealEffect>")
                    || _string.StartsWith("<StatusEffectAttachmentEffect>"))
                {
                    return StringToUnitTargetingEffect(_string, id, activationCondition, timesToAplly, successRate, diffusionDistance, new List<Effect>(), animationId);
                }

                return null;
            }
            catch (Exception ex)
            {
                Debug.Log(ex.Message);
                return null;
            }
        }

        private UnitTargetingEffect StringToUnitTargetingEffect(string _string, int _id, ComplexCondition _activationCondition, Tag _timesToApply, Tag _successRate, Tag _diffusionDistance, List<Effect> _secondaryEffects, int _animationId)
        {
            try
            {
                string sectionString = string.Empty;

                _string.DettachPortionFromString("<TargetClassification>", "</TargetClassification>", ref sectionString);
                sectionString = DataLoader.RemoveOpeningAndClosingTags(sectionString, "TargetClassification");
                eTargetUnitClassification targetClassification = sectionString.ToCorrespondingEnumValue<eTargetUnitClassification>();

                if (_string.StartsWith("<DamageEffect>"))
                    return StringToDamageEffect(_string, _id, _activationCondition, _timesToApply, _successRate, _diffusionDistance, _secondaryEffects, _animationId, targetClassification);
                else if (_string.StartsWith("<HealEffect>"))
                    return StringToHealEffect(_string, _id, _activationCondition, _timesToApply, _successRate, _diffusionDistance, _secondaryEffects, _animationId, targetClassification);
                else if (_string.StartsWith("<StatusEffectAttachmentEffect>"))
                    return StringToStatusEffectAttachmentEffect(_string, _id, _activationCondition, _timesToApply, _successRate, _diffusionDistance, _secondaryEffects, _animationId, targetClassification);

                return null;
            }
            catch (Exception ex)
            {
                Debug.Log(ex.Message);
                return null;
            }
        }

        private DamageEffect StringToDamageEffect(string _string, int _id, ComplexCondition _activationCondition, Tag _timesToApply, Tag _successRate, Tag _diffusionDistance, List<Effect> _secondaryEffects, int _animationId, eTargetUnitClassification _targetClassification)
        {
            try
            {
                string sectionString = string.Empty;

                _string.DettachPortionFromString("<AttackClassification>", "</AttackClassification>", ref sectionString);
                sectionString = DataLoader.RemoveOpeningAndClosingTags(sectionString, "AttackClassification");
                eAttackClassification attackClassification = sectionString.ToCorrespondingEnumValue<eAttackClassification>();

                _string.DettachPortionFromString("<Value>", "</Value>", ref sectionString);
                sectionString = DataLoader.RemoveOpeningAndClosingTags(sectionString, "Value");
                Tag value = Tag.NewTag(sectionString);

                _string.DettachPortionFromString("<IsFixedValue>", "</IsFixedValue>", ref sectionString);
                sectionString = DataLoader.RemoveOpeningAndClosingTags(sectionString, "IsFixedValue");
                bool isFixedValue = Convert.ToBoolean(sectionString);

                _string.DettachPortionFromString("<Element>", "</Element>", ref sectionString);
                sectionString = DataLoader.RemoveOpeningAndClosingTags(sectionString, "Element");
                eElement element = sectionString.ToCorrespondingEnumValue<eElement>();

                return new DamageEffect(_id, _activationCondition, _timesToApply, _successRate, _diffusionDistance, _secondaryEffects, _animationId, _targetClassification, attackClassification, value, isFixedValue, element);
            }
            catch (Exception ex)
            {
                Debug.Log(ex.Message);
                return null;
            }
        }

        private HealEffect StringToHealEffect(string _string, int _id, ComplexCondition _activationCondition, Tag _timesToApply, Tag _successRate, Tag _diffusionDistance, List<Effect> _secondaryEffects, int _animationId, eTargetUnitClassification _targetClassification)
        {
            try
            {
                string sectionString = string.Empty;

                _string.DettachPortionFromString("<Value>", "</Value>", ref sectionString);
                sectionString = DataLoader.RemoveOpeningAndClosingTags(sectionString, "Value");
                Tag value = Tag.NewTag(sectionString);

                _string.DettachPortionFromString("<IsFixedValue>", "</IsFixedValue>", ref sectionString);
                sectionString = DataLoader.RemoveOpeningAndClosingTags(sectionString, "IsFixedValue");
                bool isFixedValue = Convert.ToBoolean(sectionString);

                return new HealEffect(_id, _activationCondition, _timesToApply, _successRate, _diffusionDistance, _secondaryEffects, _animationId, _targetClassification, value, isFixedValue);
            }
            catch (Exception ex)
            {
                Debug.Log(ex.Message);
                return null;
            }
        }

        private StatusEffectAttachmentEffect StringToStatusEffectAttachmentEffect(string _string, int _id, ComplexCondition _activationCondition, Tag _timesToApply, Tag _successRate, Tag _diffusionDistance, List<Effect> _secondaryEffects, int _animationId, eTargetUnitClassification _targetClassification)
        {
            try
            {
                string sectionString = string.Empty;

                _string.DettachPortionFromString("<StatusEffectDataId>", "</StatusEffectDataId>", ref sectionString);
                sectionString = DataLoader.RemoveOpeningAndClosingTags(sectionString, "StatusEffectDataId");
                int statusEffectDataId = Convert.ToInt32(sectionString);
                StatusEffectData dataOfStatusEffectToAttach = m_statusEffectDataList.First(x => x.Id == statusEffectDataId);

                return new StatusEffectAttachmentEffect(_id, _activationCondition, _timesToApply, _successRate, _diffusionDistance, _secondaryEffects, _animationId, _targetClassification, dataOfStatusEffectToAttach);
            }
            catch (Exception ex)
            {
                Debug.Log(ex.Message);
                return null;
            }
        }

        private ComplexCondition StringToComplexCondition(string _string, string _tagTitle)
        {
            try
            {
                if (!_string.StartsWith("<" + _tagTitle + ">"))
                    return null;

                List<List<Condition>> conditionSets = new List<List<Condition>>();

                _string = DataLoader.RemoveOpeningAndClosingTags(_string, _tagTitle);

                string conditionSetString = string.Empty;

                while (_string != "")
                {
                    _string = _string.DettachPortionFromString("<ConditionSet>", "</ConditionSet>", ref conditionSetString);
                    conditionSets.Add(StringToConditionSet(conditionSetString));
                }

                return new ComplexCondition(conditionSets);
            }
            catch (Exception ex)
            {
                Debug.Log(ex.Message);
                return null;
            }
        }

        private List<Condition> StringToConditionSet(string _string)
        {
            try
            {
                if (!_string.StartsWith("<ConditionSet>"))
                    return null;

                List<Condition> conditionSet = new List<Condition>();

                _string = DataLoader.RemoveOpeningAndClosingTags(_string, "ConditionSet");

                string conditionString = string.Empty;

                while (_string != "")
                {
                    _string = _string.DettachPortionFromString("<Condition>", "</Condition>", ref conditionString);
                    conditionSet.Add(StringToCondition(conditionString));
                }

                return conditionSet;
            }
            catch (Exception ex)
            {
                Debug.Log(ex.Message);
                return null;
            }
        }

        private Condition StringToCondition(string _string)
        {
            try
            {
                if (!_string.StartsWith("<Condition>"))
                    return null;

                List<Condition> conditionSet = new List<Condition>();

                string sectionString = string.Empty;

                _string.DettachPortionFromString("<TagA>", "</TagA>", ref sectionString);
                sectionString = DataLoader.RemoveOpeningAndClosingTags(sectionString, "TagA");
                Tag tagA = Tag.NewTag(sectionString);

                _string.DettachPortionFromString("<RelationType>", "</RelationType>", ref sectionString);
                sectionString = DataLoader.RemoveOpeningAndClosingTags(sectionString, "RelationType");
                eRelationType relationType = sectionString.ToCorrespondingEnumValue<eRelationType>();

                _string.DettachPortionFromString("<TagB>", "</TagB>", ref sectionString);
                sectionString = DataLoader.RemoveOpeningAndClosingTags(sectionString, "TagB");
                Tag tagB = Tag.NewTag(sectionString);

                return new Condition(tagA, relationType, tagB);
            }
            catch (Exception ex)
            {
                Debug.Log(ex.Message);
                return null;
            }
        }

        private List<SkillData> ResponseStringToSkillDataList(string _response)
        {
            try
            {
                List<SkillData> result = new List<SkillData>();

                _response = _response.Remove(0, "<Skills>".Length);
                _response = _response.Remove(_response.Length - "</Skills>".Length, "</Skills>".Length);

                string skillString = string.Empty;
                while (_response != "")
                {
                    if (_response.StartsWith("<OrdinarySkillData>"))
                        _response = _response.DettachPortionFromString("<OrdinarySkillData>", "</OrdinarySkillData>", ref skillString);
                    else if (_response.StartsWith("<CounterSkillData>"))
                        _response = _response.DettachPortionFromString("<CounterSkillData>", "</CounterSkillData>", ref skillString);
                    else if (_response.StartsWith("<UltimateSkillData>"))
                        _response = _response.DettachPortionFromString("<UltimateSkillData>", "</UltimateSkillData>", ref skillString);
                    else if (_response.StartsWith("<PassiveSkillData>"))
                        _response = _response.DettachPortionFromString("<PassiveSkillData>", "</PassiveSkillData>", ref skillString);

                    result.Add(StringToSkillData(skillString));
                }

                return result;
            }
            catch (Exception ex)
            {
                Debug.Log(ex.Message);
                return null;
            }
        }

        private SkillData StringToSkillData(string _string)
        {
            try
            {
                string sectionString = string.Empty;

                _string.DettachPortionFromString("<Id>", "</Id>", ref sectionString);
                sectionString = DataLoader.RemoveOpeningAndClosingTags(sectionString, "Id");
                int id = Convert.ToInt32(sectionString);

                _string.DettachPortionFromString("<Name>", "</Name>", ref sectionString);
                sectionString = DataLoader.RemoveOpeningAndClosingTags(sectionString, "Name");
                string name = String.Copy(sectionString);

                _string.DettachPortionFromString("<IconAsBytes>", "</IconAsBytes>", ref sectionString);
                sectionString = DataLoader.RemoveOpeningAndClosingTags(sectionString, "IconAsBytes");
                byte[] iconAsBytes = Convert.FromBase64String(sectionString);

                _string.DettachPortionFromString("<TemporalStatusEffectDataIds>", "</TemporalStatusEffectDataIds>", ref sectionString);
                sectionString = DataLoader.RemoveOpeningAndClosingTags(sectionString, "TemporalStatusEffectDataIds");
                List<StatusEffectData> temporalStatusEffectsData = new List<StatusEffectData>();
                string temporalStatusEffectDataIdString = "";
                while (sectionString != "")
                {
                    sectionString = sectionString.DettachPortionFromString("<StatusEffectDataId>", "</StatusEffectDataId>", ref temporalStatusEffectDataIdString);
                    temporalStatusEffectDataIdString = DataLoader.RemoveOpeningAndClosingTags(temporalStatusEffectDataIdString, "StatusEffectDataId");
                    int temporalStatusEffectDataId = Convert.ToInt32(temporalStatusEffectDataIdString);
                    temporalStatusEffectsData.Add(m_statusEffectDataList.First(x => x.Id == temporalStatusEffectDataId));
                }

                _string.DettachPortionFromString("<AnimationId>", "</AnimationId>", ref sectionString);
                sectionString = DataLoader.RemoveOpeningAndClosingTags(sectionString, "AnimationId");
                int animationId = Convert.ToInt32(sectionString);

                if (_string.StartsWith("<OrdinarySkillData>")
                    || _string.StartsWith("<CounterSkillData>")
                    || _string.StartsWith("<UltimateSkillData>"))
                {
                    return StringToActiveSkillData(_string, id, name, iconAsBytes, temporalStatusEffectsData.OfType<BackgroundStatusEffectData>().ToList(), animationId);
                }
                else if (_string.StartsWith("PassiveSkillData"))
                    return StringToPassiveSkillData(_string, id, name, iconAsBytes, temporalStatusEffectsData, animationId);

                return null;
            }
            catch (Exception ex)
            {
                Debug.Log(ex.Message);
                return null;
            }
        }

        private ActiveSkillData StringToActiveSkillData(string _string, int _id, string _name, byte[] _iconAsBytes, List<BackgroundStatusEffectData> _temporalStatusEffectsData, int _animationId)
        {
            try
            {
                string sectionString = string.Empty;

                _string.DettachPortionFromString("<MaxNumberOfTargets>", "</MaxNumberOfTargets>", ref sectionString);
                sectionString = DataLoader.RemoveOpeningAndClosingTags(sectionString, "MaxNumberOfTargets");
                Tag maxNumberOfTargets = Tag.NewTag(sectionString);

                _string.DettachPortionFromString("<EffectId>", "</EffectId>", ref sectionString);
                sectionString = DataLoader.RemoveOpeningAndClosingTags(sectionString, "EffectId");
                int effectId = Convert.ToInt32(sectionString);
                Effect effect = m_effectList.First(x => x.Id == effectId);

                if (_string.StartsWith("<OrdinarySkillData>"))
                    return StringToOrdinarySkillData(_string, _id, _name, _iconAsBytes, _temporalStatusEffectsData, _animationId, maxNumberOfTargets, effect);
                else if (_string.StartsWith("<CounterSkillData>"))
                    return StringToCounterSkillData(_string, _id, _name, _iconAsBytes, _temporalStatusEffectsData, _animationId, maxNumberOfTargets, effect);
                else if (_string.StartsWith("<UltimateSkillData>"))
                    return StringToUltimateSkillData(_string, _id, _name, _iconAsBytes, _temporalStatusEffectsData, _animationId, maxNumberOfTargets, effect);

                return null;
            }
            catch (Exception ex)
            {
                Debug.Log(ex.Message);
                return null;
            }
        }

        private OrdinarySkillData StringToOrdinarySkillData(string _string, int _id, string _name, byte[] _iconAsBytes, List<BackgroundStatusEffectData> _temporalStatusEffectsData, int _animationId, Tag _maxNumberOfTargets, Effect _effect)
        {
            try
            {
                string sectionString = string.Empty;

                _string.DettachPortionFromString("<SPCost>", "</SPCost>", ref sectionString);
                sectionString = DataLoader.RemoveOpeningAndClosingTags(sectionString, "SPCost");
                int spCost = Convert.ToInt32(sectionString);

                _string.DettachPortionFromString("<ItemCosts>", "</ItemCosts>", ref sectionString);
                sectionString = DataLoader.RemoveOpeningAndClosingTags(sectionString, "ItemCosts");
                Dictionary<int, int> itemCosts = new Dictionary<int, int>();
                string itemCostString = "";
                string itemIdString = "";
                string quantityString = "";
                while (sectionString != "")
                {
                    sectionString = sectionString.DettachPortionFromString("<ItemCost>", "</ItemCost>", ref itemCostString);

                    sectionString.DettachPortionFromString("<ItemId>", "</ItemId>", ref itemIdString);
                    itemIdString = DataLoader.RemoveOpeningAndClosingTags(itemIdString, "ItemId");
                    int itemId = Convert.ToInt32(itemIdString);

                    sectionString.DettachPortionFromString("<Quantity>", "</Quantity>", ref quantityString);
                    quantityString = DataLoader.RemoveOpeningAndClosingTags(quantityString, "Quantity");
                    int quantity = Convert.ToInt32(quantityString);

                    itemCosts.Add(itemId, quantity);
                }

                return new OrdinarySkillData(_id, _name, _iconAsBytes, _temporalStatusEffectsData, _animationId, _maxNumberOfTargets, _effect, spCost, itemCosts);
            }
            catch (Exception ex)
            {
                Debug.Log(ex.Message);
                return null;
            }
        }

        private CounterSkillData StringToCounterSkillData(string _string, int _id, string _name, byte[] _iconAsBytes, List<BackgroundStatusEffectData> _temporalStatusEffectsData, int _animationId, Tag _maxNumberOfTargets, Effect _effect)
        {
            try
            {
                string sectionString = string.Empty;

                _string.DettachPortionFromString("<SPCost>", "</SPCost>", ref sectionString);
                sectionString = DataLoader.RemoveOpeningAndClosingTags(sectionString, "SPCost");
                int spCost = Convert.ToInt32(sectionString);

                _string.DettachPortionFromString("<ItemCosts>", "</ItemCosts>", ref sectionString);
                sectionString = DataLoader.RemoveOpeningAndClosingTags(sectionString, "ItemCosts");
                Dictionary<int, int> itemCosts = new Dictionary<int, int>();
                string itemCostString = "";
                string itemIdString = "";
                string quantityString = "";
                while (sectionString != "")
                {
                    sectionString = sectionString.DettachPortionFromString("<ItemCost>", "</ItemCost>", ref itemCostString);

                    sectionString.DettachPortionFromString("<ItemId>", "</ItemId>", ref itemIdString);
                    itemIdString = DataLoader.RemoveOpeningAndClosingTags(itemIdString, "ItemId");
                    int itemId = Convert.ToInt32(itemIdString);

                    sectionString.DettachPortionFromString("<Quantity>", "</Quantity>", ref quantityString);
                    quantityString = DataLoader.RemoveOpeningAndClosingTags(quantityString, "Quantity");
                    int quantity = Convert.ToInt32(quantityString);

                    itemCosts.Add(itemId, quantity);
                }

                _string.DettachPortionFromString("<EventTriggerTiming>", "</EventTriggerTiming>", ref sectionString);
                sectionString = DataLoader.RemoveOpeningAndClosingTags(sectionString, "EventTriggerTiming");
                eEventTriggerTiming eventTriggerTiming = sectionString.ToCorrespondingEnumValue<eEventTriggerTiming>();

                _string.DettachPortionFromString("<ActivationCondition>", "</ActivationCondition>", ref sectionString);
                ComplexCondition activationCondition = StringToComplexCondition(sectionString, "ActivationCondition");

                return new CounterSkillData(_id, _name, _iconAsBytes, _temporalStatusEffectsData, _animationId, _maxNumberOfTargets, _effect, spCost, itemCosts, eventTriggerTiming, activationCondition);
            }
            catch (Exception ex)
            {
                Debug.Log(ex.Message);
                return null;
            }
        }

        private UltimateSkillData StringToUltimateSkillData(string _string, int _id, string _name, byte[] _iconAsBytes, List<BackgroundStatusEffectData> _temporalStatusEffectsData, int _animationId, Tag _maxNumberOfTargets, Effect _effect)
        {
            try
            {
                return new UltimateSkillData(_id, _name, _iconAsBytes, _temporalStatusEffectsData, _animationId, _maxNumberOfTargets, _effect);
            }
            catch (Exception ex)
            {
                Debug.Log(ex.Message);
                return null;
            }
        }

        private PassiveSkillData StringToPassiveSkillData(string _string, int _id, string _name, byte[] _iconAsBytes, List<StatusEffectData> _temporalStatusEffectsData, int _animationId)
        {
            try
            {
                string sectionString = string.Empty;

                _string.DettachPortionFromString("<TargetClassification>", "</TargetClassification>", ref sectionString);
                sectionString = DataLoader.RemoveOpeningAndClosingTags(sectionString, "TargetClassification");
                eTargetUnitClassification targetClassification = sectionString.ToCorrespondingEnumValue<eTargetUnitClassification>();

                _string.DettachPortionFromString("<ActivationCondition>", "</ActivationCondition>", ref sectionString);
                ComplexCondition activationCondition = StringToComplexCondition(sectionString, "ActivationCondition");

                return new PassiveSkillData(_id, _name, _iconAsBytes, _temporalStatusEffectsData, _animationId, targetClassification, activationCondition);
            }
            catch (Exception ex)
            {
                Debug.Log(ex.Message);
                return null;
            }
        }

        private void LoadSecondaryEffects()
        {
            foreach (var entry in m_effectId_secondaryEffectId)
            {
                m_effectList.First(x => x.Id == entry.Key).SecondaryEffects.Add(m_effectList.First(x => x.Id == entry.Value));
            }

            m_effectList.ForEach(x => x.DisableModification());
        }

        private void LoadTransformableWeaponsData()
        {
            foreach (var entry in m_weaponId_transformableWeaponId)
            {
                m_weaponDataList.First(x => x.Id == entry.Key).TransformableWeapons.Add(m_weaponDataList.First(x => x.Id == entry.Value));
            }

            m_weaponDataList.ForEach(x => x.DisableModification());
        }

        private void LoadUnitEvolutionRecipes()
        {
            foreach (var entry in m_unitId_progressiveEvolutionRecipeBase)
            {
                UnitData unitData = m_unitDataList.First(x => x.Id == entry.Value.AfterEvolutionUnitId);

                List<EvolutionMaterial> materials = new List<EvolutionMaterial>();
                for (int i = 0; i < CoreValues.MAX_NUM_OF_ELEMENTS_IN_RECIPE; i++)
                {
                    materials.Add(m_itemList.OfType<EvolutionMaterial>().First(x => x.Id == entry.Value.MaterialIds[i]));
                }

                UnitEvolutionRecipe progressiveEvolutionRecipe = new UnitEvolutionRecipe(unitData, materials, entry.Value.Cost);

                m_unitDataList.First(x => x.Id == entry.Key).ProgressiveEvolutionRecipes.Add(progressiveEvolutionRecipe);
            }

            foreach (var entry in m_unitId_retrogressiveEvolutionRecipeBase)
            {
                UnitData unitData = m_unitDataList.First(x => x.Id == entry.Value.AfterEvolutionUnitId);

                List<EvolutionMaterial> materials = new List<EvolutionMaterial>();
                for (int i = 0; i < CoreValues.MAX_NUM_OF_ELEMENTS_IN_RECIPE; i++)
                {
                    materials.Add(m_itemList.OfType<EvolutionMaterial>().First(x => x.Id == entry.Value.MaterialIds[i]));
                }

                UnitEvolutionRecipe retrogressiveEvolutionRecipe = new UnitEvolutionRecipe(unitData, materials, entry.Value.Cost);

                m_unitDataList.First(x => x.Id == entry.Key).RetrogressiveEvolutionRecipe = retrogressiveEvolutionRecipe;
            }

            m_unitDataList.ForEach(x => x.DisableModification());
        }

        private void LoadSkillInheritors(List<Unit> _units)
        {
            foreach (var item in m_playableUnitId_inheritorUnitId_inheritingSkillId)
            {
                Unit unit = _units.First(x => x.UniqueId == item.Item1);

                unit.SkillInheritor = _units.FirstOrDefault(x => x.UniqueId == item.Item2);
                unit.InheritingSkillId = item.Item3;
            }
        }

        private class UnitEvolutionRecipeBase
        {
            public UnitEvolutionRecipeBase(int _afterEvolutionUnitId, int _materialId1, int _materialId2, int _materialId3, int _materialId4, int _materialId5, int _cost)
            {
                AfterEvolutionUnitId = _afterEvolutionUnitId;

                MaterialIds = new int[5];
                MaterialIds[0] = _materialId1;
                MaterialIds[1] = _materialId2;
                MaterialIds[2] = _materialId3;
                MaterialIds[3] = _materialId4;
                MaterialIds[4] = _materialId5;

                Cost = _cost;
            }

            public int AfterEvolutionUnitId { get; }
            public int[] MaterialIds { get; }
            public int Cost { get; }
        }
    }
}
