﻿using EEANGames.TBSG._01.MainClassLib;
using EEANGames.TBSG._01.Unity;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Networking;
using UnityEngine.UI;

public class ConnectionTextDisplayer : MonoBehaviour
{
    #region Serialized Fields
    public Text ConnectionText;
    #endregion

    // Start is called before the first frame update
    void Start()
    {
        StartCoroutine(CheckConnectionAndSetText());
    }

    IEnumerator CheckConnectionAndSetText()
    {
        ConnectionText.text = "Server is Currently Off.\nIt Will be Available from 7 a.m. till 10 p.m.";

        Dictionary<string, string> values = new Dictionary<string, string>
                {
                    {"subject", "CheckConnection"},
                };

        UnityWebRequest uwr = UnityWebRequest.Post(CoreValues.SERVER_URL, values);
        yield return uwr.SendWebRequest();

        if (!uwr.isNetworkError)
            ConnectionText.text = "Server is On";
    }
}
