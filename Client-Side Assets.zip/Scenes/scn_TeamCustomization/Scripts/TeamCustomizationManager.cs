﻿using EEANGames.TBSG._01.MainClassLib;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using EEANGames.TBSG._01.CommonEnums;
//using EEANGames.TBSG._01.MainClassLib.DBDataHandler.ForUnity;
using System;

[RequireComponent(typeof(InformationPanelManager))]
[RequireComponent(typeof(InformationPanelManager_Unit))]
public class TeamCustomizationManager : MonoBehaviour {

    private List<Team> Teams;
    public int CurrentTeamIndex { get; private set; }
    private Text TeamLabel;
    private Text SaveResultMessage;
    private UnityEngine.UI.Image[] UnitIcons;
    private UnityEngine.UI.Image[] UnitFrames;
    private Button[] UnitInfoButtons;

    private const int NUMBER_OF_MEMBERS = 5;

    private InformationPanelManager_Unit m_informationPanelManager_Unit;

    // Use this for initialization
    void Awake () {
        Teams = GameDataContainer.Instance.Player.Teams;

        CurrentTeamIndex = 0; // Set to default value

        Transform Panel = this.transform.Find("Canvas").Find("Panel");
        m_informationPanelManager_Unit = this.GetComponent<InformationPanelManager_Unit>();
        TeamLabel = Panel.Find("TeamLabel").GetComponent<Text>();
        SaveResultMessage = Panel.Find("SaveResultMessage").GetComponent<Text>();
        UnitIcons = new UnityEngine.UI.Image[NUMBER_OF_MEMBERS];
        UnitFrames = new UnityEngine.UI.Image[NUMBER_OF_MEMBERS];
        UnitInfoButtons = new Button[NUMBER_OF_MEMBERS];
        for (int i = 1; i <= NUMBER_OF_MEMBERS; i++)
        {
            Transform Unit = Panel.Find("Member Set " + i.ToString()).Find("Unit");
            UnitIcons[i - 1] = Unit.GetComponent<UnityEngine.UI.Image>();
            UnitFrames[i - 1] = Unit.Find("Frame").GetComponent<UnityEngine.UI.Image>();
            UnitInfoButtons[i - 1] = Unit.Find("Info").GetComponent<Button>();
        }

        RefreshScene();
	}

    public void NextTeamIndex()
    {
        if (CurrentTeamIndex >= Teams.Count)
            CurrentTeamIndex = 0;
        else
            CurrentTeamIndex++;
    }

    public void PreviousTeamIndex()
    {
        if (CurrentTeamIndex <= 0)
            CurrentTeamIndex = Teams.Count - 1;
        else
            CurrentTeamIndex--;
    }

    public void RefreshScene()
    {
        try
        {
            TeamLabel.text = "Team " + (CurrentTeamIndex + 1).ToString();
            for (int i = 1; i <= NUMBER_OF_MEMBERS; i++)
            {
                UnitInfoButtons[i - 1].onClick.RemoveAllListeners();

                if (Teams[CurrentTeamIndex].MemberSets[i - 1].Member != null)
                {
                    //UnitIcons[i - 1].sprite = ConverterForUnity.ByteArrayToSprite(Teams[CurrentTeamIndex].MemberSets[i - 1].Member.IconAsByteArray.ImageAsByteArray);

                    UnitFrames[i - 1].sprite = FrameSpriteManager.FrameSpriteForCorrespondingRarity(Teams[CurrentTeamIndex].MemberSets[i - 1].Member.BaseInfo.Rarity);
                    int unitUniqueId = Teams[CurrentTeamIndex].MemberSets[i - 1].Member.UniqueId;
                    UnitInfoButtons[i - 1].onClick.AddListener(() => m_informationPanelManager_Unit.InstantiateInfoPanel(unitUniqueId));
                }
                else
                {
                    UnitIcons[i - 1].sprite = null;
                    UnitFrames[i - 1].sprite = null;
                }
            }
        }
        catch (Exception ex)
        {
            Debug.Log(ex.Message);
        }
    }

    //public void SaveTeam()
    //{
    //    SaveResultMessage.color = new Color(1, 1, 1, 1f);

    //    if (EFDataHandler.SaveTeamData(GameDataContainer.Instance.Player.Teams[CurrentTeamIndex], GameDataContainer.Instance.Player, CurrentTeamIndex + 1))
    //    {
    //        //SaveResultMessage.text = "<color=green>Saved Successfully!</color>";
    //        SaveResultMessage.color = Color.green;
    //        SaveResultMessage.text = "Saved Successfully!";
    //    }
    //    else
    //    {
    //        //SaveResultMessage.text = "<color=red>Failed to Save</color>";
    //        SaveResultMessage.color = Color.red;
    //        SaveResultMessage.text = "Failed to Save";
    //    }
    //}

}
