﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ParticleDisposer : MonoBehaviour {

    private float m_startTime;

    public float LifeSpan;

	// Use this for initialization
	void Awake () {
        m_startTime = Time.realtimeSinceStartup;
	}
	
	// Update is called once per frame
	void Update () {
        if (Time.realtimeSinceStartup - m_startTime > LifeSpan)
            Destroy(this.gameObject);
	}
}
