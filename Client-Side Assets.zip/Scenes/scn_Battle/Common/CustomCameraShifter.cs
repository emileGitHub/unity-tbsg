﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[RequireComponent(typeof(Camera))]
public class CustomCameraShifter : MonoBehaviour
{
    private List<CAMERA_INFO> CamerasInfo;
    private int currentIndex;

    void Start()
    {
        CamerasInfo = new List<CAMERA_INFO>();

        CamerasInfo.Add(new CAMERA_INFO { Position = this.transform.position, Rotation = this.transform.rotation }); //Default Position in the editor
        CamerasInfo.Add(new CAMERA_INFO { Position = new Vector3(23, 174, 155), Rotation = Quaternion.Euler(new Vector3(62, 0, 0)) });
        CamerasInfo.Add(new CAMERA_INFO { Position = new Vector3(480, 274, 218), Rotation = Quaternion.Euler(new Vector3(60, -45, -0.25f)) });

        currentIndex = 0;

        this.transform.position = CamerasInfo[currentIndex].Position;
        this.transform.rotation = CamerasInfo[currentIndex].Rotation;

    }

    public void ChangeCameraProperties()
    {
        if (currentIndex == CamerasInfo.Count - 1) //If it is the last index of CamerasInfo
            currentIndex = 0;
        else
            currentIndex++;

        this.transform.position = CamerasInfo[currentIndex].Position;
        this.transform.rotation = CamerasInfo[currentIndex].Rotation;
    }
}

public struct CAMERA_INFO
{
    public Vector3 Position;
    public Quaternion Rotation;
}
