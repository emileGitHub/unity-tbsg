﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Networking;
//using EEANGames.TBSG._01.MainClassLib.DBDataHandler.ForUnity;
using System;
using EEANGames.TBSG._01.CommonEnums;
using EEANGames.TBSG._01.MainClassLib;
using UnityEngine.UI;
using EEANGames.ImageConverter;
using EEANGames.ImageConverter.Unity;

public class UnitController_SinglePlayer : MonoBehaviour
{
    public int PublicIndex; // No unit can have same index
    public int PrivateIndex; // Units of same Player cannot have same id
    public int OwnerId;

    private UnityBattleSystem_SinglePlayer m_mainScript;

    private MeshRenderer m_meshRenderer_frame;
    private MeshRenderer m_meshRenderer_unit;
    //private MeshRenderer m_meshRenderer_class;
    private MeshRenderer m_meshRenderer_backGround;

    private MeshCollider m_collider;

    public UnitInstance UnitReference { get; private set; }

    //private ParticleSet ParticleSet;

    public bool IsInitializedInternally { get; private set; }
    public bool IsInitializedExternally { get; private set; }
    private bool m_isRotationAdjusted;

    private readonly Vector3 m_invalidPosition = new Vector3(500, 500, -500);

    // Use this for initialization
    void Awake()
    {
        try
        {
            IsInitializedInternally = false;
            IsInitializedExternally = false;
            m_isRotationAdjusted = false;
            //ParticleSet = GameObject.Find("ParticleSet").GetComponent<ParticleSet>();

            Transform frame = this.transform.Find("Frame");
            m_meshRenderer_frame = frame.GetComponent<MeshRenderer>();
            m_collider = frame.GetComponent<MeshCollider>();
            //m_meshRenderer_class = this.transform.Find("SmallSquarePlane").GetComponent<MeshRenderer>();
            m_meshRenderer_unit = this.transform.Find("LargeSquarePlane").GetComponent<MeshRenderer>();
            m_meshRenderer_backGround = this.transform.Find("OctagonPlane").GetComponent<MeshRenderer>();

            //Required for Update() to avoid not being called
            if (!this.isActiveAndEnabled)
                this.enabled = true;
        }
        catch(Exception ex)
        {
            Debug.Log("UnitController_SinglePlayer: at Awake()" + ex.Message);
        }
    }

    void Update()
    {
        if (!IsInitializedInternally)
            Initialize();

        if (!m_isRotationAdjusted)
        {
            //GameObject[] players = GameObject.FindGameObjectsWithTag("Player");

            //PlayerController pc = players[0].GetComponent<PlayerController>();

            //if(this.PlayerId == 2)
            //{
            //    this.transform.position += new Vector3(7f, 0, 0);
            //    this.transform.Rotate(0, 180f, 0);
            //    m_isRotationAdjusted = true;
            //}
        }

        if (IsInitializedInternally && IsInitializedExternally)
        {
            if (!UnitReference.IsAlive && this.transform.localPosition != m_invalidPosition)
                this.transform.localPosition = m_invalidPosition; //Send object out of screen
        }
    }


    private void Initialize()
    {
        try
        {
            if (m_mainScript == null)
                m_mainScript = this.transform.root.GetComponent<UnityBattleSystem_SinglePlayer>();

            if (m_mainScript.IsInitialized)
            {
                Debug.Log("UnitController_SinglePlayer: Start Initialization.");

                for (int i = 0; i < m_mainScript.Players.Length; i++)
                {
                    if (m_mainScript.PlayerControllers[i].PlayerId == OwnerId)
                    {
                        this.transform.parent = m_mainScript.Players[i].transform;
                        break;
                    }
                }

                if (this.transform.parent == null)
                {
                    Debug.Log("UnitController_SinglePlayer: parent object not set");
                    return;
                }


                //if (!LoadSprites())
                //{
                //    Debug.Log("UnitController_SinglePlayer: error at LoadSprites()");
                //    return;
                //}

                if (!SetImages())
                {
                    Debug.Log("UnitController_SinglePlayer: error at SetImages()");
                    return;
                }

                //if (!AdjustScale())
                //{
                //    Debug.Log("UnitController_SinglePlayer: error at AdjustScale()");
                //    return;
                //}

                //if (LocalPlayerIdentifier.PlayerController.PlayerId == 1)
                //    positionAdjustmentValue *= -1;

                IsInitializedInternally = true;
                Debug.Log("UnitController_SinglePlayer: End Initialization.");
            }
        }
        catch (Exception ex)
        {
            Debug.Log("UnitController_SinglePlayer: at Initialize() " + ex.Message);
        }
    }

    public bool ExternalInitialization(int _publicIndex, int _privateIndex, int _ownerId, UnitInstance _unitReference)
    {
        PublicIndex = _publicIndex;
        PrivateIndex = _privateIndex;
        OwnerId = _ownerId;
        UnitReference = _unitReference;

        if (_unitReference != null)
            IsInitializedExternally = true;

        return IsInitializedExternally;
    }

    //private bool AdjustScale()
    //{
    //    try
    //    {
    //        this.transform.localScale = m_mainScript.UnitScale;
    //        return AdjustCollider(); ;
    //    }
    //    catch (Exception ex)
    //    {
    //        Debug.Log("UnitController_SinglePlayer: at AdjustScale() " + ex.Message);
    //        return false;
    //    }
    //}

    //private bool AdjustCollider()
    //{
    //    try
    //    {
    //        collider.size = meshRenderer_frame.bounds.size;
    //        collider.offset = new Vector2(collider.size.x / 2, collider.size.y / 2);
    //        return true;
    //    }
    //    catch (Exception ex)
    //    {
    //        Debug.Log("UnitController_SinglePlayer: at AdjustCollider() " + ex.Message);
    //        return false;
    //    }
    //}

    //private bool LoadSprites()
    //{
    //    try
    //    {
    //        AnimationSprites = SpriteSplitter.SpriteToMultipleSprites(UnitSprites[UnitSpriteId - 1], NUM_COLUMNS, NUM_ROWS);

    //        if (AnimationSprites.Count != NUM_COLUMNS * NUM_ROWS)
    //            return false;

    //        return true;
    //    }
    //    catch (Exception ex)
    //    {
    //        Debug.Log("UnitController_SinglePlayer: at LoadSprites() " + ex.Message);
    //        return false;
    //    }
    //}

    private bool SetImages()
    {
        try
        {
            Shader defaultShader = Shader.Find("Sprites/Default");

            int rarityIndex = (Convert.ToInt32(this.UnitReference.BaseInfo.Rarity) / 20) - 1;
            m_meshRenderer_frame.material = MaterialContainer.Instance.RarityMaterials[rarityIndex];

            m_meshRenderer_unit.material.mainTexture = UnityImageConverter.ByteArrayToTexture(UnitReference.BaseInfo.IconAsBytes);
            m_meshRenderer_unit.material.shader = defaultShader;

            return true;
        }
        catch (Exception ex)
        {
            Debug.Log("UnitController_SinglePlayer.SetImages() " + ex.Message);
            return false;
        }
    }

    //[Client]
    //private void ChangeSprite(int _index)
    //{
    //    try
    //    {
    //        meshRenderer.sprite = AnimationSprites[_index];
    //        PreviousSpriteIndex = CurrentSpriteIndex;
    //        CurrentSpriteIndex = _index;
    //    }
    //    catch (Exception ex)
    //    {
    //        Debug.Log("UnitController_SinglePlayer: at ChangeSprite() " + ex.Message);
    //    }
    //}

    //[Client]
    //private void SpriteAnimation()
    //{
    //    try
    //    {
    //        switch (ToActualDirection(TxtDataHandler.ToCorrespondingEnumValue<eDirection>(DirectionFacing)))
    //        {
    //            case eDirection.BACK:
    //                {
    //                    const int ROW_INDEX = 0;
    //                    switch (CurrentSpriteIndex)
    //                    {
    //                        default:
    //                            ChangeSprite(NUM_COLUMNS * ROW_INDEX + 1);
    //                            break;
    //                        case NUM_COLUMNS * ROW_INDEX + 0:
    //                        case NUM_COLUMNS * ROW_INDEX + 2:
    //                            ChangeSprite(NUM_COLUMNS * ROW_INDEX + 1);
    //                            break;
    //                        case NUM_COLUMNS * ROW_INDEX + 1:
    //                            if (PreviousSpriteIndex == CurrentSpriteIndex - 1)
    //                                ChangeSprite(CurrentSpriteIndex + 1);
    //                            else // if (PreviousSpriteIndex == CurrentSpriteIndex + 1)
    //                                ChangeSprite(CurrentSpriteIndex - 1);
    //                            break;
    //                    }
    //                }
    //                break;
    //            case eDirection.LEFT:
    //                {
    //                    const int ROW_INDEX = 1;
    //                    switch (CurrentSpriteIndex)
    //                    {
    //                        default:
    //                            ChangeSprite(NUM_COLUMNS * ROW_INDEX + 1);
    //                            break;
    //                        case NUM_COLUMNS * ROW_INDEX + 0:
    //                        case NUM_COLUMNS * ROW_INDEX + 2:
    //                            ChangeSprite(NUM_COLUMNS * ROW_INDEX + 1);
    //                            break;
    //                        case NUM_COLUMNS * ROW_INDEX + 1:
    //                            if (PreviousSpriteIndex == CurrentSpriteIndex - 1)
    //                                ChangeSprite(CurrentSpriteIndex + 1);
    //                            else // if (PreviousSpriteIndex == CurrentSpriteIndex + 1)
    //                                ChangeSprite(CurrentSpriteIndex - 1);
    //                            break;
    //                    }
    //                }
    //                break;
    //            case eDirection.FRONT:
    //                {
    //                    const int ROW_INDEX = 2;
    //                    switch (CurrentSpriteIndex)
    //                    {
    //                        default:
    //                            ChangeSprite(NUM_COLUMNS * ROW_INDEX + 1);
    //                            break;
    //                        case NUM_COLUMNS * ROW_INDEX + 0:
    //                        case NUM_COLUMNS * ROW_INDEX + 2:
    //                            ChangeSprite(NUM_COLUMNS * ROW_INDEX + 1);
    //                            break;
    //                        case NUM_COLUMNS * ROW_INDEX + 1:
    //                            if (PreviousSpriteIndex == CurrentSpriteIndex - 1)
    //                                ChangeSprite(CurrentSpriteIndex + 1);
    //                            else // if (PreviousSpriteIndex == CurrentSpriteIndex + 1)
    //                                ChangeSprite(CurrentSpriteIndex - 1);
    //                            break;
    //                    }
    //                }
    //                break;
    //            case eDirection.RIGHT:
    //                {
    //                    const int ROW_INDEX = 3;
    //                    switch (CurrentSpriteIndex)
    //                    {
    //                        default:
    //                            ChangeSprite(NUM_COLUMNS * ROW_INDEX + 1);
    //                            break;
    //                        case NUM_COLUMNS * ROW_INDEX + 0:
    //                        case NUM_COLUMNS * ROW_INDEX + 2:
    //                            ChangeSprite(NUM_COLUMNS * ROW_INDEX + 1);
    //                            break;
    //                        case NUM_COLUMNS * ROW_INDEX + 1:
    //                            if (PreviousSpriteIndex == CurrentSpriteIndex - 1)
    //                                ChangeSprite(CurrentSpriteIndex + 1);
    //                            else // if (PreviousSpriteIndex == CurrentSpriteIndex + 1)
    //                                ChangeSprite(CurrentSpriteIndex - 1);
    //                            break;
    //                    }
    //                }
    //                break;
    //            default:
    //                break;
    //        }
    //    }
    //    catch (Exception ex)
    //    {
    //        Debug.Log("UnitController_SinglePlayer: at SpriteAnimation() " + ex.Message);
    //    }
    //}

    //private eDirection ToActualDirection(eDirection _playerBasedDirection)
    //{
    //    try
    //    {
    //        //if (LocalPlayerIdentifier.IsInitialized)
    //        //{
    //        //    if (LocalPlayerIdentifier.PlayerController.PlayerId != Id_OwnerPlayer)
    //        //    {
    //        //        switch (_playerBasedDirection)
    //        //        {
    //        //            case eDirection.LEFT:
    //        //                return eDirection.RIGHT;
    //        //            case eDirection.RIGHT:
    //        //                return eDirection.LEFT;
    //        //            case eDirection.BACK:
    //        //                return eDirection.FRONT;
    //        //            default: // case eDirection.FRONT
    //        //                return eDirection.BACK;
    //        //        }
    //        //    }
    //        //}
    //        //else
    //        //    return _playerBasedDirection;
    //    }
    //    catch (Exception ex)
    //    {
    //        Debug.Log("UnitController_SinglePlayer: at ToActualDirection() " + ex.Message);
    //        return _playerBasedDirection;
    //    }
    //}

    //#region Server/Host Side Code
    //public bool SyncVarInitialization(int _publicId, int _privateId, int _ownerId, int _iconId, eDirection _directionFacing, string _nickname, string _name, int _element1, int _element2, int _level, int _maxHP, int _remainingHP, int _phyStr, int _phyRes, int _magStr, int _magRes, int _vit, List<string> _skillNames)
    //{
    //    try
    //    {
    //        m_mainScript = GameObject.Find("BattleSystemController").GetComponent<BattleSystem>();

    //        if (!m_mainScript.IsInitialized && LocalPlayerIdentifier.IsInitialized)
    //        {
    //            Debug.Log("UnitController_SinglePlayer (Script): Start SyncVar Initialization.");

    //            Unit_PublicId = _publicId;
    //            Unit_PrivateId = _privateId;
    //            Id_OwnerPlayer = _ownerId;
    //            UnitIconId = _iconId;
    //            DirectionFacing = _directionFacing.ToString();
    //            Nickname = _nickname;
    //            Name = _name;
    //            Element1 = _element1;
    //            Element2 = _element2;
    //            Level = _level;
    //            MaxHP = _maxHP;
    //            RemainingHP = _remainingHP;
    //            PhyStr = _phyStr;
    //            PhyRes = _phyRes;
    //            MagStr = _magStr;
    //            MagRes = _magRes;
    //            Vit = _vit;
    //            IsAlive = true;

    //            SyncList_SkillName.Clear();
    //            foreach (string skillName in _skillNames)
    //            {
    //                SyncList_SkillName.Add(skillName);
    //            }

    //            if (!m_mainScript.isScaleAdjusted)
    //                m_mainScript.InitializeUnitScale(this.gameObject);
    //            if (!m_mainScript.isScaleAdjusted)
    //                return false;

    //            Debug.Log("UnitController_SinglePlayer (Script): End SyncVar Initialization.");
    //            return true;
    //        }

    //        return false;
    //    }
    //    catch (Exception ex)
    //    {
    //        Debug.Log("UnitController_SinglePlayer: at SyncVarInitialization() " + ex.Message);
    //        return false;
    //    }
    //}
    //#endregion

    //#region Client Rpc
    //[ClientRpc]
    //public void Rpc_UpdateDirection(eDirection _direction)
    //{
    //    DirectionFacing = _direction.ToString();
    //}

    //[ClientRpc]
    //public void Rpc_Move(Vector3 _nextPosition)
    //{
    //    //float seconds = 2.0f;
    //    //float startingTime = Time.timeSinceLevelLoad;
    //    //float difference = Time.timeSinceLevelLoad - startingTime;
    //    //float timeRate = difference / seconds;

    //    //while (this.transform.position != _nextPosition)
    //    //{
    //    //    this.transform.position = Vector3.Lerp(this.transform.position, _nextPosition, timeRate);
    //    //}

    //    //SpriteAnimation(); // Rotate Unit Before Moving Position

    //    float positionAdjustmentValue = m_meshRenderer_frame.bounds.size.x / 2;
    //    if (LocalPlayerIdentifier.PlayerController.PlayerId == 1)
    //        positionAdjustmentValue *= -1;

    //    _nextPosition += new Vector3(positionAdjustmentValue, 0, 0);

    //    if (this.transform.position != _nextPosition)
    //        this.transform.position = _nextPosition;
    //}

    //[ClientRpc]
    //public void Rpc_SyncStatus(int _maxHP, int _remainingHP, bool _isAlive)
    //{
    //    MaxHP = _maxHP;
    //    RemainingHP = _remainingHP;
    //    IsAlive = _isAlive;
    //}
    //#endregion
}
