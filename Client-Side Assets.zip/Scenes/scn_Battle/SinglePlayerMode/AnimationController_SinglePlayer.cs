﻿using EEANGames.ExtensionMethods;
using EEANGames.TBSG._01.MainClassLib;
using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class AnimationController_SinglePlayer : MonoBehaviour {

    #region Serialized Fields
    public List<GameObject> EffectParticlePrefabs;
    #endregion

    #region Properties
    public bool LockUI { get { return m_playingAnimation; } }
    public bool IsInitialized { get; private set; }
    #endregion

    #region Private Fields
    private UnityBattleSystem_SinglePlayer m_mainScript;
    private TileMapManager_SinglePlayer m_tileMapManager;

    private SPDisplayer_SinglePlayer m_spDisplayer;
    private TeamStatusDisplayer_SinglePlayer m_teamStatusDisplayer;

    private Text m_centralText;

    private int m_indexOfLastLog;

    private bool m_playingAnimation;
    #endregion

    // Use this for initialization
    void Awake () {
        IsInitialized = false;

        m_indexOfLastLog = -1;

        m_playingAnimation = false;
    }
	
	// Update is called once per frame
	void Update () {
        if (!IsInitialized)
            Initialize();

        if (IsInitialized)
        {
            if (m_indexOfLastLog < m_mainScript.BattleSystemCore.EventLogs.Count - 1
                && !m_playingAnimation)
            {
                StartCoroutine(Animate(m_indexOfLastLog + 1));
            }
        }
	}

    private void Initialize()
    {
        if (m_mainScript == null)
            m_mainScript = this.transform.root.GetComponent<UnityBattleSystem_SinglePlayer>();
        if (m_mainScript == null)
            return;

        GameObject gameBoard = GameObject.FindGameObjectWithTag("GameBoard");

        if (m_tileMapManager == null)
            m_tileMapManager = gameBoard?.GetComponent<TileMapManager_SinglePlayer>();
        if (m_tileMapManager == null)
            return;

        if (m_spDisplayer == null)
            m_spDisplayer = gameBoard?.GetComponent<SPDisplayer_SinglePlayer>();
        if (m_spDisplayer == null)
            return;

        GameObject canvas = GameObject.FindGameObjectWithTag("Canvas");

        if (m_teamStatusDisplayer == null)
            m_teamStatusDisplayer = canvas?.transform.Find("Panel@TeamStatus")?.GetComponent<TeamStatusDisplayer_SinglePlayer>();
        if (m_teamStatusDisplayer == null)
            return;

        if (m_centralText == null)
        {
            m_centralText = canvas?.transform.Find("Text@Central").GetComponent<Text>();
        }
        if (m_centralText == null)
            return;

        if (m_tileMapManager.IsInitialized)
            IsInitialized = true;
    }

    IEnumerator Animate(int _indexOfLog)
    {
        m_playingAnimation = true;

        EventLog log = m_mainScript.BattleSystemCore.EventLogs[_indexOfLog];

        Vector3 position = Vector3.negativeInfinity;

        if (log is AutomaticEventLog)
        {
            if (log is TurnChangeEventLog)
            {
                var detailedLog = log as TurnChangeEventLog;

                string message = (detailedLog.TurnInitiatingPlayerId == m_mainScript.LocalPlayer_PlayerController.PlayerId) ? "Your" : "Opponent's";

                decimal nextEventTurn = detailedLog.EventTurn + 0.5m;
                int playerTurn = (detailedLog.TurnInitiatingPlayerId == 1) ? nextEventTurn.Ceiling() : nextEventTurn.Floor(); 

                message += " Turn\n<" + playerTurn + ">";

                m_centralText.text = message;

                Color color = m_centralText.color;
                color.a = 1f;
                m_centralText.color = color;

                m_spDisplayer.TryUpdateSPGraphic();
                yield return StartCoroutine(VanishCentralText(3f));
            }
            else if (log is EffectTrialLog)
            {
                var effectLog = log as EffectTrialLog;

                if (log is EffectTrialLog_DamageEffect)
                {
                    var detailedLog = log as EffectTrialLog_DamageEffect;
                    position = m_tileMapManager.TileMeshRenderers[detailedLog.TargetLocationTileIndex].bounds.center;

                    GameObject unitChip = m_mainScript.Units[detailedLog.TargetId];
                    Transform hpBar = unitChip?.transform.Find("HPBar");
                    HPBarController_SinglePlayer hpBarController = hpBar?.GetComponent<HPBarController_SinglePlayer>();
                    hpBarController.TryUpdateHP(detailedLog.Value * -1, detailedLog.DidSucceed, detailedLog.WasCritical, detailedLog.RemainingHPAfterModification);
                }

                m_spDisplayer.TryUpdateSPGraphic();

                GameObject.Instantiate(EffectParticlePrefabs[effectLog.AnimationId], position, Quaternion.identity);

                yield return new WaitForSeconds(1);
            }
        }

        m_teamStatusDisplayer.TryUpdateTeamStatus();

        m_indexOfLastLog = _indexOfLog;

        m_playingAnimation = false;
    }

    IEnumerator VanishCentralText(float _seconds)
    {
        Color color = m_centralText.color;

        float timeElapsed = 0f;

        while (timeElapsed <= _seconds)
        {
            color.a = 1f - (timeElapsed / _seconds);
            m_centralText.color = color;

            Debug.Log("Time Elapsed: " + timeElapsed.ToString() + "; Text Alpha: " + m_centralText.color.a.ToString());

            timeElapsed += Time.deltaTime;

            yield return null;
        }
    }
}
