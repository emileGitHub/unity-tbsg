﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class InfoPanelManager_SinglePlayer : MonoBehaviour
{
    #region Properties
    public List<GameObject> InfoPanels { get; private set; }
    public bool IsInitialized { get; private set; }
    #endregion#

    #region Private Member Variables
    private UnityBattleSystem_SinglePlayer m_mainScript;

    private Transform m_canvas;
    #endregion

    // Use this for initialization
    void Awake()
    {
        InfoPanels = new List<GameObject>();
        IsInitialized = false;
    }

    // Update is called once per frame
    void Update()
    {
        if (!IsInitialized)
            Inititalize();
    }

    private void Inititalize()
    {
        try
        {
            if (m_canvas == null)
                m_canvas = GameObject.Find("Canvas").transform;

            if (m_mainScript == null)
                m_mainScript = this.transform.root.GetComponent<UnityBattleSystem_SinglePlayer>();

            if (m_mainScript != null && m_canvas != null)
                IsInitialized = true;

        }
        catch (Exception ex)
        {
            Debug.Log("InfoPanelManager_SinglePlayer: at Initialize() " + ex.Message);
        }
    }

    public void AddInfoPanel(GameObject _infoPanel)
    {
        if(_infoPanel != null)
            InfoPanels.Add(_infoPanel);
    }

    public void RemoveInfoPanel(GameObject _infoPanel)
    {
        if(InfoPanels.Exists(x => x == _infoPanel))
            InfoPanels.Remove(_infoPanel);
    }
}

