﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[RequireComponent(typeof(PlayerController_SinglePlayer))]
public class CPU_AI : MonoBehaviour {

    #region Private Fields
    private UnityBattleSystem_SinglePlayer m_mainScript;
    private PlayerController_SinglePlayer m_playerController;

    private bool m_isInitialized;
    #endregion

    // Awake is called before Update for the first frame
    void Awake () {
        m_isInitialized = false;
    }

    // Update is called once per frame
    void Update () {
        if (!m_isInitialized)
            Initialize();
        else if (m_playerController.IsCPU && m_playerController.IsMyTurn)
            Act();
    }

    private void Initialize()
    {
        if (m_mainScript == null)
            m_mainScript = this.transform.root.GetComponent<UnityBattleSystem_SinglePlayer>();
        if (m_mainScript == null)
            return;

        if (m_playerController == null)
            m_playerController = this.GetComponent<PlayerController_SinglePlayer>();

        if (m_mainScript.IsInitialized && m_playerController.IsInitialized)
            m_isInitialized = true;
    }

    private void Act()
    {
        m_mainScript.ChangeTurn();
        //if (!m_playerController.HasMoved)
        //{
        //    Random.Random.randInit();
        //    Random.Random.getRand(0, m_playerController)
        //}
    }
}
