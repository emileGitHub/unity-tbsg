﻿using EEANGames.TBSG._01.MainClassLib;
using EEANGames.ImageConverter.Unity;
using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

[RequireComponent(typeof(InfoPanelManager_SinglePlayer))]
public class InfoPanelManager_Effect_SinglePlayer : MonoBehaviour
{

    #region Serialized Fields
    public GameObject EffectInfoPanelPrefab;
    public GameObject EffectButtonPrefab;
    #endregion

    #region Private Fields
    private UnityBattleSystem_SinglePlayer m_mainScript;

    private InfoPanelManager_SinglePlayer m_mainInfoPanelManager;

    private List<GameObject> m_infoPanels;
    private Transform m_canvas;

    private bool m_isInitialized;
    #endregion

    //Use this for initialization

    void Awake()
    {
        m_infoPanels = new List<GameObject>();
        m_mainInfoPanelManager = this.GetComponent<InfoPanelManager_SinglePlayer>();
        m_isInitialized = false;
    }

    // Update is called once per frame
    void Update()
    {
        if (!m_isInitialized)
            Inititalize();

        if (m_isInitialized)
        {
            //UpdateTexts();
        }
    }

    private void Inititalize()
    {
        try
        {
            if (m_canvas == null)
                m_canvas = GameObject.FindGameObjectWithTag("Canvas").transform;

            if (m_mainScript == null)
                m_mainScript = this.transform.root.GetComponent<UnityBattleSystem_SinglePlayer>();

            if (m_mainScript != null && m_canvas != null)
                m_isInitialized = true;
        }
        catch (Exception ex)
        {
            Debug.Log("UnitDataDisplayer: at Initialize() " + ex.Message);
        }
    }

    public void InstantiateInfoPanel(Effect _effect)
    {
        GameObject infoPanel = Instantiate(EffectInfoPanelPrefab, m_canvas, false);
        infoPanel.transform.Find("Image@Background").Find("Button@Close").GetComponent<Button>().onClick.AddListener(() => RemoveInfoPanel(infoPanel));
        m_infoPanels.Add(infoPanel);
        m_mainInfoPanelManager.AddInfoPanel(infoPanel);

        InitializeInfoPanel(infoPanel, _effect);
    }

    private void InitializeInfoPanel(GameObject _infoPanel, Effect _effect)
    {
        try
        {
            Transform infoPanelBG = _infoPanel.transform.Find("Image@Background");

            Text details = infoPanelBG.Find("Panel@Details").Find("ScrollMenu").Find("Contents").Find("Text@Details").GetComponent<Text>();
            details.text = GetDetails(_effect);

            Transform effects = infoPanelBG.Find("Panel@SecondaryEffects");
            for (int i = 0; i < _effect.SecondaryEffects.Count; i++)
            {
                GameObject tmp_effect = Instantiate(EffectButtonPrefab, effects);
                tmp_effect.name = "Secondary Effect " + (i + 1).ToString();
                Button tmp_effectButton = tmp_effect.GetComponent<Button>();
                Effect e = _effect.SecondaryEffects[i];
                tmp_effectButton.onClick.AddListener(() => InstantiateInfoPanel(e));
                //SetIcon
                tmp_effect.transform.Find("Text@Title").GetComponent<Text>().text = tmp_effect.name;
            }

        }
        catch (Exception ex)
        {
            Debug.Log("InfoPanelManager_Effect_SinglePlayer.InitializeInfoPanel() : " + ex.Message);
        }
    }

    private string GetDetails(Effect _effect)
    {
        string result = string.Empty;

        string activationConditions = _effect.ActivationCondition.HierarchyString;
        string timesToApply = _effect.TimesToApply.HierarchyString;
        string successRate = _effect.SuccessRate.HierarchyString;

        string commonString = string.Empty;
        commonString += "Activation Conditions:\n" + activationConditions + "\n\n";
        commonString += "Times To Apply:\n" + timesToApply + "\n\n";
        commonString += "Success Rate:\n" + successRate + "\n\n";

        if (_effect is DamageEffect)
        {
            DamageEffect effect = _effect as DamageEffect;

            result += "Effect Type: Damage\n\n";
            result += commonString;
            result += "Target Unit:\n" + effect.TargetClassification.ToString() + "\n\n";
            result += "Attack Classification:\n" + effect.AttackClassification.ToString() + "\n\n";
            result += "Element:\n" + effect.Element.ToString() + "\n\n";
            result += "Damage Type:\n" + ((effect.IsFixedValue == true) ? "Fixed" : "Power") + "\n\n";
            result += "Value:\n" + effect.Value.HierarchyString + "\n\n";
        }
        else if (_effect is HealEffect)
        {
            HealEffect effect = _effect as HealEffect;

            result += "Effect Type: Heal\n\n";
            result += commonString;
            result += "Target Unit:\n" + effect.TargetClassification.ToString() + "\n\n";
            result += "Damage Type:\n" + ((effect.IsFixedValue == true) ? "Fixed" : "Power") + "\n\n";
            result += "Value:\n" + effect.Value.HierarchyString + "\n\n";
        }
        else if (_effect is StatusEffectAttachmentEffect)
        {
            StatusEffectAttachmentEffect effect = _effect as StatusEffectAttachmentEffect;

            result += "Effect Type: Status Effect Attachment\n\n";
            result += commonString;
            result += "Target Unit:\n" + effect.TargetClassification.ToString() + "\n\n";

            result += "{Status Effect}\n";
            result += "Duration ends when either of the following becomes false >>\n";
            result += "While:\n" + effect.DataOfStatusEffectToAttach.Duration.WhileCondition.HierarchyString + "\n";
            result += "Turns:\n" + effect.DataOfStatusEffectToAttach.Duration.Turns.HierarchyString + "\n";
            result += "Times:\n" + effect.DataOfStatusEffectToAttach.Duration.ActivationTimes.HierarchyString + "\n";
            result += "Activation Condition >>\n" + effect.DataOfStatusEffectToAttach.ActivationCondition.HierarchyString + "\n";
        }
        else if (_effect is TileTrapEffect)
        {

        }

        return result;
    }

    //Remove newest info panel
    public void RemoveInfoPanel(GameObject _infoPanel)
    {
        m_mainInfoPanelManager.RemoveInfoPanel(_infoPanel);
        m_infoPanels.Remove(_infoPanel);
        Destroy(_infoPanel);
    }
}

