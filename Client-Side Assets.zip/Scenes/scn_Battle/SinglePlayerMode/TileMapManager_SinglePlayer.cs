﻿using EEANGames.TBSG._01.CommonEnums;
using EEANGames.TBSG._01.MainClassLib;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using UnityEngine.Networking;
using UnityEngine.UI;

[RequireComponent(typeof(MeshRenderer))]
public class TileMapManager_SinglePlayer : MonoBehaviour
{
    #region Serialized Fields
    public UnityEngine.Material NormalTile;
    public UnityEngine.Material BlueTile;
    public UnityEngine.Material RedTile;
    public UnityEngine.Material GreenTile;
    public UnityEngine.Material OcherTile;
    public UnityEngine.Material PurpleTile;
    public UnityEngine.Material YellowTile;
    public UnityEngine.Material HealTile;
    #endregion

    public const int sizeX = CoreValues.SIZE_OF_A_SIDE_OF_BOARD;
    public const int sizeZ = CoreValues.SIZE_OF_A_SIDE_OF_BOARD;

    #region Properties
    public bool IsInitialized { get; private set; }
    public List<MeshRenderer> TileMeshRenderers { get; private set; }
    #endregion

    #region Private Member Variables
    private UnityBattleSystem_SinglePlayer m_mainScript;
    #endregion

    // Use this for initialization
    void Awake()
    {
        try
        {
            IsInitialized = false;

            TileMeshRenderers = new List<MeshRenderer>();
        }
        catch (Exception ex)
        {
            Debug.Log("TileMap: at Awake() " + ex.Message);
        }
    }


    #region Client Side Code
    void Update()
    {
        if (!IsInitialized)
            Initialize();
    }

    public void Initialize()
    {
        try
        {
            if (m_mainScript == null)
                m_mainScript = this.transform.root.GetComponent<UnityBattleSystem_SinglePlayer>();

            if (m_mainScript.IsInitialized)
            {
                Debug.Log("TileMap (Script): Start Initialize.");

                if (!GetTiles())
                    return;

                if (m_mainScript.LocalPlayer_PlayerController.PlayerId != 1)
                {
                    if (!RotateTiles())
                        return;
                }

                if (!ApplyMaterialToTiles())
                    return;

                IsInitialized = true;
                Debug.Log("TileMap (Script): End Initialize.");
            }
        }
        catch (Exception ex)
        {
            Debug.Log("TileMap: at Initialize() " + ex.Message);
        }
    }

    private bool GetTiles()
    {
        try
        {
            TileMeshRenderers.Clear();

            for (int z = 0; z < sizeZ; z++)
            {
                for (int x = 0; x < sizeX; x++)
                {
                    string tileObjectName = "Tile" + (sizeZ * z + x).ToString();

                    MeshRenderer tmp_mr = this.transform.Find(tileObjectName).GetComponent<MeshRenderer>();

                    if (tmp_mr != null)
                        TileMeshRenderers.Add(tmp_mr);
                    else
                        return false;
                }
            }

            return true;
        }
        catch (Exception ex)
        {
            Debug.Log("TileMap: at GetTiles() " + ex.Message);
            return false;
        }
    }

    private bool RotateTiles()
    {
        try
        {
            foreach (MeshRenderer mr in TileMeshRenderers)
            {
                mr.transform.Rotate(0f, 0f, 180f);
            }

            return true;
        }
        catch (Exception ex)
        {
            Debug.Log("TileMapManager_SinglePlayer.RotateTiles() : " + ex.Message);
            return false;
        }

    }

    public bool ApplyMaterialToTiles()
    {
        try
        {
            for (int z = 0; z < sizeZ; z++)
            {
                for (int x = 0; x < sizeX; x++)
                {
                    eTileType tileType = m_mainScript.BattleSystemCore.Field.Board.Sockets[x, z].TileType;

                    int index = sizeZ * z + x;

                    TileMeshRenderers[index].material = TileTypeToMaterial(tileType);
                }
            }

            return true;
        }
        catch (Exception ex)
        {
            Debug.Log("TileMap: at ApplyMaterialToTiles(). " + ex.Message);
            return false;
        }
    }
    #endregion

    public void ChangeTile(int _boardCoordX, int _boardCoordY, eTileType _tileType)
    {
        if (_boardCoordX >= 0 && _boardCoordX < sizeX
            && _boardCoordY >= 0 && _boardCoordY < sizeZ)
        {
            int index = sizeX * _boardCoordY + _boardCoordX;
            TileMeshRenderers[index].material = TileTypeToMaterial(_tileType);
        }
    }

    private Material TileTypeToMaterial(eTileType _tileType)
    {
        switch (_tileType)
        {
            default: //eTileType.NORMAL
                return NormalTile;
            case eTileType.Blue:
                return BlueTile;
            case eTileType.Red:
                return RedTile;
            case eTileType.Green:
                return GreenTile;
            case eTileType.Ocher:
                return OcherTile;
            case eTileType.Purple:
                return PurpleTile;
            case eTileType.Yellow:
                return YellowTile;
            case eTileType.Heal:
                return HealTile;
        }
    }
}

