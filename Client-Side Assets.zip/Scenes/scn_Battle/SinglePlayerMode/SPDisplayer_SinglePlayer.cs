﻿using EEANGames.TBSG._01.MainClassLib;
using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SPDisplayer_SinglePlayer : MonoBehaviour
{

    public UnityEngine.Material ActiveStoneMaterial;
    public UnityEngine.Material InactiveStoneMaterial;

    private bool m_isInitialized;
    private UnityBattleSystem_SinglePlayer m_mainScript;

    private MeshRenderer[][] m_spObjectsMR;

    private int[] m_latestRemainingSP;
    private int[] m_latestMaxSP; 

    // Use this for initialization
    void Awake()
    {
        m_isInitialized = false;
    }

    // Update is called once per frame
    void Update()
    {
        if (!m_isInitialized)
            Initialize();

        //TryUpdateSPGraphic()
    }

    private void Initialize()
    {
        try
        {
            if (m_mainScript == null)
                m_mainScript = this.transform.root.GetComponent<UnityBattleSystem_SinglePlayer>();

            if (m_mainScript.IsInitialized
                && !m_isInitialized)
            {
                m_spObjectsMR = new MeshRenderer[m_mainScript.PlayerControllers.Count][];
                m_latestRemainingSP = new int[m_spObjectsMR.Length];
                m_latestMaxSP = new int[m_spObjectsMR.Length];

                for (int i = 0; i < m_mainScript.PlayerControllers.Count; i++)
                {
                    if (m_mainScript.PlayerControllers[i].IsInitialized)
                    {
                        m_latestMaxSP[i] = m_mainScript.PlayerControllers[i].MaxSP;
                        m_latestRemainingSP[i] = m_mainScript.PlayerControllers[i].RemainingSP;

                        m_spObjectsMR[i] = new MeshRenderer[CoreValues.MAX_SP];
                        for (int j = 0; j < m_spObjectsMR[i].Length; j++)
                        {
                            m_spObjectsMR[i][j] = this.transform.Find("SkillStone" + m_mainScript.PlayerControllers[i].PlayerId.ToString() + "_" + (j + 1).ToString()).GetComponent<MeshRenderer>();
                        }

                        UpdateSPGraphic(i);

                        m_isInitialized = true;
                    }
                }
            }
        }
        catch (Exception ex)
        {
            Debug.Log("SPTextManager: at Initialize() " + ex.Message);
        }
    }

    public void TryUpdateSPGraphic()
    {
        if (m_isInitialized)
        {
            for (int i = 0; i < m_mainScript.PlayerControllers.Count; i++)
            {
                if (m_mainScript.PlayerControllers[i].MaxSP != m_latestMaxSP[i]
                    || m_mainScript.PlayerControllers[i].RemainingSP != m_latestRemainingSP[i])
                {
                    m_latestMaxSP[i] = m_mainScript.PlayerControllers[i].MaxSP;
                    m_latestRemainingSP[i] = m_mainScript.PlayerControllers[i].RemainingSP;

                    UpdateSPGraphic(i);
                }
            }
        }
    }

    private void UpdateSPGraphic(int _playerControllerIndex)
    {
        for (int i = 0; i < m_latestRemainingSP[_playerControllerIndex]; i++)
        {
            m_spObjectsMR[_playerControllerIndex][i].material = ActiveStoneMaterial;
        }

        for (int i = m_latestRemainingSP[_playerControllerIndex]; i < m_spObjectsMR[_playerControllerIndex].Length; i++)
        {
            m_spObjectsMR[_playerControllerIndex][i].material = InactiveStoneMaterial;
        }
    }
}
