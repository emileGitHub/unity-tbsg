﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using UnityEngine.UI;

public class EndTurnButtonManager : MonoBehaviour {

    #region Private Fields
    private bool m_isInitialized;

    private UnityBattleSystem_SinglePlayer m_mainScript;
    private PlayerController_SinglePlayer m_playerController;

    private Button m_endTurnButton;
    #endregion

    // Use this for initialization
    void Awake () {
        m_isInitialized = false;
        m_endTurnButton = this.transform.Find("Button@EndTurn").GetComponent<Button>();
	}
	
	// Update is called once per frame
	void Update () {
        if (!m_isInitialized)
            Initialize();
        else
        {
            if (m_playerController.IsMyTurn && !m_endTurnButton.enabled)
                m_endTurnButton.enabled = true;
            else if (!m_playerController.IsMyTurn && m_endTurnButton.enabled)
                m_endTurnButton.enabled = false;
        }
	}

    private void Initialize()
    {
        try
        {
            if (m_mainScript == null)
                m_mainScript = this.transform.root.GetComponent<UnityBattleSystem_SinglePlayer>();
            if (m_mainScript == null)
                return;

            if (m_mainScript.IsInitialized)
            {
                m_playerController = m_mainScript.PlayerControllers.First(x => !x.IsCPU);
                if (m_playerController == null)
                    return;

                m_isInitialized = true;
            }
        }
        catch (Exception ex)
        {
            Debug.Log("ActionUIDisplayer.Initialize() : " + ex.Message);
        }
    }
}
