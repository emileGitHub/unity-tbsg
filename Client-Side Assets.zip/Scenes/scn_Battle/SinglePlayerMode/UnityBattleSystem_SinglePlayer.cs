﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using EEANGames.TBSG._01.MainClassLib;
using UnityEngine.Networking;
using EEANGames.TBSG._01.CommonEnums;
using System;
using UnityEngine.UI;
using System.Linq;
using EEANGames;

[RequireComponent(typeof(AnimationController_SinglePlayer))]
public class UnityBattleSystem_SinglePlayer : MonoBehaviour {

    #region Serialized Field
    public GameObject UnitPrefab;
    #endregion

    #region Properties
    public GameObject[] Players { get; private set; }
    public List<PlayerController_SinglePlayer> PlayerControllers { get; private set; }
    public PlayerController_SinglePlayer LocalPlayer_PlayerController { get; private set; }

    public List<GameObject> Units { get; private set; }
    public List<GameObject> Player1Units { get; private set; }
    public List<GameObject> Player2Units { get; private set; }

    public BattleSystemCore BattleSystemCore { get; private set; }

    public bool IsInitialized { get; private set; }
    #endregion

    #region Private Fields
    private bool m_arePlayersSet;

    private AnimationController_SinglePlayer m_animationController;

    private TileMaskManager_SinglePlayer m_tileMaskManager;
    private GameObject m_gameBoardSet;
    private Transform m_baseTile;
    private Vector2 m_tileSize;

    private List<eTileType> m_tileSet;

    private bool m_areTileDataSet;
    private bool m_isFieldSet;
    private bool m_areUnitsSet;
    #endregion


    // Use this for Initialization of simple properties
    void Awake()
    {
        IsInitialized = false;
        m_areTileDataSet = false;
        m_isFieldSet = false;
        m_areUnitsSet = false;
        m_arePlayersSet = false;
        m_animationController = this.GetComponent<AnimationController_SinglePlayer>();
        m_gameBoardSet = GameObject.FindGameObjectWithTag("GameBoard");
        m_tileMaskManager = m_gameBoardSet.GetComponent<TileMaskManager_SinglePlayer>();
        m_baseTile = m_gameBoardSet.transform.Find("Tile0");
        MeshRenderer mr = m_baseTile.GetComponent<MeshRenderer>();
        m_tileSize = new Vector2(mr.bounds.size.x, mr.bounds.size.z);
        Units = new List<GameObject>();
        Player1Units = new List<GameObject>();
        Player2Units = new List<GameObject>();
        PlayerControllers = new List<PlayerController_SinglePlayer>();
    }

    // Use this for detailed initialization
    // Update() is being used to make sure that all Player Instances are created before the detailed initialization
    void Update()
    {
        if (!IsInitialized)
            Initialize();

        if (IsInitialized)
        {
            if (BattleSystemCore.IsMatchEnd)
                EndMatch();
        }
    }

    private void Initialize()
    {
        try
        {
            Debug.Log("BattleSystem_SinglePlayer: Start Initialization.");

            if (!m_arePlayersSet)
            {
                if (Players == null || Players.Length < 2)
                    Players = GameObject.FindGameObjectsWithTag("Player");

                if (Players.Length < 2) // if not all Players have been spawned
                    return; // Stop Initialization

                PlayerControllers.Clear(); // Get the primary script of each Player Object
                foreach (GameObject player in Players)
                {
                    PlayerController_SinglePlayer tmp_playerController = player.GetComponent<PlayerController_SinglePlayer>();
                    if (tmp_playerController == null
                        || !tmp_playerController.IsInitialized)
                    {
                        return;
                    }

                    PlayerControllers.Add(tmp_playerController);
                }

                if (LocalPlayer_PlayerController == null)
                    LocalPlayer_PlayerController = PlayerControllers.First(x => !x.IsCPU); //Set reference to the local player's PlayerController

                if (!SetPlayOrder()) // If failed to set Playing Order
                    return;

                Debug.Log("Players set successfully!");
                m_arePlayersSet = true;
            }

            if (!m_areTileDataSet)
            {
                m_tileSet = new List<eTileType>
                {
                    eTileType.Normal,
                    eTileType.Normal,
                    eTileType.Normal,
                    eTileType.Normal,
                    eTileType.Blue,
                    eTileType.Red,
                    eTileType.Green,
                    eTileType.Ocher,
                    eTileType.Purple,
                    eTileType.Yellow,
                    eTileType.Heal
                }; // Define the set of tiles available --- repetition of tiles will increase the probability that the board contains the specific tile

                if (m_tileSet != null && m_tileSet.Count > 0)
                {
                    Debug.Log("Tile data set successfully!");
                    m_areTileDataSet = true;
                }
                else
                    return;
            }

            if (!m_isFieldSet)
            {
                Field field = Field.NewField(PlayerControllers[0].PlayerData as Player, 0, PlayerControllers[1].PlayerData as Player, 1, m_tileSet);
                BattleSystemCore = new BattleSystemCore(field);
                if (BattleSystemCore == null) // if FieldInstance was not created successfully
                    return;

                //Sync player data values
                for (int i = 0; i < Players.Length; i++)
                {
                    PlayerControllers[i].PlayerData = BattleSystemCore.Field.Players[i]; //Swap PlayerData (currently instance of Player class) with instance of newly created PlayerOnBoard (child class of Player class)
                    PlayerControllers[i].SyncProperties();
                }

                Debug.Log("Field set successfully!");
                m_isFieldSet = true;
            }

            if (!m_areUnitsSet)
            {
                Units.Clear(); // Reset List in case it already contains game objects
                foreach (UnitInstance unit in BattleSystemCore.Field.Players[0].AlliedUnits) // Spawn Units owned by Player 1
                {
                    if (!SpawnUnit(unit, 0))
                        return;
                }

                foreach (UnitInstance unit in BattleSystemCore.Field.Players[1].AlliedUnits) // Spawn Units owned by Player 2
                {
                    if (!SpawnUnit(unit, 1))
                        return;
                }

                Debug.Log("Units set successfully!");
                m_areUnitsSet = true;
            }

            if (m_areTileDataSet
                && m_isFieldSet
                && m_areUnitsSet)
            {
                IsInitialized = true;
                Debug.Log("BattleSystem_SinglePlayer: End Initialization.");
            }
        }
        catch (Exception ex)
        {
            Debug.Log("BattleSystem_SinglePlayer: at Initialize()" + ex.Message);
        }
    }

    //private void UpdatePlayerControllersProperties()
    //{
    //    for(int i = 0; i < PlayerControllers.Count; i++)
    //    {
    //        int maxSP = BattleSystemCore.Field.Players[i].MaxSP;
    //        int remainingSP = BattleSystemCore.Field.Players[i].RemainingSP;
    //        int selectedAlliedUnitId = BattleSystemCore.Field.Players[i].SelectedUnitIndex;

    //        if (PlayerControllers[i].MaxSP != maxSP
    //            || PlayerControllers[i].RemainingSP != remainingSP
    //            || PlayerControllers[i].SelectedAlliedUnitId != selectedAlliedUnitId)
    //        {
    //            PlayerControllers[i].SyncProperties();
    //        }
    //    }
    //}

    public void ChangeTurn()
    {
        if (!m_animationController.IsInitialized || m_animationController.LockUI)
            return;

        BattleSystemCore.ChangeTurn();
        foreach (PlayerController_SinglePlayer playerController in PlayerControllers)
        {
            playerController.SyncProperties();
        }
    }

    public void Concede()
    {
        if (!m_animationController.IsInitialized || m_animationController.LockUI)
            return;

        int currentPlayerIndex = PlayerControllers[0].IsMyTurn ? 0 : 1;
        int currentPlayerId = PlayerControllers[currentPlayerIndex].PlayerId;

        BattleSystemCore.EndMatch(BattleSystemCore.Field.Players[currentPlayerId - 1]);
    }

    private void EndMatch()
    {
        bool m_isLocalPlayerWinner = BattleSystemCore.IsPlayer1Winner;

        if (LocalPlayer_PlayerController.PlayerId != 1)
            m_isLocalPlayerWinner = !m_isLocalPlayerWinner;

        // Proceed to the ending phase of the match.
    }

    private bool SpawnUnit(UnitInstance _unit, int _playerIndex)
    {
        try
        {
            Debug.Log("BattleSystem_SinglePlayer: Start Unit Spawning.");

            GameObject Unit = Instantiate(UnitPrefab, Vector3.zero, Quaternion.identity, this.transform.root);

            _2DCoord coord = BattleSystemCore.Field.UnitLocation(_unit); // Get location as logical 2D Coordinate (x, y) --- this is not Unity coordinate
            Unit.transform.position = GetActualPosition(coord); // Get and Set the actual position in the Unity world
            if (_playerIndex != 0)
                Unit.transform.Rotate(0f, 180f, 0f); //Rotate 180 degrees to adjust player 2's units' direction facing.

            //Return false if not succeeded
            if (!Unit.GetComponent<UnitController_SinglePlayer>()
                .ExternalInitialization(BattleSystemCore.Field.Units.IndexOf(_unit),
                                       BattleSystemCore.Field.Players[_playerIndex].AlliedUnits.IndexOf(_unit),
                                       _playerIndex + 1,
                                       _unit))
            {
                Destroy(Unit); // destroy not to leave the unsynced instance in unity world
                return false;
            }

            Unit.name = _unit.Nickname; //To make it easier to identify on editor

            if (_playerIndex == 0)
                Player1Units.Add(Unit);
            else
                Player2Units.Add(Unit);

            Units.Add(Unit);

            Debug.Log("BattleSystem_SinglePlayer: End Unit Spawning.");
            return true;
        }
        catch (Exception ex)
        {
            Debug.Log("BattleSystem_SinglePlayer: at SpawnUnit() " + ex.Message);
            return false;
        }
    }

    private Vector3 GetActualPosition(_2DCoord _coord)
    {
        try
        {
            int tileNum = _coord.Y * CoreValues.SIZE_OF_A_SIDE_OF_BOARD + _coord.X;
            Transform tileMask = GameObject.Find("Tile" + tileNum.ToString()).transform.Find("Mask" + tileNum.ToString());

            float adjustmentValueY = 0.01f;

            float x = tileMask.position.x;
            float y = tileMask.position.y + adjustmentValueY;
            float z = tileMask.position.z;

            return new Vector3(x, y, z);
        }
        catch (Exception ex)
        {
            Debug.Log("BattleSystem_SinglePlayer: at GetActualPosition() " + ex.Message);
            return new Vector3(-1, -1, -1);
        }
    }

    public void MoveUnit(_2DCoord _destination)
    {
        try
        {
            PlayerOnBoard pob = BattleSystemCore.CurrentTurnPlayer;
            UnitInstance unit = pob.AlliedUnits[pob.SelectedUnitIndex];

            BattleSystemCore.MoveUnit(unit, _destination);

            int unitIndex = BattleSystemCore.Field.Units.IndexOf(pob.AlliedUnits[pob.SelectedUnitIndex]);
            GameObject Unit = Units[unitIndex];
            Unit.transform.position = GetActualPosition(BattleSystemCore.Field.UnitLocation(unit));

            PlayerController_SinglePlayer playerController = PlayerControllers.First(x => x.PlayerData == pob);
            playerController.SyncProperties();

            UpdateMovableArea(playerController.PlayerId, pob.SelectedUnitIndex);
        }
        catch (Exception ex)
        {
            Debug.Log("BattleSystem_SinglePlayer: at MoveUnit() " + ex.Message);
        }
    }

    public void Attack(List<_2DCoord> _targetCoords)
    {
        try
        {
            PlayerOnBoard pob = BattleSystemCore.CurrentTurnPlayer;
            UnitInstance unit = pob.AlliedUnits[pob.SelectedUnitIndex];

            BattleSystemCore.RequestAttack(unit, _targetCoords);

            PlayerController_SinglePlayer playerController = PlayerControllers.First(x => x.PlayerData == pob);
            playerController.SyncProperties();

            UpdateAttackTargetableArea(playerController.PlayerId, pob.SelectedUnitIndex);
        }
        catch (Exception ex)
        {
            Debug.Log("BattleSystem_SinglePlayer: at Attack() " + ex.Message);
        }
    }

    public void UseSkill(string _skillName, List<_2DCoord> _targetCoords)
    {
        try
        {
            PlayerOnBoard pob = BattleSystemCore.CurrentTurnPlayer;
            UnitInstance unit = pob.AlliedUnits[pob.SelectedUnitIndex];

            CostRequiringSkill skill = unit.Skills.OfType<CostRequiringSkill>().First(x => x.BaseInfo.Name == _skillName);

            //List<EFFECT_RESULT> effectResults = BattleSystemCore.RequestSkillUse(unit, skill);
            //if (effectResults.Count > 0)
            //{
            //    //m_animationController.SkillAnimation(UnitController.Unit_PublicId, effectResults);
            //}

            BattleSystemCore.RequestSkillUse(unit, skill, _targetCoords);

            PlayerController_SinglePlayer playerController = PlayerControllers.First(x => x.PlayerData == pob);
            playerController.SyncProperties();

            UpdateSkillTargetableArea(playerController.PlayerId, pob.SelectedUnitIndex, _skillName);
        }
        catch (Exception ex)
        {
            Debug.Log("BattleSystem_SinglePlayer: at Attack() " + ex.Message);
        }
    }

    //public void UseUltimateSkill(string _skillName, List<_2DCoord> _targetCoords)
    //{
    //
    //
    //
    //}

    //public void RequestSkillCost(int _playerId, int _unitIndex, string _skillName)
    //{
    //    int playerIndex = _playerId - 1; // _playerId is one-based and playerIndex needs to be zero-based

    //    PlayerOnBoard pob = BattleSystemCore.Field.Players[playerIndex];
    //    UnitInstance unit = pob.AlliedUnits[_unitIndex];

    //    int requiredSP = (unit.BaseInfo.Skills.First(x => x.Name == _skillName) as CostRequiringSkill).SPCost;
    //}

    //private void SyncUnitStatus_All()
    //{
    //    try
    //    {
    //        foreach (GameObject Unit in Player1Units)
    //        {
    //            UnitController_SinglePlayer UnitController = Unit.GetComponent<UnitController_SinglePlayer>();

    //            UnitInstance unit = BattleSystemCore.Field.Players[0].AlliedUnits[UnitController.Unit_PrivateId];

    //            //UnitController.Rpc_SyncStatus(Calculator.MaxHP(unit), unit.RemainingHP, unit.isAlive);
    //        }

    //        foreach (GameObject Unit in Player2Units)
    //        {
    //            UnitController_SinglePlayer UnitController = Unit.GetComponent<UnitController_SinglePlayer>();

    //            UnitInstance unit = BattleSystemCore.Field.Players[1].AlliedUnits[UnitController.Unit_PrivateId];

    //            //UnitController.Rpc_SyncStatus(Calculator.MaxHP(unit), unit.RemainingHP, unit.isAlive);
    //        }
    //    }
    //    catch (Exception ex)
    //    {
    //        Debug.Log("BattleSystem_SinglePlayer: at SyncUnitStatus_All() " + ex.Message);
    //    }
    //}

    public void ChangeUnit(int _playerId, int _unitIndex)
    {
        try
        {
            if (m_animationController.LockUI)
                return;

            int internalPlayerId = _playerId - 1;

            PlayerOnBoard pob = BattleSystemCore.Field.Players[internalPlayerId];

            if(_unitIndex != pob.SelectedUnitIndex)
            {
                BattleSystemCore.ChangeSelectedUnit(pob, _unitIndex);
                Debug.Log("Selected Unit has been changed");

                PlayerControllers[internalPlayerId].SyncProperties();

                Debug.Log("Unit Selection Info was Synced!");
            }
        }
        catch (Exception ex)
        {
            Debug.Log("BattleSystem_SinglePlayer: at ChangeUnit() " + ex.Message);
        }
    }

    public void UpdateMovableArea(int _playerId, int _unitIndex)
    {
        try
        {
            int playerIndex = _playerId - 1; // _playerId is one-based and playerIndex needs to be zero-based

            PlayerOnBoard pob = BattleSystemCore.Field.Players[playerIndex];
            UnitInstance unit = pob.AlliedUnits[_unitIndex];

            m_tileMaskManager.UpdateMaxNumOfTargets(1);
            m_tileMaskManager.UpdateTargetArea(BattleSystemCore.GetMovableAndSelectableArea(unit));
        }
        catch (Exception ex)
        {
            Debug.Log("BattleSystem_SinglePlayer: at UpdateMovableArea() " + ex.Message + ex.InnerException);
        }
    }

    public void UpdateAttackTargetableArea(int _playerId, int _unitIndex)
    {
        try
        {
            int playerIndex = _playerId - 1; // _playerId is one-based and playerIndex needs to be zero-based

            PlayerOnBoard pob = BattleSystemCore.Field.Players[playerIndex];
            UnitInstance unit = pob.AlliedUnits[_unitIndex];

            m_tileMaskManager.UpdateMaxNumOfTargets(Calculator.MaxNumOfTargets(unit, GameDataContainer.Instance.BasicAttackSkill, BattleSystemCore.GetAttackTargetableArea(unit), BattleSystemCore));
            m_tileMaskManager.UpdateTargetArea(BattleSystemCore.GetAttackTargetableAndSelectableArea(unit));
        }
        catch (Exception ex)
        {
            Debug.Log("BattleSystem_SinglePlayer: at UpdateAttackTargetableArea() " + ex.Message);
        }
    }

    public void UpdateSkillTargetableArea(int _playerId, int _unitIndex, string _skillName)
    {
        try
        {
            int playerIndex = _playerId - 1; // _playerId is one-based and playerIndex needs to be zero-based

            PlayerOnBoard pob = BattleSystemCore.Field.Players[playerIndex];
            UnitInstance unit = pob.AlliedUnits[_unitIndex];

            var skill = unit.Skills.OfType<ActiveSkill>().First(x => x.BaseInfo.Name == _skillName);

            m_tileMaskManager.UpdateMaxNumOfTargets(Calculator.MaxNumOfTargets(unit, skill, BattleSystemCore.GetSkillTargetableArea(unit, skill), BattleSystemCore));

            if (skill is CostRequiringSkill)
                m_tileMaskManager.UpdateTargetArea(BattleSystemCore.GetSkillTargetableAndSelectableArea(unit, skill as CostRequiringSkill));
            else if (skill is UltimateSkill)
                m_tileMaskManager.UpdateTargetArea(BattleSystemCore.GetSkillTargetableAndSelectableArea(unit, skill as UltimateSkill));
        }
        catch (Exception ex)
        {
            Debug.Log("BattleSystem_SinglePlayer: at UpdateSkillTargetableArea() " + ex.Message);
        }
    }

    public void UpdateTargetableAreaToNull()
    {
        m_tileMaskManager.UpdateTargetArea(null);
    }

    public bool SetPlayOrder()
    {
        try
        {
            Random.Random.randInit();
            int randNum = Random.Random.getRand(1, 10); //Randomly select which Player will start playing first
            if (randNum > 5)
            {
                //Change player order in list
                {
                    GameObject tmp = Players[0];
                    Players[0] = Players[1];
                    Players[1] = tmp;
                }

                {
                    PlayerController_SinglePlayer tmp = PlayerControllers[0];
                    PlayerControllers[0] = PlayerControllers[1];
                    PlayerControllers[1] = tmp;
                }
            }
            //else if (randNum <= 5)
            //Do nothing;

            PlayerControllers[0].SyncProperties(1); // Giving it an Id of 1 so that it knows it is Player 1. Starts first
            PlayerControllers[1].SyncProperties(2); // Giving it an Id of 2 so that it knows it is Player 2. Starts after Player 1
            
            return true;
        }
        catch(Exception ex)
        {
            Debug.Log("BattleSystem_SinglePlayer: at SetPlayOrder() " + ex.Message);
            return false;
        }
    }
}
