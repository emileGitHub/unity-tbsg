﻿using EEANGames.TBSG._01.MainClassLib;
using EEANGames.ImageConverter.Unity;
using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

[RequireComponent(typeof(InfoPanelManager_SinglePlayer))]
public class InfoPanelManager_Unit_SinglePlayer : MonoBehaviour {

    #region Serialized Fields
    public GameObject UnitInfoPanelPrefab;
    public GameObject SkillButtonPrefab;
    #endregion

    #region Private Member Variables
    private UnityBattleSystem_SinglePlayer m_mainScript;

    private InfoPanelManager_SinglePlayer m_mainInfoPanelManager;
    private InfoPanelManager_Skill_SinglePlayer m_infoPanelManager_Skill;

    private AnimationController_SinglePlayer m_animationController;

    private List<GameObject> m_infoPanels;
    private Transform m_canvas;

    private bool m_isInitialized;
    #endregion

    //Use this for initialization

    void Awake()
    {
        m_infoPanels = new List<GameObject>();
        m_mainInfoPanelManager = this.transform.GetComponent<InfoPanelManager_SinglePlayer>();
        m_infoPanelManager_Skill = this.transform.root.GetComponent<InfoPanelManager_Skill_SinglePlayer>();
        m_isInitialized = false;
    }

    // Update is called once per frame
    void Update()
    {
        if (!m_isInitialized)
            Inititalize();

        if (m_isInitialized)
        {
            //UpdateTexts();
        }
    }

    private void Inititalize()
    {
        try
        {
            if (m_canvas == null)
                m_canvas = GameObject.FindGameObjectWithTag("Canvas").transform;

            if (m_mainScript == null)
                m_mainScript = this.transform.root.GetComponent<UnityBattleSystem_SinglePlayer>();

            if (m_animationController == null)
                m_animationController = this.GetComponent<AnimationController_SinglePlayer>();

            if (m_mainScript != null && m_canvas != null && m_animationController != null)
                m_isInitialized = true;
        }
        catch (Exception ex)
        {
            Debug.Log("UnitDataDisplayer: at Initialize() " + ex.Message);
        }
    }

    public void InstantiateInfoPanel(UnitController_SinglePlayer _unitControllerScript)
    {
        if (m_animationController.LockUI)
            return;

        GameObject infoPanel = Instantiate(UnitInfoPanelPrefab, m_canvas, false);
        infoPanel.transform.Find("Image@Background").Find("Button@Close").GetComponent<Button>().onClick.AddListener(() => RemoveInfoPanel(infoPanel));
        m_infoPanels.Add(infoPanel);
        m_mainInfoPanelManager.AddInfoPanel(infoPanel);

        InitializeInfoPanel(infoPanel, _unitControllerScript);
    }

    private void InitializeInfoPanel(GameObject _infoPanel, UnitController_SinglePlayer _unitControllerScript)
    {
        try
        {
            Transform infoPanelBG = _infoPanel.transform.Find("Image@Background");
            infoPanelBG.Find("Text@UnitNickname").GetComponent<Text>().text = _unitControllerScript.UnitReference.Nickname;

            Transform unitCard = infoPanelBG.Find("UnitCard");
            unitCard.Find("NamePlate").Find("Text@Name").GetComponent<Text>().text = _unitControllerScript.UnitReference.BaseInfo.Name;
            unitCard.Find("Text@Level").GetComponent<Text>().text = Calculator.Level(_unitControllerScript.UnitReference).ToString();
            unitCard.Find("MaxHP").Find("Text@Value").GetComponent<Text>().text = Calculator.MaxHP(_unitControllerScript.UnitReference).ToString();
            unitCard.Find("PhyStr").Find("Text@Value").GetComponent<Text>().text = Calculator.PhysicalStrength(_unitControllerScript.UnitReference).ToString();
            unitCard.Find("PhyRes").Find("Text@Value").GetComponent<Text>().text = Calculator.PhysicalResistance(_unitControllerScript.UnitReference).ToString();
            unitCard.Find("MagStr").Find("Text@Value").GetComponent<Text>().text = Calculator.MagicalStrength(_unitControllerScript.UnitReference).ToString();
            unitCard.Find("MagRes").Find("Text@Value").GetComponent<Text>().text = Calculator.MagicalResistance(_unitControllerScript.UnitReference).ToString();
            unitCard.Find("Vit").Find("Text@Value").GetComponent<Text>().text = Calculator.Vitality(_unitControllerScript.UnitReference).ToString();

            int unitTextureId = _unitControllerScript.UnitReference.BaseInfo.Id; // To be modified
            unitCard.Find("Image@Unit").GetComponent<Image>().sprite = UnityImageConverter.TextureToSprite(TextureContainer.Instance.UnitTextures[unitTextureId]);

            int element1_index = Convert.ToInt32(_unitControllerScript.UnitReference.BaseInfo.Elements[0]) - 1;
            int element2_index = Convert.ToInt32(_unitControllerScript.UnitReference.BaseInfo.Elements[1]) - 1;
            Transform elementBackground = unitCard.Find("Image@ElementBackground");
            Transform element1 = elementBackground.Find("Image@Element1");
            Transform element2 = elementBackground.Find("Image@Element2");

            if (element1_index < 0)
                element1.GetComponent<CanvasRenderer>().SetAlpha(0);
            else
            {
                element1.GetComponent<CanvasRenderer>().SetAlpha(1f);
                element1.GetComponent<Image>().sprite = SpriteContainer.Instance.ElementIcons[element1_index];
            }

            if (element2_index < 0)
                element2.GetComponent<CanvasRenderer>().SetAlpha(0);
            else
            {
                element2.GetComponent<CanvasRenderer>().SetAlpha(1f);
                element2.GetComponent<Image>().sprite = SpriteContainer.Instance.ElementIcons[element2_index];
            }

            Transform targetAreaTypes = unitCard.Find("Panel@TargetAreaTypes");
            targetAreaTypes.Find("Image@MovementRangeType").Find("Text").GetComponent<Text>().text = _unitControllerScript.UnitReference.BaseInfo.MovementRangeClassification.ToString(); ;
            targetAreaTypes.Find("Image@NonMovementActionRangeType").Find("Text").GetComponent<Text>().text = _unitControllerScript.UnitReference.BaseInfo.NonMovementActionRangeClassification.ToString(); ;

            Transform skills = infoPanelBG.Find("Panel@Skills");
            foreach(Skill skill in _unitControllerScript.UnitReference.Skills)
            {
                GameObject tmp_skill = Instantiate(SkillButtonPrefab, skills);
                tmp_skill.name = skill.BaseInfo.Name;
                Button tmp_skillButton = tmp_skill.GetComponent<Button>();
                tmp_skillButton.onClick.AddListener(() => m_infoPanelManager_Skill.InstantiateInfoPanel(skill));
                //SetIcon
                tmp_skill.transform.Find("Text@Title").GetComponent<Text>().text = skill.BaseInfo.Name;
            }
        }
        catch(Exception ex)
        {
            Debug.Log("InfoPanelManager_Unit_SinglePlayer.InitializeInfoPanel() : " + ex.Message);
        }
    }

    //Remove newest info panel
    public void RemoveInfoPanel(GameObject _infoPanel)
    {
        m_mainInfoPanelManager.RemoveInfoPanel(_infoPanel);
        m_infoPanels.Remove(_infoPanel);
        Destroy(_infoPanel);
    }
}
