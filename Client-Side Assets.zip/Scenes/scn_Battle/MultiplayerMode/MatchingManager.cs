﻿using EEANGames.TBSG._01.MainClassLib;
using EEANGames.TBSG._01.Unity;
using System.Collections;
using System.Collections.Generic;
using UnityEditor;
using UnityEngine;
using UnityEngine.Networking;
using UnityEngine.UI;

public class MatchingManager : MonoBehaviour
{
    #region Serialized Fields
    public Text LoadingText;
    public string Text;
    #endregion

    #region Private Fields
    private bool m_isMatching;
    #endregion

    // Use this for initialization
    void Awake()
    {
        m_isMatching = false;

        StartCoroutine(StartMatching());
    }

    // Updates once per frame
    void FixedUpdate()
    {
        // If the new scene has started loading...
        if (m_isMatching)
        {
            if (LoadingText.text != Text)
                LoadingText.text = Text;

            // ...then pulse the transparency of the loading text to let the player know that the computer is still working.
            LoadingText.color = new Color(LoadingText.color.r, LoadingText.color.g, LoadingText.color.b, Mathf.PingPong(Time.time, 1));

            StartCoroutine(CheckMatchingStatus());
        }

    }

    IEnumerator StartMatching()
    {
        Dictionary<string, string> values = new Dictionary<string, string>
                {
                    {"subject", "StartMatching"},
                    {"playerId", GameDataContainer.Instance.Player.Id.ToString()},
                    {"teamIndex", 0.ToString()}
                };

        UnityWebRequest uwr = UnityWebRequest.Post(CoreValues.SERVER_URL, values);
        yield return uwr.SendWebRequest();

        string errorMsg = string.Empty;

        if (uwr.isNetworkError)
            errorMsg = "Connection Error: " + uwr.error + "\nPlease check your Internet connection.";
        else
        {
            string response = uwr.downloadHandler.text;

            switch (response)
            {
                case "matching":
                    m_isMatching = true;
                    break;

                case "alreadyInMatch":
                    errorMsg = "The player is already in match!";
                    break;

                case "alreadyWaiting":
                    errorMsg = "Matching request was already recived!";
                    break;

                default:
                    errorMsg = "Something when wrong!";
                    break;
            }
        }

        if (errorMsg != "")
            PopUpWindowManager.Instance.CreatePopUp("Error!", errorMsg, "Return To Selection Menu", () => SceneConnector.GoToScene("scn_BattleMode"), ePopUpWindowType.Simple);
    }

    IEnumerator CheckMatchingStatus()
    {
        Dictionary<string, string> values = new Dictionary<string, string>
                {
                    {"subject", "CheckMatchingStatus"},
                    {"playerId", GameDataContainer.Instance.Player.Id.ToString()}
                };

        UnityWebRequest uwr = UnityWebRequest.Post(CoreValues.SERVER_URL, values);
        yield return uwr.SendWebRequest();

        string errorMsg = string.Empty;

        if (uwr.isNetworkError)
            errorMsg = "Connection Error: " + uwr.error + "\nPlease check your Internet connection.";
        else
        {
            string response = uwr.downloadHandler.text;

            if (response == "matched")
                SceneConnector.GoToScene("scn_MultiplayerBattle");
        }
    }
}
