﻿using EEANGames.TBSG._01.MainClassLib;
using EEANGames.TBSG._01.Unity;
using System.Collections;
using System.Collections.Generic;
using UnityEditor;
using UnityEngine;
using UnityEngine.Networking;
using UnityEngine.UI;

public class MatchingManager : MonoBehaviour
{
    #region Serialized Fields
    public Text LoadingText;
    public string Text;
    #endregion

    #region Private Fields
    private bool m_isMatching;
    #endregion

    // Awake is called before Update for the first frame
    void Awake()
    {
        m_isMatching = false;

        StartCoroutine(StartMatching());
    }

    // Updates once per frame
    void FixedUpdate()
    {
        // If the new scene has started loading...
        if (m_isMatching)
        {
            if (LoadingText.text != Text)
                LoadingText.text = Text;

            // ...then pulse the transparency of the loading text to let the player know that the application is still working.
            LoadingText.color = new Color(LoadingText.color.r, LoadingText.color.g, LoadingText.color.b, Mathf.PingPong(Time.time, 1));

            StartCoroutine(CheckMatchingStatus());
        }

    }

    IEnumerator StartMatching()
    {
        Dictionary<string, string> values = new Dictionary<string, string>
                {
                    {"subject", "StartMatching"},
                    {"sessionId", GameDataContainer.Instance.SessionId},
                    {"playerId", GameDataContainer.Instance.Player.Id.ToString()},
                    {"teamIndex", 0.ToString()}
                };

        UnityWebRequest uwr = UnityWebRequest.Post(CoreValues.SERVER_URL, values);
        yield return uwr.SendWebRequest();

        string errorMsg = string.Empty;

        if (uwr.isNetworkError)
            errorMsg = "Connection Error: " + uwr.error + "\nPlease check your Internet connection.";
        else
        {
            string response = uwr.downloadHandler.text;

            switch (response)
            {
                case "matching":
                    m_isMatching = true;
                    break;

                case "alreadyInMatch":
                    errorMsg = "The player is already in match!";
                    break;

                case "alreadyWaiting":
                    errorMsg = "Matching request was already recived!";
                    break;

                case "sessionExpired":
                    errorMsg = CoreValues.SESSION_ERROR_MESSAGE;
                    break;

                default:
                    errorMsg = "Something went wrong!";
                    break;
            }
        }

        if (errorMsg == CoreValues.SESSION_ERROR_MESSAGE)
            PopUpWindowManager.Instance.CreateSimplePopUp("Session Error!", errorMsg, "Return To Title", () => SceneConnector.GoToScene("scn_Title"));
        else if (errorMsg != "")
            PopUpWindowManager.Instance.CreateSimplePopUp("Error!", errorMsg, "Return To Selection Menu", () => SceneConnector.GoToScene("scn_BattleMode"));
    }

    IEnumerator CheckMatchingStatus()
    {
        Dictionary<string, string> values = new Dictionary<string, string>
                {
                    {"subject", "CheckMatchingStatus"},
                    {"sessionId", GameDataContainer.Instance.SessionId},
                    {"playerId", GameDataContainer.Instance.Player.Id.ToString()}
                };

        UnityWebRequest uwr = UnityWebRequest.Post(CoreValues.SERVER_URL, values);
        yield return uwr.SendWebRequest();

        string errorMsg = string.Empty;

        if (uwr.isNetworkError)
            errorMsg = "Connection Error: " + uwr.error + "\nPlease check your Internet connection.";
        else
        {
            string response = uwr.downloadHandler.text;

            if (response == "matched")
                SceneConnector.GoToScene("scn_MultiplayerBattle");
            else if (response == "sessionExpired")
                PopUpWindowManager.Instance.CreateSimplePopUp("Session Error!", CoreValues.SESSION_ERROR_MESSAGE, "Return To Title", () => SceneConnector.GoToScene("scn_Title"));
        }
    }
}
