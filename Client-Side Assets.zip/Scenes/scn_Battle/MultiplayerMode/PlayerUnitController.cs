﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Networking;
//using EEANGames.TBSG._01.MainClassLib.DBDataHandler.ForUnity;
using System;
using EEANGames.TBSG._01.CommonEnums;
using EEANGames.TBSG._01.MainClassLib;
using UnityEngine.UI;
using EEANGames.ImageConverter.Unity;
using UnityEditor;
using EEANGames.TBSG._01.Unity;

public class PlayerUnitController : MonoBehaviour
{
    public int PublicIndex;
    public int PrivateIndex; // Units of same Player cannot have same index
    public int OwnerId;

    private UnityBattleSystem_Multiplayer m_mainScript;

    private MeshRenderer m_meshRenderer_frame;
    private MeshRenderer m_meshRenderer_unit;
    private MeshRenderer m_meshRenderer_backGround;

    private MeshCollider m_collider;

    public UnitInstance UnitReference { get; private set; }
    public int MaxHP { get; private set; }

    //private ParticleSet ParticleSet;

    public bool HasUnitDataBeenSynced { get; private set; }

    public bool IsInitializedInternally { get; private set; }
    public bool IsInitializedExternally { get; private set; }

    private readonly Vector3 m_invalidPosition = new Vector3(500, 500, -500);

    // Awake is called before Update for the first frame
    void Awake()
    {
        try
        {
            HasUnitDataBeenSynced = false;

            IsInitializedInternally = false;
            IsInitializedExternally = false;
            //ParticleSet = GameObject.Find("ParticleSet").GetComponent<ParticleSet>();

            Transform frame = this.transform.Find("Frame");
            m_meshRenderer_frame = frame.GetComponent<MeshRenderer>();
            m_collider = frame.GetComponent<MeshCollider>();
            //m_meshRenderer_class = this.transform.Find("SmallSquarePlane").GetComponent<MeshRenderer>();
            m_meshRenderer_unit = this.transform.Find("LargeSquarePlane").GetComponent<MeshRenderer>();
            m_meshRenderer_backGround = this.transform.Find("OctagonPlane").GetComponent<MeshRenderer>();

            //Required for Update() to avoid not being called
            if (!this.isActiveAndEnabled)
                this.enabled = true;
        }
        catch (Exception ex)
        {
            Debug.Log("UnitController_SinglePlayer: at Awake()" + ex.Message);
        }
    }

    void Update()
    {
        if (!IsInitializedInternally)
            Initialize();

        if (IsInitializedInternally && IsInitializedExternally)
        {
            if (!UnitReference.IsAlive && this.transform.localPosition != m_invalidPosition)
                this.transform.localPosition = m_invalidPosition; //Send object out of screen
        }
    }

    private void Initialize()
    {
        try
        {
            if (m_mainScript == null)
                m_mainScript = this.transform.root.GetComponent<UnityBattleSystem_Multiplayer>();

            if (m_mainScript.IsInitialized)
            {
                Debug.Log("UnitController_Multiplayer: Start Initialization.");

                this.transform.parent = m_mainScript.Player.transform;

                if (this.transform.parent == null)
                {
                    Debug.Log("UnitController_Multiplayer: parent object not set");
                    return;
                }


                //if (!LoadSprites())
                //{
                //    Debug.Log("UnitController_SinglePlayer: error at LoadSprites()");
                //    return;
                //}

                if (!SetImages())
                {
                    Debug.Log("UnitController_Multiplayer: error at SetImages()");
                    return;
                }

                //if (!AdjustScale())
                //{
                //    Debug.Log("UnitController_SinglePlayer: error at AdjustScale()");
                //    return;
                //}

                //if (LocalPlayerIdentifier.PlayerController.PlayerId == 1)
                //    positionAdjustmentValue *= -1;

                IsInitializedInternally = true;
                Debug.Log("UnitController_Multiplayer: End Initialization.");
            }
        }
        catch (Exception ex)
        {
            Debug.Log("UnitController_SinglePlayer: at Initialize() " + ex.Message);
        }
    }

    public bool ExternalInitialization(int _publicIndex, int _privateIndex, int _ownerId, UnitInstance _unitReference, int _maxHP)
    {
        PublicIndex = _publicIndex;
        PrivateIndex = _privateIndex;
        OwnerId = _ownerId;
        UnitReference = _unitReference;

        MaxHP = _maxHP;

        if (_unitReference != null)
            IsInitializedExternally = true;

        return IsInitializedExternally;
    }

    //private bool AdjustScale()
    //{
    //    try
    //    {
    //        this.transform.localScale = m_mainScript.UnitScale;
    //        return AdjustCollider(); ;
    //    }
    //    catch (Exception ex)
    //    {
    //        Debug.Log("UnitController_SinglePlayer: at AdjustScale() " + ex.Message);
    //        return false;
    //    }
    //}

    //private bool AdjustCollider()
    //{
    //    try
    //    {
    //        collider.size = meshRenderer_frame.bounds.size;
    //        collider.offset = new Vector2(collider.size.x / 2, collider.size.y / 2);
    //        return true;
    //    }
    //    catch (Exception ex)
    //    {
    //        Debug.Log("UnitController_SinglePlayer: at AdjustCollider() " + ex.Message);
    //        return false;
    //    }
    //}

    //private bool LoadSprites()
    //{
    //    try
    //    {
    //        AnimationSprites = SpriteSplitter.SpriteToMultipleSprites(UnitSprites[UnitSpriteId - 1], NUM_COLUMNS, NUM_ROWS);

    //        if (AnimationSprites.Count != NUM_COLUMNS * NUM_ROWS)
    //            return false;

    //        return true;
    //    }
    //    catch (Exception ex)
    //    {
    //        Debug.Log("UnitController_SinglePlayer: at LoadSprites() " + ex.Message);
    //        return false;
    //    }
    //}

    private bool SetImages()
    {
        try
        {
            Shader defaultShader = Shader.Find("Sprites/Default");

            int rarityIndex = (Convert.ToInt32(this.UnitReference.BaseInfo.Rarity) / 20) - 1;
            m_meshRenderer_frame.material = MaterialContainer.Instance.RarityMaterials[rarityIndex];

            m_meshRenderer_unit.material.mainTexture = UnityImageConverter.ByteArrayToTexture(UnitReference.BaseInfo.IconAsBytes);
            m_meshRenderer_unit.material.shader = defaultShader;

            return true;
        }
        catch (Exception ex)
        {
            Debug.Log("UnitController_SinglePlayer.SetImages() " + ex.Message);
            return false;
        }
    }

    //public IEnumerator Request_SyncProperties()
    //{
    //    if (m_mainScript.IsInitialized)
    //    {
    //        if (UnitReference != null)
    //        {
    //            HasUnitDataBeenSynced = false;

    //            yield return StartCoroutine(UpdateUnitProperties());
    //        }
    //    }
    //}
    //IEnumerator UpdateUnitProperties()
    //{
    //    Dictionary<string, string> values = new Dictionary<string, string>
    //    {
    //        {"subject", "GetUnitProperties"},
    //        {"playerId", GameDataContainer.Instance.Player.Id.ToString()},
    //        {"unitIndex", PrivateIndex.ToString() }
    //    };

    //    UnityWebRequest uwr = UnityWebRequest.Post(CoreValues.SERVER_URL, values);
    //    yield return uwr.SendWebRequest();

    //    string errorMsg = string.Empty;

    //    if (uwr.isNetworkError)
    //        PopUpWindowManager.Instance.CreateSimplePopUp("Error!", "Connection Error: " + uwr.error + "\nPlease check your Internet connection.", "OK");
    //    else
    //    {
    //        ;
    //    }
    //}
}
