﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

[RequireComponent(typeof(Text))]
public class TurnTextManager_Multiplayer : MonoBehaviour
{
    #region Private Fields
    private const string myTurnText = "Your Turn!";
    private const string opponentTurnText = "Opponent's Turn!";

    private Text m_text;

    private UnityBattleSystem_Multiplayer m_mainScript;

    private bool m_isInitialized;
    #endregion

    // Awake is called before the Update for the first frame
    void Awake()
    {
        m_isInitialized = false;

        m_text = this.GetComponent<Text>();
    }

    // Update is called once per frame
    void Update()
    {
        if (!m_isInitialized)
            Initialize();

        if (m_isInitialized)
        {
            if (m_text.text != myTurnText && m_mainScript.PlayerController.IsMyTurn)
                m_text.text = myTurnText;
            else if (m_text.text != opponentTurnText && !m_mainScript.PlayerController.IsMyTurn)
                m_text.text = opponentTurnText;
        }
    }

    private void Initialize()
    {
        if (m_mainScript == null)
            m_mainScript = this.transform.root.GetComponent<UnityBattleSystem_Multiplayer>();
        if (m_mainScript == null)
            return;

        if (!m_mainScript.IsInitialized)
            return;

        m_isInitialized = true;
    }
}
