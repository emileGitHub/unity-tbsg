﻿using EEANGames;
using EEANGames.ExtensionMethods;
using EEANGames.TBSG._01.CommonEnums;
using EEANGames.TBSG._01.ExtensionMethods;
using EEANGames.TBSG._01.MainClassLib;
using EEANGames.TBSG._01.Unity.CommonEnums;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using UnityEngine.Networking;
using UnityEngine.UI;

public class TileMaskManager_Multiplayer : MonoBehaviour
{
    #region Serialized Fields
    public UnityEngine.Material DefaultMaterial;
    public UnityEngine.Material TargetingTile_Material_NonSelectable;
    public UnityEngine.Material TargetingTile_Material_Movement_Selectable;
    public UnityEngine.Material TargetingTile_Material_Attack_Selectable;
    public UnityEngine.Material TargetingTile_Material_Skill_Selectable;
    public UnityEngine.Material TargetingTile_Material_Movement_Selected;
    public UnityEngine.Material TargetingTile_Material_Attack_Selected;
    public UnityEngine.Material TargetingTile_Material_Skill_Selected;
    #endregion

    #region Properties
    public bool IsInitialized { get; private set; }
    #endregion

    #region Private Member Variables
    private const int m_sizeX = CoreValues.SIZE_OF_A_SIDE_OF_BOARD;
    private const int m_sizeZ = CoreValues.SIZE_OF_A_SIDE_OF_BOARD;

    private UnityBattleSystem_Multiplayer m_mainScript;
    private ActionUIManager_Multiplayer m_actionUIManager;
    private AnimationController_Multiplayer m_animationController;

    private List<MeshRenderer> m_tileMasks;
    private List<MeshRenderer> m_tileUpperMasks;

    private Dictionary<_2DCoord, eMaskType> m_targetArea; //bool represents selection status
    private int m_maxNumOfTargets;

    private bool m_wasMouseButton1Down;
    #endregion

    // Use this for initialization
    void Awake()
    {
        try
        {
            IsInitialized = false;

            m_tileMasks = new List<MeshRenderer>();
            m_tileUpperMasks = new List<MeshRenderer>();

            m_targetArea = new Dictionary<_2DCoord, eMaskType>();

            m_wasMouseButton1Down = false;
        }
        catch (Exception ex)
        {
            Debug.Log("TileMap: at Awake() " + ex.Message);
        }
    }

    void Update()
    {
        if (!IsInitialized)
            Initialize();

        if (IsInitialized)
            ManageMaskVisibility();
    }

    public void Initialize()
    {
        try
        {
            if (m_mainScript == null)
                m_mainScript = this.transform.root.GetComponent<UnityBattleSystem_Multiplayer>();
            if (m_mainScript == null)
                return;

            if (m_mainScript.IsInitialized)
            {
                Debug.Log("TileMaskManager_SinglePlayer: Start Initialize.");

                if (m_actionUIManager == null)
                    m_actionUIManager = GameObject.Find("Panel@ActionUI").GetComponent<ActionUIManager_Multiplayer>();
                if (m_actionUIManager == null)
                    return;

                if (m_animationController == null)
                    m_animationController = this.transform.root.GetComponent<AnimationController_Multiplayer>();
                if (m_animationController == null)
                    return;

                if (!InitializeMaterial())
                    return;

                IsInitialized = true;
                Debug.Log("TileMaskManager_SinglePlayer: End Initialize.");
            }
        }
        catch (Exception ex)
        {
            Debug.Log("TileMap: at Initialize() " + ex.Message);
        }
    }

    public void ChangeTileSelection(int _tileIndex) { ChangeTileSelection(_tileIndex.To2DCoord()); }

    public void ChangeTileSelection(_2DCoord _coord)
    {
        if (m_animationController.LockUI)
            return;

        if (_coord == null || !m_targetArea.ContainsKey(_coord))
            return;

        if (m_targetArea[_coord] == eMaskType.NonSelectable)
            return;

        if (m_targetArea[_coord] == eMaskType.Selected)
            m_targetArea[_coord] = eMaskType.Selectable;
        else if (m_targetArea.Values.Count(x => x == eMaskType.Selected) < m_maxNumOfTargets)
            m_targetArea[_coord] = eMaskType.Selected;

        SetMaterial(_coord);

        Debug.Log("SelectionStatusChanged: Tile " + _coord.ToIndex().ToString() + " -> " + m_targetArea[_coord].ToString());
        m_actionUIManager.UpdateConfirmationButton();
    }

    public int NumOfTilesSelected()
    {
        return m_targetArea.Count(x => x.Value == eMaskType.Selected);
    }

    public List<_2DCoord> SelectedCoords()
    {
        return m_targetArea.GetKeysWithValue(eMaskType.Selected);
    }

    private void SetMaterial(_2DCoord _coord)
    {
        int tileIndex = _coord.ToIndex();

        if (tileIndex < 0 || tileIndex >= m_tileMasks.Count || tileIndex >= m_tileUpperMasks.Count) return;

        MeshRenderer tileMask_meshRenderer = m_tileMasks[tileIndex];
        MeshRenderer tileUpperMask_meshRenderer = m_tileUpperMasks[tileIndex];

        if (!m_targetArea.ContainsKey(_coord)) return;

        eMaskType maskType = m_targetArea[_coord];
        if (maskType == eMaskType.NonSelectable)
        {
            tileMask_meshRenderer.material = TargetingTile_Material_NonSelectable;
            tileUpperMask_meshRenderer.material = DefaultMaterial;
        }
        else
        {
            switch (m_actionUIManager.CurrentActionSelected)
            {
                case eActionType.Move:
                    switch (maskType)
                    {
                        default: //NonSelectable
                            break;
                        case eMaskType.Selectable:
                            tileMask_meshRenderer.material = TargetingTile_Material_Movement_Selectable;
                            tileUpperMask_meshRenderer.material = DefaultMaterial;
                            break;
                        case eMaskType.Selected:
                            tileMask_meshRenderer.material = DefaultMaterial;
                            tileUpperMask_meshRenderer.material = TargetingTile_Material_Movement_Selected;
                            break;
                    }
                    break;
                case eActionType.Attack:
                    switch (maskType)
                    {
                        default: //NonSelectable
                            break;
                        case eMaskType.Selectable:
                            tileMask_meshRenderer.material = TargetingTile_Material_Attack_Selectable;
                            tileUpperMask_meshRenderer.material = DefaultMaterial;
                            break;
                        case eMaskType.Selected:
                            tileMask_meshRenderer.material = DefaultMaterial;
                            tileUpperMask_meshRenderer.material = TargetingTile_Material_Attack_Selected;
                            break;
                    }
                    break;
                case eActionType.Skill:
                    switch (maskType)
                    {
                        default: //NonSelectable
                            break;
                        case eMaskType.Selectable:
                            tileMask_meshRenderer.material = TargetingTile_Material_Skill_Selectable;
                            tileUpperMask_meshRenderer.material = DefaultMaterial;
                            break;
                        case eMaskType.Selected:
                            tileMask_meshRenderer.material = DefaultMaterial;
                            tileUpperMask_meshRenderer.material = TargetingTile_Material_Skill_Selected;
                            break;
                    }
                    break;
                default:
                    break;
            }
        }
    }

    public void UpdateMaxNumOfTargets(int _maxNumOfTargets)
    {
        if (_maxNumOfTargets < 0)
            m_maxNumOfTargets = 0;
        else
            m_maxNumOfTargets = _maxNumOfTargets;
    }

    public void UpdateTargetArea(Dictionary<_2DCoord, bool> _targetArea)
    {
        m_targetArea.Clear();

        if (_targetArea != null)
        {
            foreach (var tile in _targetArea)
            {
                m_targetArea.Add(tile.Key, (tile.Value ? eMaskType.Selectable : eMaskType.NonSelectable));
            }
        }
    }

    public void DisplayTargetArea()
    {
        ResetMaterial();

        UpdateTargetingMaterial();
    }

    private bool InitializeMaterial()
    {
        try
        {
            if (!IsInitialized)
            {
                m_tileMasks.Clear();
                m_tileUpperMasks.Clear();

                for (int z = 1; z <= m_sizeZ; z++)
                {
                    for (int x = 1; x <= m_sizeX; x++)
                    {
                        int tileNum = m_sizeZ * (z - 1) + (x - 1);

                        string tileObjectName = "Tile" + tileNum.ToString();

                        Transform tile = this.transform.Find(tileObjectName);
                        MeshRenderer tileMaskMeshRenderer = tile.Find("Mask" + tileNum.ToString()).GetComponent<MeshRenderer>();
                        MeshRenderer tileUpperMaskMeshRenderer = tile.Find("UpperMask" + tileNum.ToString()).GetComponent<MeshRenderer>();

                        m_tileMasks.Add(tileMaskMeshRenderer);
                        m_tileUpperMasks.Add(tileUpperMaskMeshRenderer);
                    }
                }
                if (m_tileMasks.Count != m_sizeX * m_sizeZ)
                    return false;
            }

            ResetMaterial();

            return true;
        }
        catch (Exception ex)
        {
            Debug.Log("TileMap: at ResetMaterial(). " + ex.Message);
            return false;
        }
    }

    private void ResetMaterial()
    {
        foreach (MeshRenderer mr in m_tileMasks) { mr.material = DefaultMaterial; }
        foreach (MeshRenderer mr in m_tileUpperMasks) { mr.material = DefaultMaterial; }
    }

    private bool UpdateTargetingMaterial()
    {
        try
        {
            if (m_targetArea == null)
                return false;

            foreach (_2DCoord coord in m_targetArea.Keys)
            {
                if (coord.X >= 0 && coord.Y < m_sizeX
                    && coord.Y >= 0 && coord.Y < m_sizeZ)
                {
                    SetMaterial(coord);
                }
            }

            return true;
        }
        catch (Exception ex)
        {
            Debug.Log("TileMap: at UpdateTargetingMaterial(). " + ex.Message);
            return false;
        }
    }

    private void ManageMaskVisibility()
    {
        try
        {
            if (Input.GetMouseButtonDown(1) && !m_wasMouseButton1Down)
            {
                foreach (MeshRenderer tileMask in m_tileMasks) { tileMask.enabled = false; }
                foreach (MeshRenderer tileUpperMask in m_tileUpperMasks) { tileUpperMask.enabled = false; }
                m_wasMouseButton1Down = true;
            }
            else if (Input.GetMouseButtonUp(1) && m_wasMouseButton1Down)
            {
                foreach (MeshRenderer tileMask in m_tileMasks) { tileMask.enabled = true; }
                foreach (MeshRenderer tileUpperMask in m_tileUpperMasks) { tileUpperMask.enabled = true; }
                m_wasMouseButton1Down = false;
            }
        }
        catch (Exception ex)
        {
            Debug.Log("TileMask: at AdjustMaskTransparency(). " + ex.Message);
        }
    }
}