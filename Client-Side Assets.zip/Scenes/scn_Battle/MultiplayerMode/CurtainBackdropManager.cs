﻿//using System;
//using System.Collections;
//using System.Collections.Generic;
//using UnityEngine;
//using UnityEngine.UI;

//public class CurtainBackdropManager : MonoBehaviour {

//    private UnityBattleSystem mainScript;
//    private LocalPlayerIdentifier localPlayerIdentifierScript;
//    private TileMapManager tileMapScript;
//    private List<UnitController> unitControllerScripts;

//    // Use this for initialization
//    void Awake () {
//        try
//        {
//            unitControllerScripts = new List<UnitController>();
//        }
//        catch (Exception ex)
//        {
//            Debug.Log("CurtainBackdropManager: at Awake() " + ex.Message);
//        }
//    }
	
//	// Update is called once per frame
//	void Update () {
//        try
//        {
//            if (mainScript == null)
//                mainScript = GameObject.Find("BattleSystemController").GetComponent<UnityBattleSystem>();

//            if (mainScript.isInitialized)
//            {
//                LoadComponents();

//                if (AreAllComponentsInitialized())
//                    StartCoroutine(RemoveThis());
//            }
//        }
//        catch(Exception ex)
//        {
//            Debug.Log("CurtainBackdropManager: at Update() " + ex.Message);
//        }
//	}

//    private void LoadComponents()
//    {
//        try
//        {
//            if (localPlayerIdentifierScript == null)
//                localPlayerIdentifierScript = GameObject.Find("LocalPlayerIdentifier").GetComponent<LocalPlayerIdentifier>();

//            if (tileMapScript == null)
//                tileMapScript = GameObject.Find("TBSGBoard").GetComponent<TileMapManager>();

//            if (unitControllerScripts.Count < 1)
//            {
//                GameObject[] units = GameObject.FindGameObjectsWithTag("Unit");
//                foreach (GameObject unit in units)
//                {
//                    unitControllerScripts.Add(unit.GetComponent<UnitController>());
//                }
//            }
//        }
//        catch (Exception ex)
//        {
//            Debug.Log("CurtainBackdropManager: at LoadComponents() " + ex.Message);
//        }
//    }

//    private bool AreAllComponentsInitialized()
//    {
//        try
//        {
//            if (localPlayerIdentifierScript.isInitialized
//            && tileMapScript.isInitialized)
//            {
//                foreach (UnitController uc in unitControllerScripts)
//                {
//                    if (!uc.isInitialized)
//                        return false;
//                }

//                return true;
//            }
//            //else
//            return false;
//        }
//        catch (Exception ex)
//        {
//            Debug.Log("CurtainBackdropManager: at AreAllComponentsInitialized() " + ex.Message);
//            return false;
//        }
//    }

//    private IEnumerator RemoveThis()
//    {
//        Transform loadingStatus = this.transform.Find("LoadingStatus");
//        Text textComponent = loadingStatus.GetComponent<Text>();

//        textComponent.text = "End of Initialization";
//        yield return new WaitForSeconds(2f);
//        textComponent.text = "The Battle Begins!";
//        yield return new WaitForSeconds(2f);

//        loadingStatus.gameObject.SetActive(false);

//        Transform leftHalf = this.transform.Find("LeftHalf");
//        Transform rightHalf = this.transform.Find("RightHalf");

//        float myPositionX = this.transform.position.x;
//        float canvasSize = this.GetComponent<RectTransform>().rect.width;

//        while (true)
//        {
//            leftHalf.transform.position -= new Vector3(1, 0, 0);
//            rightHalf.transform.position += new Vector3(1, 0, 0);
//            yield return new WaitForSecondsRealtime(0.01f);

//            if (leftHalf.transform.position.x < (myPositionX - (canvasSize / 2)))
//                break;
//        }

//        this.gameObject.SetActive(false);
//    }
//}
