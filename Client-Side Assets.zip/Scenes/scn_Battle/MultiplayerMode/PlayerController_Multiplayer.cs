﻿using EEANGames.TBSG._01.MainClassLib;
using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Networking;

public class PlayerController_Multiplayer : MonoBehaviour
{
    #region Properties
    public PlayerOnBoard PlayerData { get; set; }

    public int PlayerId { get; private set; }

    public bool IsMyTurn { get; private set; }

    public bool HasMoved { get; private set; }
    public bool HasAttacked { get; private set; }
    public bool HasUsedUltimateSkill { get; private set; }

    public int MaxSP { get; private set; }
    public int RemainingSP { get; private set; }
    public int SelectedAlliedUnitId { get; private set; }

    public bool IsInitialized { get; private set; }
    #endregion

    #region Private Fields
    private UnityBattleSystem_Multiplayer m_mainScript;

    private bool m_isIdProvided;
    private bool m_isCameraRotationAdjusted;
    #endregion

    // Use this for initialization
    void Awake()
    {
        try
        {
            Debug.Log("PlayerController: Awake");
            IsInitialized = false;
            m_isIdProvided = false;
            m_isCameraRotationAdjusted = false;
        }
        catch (Exception ex)
        {
            Debug.Log("PlayerController: at Awake() " + ex.Message);
        }
    }

    private void Update()
    {
        if (!IsInitialized)
            Initialize();

        if (m_isIdProvided && !m_isCameraRotationAdjusted)
        {
            if (PlayerId == 2) // If Player 2
                m_isCameraRotationAdjusted = SetPlayer2CameraPosition();
            else m_isCameraRotationAdjusted = true; // No need to adjust rotation if Player 1
        }
    }

    private void Initialize()
    {
        try
        {
            Debug.Log("PlayerController: Start Initialization.");

            if (m_mainScript == null)
                m_mainScript = this.transform.root.GetComponent<UnityBattleSystem_Multiplayer>();
            if (m_mainScript == null)
                return;

            PlayerData = null;

            IsInitialized = true;
        }
        catch (Exception ex)
        {
            Debug.Log("PlayerController: at Initialize() " + ex.Message);
        }
    }

    public IEnumerator Request_SyncProperties(int _initializingId = -1)
    {
        if (!m_isIdProvided)
        {
            if (_initializingId != -1)
            {
                PlayerId = _initializingId;
                m_isIdProvided = true;
            }
            else
                yield break;
        }

        if (m_mainScript.IsInitialized)
        {
            if (PlayerData != null)
            {
                yield return StartCoroutine(SyncProperies());
            }
        }
    }

    IEnumerator SyncProperies()
    {
        yield return StartCoroutine(m_mainScript.Request_UpdatePlayerInfo());

        PlayerInfo playerInfo = m_mainScript.PlayerInfo;

        IsMyTurn = playerInfo.IsMyTurn;

        HasMoved = playerInfo.HasMoved;
        HasAttacked = playerInfo.HasAttacked;
        HasUsedUltimateSkill = playerInfo.HasUsedUltimateSkill;

        MaxSP = playerInfo.MaxSP;
        RemainingSP = playerInfo.RemainingSP;
        SelectedAlliedUnitId = playerInfo.SelectedAlliedUnitId;
    }

    private bool SetPlayer2CameraPosition()
    {
        try
        {
            GameObject boardSet = GameObject.FindGameObjectWithTag("GameBoard");
            Transform board = boardSet.transform.Find("Board");

            Debug.Log("PlayerController: Set Camera Position for Player 2");

            GameObject mc = GameObject.Find("Main Camera");
            Vector3 mcPosition = mc.transform.position;
            Vector3 mcOriginalAngles = mc.transform.rotation.eulerAngles;

            MeshRenderer boardMR = board.GetComponent<MeshRenderer>();
            Vector3 boardCenter = boardMR.bounds.center;

            mc.transform.RotateAround(boardCenter, new Vector3(0, 1f, 0), 180f); // Rotate camera based on board's y axis.

            Debug.Log("PlayerController: End InitializeExplicit (For Player2)");
            return true;
        }
        catch (Exception ex)
        {
            Debug.Log("PlayerController: at SetPlayer2CameraPosition() " + ex.Message);
            return false;
        }
    }
}

public struct PlayerInfo
{
    public bool IsMyTurn;

    public bool HasMoved;
    public bool HasAttacked;
    public bool HasUsedUltimateSkill;

    public int MaxSP;
    public int RemainingSP;
    public int SelectedAlliedUnitId;
}
