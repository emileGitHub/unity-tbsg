﻿//using System.Collections;
//using System.Collections.Generic;
//using UnityEngine;

//public class DamageTextManager : MonoBehaviour {

//    public TextMesh MyTextMesh;
//    public float Velocity;
//    public float LifeSpan;
//    private float startTime;

//    private LocalPlayerIdentifier LocalPlayerIdentifier;

//	// Use this for initialization
//	void Awake () {
//        MyTextMesh = this.GetComponent<TextMesh>();
//        startTime = Time.realtimeSinceStartup;

//        LocalPlayerIdentifier = GameObject.Find("LocalPlayerIdentifier").GetComponent<LocalPlayerIdentifier>();
//        if (LocalPlayerIdentifier.PlayerController.PlayerId == 2)
//            this.transform.Rotate(0, 180f, 0);
//	}
	
//	// Update is called once per frame
//	void Update () {
//        if (Time.realtimeSinceStartup <= startTime + LifeSpan)
//            this.transform.localPosition += new Vector3(0, Velocity);
//        else
//            Destroy(this.gameObject);
//	}
//}
