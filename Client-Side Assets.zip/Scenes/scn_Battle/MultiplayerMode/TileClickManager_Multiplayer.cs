﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[RequireComponent(typeof(MeshCollider))]
public class TileClickManager_SinglePlayer : MonoBehaviour {

    #region Private Member Variables
    private TileMaskManager_SinglePlayer m_tileMaskManager;

    private InfoPanelManager_SinglePlayer m_infoPanelManager_Central;

    private bool m_isInitialized;
    #endregion

    // Use this for initialization
    void Awake () {
        m_isInitialized = false;

        m_tileMaskManager = GameObject.FindGameObjectWithTag("GameBoard").GetComponent<TileMaskManager_SinglePlayer>();

        m_infoPanelManager_Central = this.transform.root.GetComponent<InfoPanelManager_SinglePlayer>();
    }

    // Update is called once per frame
    void Update () {
        if (!m_isInitialized)
            Initialize();
	}

    private void Initialize()
    {
        if (m_tileMaskManager.IsInitialized && m_infoPanelManager_Central.IsInitialized)
            m_isInitialized = true;
    }

    private void OnMouseDown()
    {
        try
        {
            if(m_isInitialized)
            {
                if (m_infoPanelManager_Central.InfoPanels.Count < 1)
                {
                    string tileIdString = this.name.Remove(0, 4); //Remove "Mask" from the name of this gameobject.
                    int tileId = Convert.ToInt32(tileIdString);
                    Debug.Log("Tile" + tileIdString + " Clicked");
                    m_tileMaskManager.ChangeTileSelection(tileId);
                }
            }
        }
        catch(Exception ex)
        {
            Debug.Log("TileClickManager.OnMouseDown() : " + ex.Message);
        }
    }
}
