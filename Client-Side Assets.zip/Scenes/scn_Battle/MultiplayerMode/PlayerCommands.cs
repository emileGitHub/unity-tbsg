﻿//using EEANGames.TBSG._01.CommonEnums;
//using EEANGames.TBSG._01.MainClassLib;
//using System.Collections;
//using System.Collections.Generic;
//using UnityEngine;
//using UnityEngine.Networking;

//public class PlayerCommands : NetworkBehaviour {

//    private GameObject battleSystemController;
//    private UnityBattleSystem mainScript;

//    private bool isInitialized;

//    // Awake is called before Update for the first frame
//    void Awake()
//    {
//        isInitialized = false;
//    }

//    void Update()
//    {
//        if (!isInitialized)
//            Initialize();
//    }

//    private void Initialize()
//    {
//        if (battleSystemController == null)
//            battleSystemController = GameObject.Find("BattleSystemController");
//        else if (battleSystemController != null && mainScript == null)
//        {
//            mainScript = battleSystemController.GetComponent<UnityBattleSystem>();

//            if (mainScript != null)
//                isInitialized = true;
//        }
//    }

//    [Command]
//    public void Cmd_MoveUnit(eDirection _direction)
//    {
//        if(isInitialized)
//            mainScript.MoveUnit(_direction);
//    }
//    [Command]
//    public void Cmd_Attack()
//    {
//        if (isInitialized)
//            mainScript.Attack();
//    }
//    [Command]
//    public void Cmd_Skill(string _skillName)
//    {
//        if (isInitialized)
//            mainScript.Skill(_skillName);
//    }
//    //[Command]
//    //public void Cmd_LongRangeAttack()
//    //{
//    //    if (IsInitialized)
//    //        mainScript.LongRangeAttack();
//    //}
//    //[Command]
//    //public void Cmd_OmniDirectionalAttack()
//    //{
//    //    if (IsInitialized)
//    //        mainScript.OmniDirectionalAttack();
//    //}
//    [Command]
//    public void Cmd_ChangeUnit(int _playerId, int _unitId)
//    {
//        if (isInitialized)
//        {
//                mainScript.ChangeUnit(_playerId, _unitId);
//        }
//    }

//    [Command]
//    public void Cmd_RequestMovableArea(int _playerId, int _unitId)
//    {
//        if (isInitialized)
//            mainScript.UpdateMovableArea(_playerId, _unitId);
//    }

//    [Command]
//    public void Cmd_RequestAttackTargetArea(int _playerId, int _unitId)
//    {
//        if (isInitialized)
//            mainScript.UpdateAttackTargetArea(_playerId, _unitId);
//    }

//    [Command]
//    public void Cmd_DisplaySkillTargetArea(int _playerId, int _unitId, int _skillIndex)
//    {
//        if (isInitialized)
//            mainScript.DisplaySkillTargetArea(_playerId, _unitId, _skillIndex);
//    }

//    [Command]
//    public void Cmd_RequestSkillCost(int _playerId, int _unitId, string _skillName)
//    {
//        if (isInitialized)
//            mainScript.RequestSkillCost(_playerId, _unitId, _skillName);
//    }


//    [Command]
//    public void Cmd_UnselectUnits(int _playerId)
//    {
//        if (isInitialized)
//            mainScript.UnselectUnits(_playerId);
//    }

//    [Command]
//    public void Cmd_EndTurn()
//    {
//        if (isInitialized)
//            mainScript.ChangeTurn();
//    }

//    [Command]
//    public void Cmd_Concede()
//    {
//        if (isInitialized)
//            mainScript.Concede();
//    }
//}
