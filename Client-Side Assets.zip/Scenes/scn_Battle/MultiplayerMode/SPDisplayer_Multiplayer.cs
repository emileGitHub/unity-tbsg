﻿using EEANGames.TBSG._01.MainClassLib;
using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SPDisplayer_Multiplayer : MonoBehaviour
{

    public UnityEngine.Material ActiveStoneMaterial;
    public UnityEngine.Material InactiveStoneMaterial;

    private bool m_isInitialized;
    private UnityBattleSystem_Multiplayer m_mainScript;

    private MeshRenderer[][] m_spObjectsMR;

    private int[] m_latestRemainingSP;
    private int[] m_latestMaxSP;

    // Awake is called before Update for the first frame
    void Awake()
    {
        m_isInitialized = false;
    }

    // Update is called once per frame
    void Update()
    {
        if (!m_isInitialized)
            Initialize();

        //TryUpdateSPGraphic()
    }

    private void Initialize()
    {
        try
        {
            if (m_mainScript == null)
                m_mainScript = this.transform.root.GetComponent<UnityBattleSystem_Multiplayer>();

            if (m_mainScript.IsInitialized
                && !m_isInitialized)
            {
                m_spObjectsMR = new MeshRenderer[2][]; // Fpr the two players
                m_latestRemainingSP = new int[m_spObjectsMR.Length];
                m_latestMaxSP = new int[m_spObjectsMR.Length];

                if (m_mainScript.PlayerController.IsInitialized)
                {
                    //Initialize SP info for Player
                    int playerIndex = (m_mainScript.PlayerController.PlayerId == 1) ? 0 : 1;
                    m_latestMaxSP[playerIndex] = m_mainScript.PlayerController.MaxSP;
                    m_latestRemainingSP[playerIndex] = m_mainScript.PlayerController.RemainingSP;

                    m_spObjectsMR[playerIndex] = new MeshRenderer[CoreValues.MAX_SP];
                    for (int j = 0; j < m_spObjectsMR[playerIndex].Length; j++)
                    {
                        m_spObjectsMR[playerIndex][j] = this.transform.Find("SkillStone" + m_mainScript.PlayerController.PlayerId.ToString() + "_" + (j + 1).ToString()).GetComponent<MeshRenderer>();
                    }

                    //Initialize SP info for Opponent
                    int opponentIndex = (m_mainScript.PlayerController.PlayerId == 1) ? 1 : 0;
                    m_latestMaxSP[opponentIndex] = m_mainScript.Opponent_MaxSP;
                    m_latestRemainingSP[opponentIndex] = m_mainScript.PlayerController.RemainingSP;

                    m_spObjectsMR[opponentIndex] = new MeshRenderer[CoreValues.MAX_SP];
                    for (int j = 0; j < m_spObjectsMR[opponentIndex].Length; j++)
                    {
                        m_spObjectsMR[opponentIndex][j] = this.transform.Find("SkillStone" + (opponentIndex + 1).ToString() + "_" + (j + 1).ToString()).GetComponent<MeshRenderer>();
                    }

                    UpdateSPGraphic(playerIndex);
                    UpdateSPGraphic(opponentIndex);

                    m_isInitialized = true;
                }
            }
        }
        catch (Exception ex)
        {
            Debug.Log("SPTextManager: at Initialize() " + ex.Message);
        }
    }

    public IEnumerator Request_UpdateSPGraphic()
    {
        if (m_isInitialized)
        {
            //Update SP Graphic for player
            int playerIndex = (m_mainScript.PlayerController.PlayerId == 1) ? 0 : 1;

            yield return StartCoroutine(m_mainScript.PlayerController.Request_SyncProperties());

            if (m_mainScript.PlayerController.MaxSP != m_latestMaxSP[playerIndex]
                || m_mainScript.PlayerController.RemainingSP != m_latestRemainingSP[playerIndex])
            {
                m_latestMaxSP[playerIndex] = m_mainScript.PlayerController.MaxSP;
                m_latestRemainingSP[playerIndex] = m_mainScript.PlayerController.RemainingSP;
            }

            //Update SP Graphic for opponent
            int opponentIndex = (m_mainScript.PlayerController.PlayerId == 1) ? 1 : 0;

            yield return StartCoroutine(m_mainScript.Request_UpdateOpponentInfo());

            if (m_mainScript.Opponent_MaxSP != m_latestMaxSP[opponentIndex]
                || m_mainScript.Opponent_RemainingSP != m_latestRemainingSP[opponentIndex])
            {
                m_latestMaxSP[opponentIndex] = m_mainScript.Opponent_MaxSP;
                m_latestRemainingSP[opponentIndex] = m_mainScript.Opponent_RemainingSP;
            }

            UpdateSPGraphic(playerIndex);
            UpdateSPGraphic(opponentIndex);
        }
    }
    private void UpdateSPGraphic(int _index)
    {
        for (int i = 0; i < m_latestRemainingSP[_index]; i++)
        {
            m_spObjectsMR[_index][i].material = ActiveStoneMaterial;
        }

        for (int i = m_latestRemainingSP[_index]; i < m_spObjectsMR[_index].Length; i++)
        {
            m_spObjectsMR[_index][i].material = InactiveStoneMaterial;
        }
    }
}
