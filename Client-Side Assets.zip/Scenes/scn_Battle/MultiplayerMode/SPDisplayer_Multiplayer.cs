﻿using EEANGames.TBSG._01.MainClassLib;
using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SPDisplayer_Multiplayer : MonoBehaviour
{

    public UnityEngine.Material ActiveStoneMaterial;
    public UnityEngine.Material InactiveStoneMaterial;

    private bool m_isInitialized;
    private UnityBattleSystem_Multiplayer m_mainScript;

    private MeshRenderer[][] m_spObjectsMR;

    private int[] m_latestRemainingSP;
    private int[] m_latestMaxSP;

    // Use this for initialization
    void Awake()
    {
        m_isInitialized = false;
    }

    // Update is called once per frame
    void Update()
    {
        if (!m_isInitialized)
            Initialize();

        //TryUpdateSPGraphic()
    }

    private void Initialize()
    {
        try
        {
            if (m_mainScript == null)
                m_mainScript = this.transform.root.GetComponent<UnityBattleSystem_Multiplayer>();

            if (m_mainScript.IsInitialized
                && !m_isInitialized)
            {
                m_spObjectsMR = new MeshRenderer[2][]; // Fpr the two players
                m_latestRemainingSP = new int[m_spObjectsMR.Length];
                m_latestMaxSP = new int[m_spObjectsMR.Length];

                if (m_mainScript.PlayerController.IsInitialized)
                {
                    //Initialize SP info for Player
                    int playerIndex = (m_mainScript.PlayerController.PlayerId == 1) ? 0 : 1;
                    m_latestMaxSP[playerIndex] = m_mainScript.PlayerController.MaxSP;
                    m_latestRemainingSP[playerIndex] = m_mainScript.PlayerController.RemainingSP;

                    m_spObjectsMR[playerIndex] = new MeshRenderer[CoreValues.MAX_SP];
                    for (int j = 0; j < m_spObjectsMR[playerIndex].Length; j++)
                    {
                        m_spObjectsMR[playerIndex][j] = this.transform.Find("SkillStone" + m_mainScript.PlayerController.PlayerId.ToString() + "_" + (j + 1).ToString()).GetComponent<MeshRenderer>();
                    }

                    //Initialize SP info for Opponent
                    int opponentIndex = (m_mainScript.PlayerController.PlayerId == 1) ? 1 : 0;
                    m_latestMaxSP[opponentIndex] = m_mainScript.Opponent_MaxSP;
                    m_latestRemainingSP[opponentIndex] = m_mainScript.PlayerController.RemainingSP;

                    m_spObjectsMR[opponentIndex] = new MeshRenderer[CoreValues.MAX_SP];
                    for (int j = 0; j < m_spObjectsMR[opponentIndex].Length; j++)
                    {
                        m_spObjectsMR[opponentIndex][j] = this.transform.Find("SkillStone" + (opponentIndex + 1).ToString() + "_" + (j + 1).ToString()).GetComponent<MeshRenderer>();
                    }

                    UpdateSPGraphic(playerIndex);
                    UpdateSPGraphic(opponentIndex);

                    m_isInitialized = true;
                }
            }
        }
        catch (Exception ex)
        {
            Debug.Log("SPTextManager: at Initialize() " + ex.Message);
        }
    }

    public void TryUpdateSPGraphic()
    {
        if (m_isInitialized)
        {
            //Update SP Graphic for player
            int playerIndex = (m_mainScript.PlayerController.PlayerId == 1) ? 0 : 1;
            if (m_mainScript.PlayerController.MaxSP != m_latestMaxSP[playerIndex]
                || m_mainScript.PlayerController.RemainingSP != m_latestRemainingSP[playerIndex])
            {
                m_latestMaxSP[playerIndex] = m_mainScript.PlayerController.MaxSP;
                m_latestRemainingSP[playerIndex] = m_mainScript.PlayerController.RemainingSP;

                UpdateSPGraphic(playerIndex);
            }

            //Update SP Graphic for 

        }
    }

    private void UpdateSPGraphic(int _index)
    {
        for (int i = 0; i < m_latestRemainingSP[_index]; i++)
        {
            m_spObjectsMR[_index][i].material = ActiveStoneMaterial;
        }

        for (int i = m_latestRemainingSP[_index]; i < m_spObjectsMR[_index].Length; i++)
        {
            m_spObjectsMR[_index][i].material = InactiveStoneMaterial;
        }
    }
}
