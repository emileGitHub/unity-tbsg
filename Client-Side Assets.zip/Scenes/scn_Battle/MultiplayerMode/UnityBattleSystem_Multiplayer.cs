﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using EEANGames.TBSG._01.MainClassLib;
using UnityEngine.Networking;
using EEANGames.TBSG._01.CommonEnums;
using System;
using UnityEngine.UI;
using System.Linq;
using EEANGames;
using EEANGames.ExtensionMethods;
using Assets.Resources.CommonScripts;
using UnityEditor;
using EEANGames.UnityEngine.ExtensionMethods;
using EEANGames.TBSG._01.Unity;

[RequireComponent(typeof(AnimationController_Multiplayer))]
public class UnityBattleSystem_Multiplayer : MonoBehaviour
{
    #region Serialized Field
    public GameObject PlayerUnitPrefab;
    public GameObject OpponentUnitPrefab;
    #endregion

    #region Properties
    public IList<EventLog> EventLogs { get { return m_eventLogs.AsReadOnly(); } }

    public GameObject Player { get; private set; }
    public GameObject Opponent { get; private set; }

    public List<GameObject> Units { get; private set; }
    public List<GameObject> PlayerUnits { get; private set; }
    public List<GameObject> OpponentUnits { get; private set; }

    public PlayerController_Multiplayer PlayerController { get; private set; }

    public string Opponent_Name { get; private set; }
    public int Opponent_MaxSP { get; private set; }
    public int Opponent_RemainingSP { get; private set; }
    public List<OpponentUnitInfo> OpponentUnitInfos { get; private set; }
    public bool HasOpponentInfoBeenLoaded { get; private set; }

    public PlayerInfo PlayerInfo { get; private set; }
    public bool HasPlayerInfoBeenLoaded { get; private set; }

    public eTileType[,] TileMap { get; private set; }

    public bool IsInitialized { get; private set; }
    #endregion

    #region Private Fields
    private AnimationController_Multiplayer m_animationController;

    private TileMaskManager_Multiplayer m_tileMaskManager;
    private GameObject m_gameBoardSet;
    private Transform m_baseTile;
    private Vector2 m_tileSize;

    private List<EventLog> m_eventLogs;

    private Dictionary<int, _2DCoord> m_initialUnitPositions;
    private Dictionary<int, int> m_playerUnitIdAndIndexMapping;

    private Dictionary<_2DCoord, bool> m_targetableAndSelectableArea;
    private int m_maxNumOfTargets;

    private bool m_isGettingMissingEventLogs;

    private bool m_arePlayersSet;
    private bool m_isPlayerDataSet;
    private bool m_isOpponentDataSet;
    private bool m_isTileMapSet;
    private bool m_areUnitsSet;
    private bool m_isInitializing;
    #endregion

    // Use this for Initialization of simple properties
    void Awake()
    {
        HasPlayerInfoBeenLoaded = false;

        m_isGettingMissingEventLogs = false;

        IsInitialized = false;
        m_arePlayersSet = false;
        m_isPlayerDataSet = false;
        m_isOpponentDataSet = false;
        m_isTileMapSet = false;
        m_areUnitsSet = false;
        m_isInitializing = false;

        m_animationController = this.GetComponent<AnimationController_Multiplayer>();
        m_gameBoardSet = GameObject.FindGameObjectWithTag("GameBoard");
        m_tileMaskManager = m_gameBoardSet.GetComponent<TileMaskManager_Multiplayer>();
        m_baseTile = m_gameBoardSet.transform.Find("Tile0");
        MeshRenderer mr = m_baseTile.GetComponent<MeshRenderer>();
        m_tileSize = new Vector2(mr.bounds.size.x, mr.bounds.size.z);

        m_eventLogs = new List<EventLog>();

        m_initialUnitPositions = new Dictionary<int, _2DCoord>();
        m_playerUnitIdAndIndexMapping = new Dictionary<int, int>();
        m_targetableAndSelectableArea = new Dictionary<_2DCoord, bool>();

        Units = new List<GameObject>();
        PlayerUnits = new List<GameObject>();
        OpponentUnits = new List<GameObject>();

        OpponentUnitInfos = new List<OpponentUnitInfo>();
    }

    // Use this for detailed initialization
    // Update() is being used to make sure that all Player Instances are created before the detailed initialization
    void Update()
    {
        if (!IsInitialized && !m_isInitializing)
            Initialize();
    }

    // Called once per frame
    private void FixedUpdate()
    {
        if (!m_isGettingMissingEventLogs)
        {
            m_isGettingMissingEventLogs = true;
            StartCoroutine(GetMissingEventLogs());
        }
    }

    private void Initialize()
    {
        try
        {
            Debug.Log("BattleSystem_Multiplayer: Start Initialization.");

            if (!m_arePlayersSet)
            {
                if (Player == null)
                    Player = GameObject.Find("Player");
                if (Player == null)
                    return;

                if (Opponent == null)
                    Opponent = GameObject.Find("Opponent");
                if (Opponent == null)
                    return;

                PlayerController = Player.GetComponent<PlayerController_Multiplayer>();
                if (PlayerController == null || !PlayerController.IsInitialized)
                    return;

                m_arePlayersSet = true;
            }

            StartCoroutine(GetMatchInfoAndInitialize());
        }
        catch (Exception ex)
        {
            Debug.Log("BattleSystem_Multiplayer: at Initialize()" + ex.Message);
        }
    }

    IEnumerator GetMatchInfoAndInitialize()
    {
        m_isInitializing = true;

        Dictionary<string, string> values = new Dictionary<string, string>
        {
            {"subject", "GetMatchInfo"},
            {"playerId", GameDataContainer.Instance.Player.Id.ToString()}
        };

        UnityWebRequest uwr = UnityWebRequest.Post(CoreValues.SERVER_URL, values);
        yield return uwr.SendWebRequest();

        Debug.Log("WebRequest Sent");

        string errorMsg = string.Empty;

        if (uwr.isNetworkError)
            errorMsg = "Connection Error: " + uwr.error + "\nPlease check your Internet connection.";
        else
        {
            string response = uwr.downloadHandler.text;
            string responseCopy = String.Copy(response);

            string sectionString = string.Empty;

            #region Load Player Data
            if (!m_isPlayerDataSet)
            {
                // Get instance of PlayerOnBoard
                responseCopy.DettachPortionFromString("<Player>", "</Player>", ref sectionString);
                PlayerOnBoard pob = ResponseStringToPlayerOnBoard(sectionString);

                // Clear the dictionary to link each player unit's Id and Index
                m_playerUnitIdAndIndexMapping.Clear();

                // Get the data of player's units and map the unique Ids to the unit indexes
                sectionString.DettachPortionFromString("<Units>", "</Units>", ref sectionString);
                sectionString = DataLoader.RemoveOpeningAndClosingTags(sectionString, "Units");
                string playerUnitString = string.Empty;
                while (sectionString != "")
                {
                    sectionString = sectionString.DettachPortionFromString("<Unit>", "</Unit>", ref playerUnitString);

                    string idString = string.Empty;
                    playerUnitString.DettachPortionFromString("<UniqueId>", "</UniqueId>", ref idString);
                    idString = DataLoader.RemoveOpeningAndClosingTags(idString, "UniqueId");
                    int id = Convert.ToInt32(idString);

                    string indexString = string.Empty;
                    playerUnitString.DettachPortionFromString("<Index>", "</Index>", ref indexString);
                    indexString = DataLoader.RemoveOpeningAndClosingTags(indexString, "Index");
                    int index = Convert.ToInt32(indexString);

                    m_playerUnitIdAndIndexMapping.Add(id, index);
                }

                // Set player data
                PlayerController.PlayerData = pob;

                // Get player Id and sync the properties from pob
                int playerId = pob.IsPlayer1 ? 1 : 2;
                yield return StartCoroutine(PlayerController.Request_SyncProperties(playerId));

                m_isPlayerDataSet = true;
            }
            #endregion

            #region Load Opponent Data
            if (!m_isOpponentDataSet)
            {
                string opponentString = string.Empty;
                responseCopy.DettachPortionFromString("<Opponent>", "</Opponent>", ref opponentString);

                // Get the name of opponent and set it to Opponent_Name variable
                opponentString.DettachPortionFromString("<Name>", "</Name>", ref sectionString);
                sectionString = DataLoader.RemoveOpeningAndClosingTags(sectionString, "Name");
                Opponent_Name = string.Copy(sectionString);

                // Get the max SP of opponent and set it to Opponent_MaxSP variable
                opponentString.DettachPortionFromString("<MaxSP>", "</MaxSP>", ref sectionString);
                sectionString = DataLoader.RemoveOpeningAndClosingTags(sectionString, "MaxSP");
                Opponent_MaxSP = Convert.ToInt32(sectionString);

                // Get the remaining SP of opponent and set it to Opponent_RemainingSP variable
                opponentString.DettachPortionFromString("<RemainingSP>", "</RemainingSP>", ref sectionString);
                sectionString = DataLoader.RemoveOpeningAndClosingTags(sectionString, "RemainingSP");
                Opponent_RemainingSP = Convert.ToInt32(sectionString);

                // Clear OpponentUnitInfos list
                OpponentUnitInfos.Clear();

                // Get the data of opponent's units and store them into OpponentUnitInfos list
                opponentString.DettachPortionFromString("<Units>", "</Units>", ref sectionString);
                sectionString = DataLoader.RemoveOpeningAndClosingTags(sectionString, "Units");
                string opponentUnitString = string.Empty;
                while (sectionString != "")
                {
                    sectionString = sectionString.DettachPortionFromString("<Unit>", "</Unit>", ref opponentUnitString);

                    OpponentUnitInfos.Add(ResponseStringToOpponentPlayerInfo(opponentUnitString));
                }

                m_isOpponentDataSet = true;
            }
            #endregion

            #region Load Tile Map
            if (!m_isTileMapSet)
            {
                // Initialize TileMap array
                TileMap = new eTileType[CoreValues.SIZE_OF_A_SIDE_OF_BOARD, CoreValues.SIZE_OF_A_SIDE_OF_BOARD];

                // Clear m_initialUnitPositions dictionary
                m_initialUnitPositions.Clear();

                // Get the tile map data and store the data into TileMap array
                // Additionally, get and set the initail position of each unit
                responseCopy.DettachPortionFromString("<Sockets>", "</Sockets>", ref sectionString);
                sectionString = DataLoader.RemoveOpeningAndClosingTags(sectionString, "Sockets");
                string socketString = string.Empty;
                while (sectionString != "")
                {
                    sectionString = sectionString.DettachPortionFromString("<Socket>", "</Socket>", ref socketString);

                    LoadTileTypeAndUnitForSocket(socketString);
                }

                m_isTileMapSet = true;
            }
            #endregion

            if (!m_areUnitsSet)
            {
                // Clear the list of unit chips
                Units.Clear();

                // Remove existing unit chips from the Unity world
                Player.transform.ClearChildren();
                Opponent.transform.ClearChildren();

                // Instantiate unit chips for player in Unity world
                foreach (UnitInstance unit in PlayerController.PlayerData.AlliedUnits)
                {
                    SpawnPlayerUnit(unit);
                }

                // Instantiate unit chips for opponent in Unity world
                foreach (OpponentUnitInfo unit in OpponentUnitInfos)
                {
                    SpawnOpponentUnit(unit);
                }

                m_areUnitsSet = true;
            }

            if (m_arePlayersSet
                && m_isPlayerDataSet
                && m_isOpponentDataSet
                && m_isTileMapSet)
            {
                IsInitialized = true;
                m_isInitializing = false;
            }
        }
    }

    private PlayerOnBoard ResponseStringToPlayerOnBoard(string _response)
    {
        string sectionString = string.Empty;

        _response = _response.DettachPortionFromString("<IsPlayer1>", "</IsPlayer1>", ref sectionString);
        sectionString = DataLoader.RemoveOpeningAndClosingTags(sectionString, "IsPlayer1");
        bool isPlayer1 = Convert.ToBoolean(sectionString);

        _response = _response.DettachPortionFromString("<MaxSP>", "</MaxSP>", ref sectionString);
        sectionString = DataLoader.RemoveOpeningAndClosingTags(sectionString, "MaxSP");
        int maxSP = Convert.ToInt32(sectionString);

        PlayerOnBoard pob = new PlayerOnBoard(GameDataContainer.Instance.Player, 0, isPlayer1);
        pob.MaxSP = maxSP;
        pob.RemainingSP = maxSP;

        return pob;
    }

    private OpponentUnitInfo ResponseStringToOpponentPlayerInfo(string _response)
    {
        string sectionString = string.Empty;

        _response = _response.DettachPortionFromString("<Index>", "</Index>", ref sectionString);
        sectionString = DataLoader.RemoveOpeningAndClosingTags(sectionString, "Index");
        int index = Convert.ToInt32(sectionString);

        _response = _response.DettachPortionFromString("<Id>", "</Id>", ref sectionString);
        sectionString = DataLoader.RemoveOpeningAndClosingTags(sectionString, "Id");
        int id = Convert.ToInt32(sectionString);

        _response = _response.DettachPortionFromString("<MaxHP>", "</MaxHP>", ref sectionString);
        sectionString = DataLoader.RemoveOpeningAndClosingTags(sectionString, "MaxHP");
        int maxHP = Convert.ToInt32(sectionString);

        _response = _response.DettachPortionFromString("<RemainingHP>", "</RemainingHP>", ref sectionString);
        sectionString = DataLoader.RemoveOpeningAndClosingTags(sectionString, "RemainingHP");
        int remainingHP = Convert.ToInt32(sectionString);

        return new OpponentUnitInfo { UnitIndex = index, Id = id, MaxHP = maxHP, RemainingHP = remainingHP };
    }

    private void LoadTileTypeAndUnitForSocket(string _response)
    {
        string sectionString = string.Empty;

        _response.DettachPortionFromString("<XCoord>", "</XCoord>", ref sectionString);
        sectionString = DataLoader.RemoveOpeningAndClosingTags(sectionString, "XCoord");
        int x = Convert.ToInt32(sectionString);

        _response.DettachPortionFromString("<YCoord>", "</YCoord>", ref sectionString);
        sectionString = DataLoader.RemoveOpeningAndClosingTags(sectionString, "YCoord");
        int y = Convert.ToInt32(sectionString);

        _response.DettachPortionFromString("<TileType>", "</TileType>", ref sectionString);
        sectionString = DataLoader.RemoveOpeningAndClosingTags(sectionString, "TileType");
        eTileType tileType = sectionString.ToCorrespondingEnumValue<eTileType>();

        // Set tile type for coordinate
        TileMap[x, y] = tileType;

        // Store the position of corresponding unit into m_initialUnitPositions list if the socket contains a unit
        if (_response.Contains("UnitIndex"))
        {
            _response.DettachPortionFromString("<UnitIndex>", "</UnitIndex>", ref sectionString);
            sectionString = DataLoader.RemoveOpeningAndClosingTags(sectionString, "UnitIndex");
            int unitIndex = Convert.ToInt32(sectionString);

            m_initialUnitPositions.Add(unitIndex, new _2DCoord(x, y));
        }
    }

    public IEnumerator Request_UpdatePlayerInfo() { yield return StartCoroutine(GetPlayerInfo()); }

    IEnumerator GetPlayerInfo()
    {
        HasPlayerInfoBeenLoaded = false;

        Dictionary<string, string> values = new Dictionary<string, string>
        {
            {"subject", "GetPlayerInfo"},
            {"playerId", GameDataContainer.Instance.Player.Id.ToString()}
        };

        UnityWebRequest uwr = UnityWebRequest.Post(CoreValues.SERVER_URL, values);
        yield return uwr.SendWebRequest();

        string errorMsg = string.Empty;

        if (uwr.isNetworkError)
            PopUpWindowManager.Instance.CreatePopUp("Error!", "Connection Error: " + uwr.error + "\nPlease check your Internet connection.", "OK", null, ePopUpWindowType.Simple);
        else
        {
            string response = uwr.downloadHandler.text;
            string responseCopy = String.Copy(response);

            string sectionString = string.Empty;

            responseCopy = responseCopy.DettachPortionFromString("<IsMyTurn>", "</IsMyTurn>", ref sectionString);
            sectionString = DataLoader.RemoveOpeningAndClosingTags(sectionString, "IsMyTurn");
            bool isMyTurn = Convert.ToBoolean(sectionString);

            responseCopy = responseCopy.DettachPortionFromString("<HasMoved>", "</HasMoved>", ref sectionString);
            sectionString = DataLoader.RemoveOpeningAndClosingTags(sectionString, "HasMoved");
            bool hasMoved = Convert.ToBoolean(sectionString);

            responseCopy = responseCopy.DettachPortionFromString("<HasAttacked>", "</HasAttacked>", ref sectionString);
            sectionString = DataLoader.RemoveOpeningAndClosingTags(sectionString, "HasAttacked");
            bool hasAttacked = Convert.ToBoolean(sectionString);

            responseCopy = responseCopy.DettachPortionFromString("<HasUsedUltimateSkill>", "</HasUsedUltimateSkill>", ref sectionString);
            sectionString = DataLoader.RemoveOpeningAndClosingTags(sectionString, "HasUsedUltimateSkill");
            bool hasUsedUltimateSkill = Convert.ToBoolean(sectionString);

            responseCopy = responseCopy.DettachPortionFromString("<MaxSP>", "</MaxSP>", ref sectionString);
            sectionString = DataLoader.RemoveOpeningAndClosingTags(sectionString, "MaxSP");
            int maxSP = Convert.ToInt32(sectionString);

            responseCopy = responseCopy.DettachPortionFromString("<RemainingSP>", "</RemainingSP>", ref sectionString);
            sectionString = DataLoader.RemoveOpeningAndClosingTags(sectionString, "RemainingSP");
            int remainingSP = Convert.ToInt32(sectionString);

            responseCopy = responseCopy.DettachPortionFromString("<SelectedAlliedUnitId>", "</SelectedAlliedUnitId>", ref sectionString);
            sectionString = DataLoader.RemoveOpeningAndClosingTags(sectionString, "SelectedAlliedUnitId");
            int selectedAlliedUnitId = Convert.ToInt32(sectionString);

            PlayerInfo = new PlayerInfo { IsMyTurn = isMyTurn, HasMoved = hasMoved, HasAttacked = hasAttacked, HasUsedUltimateSkill = hasUsedUltimateSkill, MaxSP = maxSP, RemainingSP = remainingSP, SelectedAlliedUnitId = selectedAlliedUnitId };

            HasPlayerInfoBeenLoaded = true;
        }
    }

    IEnumerator GetOpponentInfo()
    {
        HasOpponentInfoBeenLoaded = false;

        Dictionary<string, string> values = new Dictionary<string, string>
        {
            {"subject", "GetOpponentInfo"},
            {"playerId", GameDataContainer.Instance.Player.Id.ToString()}
        };

        UnityWebRequest uwr = UnityWebRequest.Post(CoreValues.SERVER_URL, values);
        yield return uwr.SendWebRequest();

        string errorMsg = string.Empty;

        if (uwr.isNetworkError)
            PopUpWindowManager.Instance.CreatePopUp("Error!", "Connection Error: " + uwr.error + "\nPlease check your Internet connection.", "OK", null, ePopUpWindowType.Simple);
        else
        {
            string response = uwr.downloadHandler.text;
            string responseCopy = String.Copy(response);

            string sectionString = string.Empty;

            // Get the max SP of opponent and set it to Opponent_MaxSP variable
            responseCopy.DettachPortionFromString("<MaxSP>", "</MaxSP>", ref sectionString);
            sectionString = DataLoader.RemoveOpeningAndClosingTags(sectionString, "MaxSP");
            Opponent_MaxSP = Convert.ToInt32(sectionString);

            // Get the remaining SP of opponent and set it to Opponent_RemainingSP variable
            responseCopy.DettachPortionFromString("<RemainingSP>", "</RemainingSP>", ref sectionString);
            sectionString = DataLoader.RemoveOpeningAndClosingTags(sectionString, "RemainingSP");
            Opponent_RemainingSP = Convert.ToInt32(sectionString);

            HasOpponentInfoBeenLoaded = true;
        }
    }

    public void Request_ChangeTurn()
    {
        if (!m_animationController.IsInitialized || m_animationController.LockUI)
            return;

        StartCoroutine(ChangeTurn());
    }
    IEnumerator ChangeTurn()
    {
        Dictionary<string, string> values = new Dictionary<string, string>
        {
            {"subject", "ChangeTurn"},
            {"playerId", GameDataContainer.Instance.Player.Id.ToString()}
        };

        UnityWebRequest uwr = UnityWebRequest.Post(CoreValues.SERVER_URL, values);
        yield return uwr.SendWebRequest();

        string errorMsg = string.Empty;

        if (uwr.isNetworkError)
            PopUpWindowManager.Instance.CreatePopUp("Error!", "Connection Error: " + uwr.error + "\nPlease check your Internet connection.", "OK", null, ePopUpWindowType.Simple);
        else
            yield return StartCoroutine(PlayerController.Request_SyncProperties());
    }

    public void Request_Concede()
    {
        if (!m_animationController.IsInitialized || m_animationController.LockUI)
            return;

        StartCoroutine(Concede());
    }
    IEnumerator Concede()
    {
        Dictionary<string, string> values = new Dictionary<string, string>
        {
            {"subject", "Concede"},
            {"playerId", GameDataContainer.Instance.Player.Id.ToString()}
        };

        UnityWebRequest uwr = UnityWebRequest.Post(CoreValues.SERVER_URL, values);
        yield return uwr.SendWebRequest();

        string errorMsg = string.Empty;

        if (uwr.isNetworkError)
            PopUpWindowManager.Instance.CreatePopUp("Error!", "Connection Error: " + uwr.error + "\nPlease check your Internet connection.", "OK", null, ePopUpWindowType.Simple);
    }

    //private void EndMatch()
    //{
    //    bool m_isLocalPlayerWinner = BattleSystemCore.IsPlayer1Winner;

    //    if (LocalPlayer_PlayerController.PlayerId != 1)
    //        m_isLocalPlayerWinner = !m_isLocalPlayerWinner;

    //     Proceed to the ending phase of the match.
    //}

    private bool SpawnPlayerUnit(UnitInstance _unit)
    {
        try
        {
            Debug.Log("BattleSystem_Multiplayer: Start Player Unit Spawning.");

            GameObject Unit = Instantiate(PlayerUnitPrefab, Vector3.zero, Quaternion.identity, this.transform.root);

            int unitIndex = m_playerUnitIdAndIndexMapping[_unit.UniqueId];
            _2DCoord coord = m_initialUnitPositions[unitIndex]; // Get location as logical 2D Coordinate (x, y) --- this is not Unity coordinate
            Unit.transform.position = GetActualPosition(coord); // Get and Set the actual position in the Unity world
            if (PlayerController.PlayerId != 1)
                Unit.transform.Rotate(0f, 180f, 0f); //Rotate 180 degrees to adjust player 2's units' direction facing.

            //Return false if not succeeded
            if (!Unit.GetComponent<PlayerUnitController>()
                .ExternalInitialization(unitIndex,
                                        PlayerController.PlayerData.AlliedUnits.IndexOf(_unit),
                                        PlayerController.PlayerData.IsPlayer1 ? 1 : 2,
                                        _unit))
            {
                Destroy(Unit); // destroy not to leave the unsynced instance in unity world
                return false;
            }

            Unit.name = _unit.Nickname; //To make it easier to identify on editor

            PlayerUnits.Add(Unit);

            Units.Add(Unit);

            Debug.Log("BattleSystem_Multiplayer: End Player Unit Spawning.");
            return true;
        }
        catch (Exception ex)
        {
            Debug.Log("BattleSystem_Multiplayer: at SpawnUnit() " + ex.Message);
            return false;
        }
    }

    private bool SpawnOpponentUnit(OpponentUnitInfo _unit)
    {
        try
        {
            Debug.Log("BattleSystem_Multiplayer: Start Opponent Unit Spawning.");

            GameObject Unit = Instantiate(OpponentUnitPrefab, Vector3.zero, Quaternion.identity, this.transform.root);

            _2DCoord coord = m_initialUnitPositions[_unit.UnitIndex]; // Get location as logical 2D Coordinate (x, y) --- this is not Unity coordinate
            Unit.transform.position = GetActualPosition(coord); // Get and Set the actual position in the Unity world
            if (PlayerController.PlayerId == 1) // If Player's id is 1, then, opponent's id is 2
                Unit.transform.Rotate(0f, 180f, 0f); //Rotate 180 degrees to adjust player 2's units' direction facing.

            //Return false if not succeeded
            if (!Unit.GetComponent<OpponentUnitController>()
                .ExternalInitialization(_unit.UnitIndex,
                                        PlayerController.PlayerData.IsPlayer1 ? 2 : 1,
                                        GameDataContainer.Instance.UnitEncyclopedia.Where(x => x.Id == _unit.Id).First(),
                                        _unit.MaxHP,
                                        _unit.RemainingHP))
            {
                Destroy(Unit); // destroy not to leave the unsynced instance in unity world
                return false;
            }

            OpponentUnits.Add(Unit);

            Units.Add(Unit);

            Debug.Log("BattleSystem_Multiplayer: End Opponent Unit Spawning.");
            return true;
        }
        catch (Exception ex)
        {
            Debug.Log("BattleSystem_Multiplayer: at SpawnUnit() " + ex.Message);
            return false;
        }
    }

    private Vector3 GetActualPosition(_2DCoord _coord)
    {
        try
        {
            int tileNum = _coord.Y * CoreValues.SIZE_OF_A_SIDE_OF_BOARD + _coord.X;
            Transform tileMask = GameObject.Find("Tile" + tileNum.ToString()).transform.Find("Mask" + tileNum.ToString());

            float adjustmentValueY = 0.01f;

            float x = tileMask.position.x;
            float y = tileMask.position.y + adjustmentValueY;
            float z = tileMask.position.z;

            return new Vector3(x, y, z);
        }
        catch (Exception ex)
        {
            Debug.Log("BattleSystem_Multiplayer: at GetActualPosition() " + ex.Message);
            return new Vector3(-1, -1, -1);
        }
    }

    public void Request_MoveUnit(_2DCoord _destination) { StartCoroutine(MoveUnit(_destination)); }
    IEnumerator MoveUnit(_2DCoord _destination)
    {
        PlayerOnBoard pob = PlayerController.PlayerData;
        UnitInstance unit = pob.AlliedUnits[PlayerController.SelectedAlliedUnitId];

        Dictionary<string, string> values = new Dictionary<string, string>
        {
            {"subject", "MoveUnit"},
            {"playerId", GameDataContainer.Instance.Player.Id.ToString()}
        };

        UnityWebRequest uwr = UnityWebRequest.Post(CoreValues.SERVER_URL, values);
        yield return uwr.SendWebRequest();

        string errorMsg = string.Empty;

        if (uwr.isNetworkError)
            errorMsg = "Connection Error: " + uwr.error + "\nPlease check your Internet connection.";
        else
        {
            yield return StartCoroutine(PlayerController.Request_SyncProperties());

            Request_UpdateMovableArea();
        }
    }

    public void Request_Attack(List<_2DCoord> _targetCoords) { StartCoroutine(Attack(_targetCoords)); }
    IEnumerator Attack(List<_2DCoord> _targetCoords)
    {
        PlayerOnBoard pob = PlayerController.PlayerData;
        UnitInstance unit = pob.AlliedUnits[PlayerController.SelectedAlliedUnitId];

        Dictionary<string, string> values = new Dictionary<string, string>
        {
            {"subject", "Attack"},
            {"playerId", GameDataContainer.Instance.Player.Id.ToString()}
        };

        UnityWebRequest uwr = UnityWebRequest.Post(CoreValues.SERVER_URL, values);
        yield return uwr.SendWebRequest();

        string errorMsg = string.Empty;

        if (uwr.isNetworkError)
            errorMsg = "Connection Error: " + uwr.error + "\nPlease check your Internet connection.";
        else
        {
            yield return StartCoroutine(PlayerController.Request_SyncProperties());

            UpdateAttackTargetableArea();
        }
    }

    public void Request_SkillUse(string _skillName, List<_2DCoord> _targetCoords) { StartCoroutine(UseSkill(_skillName, _targetCoords)); }
    IEnumerator UseSkill(string _skillName, List<_2DCoord> _targetCoords)
    {
        string targetCoordsString = string.Empty;
        foreach (_2DCoord coord in _targetCoords)
        {
            targetCoordsString += "(" + coord.X.ToString() + "," + coord.Y.ToString() + ");";
        }

        Dictionary<string, string> values = new Dictionary<string, string>
        {
            {"subject", "UseSkill"},
            {"playerId", GameDataContainer.Instance.Player.Id.ToString()},
            {"skillName", _skillName},
            {"targetCoords", targetCoordsString}
        };

        UnityWebRequest uwr = UnityWebRequest.Post(CoreValues.SERVER_URL, values);
        yield return uwr.SendWebRequest();

        string errorMsg = string.Empty;

        if (uwr.isNetworkError)
            errorMsg = "Connection Error: " + uwr.error + "\nPlease check your Internet connection.";
        else
        {
            yield return StartCoroutine(PlayerController.Request_SyncProperties());

            UpdateSkillTargetableArea(_skillName);
        }
    }

    //public void UseUltimateSkill(string _skillName, List<_2DCoord> _targetCoords)
    //{
    //
    //
    //
    //}

    //public void RequestSkillCost(int _playerId, int _unitIndex, string _skillName)
    //{
    //    int playerIndex = _playerId - 1; // _playerId is one-based and playerIndex needs to be zero-based

    //    PlayerOnBoard pob = PlayerController.PlayerData;
    //    UnitInstance unit = pob.AlliedUnits[_unitIndex];

    //    int requiredSP = (unit.BaseInfo.Skills.First(x => x.Name == _skillName) as CostRequiringSkill).SPCost;
    //}

    //private void SyncUnitStatus_All()
    //{
    //    try
    //    {
    //        foreach (GameObject Unit in Player1Units)
    //        {
    //            UnitController_SinglePlayer UnitController = Unit.GetComponent<UnitController_SinglePlayer>();

    //            UnitInstance unit = BattleSystemCore.Field.Players[0].AlliedUnits[UnitController.Unit_PrivateId];

    //            //UnitController.Rpc_SyncStatus(Calculator.MaxHP(unit), unit.RemainingHP, unit.isAlive);
    //        }

    //        foreach (GameObject Unit in Player2Units)
    //        {
    //            UnitController_SinglePlayer UnitController = Unit.GetComponent<UnitController_SinglePlayer>();

    //            UnitInstance unit = BattleSystemCore.Field.Players[1].AlliedUnits[UnitController.Unit_PrivateId];

    //            //UnitController.Rpc_SyncStatus(Calculator.MaxHP(unit), unit.RemainingHP, unit.isAlive);
    //        }
    //    }
    //    catch (Exception ex)
    //    {
    //        Debug.Log("BattleSystem_Multiplayer: at SyncUnitStatus_All() " + ex.Message);
    //    }
    //}

    public void Request_ChangeUnit(int _unitIndex)
    {
        try
        {
            if (m_animationController.LockUI)
                return;

            if (_unitIndex != PlayerController.SelectedAlliedUnitId)
                StartCoroutine(ChangeUnitAndSyncProperties(_unitIndex));
        }
        catch (Exception ex)
        {
            Debug.Log("BattleSystem_Multiplayer: at ChangeUnit() " + ex.Message);
        }
    }
    IEnumerator ChangeUnitAndSyncProperties(int _unitIndex)
    {
        yield return StartCoroutine(ChangeUnit(_unitIndex));
        Debug.Log("Selected Unit has been changed");

        yield return StartCoroutine(PlayerController.Request_SyncProperties());
        Debug.Log("Unit Selection Info was Synced!");
    }
    IEnumerator ChangeUnit(int _unitIndex)
    {
        Dictionary<string, string> values = new Dictionary<string, string>
        {
            {"subject", "ChangeUnit"},
            {"playerId", GameDataContainer.Instance.Player.Id.ToString()},
            {"unitIndex", _unitIndex.ToString() }
        };

        UnityWebRequest uwr = UnityWebRequest.Post(CoreValues.SERVER_URL, values);
        yield return uwr.SendWebRequest();

        string errorMsg = string.Empty;

        if (uwr.isNetworkError)
            errorMsg = "Connection Error: " + uwr.error + "\nPlease check your Internet connection.";
    }

    public IEnumerator Request_UpdateMovableArea() { yield return StartCoroutine(UpdateMovableArea()); }
    IEnumerator UpdateMovableArea()
    {
        m_maxNumOfTargets = 1;
        m_tileMaskManager.UpdateMaxNumOfTargets(m_maxNumOfTargets);

        yield return StartCoroutine(GetMovableAndSelectableArea());
        m_tileMaskManager.UpdateTargetArea(m_targetableAndSelectableArea);
    }
    IEnumerator GetMovableAndSelectableArea()
    {
        Dictionary<string, string> values = new Dictionary<string, string>
        {
            {"subject", "GetMovableAndSelectableArea"},
            {"playerId", GameDataContainer.Instance.Player.Id.ToString()},
        };

        UnityWebRequest uwr = UnityWebRequest.Post(CoreValues.SERVER_URL, values);
        yield return uwr.SendWebRequest();

        string errorMsg = string.Empty;

        if (uwr.isNetworkError)
            errorMsg = "Connection Error: " + uwr.error + "\nPlease check your Internet connection.";
        else
        {
            string response = uwr.downloadHandler.text;
            string responseCopy = String.Copy(response);

            string sectionString = string.Empty;

            responseCopy = responseCopy.DettachPortionFromString("<Coords>", "</Coords>", ref sectionString);
            m_targetableAndSelectableArea = ResponseStringToTargetableAndSelectableArea(sectionString);
        }
    }

    public IEnumerator Request_UpdateAttackTargetableArea() { yield return StartCoroutine(UpdateAttackTargetableArea()); }
    IEnumerator UpdateAttackTargetableArea()
    {
        yield return StartCoroutine(GetMaxNumOfTargets(GameDataContainer.Instance.BasicAttackSkill.BaseInfo.Name));
        m_tileMaskManager.UpdateMaxNumOfTargets(m_maxNumOfTargets);

        yield return StartCoroutine(GetAttackTargetableAndSelectableArea());
        m_tileMaskManager.UpdateTargetArea(m_targetableAndSelectableArea);
    }
    IEnumerator GetAttackTargetableAndSelectableArea()
    {
        Dictionary<string, string> values = new Dictionary<string, string>
        {
            {"subject", "GetMovableAndSelectableArea"},
            {"playerId", GameDataContainer.Instance.Player.Id.ToString()},
        };

        UnityWebRequest uwr = UnityWebRequest.Post(CoreValues.SERVER_URL, values);
        yield return uwr.SendWebRequest();

        string errorMsg = string.Empty;

        if (uwr.isNetworkError)
            errorMsg = "Connection Error: " + uwr.error + "\nPlease check your Internet connection.";
        else
        {
            string response = uwr.downloadHandler.text;
            string responseCopy = String.Copy(response);

            string sectionString = string.Empty;

            responseCopy = responseCopy.DettachPortionFromString("<Coords>", "</Coords>", ref sectionString);
            m_targetableAndSelectableArea = ResponseStringToTargetableAndSelectableArea(sectionString);
        }
    }

    public IEnumerator Request_UpdateSkillTargetableArea(string _skillName) { yield return StartCoroutine(UpdateSkillTargetableArea(_skillName)); }
    IEnumerator UpdateSkillTargetableArea(string _skillName)
    {
        yield return StartCoroutine(GetMaxNumOfTargets(_skillName));
        m_tileMaskManager.UpdateMaxNumOfTargets(m_maxNumOfTargets);

        yield return StartCoroutine(GetSkillTargetableAndSelectableArea());
        m_tileMaskManager.UpdateTargetArea(m_targetableAndSelectableArea);
    }
    IEnumerator GetSkillTargetableAndSelectableArea()
    {
        Dictionary<string, string> values = new Dictionary<string, string>
        {
            {"subject", "GetSkillTargetableAndSelectableArea"},
            {"playerId", GameDataContainer.Instance.Player.Id.ToString()},
        };

        UnityWebRequest uwr = UnityWebRequest.Post(CoreValues.SERVER_URL, values);
        yield return uwr.SendWebRequest();

        string errorMsg = string.Empty;

        if (uwr.isNetworkError)
            errorMsg = "Connection Error: " + uwr.error + "\nPlease check your Internet connection.";
        else
        {
            string response = uwr.downloadHandler.text;
            string responseCopy = String.Copy(response);

            string sectionString = string.Empty;

            responseCopy = responseCopy.DettachPortionFromString("<Coords>", "</Coords>", ref sectionString);
            m_targetableAndSelectableArea = ResponseStringToTargetableAndSelectableArea(sectionString);
        }
    }

    public void UpdateTargetableAreaToNull()
    {
        m_tileMaskManager.UpdateTargetArea(null);
    }

    private Dictionary<_2DCoord, bool> ResponseStringToTargetableAndSelectableArea(string _response)
    {
        Dictionary<_2DCoord, bool> result = new Dictionary<_2DCoord, bool>();

        try
        {
            string sectionString = string.Empty;

            _response.DettachPortionFromString("<Coords>", "</Coords>", ref sectionString);
            sectionString = DataLoader.RemoveOpeningAndClosingTags(sectionString, "Coords");
            string coordString = "";
            while (sectionString != "")
            {
                sectionString = sectionString.DettachPortionFromString("<Coord>", "</Coord>", ref coordString);

                string coordSubString = string.Empty;
                coordString.DettachPortionFromString("<X>", "</X>", ref coordSubString);
                coordSubString = DataLoader.RemoveOpeningAndClosingTags(coordSubString, "X");
                int x = Convert.ToInt32(coordSubString);

                coordString.DettachPortionFromString("<Y>", "</Y>", ref coordSubString);
                coordSubString = DataLoader.RemoveOpeningAndClosingTags(coordSubString, "Y");
                int y = Convert.ToInt32(coordSubString);

                coordString.DettachPortionFromString("<IsSelectable>", "</IsSelectable>", ref coordSubString);
                coordSubString = DataLoader.RemoveOpeningAndClosingTags(coordSubString, "IsSelectable");
                bool isSelectable = Convert.ToBoolean(coordSubString);

                result.Add(new _2DCoord(x, y), isSelectable);
            }

            return result;
        }
        catch (Exception ex)
        {
            Debug.Log(ex.Message);
            return null;
        }
    }

    IEnumerator GetMaxNumOfTargets(string _skillName)
    {
        Dictionary<string, string> values = new Dictionary<string, string>
        {
            {"subject", "GetMaxNumOfTargets"},
            {"playerId", GameDataContainer.Instance.Player.Id.ToString()},
            {"skillName", _skillName }
        };

        UnityWebRequest uwr = UnityWebRequest.Post(CoreValues.SERVER_URL, values);
        yield return uwr.SendWebRequest();

        string errorMsg = string.Empty;

        if (uwr.isNetworkError)
            errorMsg = "Connection Error: " + uwr.error + "\nPlease check your Internet connection.";
        else
        {
            string response = uwr.downloadHandler.text;

            m_maxNumOfTargets = Convert.ToInt32(response);
        }
    }

    IEnumerator GetMissingEventLogs()
    {
        Dictionary<string, string> values = new Dictionary<string, string>
        {
            {"subject", "GetMissingEventLogs"},
            {"playerId", GameDataContainer.Instance.Player.Id.ToString()},
            {"latestLogIndex", (m_eventLogs.Count - 1).ToString()}
        };

        UnityWebRequest uwr = UnityWebRequest.Post(CoreValues.SERVER_URL, values);
        yield return uwr.SendWebRequest();

        string errorMsg = string.Empty;

        if (uwr.isNetworkError)
            errorMsg = "Connection Error: " + uwr.error + "\nPlease check your Internet connection.";
        else
        {
            string response = uwr.downloadHandler.text;

            m_eventLogs.AddRange(ResponseStringToEventLogs(response));
        }

        m_isGettingMissingEventLogs = false;
    }

    public List<EventLog> ResponseStringToEventLogs(string _response)
    {
        try
        {
            List<EventLog> result = new List<EventLog>();

            string eventLogString = string.Empty;
            while (_response != "")
            {
                //Automatic Event Log
                if (_response.StartsWith("<TurnChangeEventLog>"))
                    _response = _response.DettachPortionFromString("<TurnChangeEventLog>", "</TurnChangeEventLog>", ref eventLogString);
                else if (_response.StartsWith("<EffectTrialLog_DamageEffect>"))
                    _response = _response.DettachPortionFromString("<EffectTrialLog_DamageEffect>", "</EffectTrialLog_DamageEffect>", ref eventLogString);
                else if (_response.StartsWith("<EffectTrialLog_HealEffect>"))
                    _response = _response.DettachPortionFromString("<EffectTrialLog_HealEffect>", "</EffectTrialLog_HealEffect>", ref eventLogString);
                else if (_response.StartsWith("<EffectTrialLog_StatusEffectAttachmentEffect>"))
                    _response = _response.DettachPortionFromString("<EffectTrialLog_StatusEffectAttachmentEffect>", "</EffectTrialLog_StatusEffectAttachmentEffect>", ref eventLogString);
                else if (_response.StartsWith("<StatusEffectLog_HPModification>"))
                    _response = _response.DettachPortionFromString("<StatusEffectLog_HPModification>", "</StatusEffectLog_HPModification>", ref eventLogString);
                //Action Log
                else if (_response.StartsWith("<ActionLog_Move>"))
                    _response = _response.DettachPortionFromString("<ActionLog_Move>", "</ActionLog_Move>", ref eventLogString);
                else if (_response.StartsWith("<ActionLog_Attack>"))
                    _response = _response.DettachPortionFromString("<ActionLog_Attack>", "</ActionLog_Attack>", ref eventLogString);
                else if (_response.StartsWith("<ActionLog_UnitTargetingSkill>"))
                    _response = _response.DettachPortionFromString("<ActionLog_UnitTargetingSkill>", "</ActionLog_UnitTargetingSkill>", ref eventLogString);
                else if (_response.StartsWith("<ActionLog_TileTargetingSkill>"))
                    _response = _response.DettachPortionFromString("<ActionLog_TileTargetingSkill>", "</ActionLog_TileTargetingSkill>", ref eventLogString);

                result.Add(StringToEventLog(eventLogString));
            }

            return result;
        }
        catch (Exception ex)
        {
            Debug.Log(ex.Message);
            return null;
        }
    }

    private EventLog StringToEventLog(string _string)
    {
        try
        {
            string sectionString = string.Empty;

            _string.DettachPortionFromString("<EventTurn>", "</EventTurn>", ref sectionString);
            sectionString = DataLoader.RemoveOpeningAndClosingTags(sectionString, "EventTurn");
            decimal eventTurn = Convert.ToDecimal(sectionString);

            if (_string.StartsWith("<TurnChangeEventLog>")
                || _string.StartsWith("<EffectTrialLog_DamageEffect>")
                || _string.StartsWith("<EffectTrialLog_HealEffect>")
                || _string.StartsWith("<EffectTrialLog_StatusEffectAttachmentEffect>")
                || _string.StartsWith("<StatusEffectLog_HPModification>"))
            {
                return StringToAutomaticEventLog(_string, eventTurn);
            }
            else if (_string.StartsWith("<ActionLog_Move>")
                || _string.StartsWith("<ActionLog_Attack>")
                || _string.StartsWith("<ActionLog_UnitTargetingSkill>")
                || _string.StartsWith("<ActionLog_TileTargetingSkill>"))
            {
                return StringToActionLog(_string, eventTurn);
            }

            return null;
        }
        catch (Exception ex)
        {
            Debug.Log(ex.Message);
            return null;
        }
    }

    private AutomaticEventLog StringToAutomaticEventLog(string _string, decimal _eventTurn)
    {
        try
        {
            if (_string.StartsWith("<TurnChangeEventLog>"))
                return StringToTurnChangeEventLog(_string, _eventTurn);
            else if (_string.StartsWith("<EffectTrialLog_DamageEffect>")
                || _string.StartsWith("<EffectTrialLog_HealEffect>")
                || _string.StartsWith("<EffectTrialLog_StatusEffectAttachmentEffect>"))
                return StringToEffectTrialLog(_string, _eventTurn);
            else if (_string.StartsWith("<StatusEffectLog_HPModification>"))
                return StringToStatusEffectLog(_string, _eventTurn);

            return null;
        }
        catch (Exception ex)
        {
            Debug.Log(ex.Message);
            return null;
        }
    }

    private AutomaticEventLog StringToTurnChangeEventLog(string _string, decimal _eventTurn)
    {
        try
        {
            string sectionString = string.Empty;

            _string.DettachPortionFromString("<TurnEndingPlayerId>", "</TurnEndingPlayerId>", ref sectionString);
            sectionString = DataLoader.RemoveOpeningAndClosingTags(sectionString, "TurnEndingPlayerId");
            int turnEndingPlayerId = Convert.ToInt32(sectionString);

            _string.DettachPortionFromString("<TurnInitiatingPlayerId>", "</TurnInitiatingPlayerId>", ref sectionString);
            sectionString = DataLoader.RemoveOpeningAndClosingTags(sectionString, "TurnInitiatingPlayerId");
            int turnInitiatingPlayerId = Convert.ToInt32(sectionString);

            return new TurnChangeEventLog(_eventTurn, turnEndingPlayerId, turnInitiatingPlayerId);
        }
        catch (Exception ex)
        {
            Debug.Log(ex.Message);
            return null;
        }
    }

    private AutomaticEventLog StringToEffectTrialLog(string _string, decimal _eventTurn)
    {
        try
        {
            string sectionString = string.Empty;

            _string.DettachPortionFromString("<AnimationId>", "</AnimationId>", ref sectionString);
            sectionString = DataLoader.RemoveOpeningAndClosingTags(sectionString, "AnimationId");
            int animationId = Convert.ToInt32(sectionString);

            _string.DettachPortionFromString("<DidSucceed>", "</DidSucceed>", ref sectionString);
            sectionString = DataLoader.RemoveOpeningAndClosingTags(sectionString, "DidSucceed");
            bool didSucceed = Convert.ToBoolean(sectionString);

            if (_string.StartsWith("<EffectTrialLog_DamageEffect>")
                || _string.StartsWith("<EffectTrialLog_HealEffect>")
                || _string.StartsWith("<EffectTrialLog_StatusEffectAttachmentEffect>"))
            {
                return StringToUnitTargetingEffectTrialLog(_string, _eventTurn, animationId, didSucceed);
            }

            return null;
        }
        catch (Exception ex)
        {
            Debug.Log(ex.Message);
            return null;
        }
    }

    private EffectTrialLog_UnitTargetingEffect StringToUnitTargetingEffectTrialLog(string _string, decimal _eventTurn, int _animationId, bool _didSucceed)
    {
        try
        {
            string sectionString = string.Empty;

            _string.DettachPortionFromString("<TargetId>", "</TargetId>", ref sectionString);
            sectionString = DataLoader.RemoveOpeningAndClosingTags(sectionString, "TargetId");
            int targetId = Convert.ToInt32(sectionString);

            _string.DettachPortionFromString("<TargetName>", "</TargetName>", ref sectionString);
            sectionString = DataLoader.RemoveOpeningAndClosingTags(sectionString, "TargetName");
            string targetName = sectionString;

            _string.DettachPortionFromString("<TargetNickname>", "</TargetNickname>", ref sectionString);
            sectionString = DataLoader.RemoveOpeningAndClosingTags(sectionString, "TargetNickname");
            string targetNickname = sectionString;

            _string.DettachPortionFromString("<TargetLocationTileIndex>", "</TargetLocationTileIndex>", ref sectionString);
            sectionString = DataLoader.RemoveOpeningAndClosingTags(sectionString, "TargetLocationTileIndex");
            int targetLocationTileIndex = Convert.ToInt32(sectionString);

            if (_string.StartsWith("<EffectTrialLog_DamageEffect>"))
                return StringToDamageEffectTrialLog(_string, _eventTurn, _animationId, _didSucceed, targetId, targetName, targetNickname, targetLocationTileIndex);
            else if (_string.StartsWith("<EffectTrialLog_HealEffect>"))
                return StringToHealEffectTrialLog(_string, _eventTurn, _animationId, _didSucceed, targetId, targetName, targetNickname, targetLocationTileIndex);
            else if (_string.StartsWith("<EffectTrialLog_StatusEffectAttachmentEffect>"))
                return StringToStatusEffectAttachmentEffectTrialLog(_string, _eventTurn, _animationId, _didSucceed, targetId, targetName, targetNickname, targetLocationTileIndex);

            return null;
        }
        catch (Exception ex)
        {
            Debug.Log(ex.Message);
            return null;
        }
    }

    private EffectTrialLog_DamageEffect StringToDamageEffectTrialLog(string _string, decimal _eventTurn, int _animationId, bool _didSucceed, int _targetId, string _targetName, string _targetNickname, int _targetLocationTileIndex)
    {
        try
        {
            string sectionString = string.Empty;

            _string.DettachPortionFromString("<WasImmune>", "</WasImmune>", ref sectionString);
            sectionString = DataLoader.RemoveOpeningAndClosingTags(sectionString, "WasImmune");
            bool wasImmune = Convert.ToBoolean(sectionString);

            _string.DettachPortionFromString("<WasCritical>", "</WasCritical>", ref sectionString);
            sectionString = DataLoader.RemoveOpeningAndClosingTags(sectionString, "WasCritical");
            bool wasCritical = Convert.ToBoolean(sectionString);

            _string.DettachPortionFromString("<Effectiveness>", "</Effectiveness>", ref sectionString);
            sectionString = DataLoader.RemoveOpeningAndClosingTags(sectionString, "Effectiveness");
            eEffectiveness effectiveness = sectionString.ToCorrespondingEnumValue<eEffectiveness>();

            _string.DettachPortionFromString("<Value>", "</Value>", ref sectionString);
            sectionString = DataLoader.RemoveOpeningAndClosingTags(sectionString, "Value");
            int value = Convert.ToInt32(sectionString);

            _string.DettachPortionFromString("<RemainingHPAfterModification>", "</RemainingHPAfterModification>", ref sectionString);
            sectionString = DataLoader.RemoveOpeningAndClosingTags(sectionString, "RemainingHPAfterModification");
            int remainingHPAfterModification = Convert.ToInt32(sectionString);

            return new EffectTrialLog_DamageEffect(_eventTurn, _animationId, _didSucceed, _targetId, _targetName, _targetNickname, _targetLocationTileIndex, wasImmune, wasCritical, effectiveness, value, remainingHPAfterModification);
        }
        catch (Exception ex)
        {
            Debug.Log(ex.Message);
            return null;
        }
    }

    private EffectTrialLog_HealEffect StringToHealEffectTrialLog(string _string, decimal _eventTurn, int _animationId, bool _didSucceed, int _targetId, string _targetName, string _targetNickname, int _targetLocationTileIndex)
    {
        try
        {
            string sectionString = string.Empty;

            _string.DettachPortionFromString("<WasCritical>", "</WasCritical>", ref sectionString);
            sectionString = DataLoader.RemoveOpeningAndClosingTags(sectionString, "WasCritical");
            bool wasCritical = Convert.ToBoolean(sectionString);

            _string.DettachPortionFromString("<Value>", "</Value>", ref sectionString);
            sectionString = DataLoader.RemoveOpeningAndClosingTags(sectionString, "Value");
            int value = Convert.ToInt32(sectionString);

            _string.DettachPortionFromString("<RemainingHPAfterModification>", "</RemainingHPAfterModification>", ref sectionString);
            sectionString = DataLoader.RemoveOpeningAndClosingTags(sectionString, "RemainingHPAfterModification");
            int remainingHPAfterModification = Convert.ToInt32(sectionString);

            return new EffectTrialLog_HealEffect(_eventTurn, _animationId, _didSucceed, _targetId, _targetName, _targetNickname, _targetLocationTileIndex, wasCritical, value, remainingHPAfterModification);
        }
        catch (Exception ex)
        {
            Debug.Log(ex.Message);
            return null;
        }
    }

    private EffectTrialLog_StatusEffectAttachmentEffect StringToStatusEffectAttachmentEffectTrialLog(string _string, decimal _eventTurn, int _animationId, bool _didSucceed, int _targetId, string _targetName, string _targetNickname, int _targetLocationTileIndex)
    {
        try
        {
            string sectionString = string.Empty;

            _string.DettachPortionFromString("<AttachedStatusEffectId>", "</AttachedStatusEffectId>", ref sectionString);
            sectionString = DataLoader.RemoveOpeningAndClosingTags(sectionString, "AttachedStatusEffectId");
            int attachedStatusEffectId = Convert.ToInt32(sectionString);

            return new EffectTrialLog_StatusEffectAttachmentEffect(_eventTurn, _animationId, _didSucceed, _targetId, _targetName, _targetNickname, _targetLocationTileIndex, attachedStatusEffectId);
        }
        catch (Exception ex)
        {
            Debug.Log(ex.Message);
            return null;
        }
    }

    private StatusEffectLog StringToStatusEffectLog(string _string, decimal _eventTurn)
    {
        try
        {
            string sectionString = string.Empty;

            _string.DettachPortionFromString("<EffectHolderId>", "</EffectHolderId>", ref sectionString);
            sectionString = DataLoader.RemoveOpeningAndClosingTags(sectionString, "EffectHolderId");
            int effectHolderId = Convert.ToInt32(sectionString);

            _string.DettachPortionFromString("<EffectHolderName>", "</EffectHolderName>", ref sectionString);
            sectionString = DataLoader.RemoveOpeningAndClosingTags(sectionString, "EffectHolderName");
            string effectHolderName = sectionString;

            _string.DettachPortionFromString("<EffectHolderNickname>", "</EffectHolderNickname>", ref sectionString);
            sectionString = DataLoader.RemoveOpeningAndClosingTags(sectionString, "EffectHolderNickname");
            string effectHolderNickname = sectionString;

            if (_string.StartsWith("<StatusEffectLog_HPModification>"))
                return StringToHPModificationStatusEffectLog(_string, _eventTurn, effectHolderId, effectHolderName, effectHolderNickname);

            return null;
        }
        catch (Exception ex)
        {
            Debug.Log(ex.Message);
            return null;
        }
    }

    private StatusEffectLog_HPModification StringToHPModificationStatusEffectLog(string _string, decimal _eventTurn, int _effectHolderId, string _effectHolderName, string _effectHolderNickname)
    {
        try
        {
            string sectionString = string.Empty;

            _string.DettachPortionFromString("<IsPositive>", "</IsPositive>", ref sectionString);
            sectionString = DataLoader.RemoveOpeningAndClosingTags(sectionString, "IsPositive");
            bool isPositive = Convert.ToBoolean(sectionString);

            _string.DettachPortionFromString("<Value>", "</Value>", ref sectionString);
            sectionString = DataLoader.RemoveOpeningAndClosingTags(sectionString, "Value");
            int value = Convert.ToInt32(sectionString);

            _string.DettachPortionFromString("<RemainingHPAfterModification>", "</RemainingHPAfterModification>", ref sectionString);
            sectionString = DataLoader.RemoveOpeningAndClosingTags(sectionString, "RemainingHPAfterModification");
            int remainingHPAfterModification = Convert.ToInt32(sectionString);

            return new StatusEffectLog_HPModification(_eventTurn, _effectHolderId, _effectHolderName, _effectHolderNickname, isPositive, value, remainingHPAfterModification);
        }
        catch (Exception ex)
        {
            Debug.Log(ex.Message);
            return null;
        }
    }

    private ActionLog StringToActionLog(string _string, decimal _actionTurn)
    {
        try
        {
            string sectionString = string.Empty;

            _string.DettachPortionFromString("<ActorId>", "</ActorId>", ref sectionString);
            sectionString = DataLoader.RemoveOpeningAndClosingTags(sectionString, "ActorId");
            int actorId = Convert.ToInt32(sectionString);

            _string.DettachPortionFromString("<ActorName>", "</ActorName>", ref sectionString);
            sectionString = DataLoader.RemoveOpeningAndClosingTags(sectionString, "ActorName");
            string actorName = sectionString;

            _string.DettachPortionFromString("<ActorNickname>", "</ActorNickname>", ref sectionString);
            sectionString = DataLoader.RemoveOpeningAndClosingTags(sectionString, "ActorNickname");
            string actorNickname = sectionString;

            if (_string.StartsWith("<ActionLog_Move>"))
                return StringToMoveActionLog(_string, _actionTurn, actorId, actorName, actorNickname);
            else if (_string.StartsWith("<ActionLog_Attack>"))
                return StringToAttackActionLog(_string, _actionTurn, actorId, actorName, actorNickname);
            else if (_string.StartsWith("<ActionLog_UnitTargetingSkill>")
                || _string.StartsWith("<ActionLog_TileTargetingSkill>"))
                return StringToSkillActionLog(_string, _actionTurn, actorId, actorName, actorNickname);

            return null;
        }
        catch (Exception ex)
        {
            Debug.Log(ex.Message);
            return null;
        }
    }

    private ActionLog_Move StringToMoveActionLog(string _string, decimal _actionTurn, int _actorId, string _actorName, string _actorNickname)
    {
        try
        {
            string sectionString = string.Empty;

            string initialCoordString = string.Empty;
            _string.DettachPortionFromString("<InitialCoord>", "</InitialCoord>", ref initialCoordString);

            initialCoordString.DettachPortionFromString("<X>", "</X>", ref sectionString);
            sectionString = DataLoader.RemoveOpeningAndClosingTags(sectionString, "X");
            int initialCoordX = Convert.ToInt32(sectionString);

            initialCoordString.DettachPortionFromString("<Y>", "</Y>", ref sectionString);
            sectionString = DataLoader.RemoveOpeningAndClosingTags(sectionString, "Y");
            int initialCoordY = Convert.ToInt32(sectionString);

            _2DCoord initialCoord = new _2DCoord(initialCoordX, initialCoordY);

            string eventualCoordString = string.Empty;
            _string.DettachPortionFromString("<EventualCoord>", "</EventualCoord>", ref eventualCoordString);

            eventualCoordString.DettachPortionFromString("<X>", "</X>", ref sectionString);
            sectionString = DataLoader.RemoveOpeningAndClosingTags(sectionString, "X");
            int eventualCoordX = Convert.ToInt32(sectionString);

            eventualCoordString.DettachPortionFromString("<Y>", "</Y>", ref sectionString);
            sectionString = DataLoader.RemoveOpeningAndClosingTags(sectionString, "Y");
            int eventualCoordY = Convert.ToInt32(sectionString);

            _2DCoord eventualCoord = new _2DCoord(eventualCoordX, eventualCoordY);

            return new ActionLog_Move(_actionTurn, _actorId, _actorName, _actorNickname, initialCoord, eventualCoord);
        }
        catch (Exception ex)
        {
            Debug.Log(ex.Message);
            return null;
        }
    }

    private ActionLog_Attack StringToAttackActionLog(string _string, decimal _actionTurn, int _actorId, string _actorName, string _actorNickname)
    {
        try
        {
            string sectionString = string.Empty;

            _string.DettachPortionFromString("<ActorLocationTileIndex>", "</ActorLocationTileIndex>", ref sectionString);
            sectionString = DataLoader.RemoveOpeningAndClosingTags(sectionString, "ActorLocationTileIndex");
            int actorLocationTileIndex = Convert.ToInt32(sectionString);

            _string.DettachPortionFromString("<TargetId>", "</TargetId>", ref sectionString);
            sectionString = DataLoader.RemoveOpeningAndClosingTags(sectionString, "TargetId");
            int targetId = Convert.ToInt32(sectionString);

            _string.DettachPortionFromString("<TargetLocationTileIndex>", "</TargetLocationTileIndex>", ref sectionString);
            sectionString = DataLoader.RemoveOpeningAndClosingTags(sectionString, "TargetLocationTileIndex");
            int targetLocationTileIndex = Convert.ToInt32(sectionString);

            return new ActionLog_Attack(_actionTurn, _actorId, _actorName, _actorNickname, actorLocationTileIndex, targetId, targetLocationTileIndex);
        }
        catch (Exception ex)
        {
            Debug.Log(ex.Message);
            return null;
        }
    }

    private ActionLog_Skill StringToSkillActionLog(string _string, decimal _actionTurn, int _actorId, string _actorName, string _actorNickname)
    {
        try
        {
            string sectionString = string.Empty;

            _string.DettachPortionFromString("<SkillName>", "</SkillName>", ref sectionString);
            sectionString = DataLoader.RemoveOpeningAndClosingTags(sectionString, "SkillName");
            string skillName = sectionString;

            _string.DettachPortionFromString("<ActorLocationTileIndex>", "</ActorLocationTileIndex>", ref sectionString);
            sectionString = DataLoader.RemoveOpeningAndClosingTags(sectionString, "ActorLocationTileIndex");
            int actorLocationTileIndex = Convert.ToInt32(sectionString);

            _string.DettachPortionFromString("<AnimationId>", "</AnimationId>", ref sectionString);
            sectionString = DataLoader.RemoveOpeningAndClosingTags(sectionString, "AnimationId");
            int animationId = Convert.ToInt32(sectionString);

            if (_string.StartsWith("<ActionLog_UnitTargetingSkill>"))
                return StringToUnitTargetingSkillActionLog(_string, _actionTurn, _actorId, _actorName, _actorNickname, skillName, actorLocationTileIndex, animationId);
            if (_string.StartsWith("<ActionLog_TileTargetingSkill>"))
                return StringToTileTargetingSkillActionLog(_string, _actionTurn, _actorId, _actorName, _actorNickname, skillName, actorLocationTileIndex, animationId);

            return null;
        }
        catch (Exception ex)
        {
            Debug.Log(ex.Message);
            return null;
        }
    }

    private ActionLog_UnitTargetingSkill StringToUnitTargetingSkillActionLog(string _string, decimal _actionTurn, int _actorId, string _actorName, string _actorNickname, string _skillName, int _actorLocationTileIndex, int _animationId)
    {
        try
        {
            string sectionString = string.Empty;

            _string.DettachPortionFromString("<Targets>", "</Targets>", ref sectionString);
            sectionString = DataLoader.RemoveOpeningAndClosingTags(sectionString, "Targets");
            List<Tuple<string, string, string>> targetsName_Nickname_OwnerName = new List<Tuple<string, string, string>>();
            string targetString = string.Empty;
            while (sectionString != "")
            {
                sectionString = sectionString.DettachPortionFromString("<Target>", "</Target>", ref targetString);

                string name = string.Empty;
                targetString.DettachPortionFromString("<Name>", "</Name>", ref name);
                name = DataLoader.RemoveOpeningAndClosingTags(name, "Name");

                string nickname = string.Empty;
                targetString.DettachPortionFromString("<Nickname>", "</Nickname>", ref nickname);
                nickname = DataLoader.RemoveOpeningAndClosingTags(nickname, "Nickname");

                string ownerName = string.Empty;
                targetString.DettachPortionFromString("<OwnerName>", "</OwnerName>", ref ownerName);
                ownerName = DataLoader.RemoveOpeningAndClosingTags(ownerName, "OwnerName");

                targetsName_Nickname_OwnerName.Add(new Tuple<string, string, string>(name, nickname, ownerName));
            }

            return new ActionLog_UnitTargetingSkill(_actionTurn, _actorId, _actorName, _actorNickname, _skillName, _actorLocationTileIndex, _animationId, targetsName_Nickname_OwnerName);
        }
        catch (Exception ex)
        {
            Debug.Log(ex.Message);
            return null;
        }
    }

    private ActionLog_TileTargetingSkill StringToTileTargetingSkillActionLog(string _string, decimal _actionTurn, int _actorId, string _actorName, string _actorNickname, string _skillName, int _actorLocationTileIndex, int _animationId)
    {
        try
        {
            string sectionString = string.Empty;

            _string.DettachPortionFromString("<Coords>", "</Coords>", ref sectionString);
            sectionString = DataLoader.RemoveOpeningAndClosingTags(sectionString, "Coords");
            List<_2DCoord> targetCoords = new List<_2DCoord>();
            string coordString = string.Empty;
            while (sectionString != "")
            {
                sectionString = sectionString.DettachPortionFromString("<Coord>", "</Coord>", ref coordString);

                string coordStringX = string.Empty;
                coordString.DettachPortionFromString("<X>", "</X>", ref coordStringX);
                coordStringX = DataLoader.RemoveOpeningAndClosingTags(coordStringX, "X");
                int x = Convert.ToInt32(coordStringX);

                string coordStringY = string.Empty;
                coordString.DettachPortionFromString("<Y>", "</Y>", ref coordStringY);
                coordStringY = DataLoader.RemoveOpeningAndClosingTags(coordStringY, "Y");
                int y = Convert.ToInt32(coordStringY);

                targetCoords.Add(new _2DCoord(x, y));
            }

            return new ActionLog_TileTargetingSkill(_actionTurn, _actorId, _actorName, _actorNickname, _skillName, _actorLocationTileIndex, _animationId, targetCoords);
        }
        catch (Exception ex)
        {
            Debug.Log(ex.Message);
            return null;
        }
    }
}

public struct OpponentUnitInfo
{
    public int UnitIndex;
    public int Id;
    public int MaxHP;
    public int RemainingHP;
}
