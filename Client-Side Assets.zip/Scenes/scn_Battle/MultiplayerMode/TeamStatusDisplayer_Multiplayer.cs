﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine.UI;
using UnityEngine;
using System;
using EEANGames.TBSG._01.MainClassLib;
using EEANGames.ImageConverter.Unity;
using EEANGames.UnityEngine.ExtensionMethods;

public class TeamStatusDisplayer_Multiplayer : MonoBehaviour {

    #region Serialized Fields
    public GameObject UnitStatusPrefab;
    public GameObject StatusEffectIconPrefab;
    #endregion

    #region Properties
    #endregion

    #region Private Fields
    private InfoPanelManager_Unit_Multiplayer m_unitInfoPanelManager;

    private List<Button> m_unitButtons;
    private List<Image> m_unitImages;
    private List<Image> m_frameTextureImages;
    private List<Button> m_infoButtons;
    private List<Transform> m_statusEffects;
    private List<Slider> m_hpBars;
    private List<Text> m_hpTexts;

    private UnityBattleSystem_Multiplayer m_mainScript;

    private List<PlayerUnitController> m_unitControllers;

    private bool m_isInitialized;

    private int m_currentSelectedUnitIndex;
    #endregion

    // Awake is called before Update for the first frame
    void Awake () {
        m_isInitialized = false;

        m_unitInfoPanelManager = this.transform.root.GetComponent<InfoPanelManager_Unit_Multiplayer>();

        m_unitButtons = new List<Button>();
        m_unitImages = new List<Image>();
        m_frameTextureImages = new List<Image>();
        m_infoButtons = new List<Button>();
        m_statusEffects = new List<Transform>();
        m_hpBars = new List<Slider>();
        m_hpTexts = new List<Text>();

        m_unitControllers = new List<PlayerUnitController>();

        m_currentSelectedUnitIndex = -1;
	}
	
	// Update is called once per frame
	void Update () {
        if (!m_isInitialized)
            Initialize();

        if (m_isInitialized)
        {
            PlayerController_Multiplayer tmp_playerController = m_mainScript.PlayerController;
            if (tmp_playerController.SelectedAlliedUnitId != m_currentSelectedUnitIndex)
            {
                m_currentSelectedUnitIndex = tmp_playerController.SelectedAlliedUnitId;
                UpdateHighlight();
            }
            
        }
	}

    private void Initialize()
    {
        try
        {
            if (m_mainScript == null)
                m_mainScript = this.transform.root.GetComponent<UnityBattleSystem_Multiplayer>();
            if (m_mainScript == null)
                return;

            if (m_mainScript.IsInitialized)
            {
                int playerId = m_mainScript.PlayerController.PlayerId;
                List<GameObject> tmp_unitReferences = m_mainScript.PlayerUnits;
                m_unitControllers.Clear();
                for (int i = 0; i < tmp_unitReferences.Count; i++)
                {
                    PlayerUnitController tmp_unitController = tmp_unitReferences[i].GetComponent<PlayerUnitController>();
                    m_unitControllers.Add(tmp_unitController);

                    GameObject tmp_unitStatus = Instantiate(UnitStatusPrefab, this.transform);
                    tmp_unitStatus.name = "UnitStatus@" + (i + 1).ToString();
                }

                m_unitButtons.Clear();
                m_unitImages.Clear();
                m_frameTextureImages.Clear();
                m_infoButtons.Clear();
                m_statusEffects.Clear();
                m_hpBars.Clear();
                m_hpTexts.Clear();

                foreach (Transform unitStatus in this.transform)
                {
                    Transform tmp_button = unitStatus.Find("Button@Unit");
                    m_unitButtons.Add(tmp_button.GetComponent<Button>());
                    m_unitImages.Add(tmp_button.Find("Image@Unit").GetComponent<Image>());
                    m_frameTextureImages.Add(tmp_button.Find("Image@Frame").Find("Image@Texture").GetComponent<Image>());
                    m_infoButtons.Add(tmp_button.Find("Button@Info").GetComponent<Button>());

                    m_statusEffects.Add(unitStatus.Find("StatusEffect"));

                    m_hpBars.Add(unitStatus.Find("Slider@HPBar").GetComponent<Slider>());

                    m_hpTexts.Add(unitStatus.Find("Text@HP").GetComponent<Text>());
                }

                int childCount = this.transform.childCount;
                if (m_unitButtons.Count != childCount
                    || m_unitImages.Count != childCount
                    || m_frameTextureImages.Count != childCount
                    || m_infoButtons.Count != childCount
                    || m_statusEffects.Count != childCount
                    || m_hpBars.Count != childCount
                    || m_hpTexts.Count != childCount)
                {
                    return;
                }

                for (int i = 0; i < tmp_unitReferences.Count; i++)
                {
                    PlayerUnitController tmp_unitController = m_unitControllers[i];
                    m_unitButtons[i].onClick.AddListener(() => m_mainScript.Request_ChangeUnit(tmp_unitController.PrivateIndex));
                    m_infoButtons[i].onClick.AddListener(() => m_unitInfoPanelManager.InstantiateInfoPanel(tmp_unitController));

                    int rarityIndex = (Convert.ToInt32(m_unitControllers[i].UnitReference.BaseInfo.Rarity) / 20) - 1;
                    m_frameTextureImages[i].sprite = SpriteContainer.Instance.RaritySprites[rarityIndex];

                    m_unitImages[i].sprite = UnityImageConverter.ByteArrayToSprite(tmp_unitController.UnitReference.BaseInfo.IconAsBytes);
                }

                TryUpdateTeamStatus();

                Debug.Log("Team Status Panel initialized successfully!");
                m_isInitialized = true;
            }
        }
        catch(Exception ex)
        {
            Debug.Log("TeamStatusDisplayer.Initialize(): " + ex.Message);
        }
    }

    public void TryUpdateTeamStatus()
    {
        UpdateHPInfo();
        UpdateStatusEffects();
    }

    private void UpdateStatusEffects()
    {
        for (int i = 0; i < m_unitControllers.Count; i++)
        {
            m_statusEffects[i].ClearChildren();
            foreach (StatusEffect statusEffect in m_unitControllers[i].UnitReference.StatusEffects)
            {
                GameObject statusEffectIcon = Instantiate(StatusEffectIconPrefab, m_statusEffects[i]);
                // statusEffectIcon.GetComponent<Image>().sprite = Set some image.
                Transform text_timesRemaining = statusEffectIcon.transform.Find("Text@TimesRemaining");
                text_timesRemaining.GetComponent<Text>().text = (statusEffect.Duration.ActivationTimes != 0) ? statusEffect.Duration.ActivationTimes.ToString() : string.Empty;
                Transform text_turnsRemaining = statusEffectIcon.transform.Find("Text@TurnsRemaining");
                text_turnsRemaining.GetComponent<Text>().text = (statusEffect.Duration.Turns != 0m) ? statusEffect.Duration.Turns.ToString() : string.Empty;
            }
        }
    }

    private void UpdateHPInfo()
    {
        try
        {
            for (int i = 0; i < this.transform.childCount; i++)
            {
                int remainingHP = m_unitControllers[i].UnitReference.RemainingHP;
                int maxHP = Calculator.MaxHP(m_unitControllers[i].UnitReference);

                m_hpBars[i].value = (float)remainingHP / maxHP;
                m_hpTexts[i].text = remainingHP.ToString() + " / " + maxHP.ToString();
            }
        }
        catch (Exception ex)
        {
            Debug.Log("TeamStatusDisplayer.RefreshTeamStatus(): " + ex.Message);
        }
    }

    private void UpdateHighlight()
    {
        if (m_currentSelectedUnitIndex > m_frameTextureImages.Count)
            return;

        ResetHighlight();

        if (m_currentSelectedUnitIndex >= 0)
            m_frameTextureImages[m_currentSelectedUnitIndex].color = Color.red;
    }

    private void ResetHighlight()
    {
        foreach (Image frameImage in m_frameTextureImages)
        {
            frameImage.color = Color.white;
        }
    }
}
