﻿using EEANGames;
using EEANGames.TBSG._01.MainClassLib;
using EEANGames.TBSG._01.Unity;
using EEANGames.TBSG._01.Unity.CommonEnums;
using EEANGames.UnityEngine.ExtensionMethods;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using UnityEngine.UI;

public class ActionUIManager_Multiplayer : MonoBehaviour {

    #region Serialized Fields
    public GameObject MoveButtonPrefab;
    public GameObject AttackButtonPrefab;
    public GameObject ItemButtonPrefab;
    public GameObject SkillButtonPrefab;
    #endregion

    #region Properties
    public eActionType CurrentActionSelected { get; private set; }

    public List<PlayerUnitController> UnitControllers { get; private set; }
    public int CurrentUnitId { get; private set; }
    public string NameOfSelectedSkill { get; private set; }

    public bool IsInitialized { get; private set; }
    public bool IsUIOn { get; private set; }
    #endregion

    #region Private Fields
    private UnityBattleSystem_Multiplayer m_mainScript;
    private PlayerController_Multiplayer m_playerController;
    private TileMaskManager_Multiplayer m_tileMaskManager; //m_tileMaskManager checks for this.IsInitialized in order to initialize itself.
    private AnimationController_Multiplayer m_animationController;

    private Transform m_panel_nonUSkillActions;
    private Button m_moveButton;
    private Button m_attackButton;
    private Button m_itemButton;
    private List<Button> m_skillButtons;

    private Button m_confirmationButton;

    private readonly Color m_buttonColor_bright = new Color32(236, 192, 172, 255);
    private readonly Color m_buttonColor_color = new Color32(186, 135, 112, 255);
    private readonly Color m_buttonColor_default = Color.white;
    private readonly Color m_buttonColor_transparent = new Color(0, 0, 0, 0);
    #endregion

    // Use this for initialization
    void Awake() {
        CurrentActionSelected = eActionType.None;
        NameOfSelectedSkill = string.Empty;

        IsInitialized = false;
        IsUIOn = false;
        CurrentUnitId = -1;
        UnitControllers = new List<PlayerUnitController>();

        m_panel_nonUSkillActions = this.transform.Find("Panel@NonUSkillActions");

        m_skillButtons = new List<Button>();

        m_confirmationButton = this.transform.Find("Panel@ActionConfirmation").Find("Button@ConfirmAction").GetComponent<Button>();
    }

    // Update is called once per frame
    void Update() {
        if (!IsInitialized)
            Initialize();

        if (IsInitialized)
        {
            if ((m_playerController.IsMyTurn && !IsUIOn)
                || (!m_playerController.IsMyTurn && IsUIOn))
            {
                CurrentActionSelected = eActionType.None;
                ResetUI(m_playerController.IsMyTurn);
                StartCoroutine(DisplayTargetAreaForAction(CurrentActionSelected));
            }
            else if (m_playerController.IsMyTurn && CurrentUnitId != m_playerController.SelectedAlliedUnitId)
            {
                CurrentUnitId = m_playerController.SelectedAlliedUnitId;
                ResetUI(m_playerController.IsMyTurn);

                if (CurrentActionSelected == eActionType.Skill)
                    ChangeAction(eActionType.None);
                else
                    StartCoroutine(DisplayTargetAreaForAction(CurrentActionSelected));
            }
        }
    }

    private void Initialize()
    {
        try
        {
            if (m_mainScript == null)
                m_mainScript = this.transform.root.GetComponent<UnityBattleSystem_Multiplayer>();
            if (m_mainScript == null)
                return;

            if (m_mainScript.IsInitialized)
            {
                if (m_playerController == null)
                    m_playerController = m_mainScript.PlayerController;
                if (m_playerController == null)
                    return;

                if (m_tileMaskManager == null)
                    m_tileMaskManager = GameObject.FindGameObjectWithTag("GameBoard").GetComponent<TileMaskManager_Multiplayer>();
                if (m_tileMaskManager == null)
                    return;

                if (m_animationController == null)
                    m_animationController = this.transform.root.GetComponent<AnimationController_Multiplayer>();
                if (m_animationController == null)
                    return;

                UnitControllers.Clear();
                List<GameObject> tmp_units = m_mainScript.PlayerUnits;
                foreach (GameObject unit in tmp_units)
                {
                    UnitControllers.Add(unit.GetComponent<PlayerUnitController>());
                }

                if (UnitControllers.Count != tmp_units.Count)
                    return;

                Debug.Log("ActionUIManager: Initialized successfully!");
                IsInitialized = true;
            }
        }
        catch (Exception ex)
        {
            Debug.Log("ActionUIDisplayer.Initialize() : " + ex.Message);
        }
    }

    public void ChangeAction(eActionType _action, string _skillName = "")
    {
        if (m_animationController.LockUI)
            return;

        if (CurrentActionSelected != _action
            || NameOfSelectedSkill != _skillName)
        {
            Debug.Log("ActionSelected: " + CurrentActionSelected.ToString() + " -> " + _action.ToString() + ((NameOfSelectedSkill != _skillName) ? " [" + NameOfSelectedSkill + " -> " + _skillName.ToString() + "]" : string.Empty));
            CurrentActionSelected = _action;
            NameOfSelectedSkill = _skillName;
            UpdateUI();
            StartCoroutine(DisplayTargetAreaForAction(CurrentActionSelected, _skillName));
        }
    }

    public void ConfirmAction()
    {
        if (!m_tileMaskManager.IsInitialized)
            return;

        if (!m_animationController.IsInitialized || m_animationController.LockUI)
            return;

        List<_2DCoord> selectedCoords = m_tileMaskManager.SelectedCoords();

        //List<EFFECT_RESULT> effectResult;
        switch (CurrentActionSelected)
        {
            case eActionType.Move:
                m_mainScript.Request_MoveUnit(selectedCoords.First());
                UpdateUI();
                break;
            case eActionType.Attack:
                m_mainScript.Request_Attack(selectedCoords);
                //Animation for effectResults
                UpdateUI();
                break;
            case eActionType.Skill:
                m_mainScript.Request_SkillUse(NameOfSelectedSkill, selectedCoords);
                //Animation for effectResults
                UpdateUI();
                break;
            default:
                break;
        }

        m_tileMaskManager.DisplayTargetArea(); //Display target are updated after executing an action
    }

    IEnumerator DisplayTargetAreaForAction(eActionType _action, string _skillName = "")
    {
        switch (_action)
        {
            case eActionType.Move:
                NameOfSelectedSkill = string.Empty;
                yield return StartCoroutine(m_mainScript.Request_UpdateMovableArea());
                break;
            case eActionType.Attack:
                NameOfSelectedSkill = string.Empty;
                yield return StartCoroutine(m_mainScript.Request_UpdateAttackTargetableArea());
                break;
            case eActionType.Skill:
                NameOfSelectedSkill = _skillName;
                yield return StartCoroutine(m_mainScript.Request_UpdateSkillTargetableArea(_skillName));
                break;
            default:
                m_mainScript.UpdateTargetableAreaToNull();
                break;
        }

        m_tileMaskManager.DisplayTargetArea();
    }

    private void ResetUI(bool _isMyTurn)
    {
        try
        {
            m_panel_nonUSkillActions.ClearChildren();

            if (_isMyTurn)
            {
                GameObject moveButton = Instantiate(MoveButtonPrefab, m_panel_nonUSkillActions);
                m_moveButton = moveButton.GetComponent<Button>();
                m_moveButton.onClick.AddListener(() => ChangeAction(eActionType.Move));

                GameObject attackButton = Instantiate(AttackButtonPrefab, m_panel_nonUSkillActions);
                m_attackButton = attackButton.GetComponent<Button>();
                m_attackButton.onClick.AddListener(() => ChangeAction(eActionType.Attack));

                GameObject itemButton = Instantiate(ItemButtonPrefab, m_panel_nonUSkillActions);
                m_itemButton = itemButton.GetComponent<Button>();
                m_itemButton.onClick.AddListener(() => ChangeAction(eActionType.Item));

                if (CurrentUnitId >= 0 && CurrentUnitId < UnitControllers.Count)
                {
                    m_skillButtons.Clear();
                    foreach (OrdinarySkill skill in UnitControllers[CurrentUnitId].UnitReference.Skills.OfType<OrdinarySkill>())
                    {
                        GameObject tmp_skill = Instantiate(SkillButtonPrefab, m_panel_nonUSkillActions);
                        tmp_skill.name = skill.BaseInfo.Name;
                        SkillDetailPopUpController tmp_detailPopUpController = tmp_skill.GetComponent<SkillDetailPopUpController>();
                        tmp_detailPopUpController.SkillName.text = skill.BaseInfo.Name;
                        tmp_detailPopUpController.Effects.text = "";
                            // = skill.BaseInfo.Effect.SuccessRate.ToValue<int>(m_mainScript.BattleSystemCore, UnitControllers[CurrentUnitId].UnitReference, skill.Level).ToString();
                        Button tmp_skillButton = tmp_skill.GetComponent<Button>();
                        m_skillButtons.Add(tmp_skillButton);
                        tmp_skillButton.onClick.AddListener(() => ChangeAction(eActionType.Skill, skill.BaseInfo.Name));
                    }
                }

                UpdateUI();

                if (!IsUIOn)
                    IsUIOn = true;
            }
            else
                IsUIOn = false;
        }
        catch (Exception ex)
        {
            Debug.Log("ActionUIDisplayer.ResetUI() : " + ex.Message);
        }
    }

    private void UpdateUI()
    {
        try
        {
            UpdateMoveButton();
            UpdateAttackButton();
            UpdateItemButton();
            UpdateSkillButtons();
            UpdateConfirmationButton();
        }
        catch (Exception ex)
        {
            Debug.Log("ActionUIDisplayer.UpdateUI() : " + ex.Message);
        }
    }

    private void UpdateMoveButton()
    {
        try
        {
            if (CurrentUnitId < 0
                || m_playerController.HasMoved
                /*|| unit.movementBind*/)
            {
                m_moveButton.image.color = m_buttonColor_default;
            }
            else if (CurrentActionSelected == eActionType.Move)
                m_moveButton.image.color = m_buttonColor_bright;
            else
                m_moveButton.image.color = m_buttonColor_color;

            if (CurrentUnitId >= 0
                && CurrentUnitId < (m_playerController.PlayerData as PlayerOnBoard).AlliedUnits.Count
                && !m_playerController.HasMoved
                && CurrentActionSelected != eActionType.Move)
            {
                m_moveButton.interactable = true;
            }
            else
                m_moveButton.interactable = false;

            /* if (unit.movementBind)
             *      m_moveButton.Find("Image@BindMark").GetComponent<Image>().color = m_buttonColor_default;
             * else
             */
            m_moveButton.transform.Find("Image@BindMark").GetComponent<Image>().color = m_buttonColor_transparent;

            if ((1 == 0 /*unit.moveBind*/
                    || m_playerController.HasMoved)
                && CurrentActionSelected == eActionType.Move)
            {
                ChangeAction(eActionType.None);
            }
        }
        catch (Exception ex)
        {
            Debug.Log("ActionUIDisplayer.UpdateMoveButton() : " + ex.Message);
        }
    }

    private void UpdateAttackButton()
    {
        try
        {
            if (CurrentUnitId < 0
                || m_playerController.HasAttacked
                /*|| unit.attackBind*/)
            {
                m_attackButton.image.color = m_buttonColor_default;
            }
            else if (CurrentActionSelected == eActionType.Attack)
                m_attackButton.image.color = m_buttonColor_bright;
            else
                m_attackButton.image.color = m_buttonColor_color;

            if (CurrentUnitId >= 0
                && CurrentUnitId < (m_playerController.PlayerData as PlayerOnBoard).AlliedUnits.Count
                && !m_playerController.HasAttacked
                && CurrentActionSelected != eActionType.Attack)
            {
                m_attackButton.interactable = true;
            }
            else
                m_attackButton.interactable = false;

            /* if (unit.movementBind)
             *      m_attackButton.Find("Image@BindMark").GetComponent<Image>().color = m_buttonColor_default;
             * else
             */
            m_attackButton.transform.Find("Image@BindMark").GetComponent<Image>().color = m_buttonColor_transparent;

            if ((1 == 0 /*|| unit.attackBind*/
                    || m_playerController.HasAttacked)
                && CurrentActionSelected == eActionType.Attack)
            {
                ChangeAction(eActionType.None);
            }
        }
        catch (Exception ex)
        {
            Debug.Log("ActionUIDisplayer.UpdateAttackButton() : " + ex.Message);
        }
    }

    private void UpdateItemButton()
    {
        try
        {
            if (true/*unit.itemBind*/)
            {
                m_itemButton.interactable = false;
                m_itemButton.image.color = m_buttonColor_default;
                //m_itemButton.Find("Image@BindMark").GetComponent<Image>().color = m_buttonColor_default;
            }
            else
            {
                m_itemButton.interactable = true;
                m_itemButton.transform.Find("Image@BindMark").GetComponent<Image>().color = m_buttonColor_transparent;


                if (CurrentActionSelected == eActionType.Item)
                    m_itemButton.image.color = m_buttonColor_bright;
                else
                    m_itemButton.image.color = m_buttonColor_color;
            }
        }
        catch (Exception ex)
        {
            Debug.Log("ActionUIDisplayer.UpdateItemButton() : " + ex.Message);
        }
    }

    private void UpdateSkillButtons()
    {
        try
        {
            foreach (Button skillButton in m_skillButtons)
            {
                bool areResourceEnoughForSkillExecution = UnitControllers[CurrentUnitId].UnitReference.AreResourcesEnoughForSkillExecution(skillButton.name);

                if (1 == 0/*unit.skillBind*/
                    || !areResourceEnoughForSkillExecution)
                {
                    skillButton.image.color = m_buttonColor_default;
                    //skillButton.Find("Image@BindMark").GetComponent<Image>().color = m_buttonColor_default;
                }
                else
                {
                    skillButton.transform.Find("Image@BindMark").GetComponent<Image>().color = m_buttonColor_transparent;

                    if (CurrentActionSelected == eActionType.Skill && NameOfSelectedSkill == skillButton.name)
                        skillButton.image.color = m_buttonColor_bright;
                    else
                        skillButton.image.color = m_buttonColor_color;
                }

                if (1 == 1/*!unit.skillBind*/
                     && areResourceEnoughForSkillExecution
                     && (CurrentActionSelected != eActionType.Skill
                            || (CurrentActionSelected == eActionType.Skill && NameOfSelectedSkill != skillButton.name)))
                {
                    skillButton.interactable = true;
                }
                else
                    skillButton.interactable = false;

                if ((1 == 0 /*|| unit.skillBind*/
                        || !areResourceEnoughForSkillExecution)
                    && (CurrentActionSelected == eActionType.Skill && NameOfSelectedSkill == skillButton.name))
                {
                    ChangeAction(eActionType.None);
                }
            }
        }
        catch (Exception ex)
        {
            Debug.Log("ActionUIDisplayer.UpdateSkillButton() : " + ex.Message);
        }
    }

    public void UpdateConfirmationButton()
    {
        try
        {
            if (!m_tileMaskManager.IsInitialized)
                return;

            if (CurrentActionSelected == eActionType.None
                || m_tileMaskManager.NumOfTilesSelected() <= 0)
            {
                m_confirmationButton.interactable = false;
            }
            else
                m_confirmationButton.interactable = true;

            Debug.Log("Confirmation Button Updated.");
        }
        catch (Exception ex)
        {
            Debug.Log("ActionUIDisplayer.UpdateConfirmationButton() : " + ex.Message);
        }
    }
}
