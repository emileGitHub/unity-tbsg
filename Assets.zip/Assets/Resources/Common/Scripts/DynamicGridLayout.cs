﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

[RequireComponent(typeof(GridLayoutGroup))]
[RequireComponent(typeof(RectTransform))]
public class DynamicGridLayout : MonoBehaviour {

    public int NumOfElementsPerRow;
    public float ElementHeightInRelationToWidth;
    public float PaddingPercentageLeft;
    public float PaddingPercentageRight;
    public float PaddingPercentageTop;
    public float PaddingPercentageBottom;
    public float SpacingPercentageX;
    public float SpacingPercentageY;

    private GridLayoutGroup GridLayout;
    private RectTransform RT;
    private float RtWidth;
    private float RtHeight;
    private float TotalPadding;
    private float TotalSpacingBetweenElementsPerRow;
    private float ElementSizeX;
    private float ElementSizeY;

    // Use this for initialization
    void Awake () {
        GridLayout = this.GetComponent<GridLayoutGroup>();
        RT = this.GetComponent<RectTransform>();

        RefreshGridLayout();
    }
	
	// Update is called once per frame
	void Update () {
		if(RT.sizeDelta.x != RtWidth)
        {
            RefreshGridLayout();
        }
	}

    private void RefreshGridLayout()
    {
        RtWidth = RT.rect.width;
        RtHeight = RT.rect.height;

        //Set padding
        GridLayout.padding.left = Convert.ToInt32((float)RtWidth * PaddingPercentageLeft);
        GridLayout.padding.right = Convert.ToInt32((float)RtWidth * PaddingPercentageRight);
        GridLayout.padding.top = Convert.ToInt32((float)RtHeight * PaddingPercentageTop);
        GridLayout.padding.bottom = Convert.ToInt32((float)RtHeight * PaddingPercentageBottom);

        //Set spacing
        GridLayout.spacing = new Vector2((float)RtWidth * SpacingPercentageX, (float)RtHeight * SpacingPercentageY);

        //Calculate values required to calculate the size of elements
        TotalPadding = GridLayout.padding.left + GridLayout.padding.right;
        TotalSpacingBetweenElementsPerRow = GridLayout.spacing.x * (NumOfElementsPerRow - 1);

        //Set size of each element within the grid
        ElementSizeX = (RtWidth - (TotalPadding + TotalSpacingBetweenElementsPerRow)) / NumOfElementsPerRow;
        ElementSizeY = ElementSizeX * ElementHeightInRelationToWidth;

        //Set size of each cell within the grid
        GridLayout.cellSize = new Vector2(ElementSizeX, ElementSizeY);
    }
}
