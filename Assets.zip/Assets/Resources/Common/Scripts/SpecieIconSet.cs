﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SpecieIconSet : MonoBehaviour {

    private static SpecieIconSet instance;

    public List<Sprite> SpecieIcons;
    public static List<Sprite> Icons;

    // Use this for initialization
    void Awake()
    {
        if (instance == null)
        {
            instance = this;
            Icons = SpecieIcons;
            DontDestroyOnLoad(this.gameObject);
        }
        else if (instance != this)
        {
            Destroy(this.gameObject); // Avoid having multiple components of the same type
        }
    }
}
