﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class UnitIconManager : MonoBehaviour {

    private static UnitIconManager instance;

    public List<Sprite> UnitIcons;
    public static List<Sprite> Icons;

	// Use this for initialization
	void Awake () {
        if (instance == null)
        {
            instance = this;
            Icons = UnitIcons;
            DontDestroyOnLoad(this.gameObject);
        }
        else if (instance != this)
        {
            Destroy(this.gameObject); // Avoid having multiple components of the same type
        }
    }
}
