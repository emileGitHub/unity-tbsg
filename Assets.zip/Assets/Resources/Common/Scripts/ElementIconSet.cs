﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ElementIconSet : MonoBehaviour {

    private static ElementIconSet instance;

    public List<Sprite> ElementIcons;
    public static List<Sprite> Icons;

    // Use this for initialization
    void Awake()
    {
        if (instance == null)
        {
            instance = this;
            Icons = ElementIcons;
            DontDestroyOnLoad(this.gameObject);
        }
        else if (instance != this)
        {
            Destroy(this.gameObject); // Avoid having multiple components of the same type
        }
    }
}
