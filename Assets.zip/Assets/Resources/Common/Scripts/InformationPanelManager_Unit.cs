﻿using EEANGame.TBSG.V1_0.MainClassLib;
using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

[RequireComponent(typeof(InformationPanelManager))]
public class InformationPanelManager_Unit : MonoBehaviour {

    [SerializeField]
    public GameObject UnitInfoPanelPrefab;

    private InformationPanelManager mainInformationPanelManager;

    private List<GameObject> InfoPanels;
    private Transform Canvas;

    // Use this for initialization
    void Awake()
    {
        mainInformationPanelManager = this.transform.GetComponent<InformationPanelManager>();
        InfoPanels = new List<GameObject>();
        Canvas = GameObject.FindGameObjectWithTag("Canvas").transform;
    }

    public void InstantiateInfoPanel(int _unitUniqueId)
    {
        GameObject infoPanel = Instantiate(UnitInfoPanelPrefab, Canvas, false);
        infoPanel.transform.Find("BackGround").Find("CloseButton").GetComponent<Button>().onClick.AddListener(() => RemoveInfoPanel());
        //RectTransform rt = infoPanel.GetComponent<RectTransform>();
        InfoPanels.Add(infoPanel);
        mainInformationPanelManager.AddInfoPanel(infoPanel);

        IndividualUnitData unitData = PlayerDataManager.Player.UnitsData.Find(x => x.UniqueId == _unitUniqueId);

        UpdateInfoPanel(infoPanel, unitData);
    }

    private void UpdateInfoPanel(GameObject _infoPanel, IndividualUnitData _unitData)
    {
        Transform infoPanelBG = _infoPanel.transform.Find("BackGround");

        infoPanelBG.Find("UnitNickname").GetComponent<Text>().text = _unitData.Nickname;

        Transform unitCard = infoPanelBG.Find("UnitCard");
        unitCard.Find("NamePlate").Find("Name").GetComponent<Text>().text = _unitData.Name;
        unitCard.Find("Level").GetComponent<Text>().text = _unitData.Level.ToString();
        unitCard.Find("MaxHP").Find("Amount").GetComponent<Text>().text = Calculator.MaxHP(_unitData).ToString();
        unitCard.Find("PhyStr").Find("Amount").GetComponent<Text>().text = Calculator.PhysicalStrength(_unitData).ToString();
        unitCard.Find("PhyRes").Find("Amount").GetComponent<Text>().text = Calculator.PhysicalResistance(_unitData).ToString();
        unitCard.Find("MagStr").Find("Amount").GetComponent<Text>().text = Calculator.MagicalStrength(_unitData).ToString();
        unitCard.Find("MagRes").Find("Amount").GetComponent<Text>().text = Calculator.MagicalResistance(_unitData).ToString();
        unitCard.Find("Vit").Find("Amount").GetComponent<Text>().text = Calculator.Vitality(_unitData).ToString();
        unitCard.Find("Graphic").GetComponent<Image>().sprite = UnitIconManager.Icons[_unitData.IconAsByteArray.Id - 1];

        int element1_index = Convert.ToInt32(_unitData.Elements[0]) - 1;
        int element2_index = Convert.ToInt32(_unitData.Elements[1]) - 1;
        int specie1_index = Convert.ToInt32(_unitData.SpecieTypes[0]) - 1;
        int specie2_index = Convert.ToInt32(_unitData.SpecieTypes[1]) - 1;
        int specie3_index = Convert.ToInt32(_unitData.SpecieTypes[2]) - 1;

        Transform E1 = unitCard.Find("ElementIcon1");
        Transform E2 = unitCard.Find("ElementIcon2");
        Transform S1 = unitCard.Find("SpecieIcon1");
        Transform S2 = unitCard.Find("SpecieIcon2");
        Transform S3 = unitCard.Find("SpecieIcon3");

        if (element1_index < 0)
            E1.GetComponent<CanvasRenderer>().SetAlpha(0);
        else
        {
            E1.GetComponent<CanvasRenderer>().SetAlpha(1f);
            E1.GetComponent<Image>().sprite = ElementIconSet.Icons[element1_index];
        }

        if (element2_index < 0)
            E2.GetComponent<CanvasRenderer>().SetAlpha(0);
        else
        {
            E2.GetComponent<CanvasRenderer>().SetAlpha(1f);
            E2.GetComponent<Image>().sprite = ElementIconSet.Icons[element2_index];
        }

        if (specie1_index < 0)
            S1.GetComponent<CanvasRenderer>().SetAlpha(0);
        else
        {
            S1.GetComponent<CanvasRenderer>().SetAlpha(1f);
            S1.GetComponent<Image>().sprite = SpecieIconSet.Icons[specie1_index];
        }

        if (specie2_index < 0)
            S2.GetComponent<CanvasRenderer>().SetAlpha(0);
        else
        {
            S2.GetComponent<CanvasRenderer>().SetAlpha(1f);
            S2.GetComponent<Image>().sprite = SpecieIconSet.Icons[specie2_index];
        }

        if (specie3_index < 0)
            S3.GetComponent<CanvasRenderer>().SetAlpha(0);
        else
        {
            S3.GetComponent<CanvasRenderer>().SetAlpha(1f);
            S3.GetComponent<Image>().sprite = SpecieIconSet.Icons[specie3_index];
        }
    }

    //Remove newest info panel
    public void RemoveInfoPanel()
    {
        GameObject infoPanel = InfoPanels[InfoPanels.Count - 1];
        mainInformationPanelManager.RemoveInfoPanel(infoPanel);
        InfoPanels.Remove(infoPanel);
        Destroy(infoPanel);
    }
}
