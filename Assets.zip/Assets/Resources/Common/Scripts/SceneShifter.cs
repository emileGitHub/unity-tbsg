﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

//Referenced by components in the editor
public class SceneShifter : MonoBehaviour {

    public void LoaderScene(string _sceneNameToLoad)
    {
        LoadingSceneIdentifier.SceneName =_sceneNameToLoad;
        SceneManager.LoadScene("LoaderScene");
    }

    public void ToScene(string _sceneNameToLoad)
    {
        SceneManager.LoadScene(_sceneNameToLoad);
    }

}
