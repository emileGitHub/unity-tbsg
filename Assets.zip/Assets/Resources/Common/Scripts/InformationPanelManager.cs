﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class InformationPanelManager : MonoBehaviour {

    public List<GameObject> InfoPanels { get; private set; }
    private Transform Canvas;

    // Use this for initialization
    void Awake()
    {
        InfoPanels = new List<GameObject>();
        Canvas = GameObject.FindGameObjectWithTag("Canvas").transform;
    }

    public void AddInfoPanel(GameObject _infoPanel)
    {
        if (_infoPanel != null)
            InfoPanels.Add(_infoPanel);
    }

    public void RemoveInfoPanel(GameObject _infoPanel)
    {
        if (InfoPanels.Exists(x => x == _infoPanel))
            InfoPanels.Remove(_infoPanel);
    }
}
