﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using EEANGame.TBSG.V1_0.MainClassLib;
using EEANGame.TBSG.V1_0.MainClassLib.DBDataHandler.ForUnity;

public class PlayerDataManager : MonoBehaviour {

    private static PlayerDataManager instance;

    public static Player Player;

    //Use this for initialization
    private void Awake()
    {
        if (instance == null)
        {
            instance = this;
            Player = TxtDataHandler.LoadPlayerData("default", "123456");
            DontDestroyOnLoad(this.gameObject);
        }
        else if (instance != this)
        {
            Destroy(this.gameObject); // Avoid having multiple components of the same type
        }
    } 
}
