﻿using EEANGame.TBSG.V1_0.CommonEnums;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FrameSpriteManager : MonoBehaviour {

    private static FrameSpriteManager instance;

    // Sprite for each rarity
    public Sprite NormalFrame;
    public Sprite BronzeFrame;
    public Sprite SilverFrame;
    public Sprite GoldFrame;
    public Sprite PlatinumFrame;

    //Sprites to be referenced across the scenes
    public static Sprite NormalFrameSprite;
    public static Sprite BronzeFrameSprite;
    public static Sprite SilverFrameSprite;
    public static Sprite GoldFrameSprite;
    public static Sprite PlatinumFrameSprite;

    void Awake()
    {
        if (instance == null)
        {
            instance = this;

            //Set sprites to static properties
            NormalFrameSprite = NormalFrame;
            BronzeFrameSprite = BronzeFrame;
            SilverFrameSprite = SilverFrame;
            GoldFrameSprite = GoldFrame;
            PlatinumFrameSprite = PlatinumFrame;

            DontDestroyOnLoad(this.gameObject);
        }
        else if (instance != this)
        {
            Destroy(this.gameObject); // Avoid having multiple components of the same type
        }
    }

    /// <summary>
    /// Precondition: None.
    /// PostCondition: Will return a Sprite that corresponds to the _rarity.
    /// </summary>
    /// <param name="_rarity"></param>
    public static Sprite FrameSpriteForCorrespondingRarity(eRarity _rarity)
    {
        switch (_rarity)
        {
            default: //case eRarity.NORMAL
                return NormalFrameSprite;
            case eRarity.BRONZE:
                return BronzeFrameSprite;
            case eRarity.SILVER:
                return SilverFrameSprite;
            case eRarity.GOLD:
                return GoldFrameSprite;
            case eRarity.PLATINUM:
                return PlatinumFrameSprite;
        }
    }
}
