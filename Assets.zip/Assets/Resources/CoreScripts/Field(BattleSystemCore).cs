﻿using EEANGame.TBSG.V1_0.CommonEnums;
using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

namespace EEANGame.TBSG.V1_0.MainClassLib
{
    public class Field
    {
        /// <summary>
        /// Ctor
        /// //PreCondition: _board, _player1 and _player2 have been initialized successfully
        /// //PostCondition: Field will be instantiated successfully
        /// </summary>
        /// <param name="_board"></param>
        /// <param name="_player1"></param>
        /// <param name="_player2"></param>
        private Field(Board _board, PlayerOnBoard _player1, PlayerOnBoard _player2)
        {
            Board = _board;

            Players = new PlayerOnBoard[2];
            Players[0] = _player1;
            Players[1] = _player2;

            IsMatchEnd = false;
            IsPlayer1Winner = false;

            CurrentTurnPlayer = Players[0]; // Players[0] Starts the Game

            foreach (PlayerOnBoard pob in Players)
            {
                pob.MaxSP = Rule.SP_AT_INITIALIZATION;
                pob.RemainingSP = pob.MaxSP;
            }

            //Set Initial position for each unit that Players[0] owns
            foreach (var unit in Players[0].AlliedUnits.Select((v, i) => new { v, i }))
            {
                switch(unit.i)
                {
                    default: //case 0;
                        Board.Sockets[0, 2].Unit = unit.v;
                        break;
                    case 1:
                        Board.Sockets[1, 2].Unit = unit.v;
                        break;
                    case 2:
                        Board.Sockets[2, 2].Unit = unit.v;
                        break;
                    case 3:
                        Board.Sockets[2, 1].Unit = unit.v;
                        break;
                    case 4:
                        Board.Sockets[2, 0].Unit = unit.v;
                        break;
                    case 5: // case King
                        Board.Sockets[0, 0].Unit = unit.v;
                        break;
                }
            }

            int size = Rule.SIZE_OF_A_SIDE_OF_BOARD;
            //Set Initial position for each unit that Players[1] owns
            foreach (var unit in Players[1].AlliedUnits.Select((v, i) => new { v, i }))
            {
                switch (unit.i)
                {
                    default: //case 0;
                        Board.Sockets[size - 1, size - 3].Unit = unit.v;
                        break;
                    case 1:
                        Board.Sockets[size - 2, size - 3].Unit = unit.v;
                        break;
                    case 2:
                        Board.Sockets[size - 3, size - 3].Unit = unit.v;
                        break;
                    case 3:
                        Board.Sockets[size - 3, size - 2].Unit = unit.v;
                        break;
                    case 4:
                        Board.Sockets[size - 3, size - 1].Unit = unit.v;
                        break;
                    case 5: // case King
                        Board.Sockets[size - 1, size - 1].Unit = unit.v;
                        break;
                }
            }

            //Assign all existing units into list
            Units = new List<UnitInstance>();
            foreach (PlayerOnBoard pob in Players)
            {
                foreach (UnitInstance unit in pob.AlliedUnits)
                {
                    Units.Add(unit);
                }
            }
        }

        public bool IsMatchEnd { get; private set; }
        public bool IsPlayer1Winner { get; private set; }
        public Board Board { get; private set; }
        public PlayerOnBoard[] Players { get; private set; }

        public PlayerOnBoard CurrentTurnPlayer { get; private set; }

        /// <summary>
        ///List to reference all existing units, regardless of the owner player
        /// </summary>
        public List<UnitInstance> Units { get; set; }

        /// <summary>
        /// PreCondition: _player1 and _player2 have been initialized successfully. _player1.Teams.Count > _player1TeamIndex; _player2.Teams.Count > _player2TeamIndex; _tileSet.Count > 0;
        /// PostCondition: An Instance of Field will be created and returned successfully.
        /// </summary>
        /// <param name="_player1"></param>
        /// <param name="_player1TeamNum"></param>
        /// <param name="_player2"></param>
        /// <param name="_player2TeamIndex"></param>
        /// <param name="_tileSet"></param>
        /// <returns></returns>
        public static Field NewField(Player _player1, int _player1TeamIndex, Player _player2, int _player2TeamIndex, List<eTileType> _tileSet)
        {
            Board board = new Board(_tileSet);

            PlayerOnBoard player1 = new PlayerOnBoard(_player1, _player1TeamIndex, true);
            PlayerOnBoard player2 = new PlayerOnBoard(_player2, _player2TeamIndex, false);

            return new Field(board, player1, player2);
        }

        /// <summary>
        /// PreCondition: _unit has been initialized successfully.
        /// PostCondition: If succeeded, will return a valid _2DCoord within Board. Will return _2DCoord(-1, -1) if failed.
        /// </summary>
        /// <param name="_unit"></param>
        /// <returns></returns>
        public _2DCoord UnitLocation(UnitInstance _unit)
        {
            for(int x = 1; x <= Rule.SIZE_OF_A_SIDE_OF_BOARD; x++)
            {
                for (int y = 1; y <= Rule.SIZE_OF_A_SIDE_OF_BOARD; y++)
                {
                    if (Board.Sockets[x - 1, y - 1].Unit == _unit)
                        return new _2DCoord(x - 1, y - 1);
                }
            }

            return new _2DCoord(-1, -1); // invalid coordinate for a board
        }

        ///// <summary>
        ///// PreCondition: 
        ///// </summary>
        ///// <param name="_player"></param>
        //public void ChangeSelectedUnit(PlayerOnBoard _player)
        //{
        //    List<UnitInstance> unitsAlive = _player.AlliedUnits.Where(x => x.isAlive == true).ToList();

        //    if (unitsAlive.Count == 0)
        //    {
        //        EndMatch(_player);
        //        return;
        //    }

        //    if (_player.AlliedUnits[_player.SelectedUnitIndex] == unitsAlive.Last<UnitInstance>()) //it means that the unit selected is the unit alive with greatest index number
        //    {
        //        int id_nextUnit = _player.SelectedUnitIndex;

        //        foreach (var c in _player.AlliedUnits.Select((v, i) => new { v, i })) //store UnitInstance into c.v and the index in AlliedUnits that corresponds into c.i
        //        {
        //            if (c.v == unitsAlive[0])
        //            {
        //                id_nextUnit = c.i;
        //                break;
        //            }
        //        }

        //        _player.SelectedUnitIndex = id_nextUnit;
        //    }
        //    else
        //    {
        //        int id_nextUnit = _player.SelectedUnitIndex;

        //        foreach (var c in _player.AlliedUnits.Select((v, i) => new { v, i })) //store UnitInstance into c.v and the index in AlliedUnits that corresponds into c.i
        //        {
        //            if(_player.SelectedUnitIndex < 0) //if none of the units is selected
        //            {
        //                if (c.v == unitsAlive[0])
        //                    _player.SelectedUnitIndex = c.i;
        //            }
        //            else if (c.i == _player.SelectedUnitIndex)
        //            {
        //                id_nextUnit = c.i + 1;
        //                break;
        //            }
        //        }

        //        _player.SelectedUnitIndex = id_nextUnit;
        //    }
        //}

        /// <summary>
        /// PreCondition: _player has been initialized successfully; At least one of the units in _player.AlliedUnits isAlive; _unitIndex matches the index of a unit in _player.AlliedUnits and the unit isAlive;
        /// PostCondtion: If succeeded, assigns _unitIndex to _player.Id_SelectedUnit. Calls EndMatch() in case no units owned by _player isAlive.
        /// </summary>
        /// <param name="_player"></param>
        /// <param name="_alliedUnitIndex"></param>
        public void ChangeSelectedUnit(PlayerOnBoard _player, int _alliedUnitIndex)
        {
            if (_alliedUnitIndex >= _player.AlliedUnits.Count
                || _alliedUnitIndex < 0)
            {
                UnselectUnits(_player);
                return;
            }

            if (_player.AlliedUnits[_alliedUnitIndex].isAlive)
            {
                _player.SelectedUnitIndex = _alliedUnitIndex;
                return;
            }

            List<UnitInstance> unitsAlive = _player.AlliedUnits.Where(x => x.isAlive == true).ToList();

            if (unitsAlive.Count == 0)
            {
                EndMatch(_player);
                return;
            }
        }


        /// <summary>
        /// PreCondition: _player has been initialized successfully.
        /// PostCondition: _player.SelectedUnitIndex is set to -1.
        /// </summary>
        /// <param name="_player"></param>
        public void UnselectUnits(PlayerOnBoard _player)
        {
            _player.SelectedUnitIndex = -1;
        }

        //public List<UnitInstance> SortCharacters(eCharacterPropertyType _property)
        //{
        //    List<UnitInstance> sortedList = new List<UnitInstance>();

        //    foreach (UnitInstance c in Units)
        //    {
        //        sortedList.Add(c);
        //    }

        //    switch (_property)
        //    {
        //        case eCharacterPropertyType.NAME:
        //            for(int i = 1; i <= sortedList.Count; i++)
        //            {
        //                if(sortedList.Sort())
        //            }
        //    }
        //}

        /// <summary>
        /// PreCondition: _effectUser has been initialized successfully and is assigned to a Socket on the Board; _relativeTargetArea.Count > 0;
        /// PostCondition: Returns a List of UnitInstance that was met the requirements (_targetType matched and was within the search area).
        /// </summary>
        /// <param name="_effectUser"></param>
        /// <param name="_relativeTargetArea"></param>
        /// <param name="_targetType"></param>
        /// <returns></returns>
        public List<UnitInstance> SearchUnits_EffectTarget(UnitInstance _effectUser, List<_2DCoord> _relativeTargetArea, eTargetCharacterClassificaton _targetType)
        {
            List<UnitInstance> characters = new List<UnitInstance>(); // List of UnitInstance to return.

            if (_targetType != eTargetCharacterClassificaton.SELF) // If the target Unit is not the _effectUser itself
            {
                foreach (_2DCoord relativeCoord in _relativeTargetArea) // relativeCoord is not the actual coord on the Board
                {
                    _2DCoord relativeCoordCopy = new _2DCoord(relativeCoord.X, relativeCoord.Y); //Copy to avoid overwriting the original

                    _2DCoord realTargetAreaCoord = ToRealCoord(UnitLocation(_effectUser), RelativeCoordToCorrectDirection(_effectUser.OwnerInstance, relativeCoordCopy, _effectUser.DirectionFacing));

                    if (realTargetAreaCoord.X >= 0 && realTargetAreaCoord.X <= Rule.SIZE_OF_A_SIDE_OF_BOARD - 1
                        && realTargetAreaCoord.Y >= 0 && realTargetAreaCoord.Y <= Rule.SIZE_OF_A_SIDE_OF_BOARD - 1) //it will search inside of the board
                    {
                        if (Board.Sockets[realTargetAreaCoord.X, realTargetAreaCoord.Y].Unit != null)
                        {
                            switch (_targetType)
                            {
                                case eTargetCharacterClassificaton.ALLY:
                                    if (Board.Sockets[realTargetAreaCoord.X, realTargetAreaCoord.Y].Unit.OwnerInstance == _effectUser.OwnerInstance)
                                        characters.Add(Board.Sockets[realTargetAreaCoord.X, realTargetAreaCoord.Y].Unit);
                                    break;
                                case eTargetCharacterClassificaton.ENEMY:
                                    if (Board.Sockets[realTargetAreaCoord.X, realTargetAreaCoord.Y].Unit.OwnerInstance != _effectUser.OwnerInstance)
                                        characters.Add(Board.Sockets[realTargetAreaCoord.X, realTargetAreaCoord.Y].Unit);
                                    break;
                                default:
                                    break;
                            }
                        }
                    }
                    //else the value(s) of realTargetAreaCoord is(are) out of the board 
                }
            }
            else // If the target Unit is the _effectUser itself 
                characters.Add(_effectUser); //Do not search anything and just return _effectUser

            return characters;
        }

        public List<UnitInstance> SearchUnits(UnitInstance _effectUser, List<_2DCoord> _relativeTargetArea, eTargetCharacterClassificaton _targetType)
        {
            List<UnitInstance> characters = new List<UnitInstance>();

            if (_targetType != eTargetCharacterClassificaton.SELF)
            {
                foreach (_2DCoord relativeCoord in _relativeTargetArea)
                {
                    _2DCoord relativeCoordCopy = new _2DCoord(relativeCoord.X, relativeCoord.Y); //use this not to overwrite the properties in Effect.TargetArea

                    _2DCoord realTargetAreaCoord = ToRealCoord(UnitLocation(_effectUser), RelativeCoordToCorrectDirection(_effectUser.OwnerInstance, relativeCoordCopy, _effectUser.DirectionFacing));

                    if (realTargetAreaCoord.X >= 0 && realTargetAreaCoord.X <= Rule.SIZE_OF_A_SIDE_OF_BOARD - 1
                        && realTargetAreaCoord.Y >= 0 && realTargetAreaCoord.Y <= Rule.SIZE_OF_A_SIDE_OF_BOARD - 1) //it will search inside of the board
                    {
                        if (Board.Sockets[realTargetAreaCoord.X, realTargetAreaCoord.Y].Unit != null)
                        {
                            switch (_targetType)
                            {
                                case eTargetCharacterClassificaton.ALLY:
                                    if (Board.Sockets[realTargetAreaCoord.X, realTargetAreaCoord.Y].Unit.OwnerInstance == _effectUser.OwnerInstance)
                                        characters.Add(Board.Sockets[realTargetAreaCoord.X, realTargetAreaCoord.Y].Unit);
                                    break;
                                case eTargetCharacterClassificaton.ENEMY:
                                    if (Board.Sockets[realTargetAreaCoord.X, realTargetAreaCoord.Y].Unit.OwnerInstance != _effectUser.OwnerInstance)
                                        characters.Add(Board.Sockets[realTargetAreaCoord.X, realTargetAreaCoord.Y].Unit);
                                    break;
                                default:
                                    break;
                            }
                        }
                    }
                    //else it is out of the board and will throw and IndexOutOfRangeException   
                }
            }
            else
                characters.Add(_effectUser); //Do not search and just return self

            return characters;
        }

        /*-------------------------------------------
                        Action Methods
        -------------------------------------------*/

        /// <summary>
        /// PreCondition: _unit has been initialized successfully; _unit is assigned to a Socket of the Board; _destination is a valid coord within the Board;
        /// PostCondition: _unit will be assigned to Board.Socket[_destination.X, _destination.Y] if not already occupied; If moved successfully, true will be returned;
        /// </summary>
        /// <param name="_unit"></param>
        /// <param name="_destination"></param>
        /// <returns></returns>
        private bool ChangeUnitLocation(UnitInstance _unit, _2DCoord _destination)
        {
            _2DCoord currentLocation = UnitLocation(_unit);

            _2DCoord destination = new _2DCoord(_destination.X, _destination.Y);

            try
            {
                if (Board.Sockets[destination.X, destination.Y].Unit == null) // if there is no Unit assigned to the destination Socket
                {
                    Board.Sockets[currentLocation.X, currentLocation.Y].Unit = null; // remove _unit from the current Socket
                    Board.Sockets[destination.X, destination.Y].Unit = _unit; // assign _unit to the destination Socket

                    return true;
                }
                //else if destination Socket is occupied
                return false;
            }
            catch (Exception ex)
            {
                Debug.Log("Field: at ChangeUnitLocation() " + ex.Message);
                return false;
            }
        }

        /// <summary>
        /// PreCondition: _mover has been initialized successfully;
        /// PostCondition: A list of _2DCoord corresponding to the Sockets on the Board will be returned.
        /// </summary>
        /// <param name="_mover"></param>
        /// <returns></returns>
        public List<_2DCoord> GetMovableArea(UnitInstance _mover)
        {
            List<_2DCoord> targetArea = new List<_2DCoord>();

            List<_2DCoord> relativeTargetArea = new List<_2DCoord>(); // By default, Units can only move one tile towards one of the four directions;
            relativeTargetArea.Add(new _2DCoord(0, 1));
            relativeTargetArea.Add(new _2DCoord(-1, 0));
            relativeTargetArea.Add(new _2DCoord(0, -1));
            relativeTargetArea.Add(new _2DCoord(1, 0));

            foreach (_2DCoord relativeCoord in relativeTargetArea)
            {
                _2DCoord realTargetAreaCoord = ToRealCoord(UnitLocation(_mover), RelativeCoordToCorrectDirection(_mover.OwnerInstance, relativeCoord, _mover.DirectionFacing));

                if (realTargetAreaCoord.X >= 0 && realTargetAreaCoord.X <= Rule.SIZE_OF_A_SIDE_OF_BOARD - 1
                    && realTargetAreaCoord.Y >= 0 && realTargetAreaCoord.Y <= Rule.SIZE_OF_A_SIDE_OF_BOARD - 1) //it will search inside of the board
                {
                    targetArea.Add(realTargetAreaCoord);
                }
                //else the value(s) of realTargetAreaCoord is(are) out of the board 
            }

            return targetArea;
        }

        /// <summary>
        /// [Action Method] 
        /// PreCondition: _unit has been initialized successfully; _unit is assigned to a Socket of the Board;
        /// PostCondition: If the destination is not occupied by other Unit, _unit will be moved to destination and SP will be spent.
        /// </summary>
        /// <param name="_unit"></param>
        /// <param name="_direction"></param>
        /// <returns></returns>
        public bool MoveUnit(UnitInstance _unit, eDirection _direction)
        {
            int requiredCost = 1;

            if(_unit.OwnerInstance.RemainingSP >= requiredCost) // If there is enough SP to spend
            {
                _2DCoord movementVector = new _2DCoord(0, 1);

                ChangeDirectionFacing(_unit, _direction); // Match _unit.DirectionFacing with _direction

                _2DCoord destination = ToRealCoord(UnitLocation(_unit), RelativeCoordToCorrectDirection(_unit.OwnerInstance, movementVector, _unit.DirectionFacing)); // Get the actual coord on the Board

                if (ChangeUnitLocation(_unit, destination)) // If moved successfully
                {
                    _unit.OwnerInstance.RemainingSP -= requiredCost; // Deduct SP required to move from remaining SP
                    return true;
                }
                else
                    return false;
            }

            return false;
        }

        /// <summary>
        /// PreCondition: _unit has been initialized successfully.
        /// PostCondition: _unit.DirectionFacing will be set as _direction.
        /// </summary>
        /// <param name="_unit"></param>
        /// <param name="_direction"></param>
        public void ChangeDirectionFacing(UnitInstance _unit, eDirection _direction)
        {
            if (_unit.DirectionFacing != _direction)
                _unit.DirectionFacing = _direction;
        }

        /// <summary>
        /// PreCondition: _referencePoint is a valid coord on the Board; _relativePointWithCorrectDirection has been passed through function, RelativeCoordToCorrectDirection();
        /// PostCondition: Returns correct _2DCoord based on the _referencePoint (returns the sum of the _referencePoint and _relativePointWithCorrectDirection)
        /// </summary>
        /// <param name="_referencePoint"></param>
        /// <param name="_relativeCoordWithDirectionAdjusted"></param>
        /// <returns></returns>
        private _2DCoord ToRealCoord(_2DCoord _referencePoint, _2DCoord _relativePointWithCorrectDirection)
        {
            return _referencePoint + _relativePointWithCorrectDirection;
        }

        /// <summary>
        /// PreCondition: _ownerPlayer has been initialized successfully; _coord is a valid coord within the Board;
        /// PostCondition: 
        /// </summary>
        /// <param name="_ownerPlayer"></param>
        /// <param name="_coord"></param>
        /// <param name="_directionFromPlayerPerspective"></param>
        /// <returns></returns>
        private _2DCoord RelativeCoordToCorrectDirection(PlayerOnBoard _ownerPlayer, _2DCoord _coord, eDirection _directionFromPlayerPerspective)
        {

            eFieldDirection realDirection = eFieldDirection.POSITIVE_Y; //Set this as default value

            //Set the actual value of realDirection
            if (_ownerPlayer == Players[0])
            {
                switch (_directionFromPlayerPerspective)
                {
                    case eDirection.RIGHT:
                        realDirection = eFieldDirection.POSITIVE_X;
                        break;
                    case eDirection.LEFT:
                        realDirection = eFieldDirection.NEGATIVE_X;
                        break;
                    case eDirection.BACK:
                        realDirection = eFieldDirection.NEGATIVE_Y;
                        break;
                    default:
                        //realDirection = eFieldDirection.POSITIVE_Y;
                        break;
                }
            }
            else //if (_ownerPlayer == Players[1]) --> the perspective of Players[1] is 180 degrees different from that of Players[0]
            {
                switch (_directionFromPlayerPerspective)
                {
                    case eDirection.RIGHT:
                        realDirection = eFieldDirection.NEGATIVE_X;
                        break;
                    case eDirection.LEFT:
                        realDirection = eFieldDirection.POSITIVE_X;
                        break;
                    case eDirection.BACK:
                        realDirection = eFieldDirection.POSITIVE_Y;
                        break;
                    default:
                        realDirection = eFieldDirection.NEGATIVE_Y;
                        break;
                }
            }

            //Rotate _coord based on realDirection
            switch (realDirection)
            {
                case eFieldDirection.POSITIVE_X:
                    _coord.Rotate90DegreesAnticlockwise(1);
                    break;
                case eFieldDirection.NEGATIVE_Y:
                    _coord.Rotate90DegreesAnticlockwise(2);
                    break;
                case eFieldDirection.NEGATIVE_X:
                    _coord.Rotate90DegreesAnticlockwise(3);
                    break;
                default:
                    break;
            }

            return _coord;
        }

        /// <summary>
        /// PreCondition: _attacker has been initialized successfully;
        /// PostCondition: A list of _2DCoord corresponding to the Sockets on the Board will be returned.
        /// </summary>
        /// <param name="_attacker"></param>
        /// <returns></returns>
        public List<_2DCoord> GetAttackTargetAreas(UnitInstance _attacker)
        {
            List<_2DCoord> targetArea = new List<_2DCoord>();

            List<_2DCoord> relativeTargetArea = new List<_2DCoord>(); //By default, Units can only target one tile towards _attacker.DirectionFacing
            relativeTargetArea.Add(new _2DCoord(0, 1));

            foreach (_2DCoord relativeCoord in relativeTargetArea)
            {
                _2DCoord realTargetAreaCoord = ToRealCoord(UnitLocation(_attacker), RelativeCoordToCorrectDirection(_attacker.OwnerInstance, relativeCoord, _attacker.DirectionFacing));

                if (realTargetAreaCoord.X >= 0 && realTargetAreaCoord.X <= Rule.SIZE_OF_A_SIDE_OF_BOARD - 1
                    && realTargetAreaCoord.Y >= 0 && realTargetAreaCoord.Y <= Rule.SIZE_OF_A_SIDE_OF_BOARD - 1) //it will search inside of the board
                {
                    targetArea.Add(realTargetAreaCoord);
                }
                //else the value(s) of realTargetAreaCoord is(are) out of the board 
            }

            return targetArea;
        }

        /// <summary>
        /// [Action Method] 
        /// PreCondition: _attacker has been initialized successfully.
        /// PostCondition: If there is a target within target area, calls ExecuteEffect(); Returns a list of EFFECT_RESULT;
        /// If the list of EFFECT_RESULT contains no value, the reques have been denied.
        /// </summary>
        /// <param name="_attacker"></param>
        /// <returns></returns>
        public List<EFFECT_RESULT> RequestAttack(UnitInstance _attacker)
        {
            List<EFFECT_RESULT> effectResults = new List<EFFECT_RESULT>();
            int requiredCost = 1;

            if (_attacker.OwnerInstance.RemainingSP >= requiredCost) // If there is enough SP to spend
            {
                List<_2DCoord> targetArea = new List<_2DCoord>();
                targetArea.Add(new _2DCoord(0, 1)); // Indicates which coord to target (this coord is the relative position)

                Damage basicDamageEffect = new Damage(targetArea, 1, 1.0, null, 0, eTargetCharacterClassificaton.ENEMY, eAttackClassification.PHYSIC, 1, eElement.NONE, false, 0); // Settings for Basic Attack

                List<UnitInstance> target = SearchUnits(_attacker, targetArea, basicDamageEffect.TargetType);
                if (target.Count > 0) // If there were at least one target Unit
                {
                    ExecuteEffect(_attacker, basicDamageEffect, target[0], ref effectResults);
                    _attacker.OwnerInstance.RemainingSP -= requiredCost; // Deduct SP required to attack from remaining SP
                }
            }

            return effectResults;
        }

        /// <summary>
        /// PreCondition: _damage is positive value or 0; _target has been initialized successfully and _target.isAlive is true;
        /// PostCondition: _damage will be subtracted from _target.RemainingHP; If _damage > _target.RemainingHP, _target.RemainingHP will be set to 0;
        /// </summary>
        /// <param name="_damage"></param>
        /// <param name="_target"></param>
        private void DealDamage(int _damage, UnitInstance _target)
        {
            if (_target.RemainingHP - _damage > 0)
                _target.RemainingHP -= _damage;
            else
                _target.RemainingHP = 0;
        }

        /// <summary>
        /// PreCondition: _hpValueToRestore is positive value or 0; _target has been initialized successfully and _target.isAlive is true;
        /// PostCondition: _hpValueToRestore will be added to _target.RemainingHP; If _hpValueToRestore + _target.RemainingHP > MaxHP, _target.RemainingHP will be set to MaxHP;
        /// </summary>
        /// <param name="_hpValueToRestore"></param>
        /// <param name="_target"></param>
        private void RestoreHP(int _hpValueToRestore, UnitInstance _target)
        {
            int maxHP = Calculator.MaxHP(_target);

            if (_target.RemainingHP + _hpValueToRestore < maxHP)
                _target.RemainingHP += _hpValueToRestore;
            else
                _target.RemainingHP = maxHP;
        }

        /// <summary>
        /// PreCondition: _effectToAttach and _target have been initialized successfully.
        /// PostCondition: A cloned instance of _effectToAttach will be added to _target.ContinuousEffects;
        /// </summary>
        /// <param name="_effectToAttach"></param>
        /// <param name="_target"></param>
        private void AttachEffect(ContinuousEffect _effectToAttach, UnitInstance _target)
        {
            _target.ContinuousEffects.Add(_effectToAttach.Clone()); // Add a cloned instance not to modify data in original instance
        }

        /// <summary>
        /// PreCondition: None.
        /// PostCondition: All Units with isAlive property set to false, and that are assigned to a Socket on the Board, will be removed from the Socket.
        /// </summary>
        private void RemoveUnits()
        {
            foreach (PlayerOnBoard p in Players)
            {
                foreach (UnitInstance c in p.AlliedUnits)
                {
                    _2DCoord currentLocation = UnitLocation(c);

                    if (c.isAlive == false
                        && currentLocation.X != -1) // currentLocation == -1 means that UnitLocation(c) returned a coordinate out of the board (UnitBase not found) 
                        this.Board.Sockets[currentLocation.X, currentLocation.Y].Unit = null; // Remove unit assigned to the Socket
                }
            }
        }

        /// <summary>
        /// PreCondition: None.
        /// PostCondition: Units with 0 remaining HP will be set as !isAlive and will be removed from Board.Sockets;
        /// </summary>
        public void UpdateCharactersLiveStatus()
        {
            foreach (PlayerOnBoard p in Players)
            {
                foreach (UnitInstance c in p.AlliedUnits)
                {
                    if (c.RemainingHP <= 0 && c.isAlive)
                    {
                        c.isAlive = false;
                        if (p.SelectedUnitIndex >= 0 && c == p.AlliedUnits[p.SelectedUnitIndex])
                            UnselectUnits(p);
                    }
                }
            }

            RemoveUnits();
        }

        public void EndMatch(PlayerOnBoard _loser)
        {
            IsMatchEnd = true;

            if (Players[0] == _loser)
                IsPlayer1Winner = false;
            else
                IsPlayer1Winner = true;
        }

        public List<List<_2DCoord>> GetSkillTargetAreas(UnitInstance _skillUser, Skill _skill)
        {
            List<List<_2DCoord>> targetAreas = new List<List<_2DCoord>>();

            foreach (Effect effect in _skill.Effects)
            {
                targetAreas.Add(new List<_2DCoord>());

                foreach (_2DCoord relativeCoord in effect.TargetArea)
                {
                    _2DCoord relativeCoordCopy = new _2DCoord(relativeCoord.X, relativeCoord.Y); //use this not to overwrite the properties in Effect.TargetArea

                    _2DCoord realTargetAreaCoord = ToRealCoord(UnitLocation(_skillUser), RelativeCoordToCorrectDirection(_skillUser.OwnerInstance, relativeCoordCopy, _skillUser.DirectionFacing));

                    if (realTargetAreaCoord.X >= 0 && realTargetAreaCoord.X <= Rule.SIZE_OF_A_SIDE_OF_BOARD - 1
                        && realTargetAreaCoord.Y >= 0 && realTargetAreaCoord.Y <= Rule.SIZE_OF_A_SIDE_OF_BOARD - 1) //it will search inside of the board
                    {
                        targetAreas.Last().Add(realTargetAreaCoord);
                    }
                    //else it is out of the board and will throw and IndexOutOfRangeException
                }
            }

            return targetAreas;
        }

        /// <summary>
        /// PreCondition: _skillUser and _skill have been initialized successfully;
        /// PostCondition: If there is(are) a target(s) within target area and all other _skill requirements are met, calls ExecuteEffect(); Returns a list of EFFECT_RESULT;
        /// If the list of EFFECT_RESULT contains no value, the request has been denied.
        /// </summary>
        /// <param name="_skillUser"></param>
        /// <param name="_skill"></param>
        /// <returns></returns>
        public List<EFFECT_RESULT> RequestSkillUse(UnitInstance _skillUser, Skill _skill)
        {
            List<EFFECT_RESULT> effectResults = new List<EFFECT_RESULT>();

            if (_skillUser.OwnerInstance.RemainingSP >= _skill.SPCost) // If there is enough SP to spend
            {
                bool isThereAnyTarget = false;

                foreach (Effect effect in _skill.Effects)
                {
                    if (effect.GetType() == typeof(Damage))
                    {
                        Damage damageEffect = effect as Damage;

                        var targets = SearchUnits_EffectTarget(_skillUser, damageEffect.TargetArea, damageEffect.TargetType);

                        if (targets.Count > 0)
                            isThereAnyTarget = true;

                        foreach (UnitInstance target in targets)
                        {
                            //if (effect.ActivationRequirementsLv1 == null
                            //    || (effect.ActivationRequirementsLv1 != null && effect.ActivationRequirementsLv1.IsTrue(_skillUser, targets)))
                            ExecuteEffect(_skillUser, damageEffect, target, ref effectResults);
                        }
                    }
                    else if (effect.GetType() == typeof(EffectAttachment))
                    {
                        EffectAttachment effectAttachmentEffect = effect as EffectAttachment;

                        List<_2DCoord> actualTargetArea = new List<_2DCoord>();
                        var targets = SearchUnits_EffectTarget(_skillUser, effectAttachmentEffect.TargetArea, effectAttachmentEffect.TargetType);

                        if (targets.Count > 0)
                            isThereAnyTarget = true;

                        foreach (UnitInstance target in targets)
                        {
                            //if (effect.ActivationRequirementsLv1 == null
                            //    || (effect.ActivationRequirementsLv1 != null && effect.ActivationRequirementsLv1.IsTrue(_skillUser, targets)))
                            ExecuteEffect(_skillUser, effectAttachmentEffect, target, ref effectResults);
                        }
                    }
                    else if (effect.GetType() == typeof(Heal))
                    {
                        Heal healEffect = effect as Heal;

                        List<_2DCoord> actualTargetArea = new List<_2DCoord>();
                        var targets = SearchUnits_EffectTarget(_skillUser, healEffect.TargetArea, healEffect.TargetType);

                        if (targets.Count > 0)
                            isThereAnyTarget = true;

                        foreach (UnitInstance target in targets)
                        {
                            ExecuteEffect(_skillUser, healEffect, target, ref effectResults);
                        }
                    }
                }

                if (isThereAnyTarget)
                    _skillUser.OwnerInstance.RemainingSP -= _skill.SPCost;

            }

            return effectResults;
        }

        /// <summary>
        /// Attempts to ExecuteEffect. Effects might fail if target protects itself, dodges the effect, etc.
        /// PreCondition: _effectUser, _effect, _target, and _effectResults have been initialized successfully; _effectUser.isAlive == true; _effectUser is assigned to a Socket of the Board;
        /// PostCondition: Actions corresponding to _effect will be executed.
        /// </summary>
        /// <param name="_effectUser"></param>
        /// <param name="_effect"></param>
        /// <param name="_target"></param>
        /// <param name="_effectResults"></param>
        public void ExecuteEffect(UnitInstance _effectUser, Effect _effect, object _target, ref List<EFFECT_RESULT> _effectResults)
        {

            if(_effect.GetType() == typeof(Damage)) //---------------------------------------------Damage--------------------------------------------
            {
                var effect = _effect as Damage;
                var target = _target as UnitInstance;

                //Get the index of the target unit
                int unitIndex = GetUnitIndex(target);

                bool isCritical = false; // Pass this variable into Calculator.Damage() to get desired value
                if (Calculator.DoesSucceed(_effectUser, target, effect)) // If the effect succeeded
                {
                    int damageValue = Calculator.Damage(_effectUser, effect, target, UnitLocation(_effectUser), UnitLocation(target), Board, ref isCritical);
                    DealDamage(damageValue, target);

                    _effectResults.Add(new EFFECT_RESULT { targetUnitIndex = unitIndex, animationId = effect.AnimationId, didHit = true, damageAmout = damageValue, isCritical = isCritical });

                    if (_effect.SecondaryEffects.Count > 0)
                    {
                        foreach(Effect secondaryEffect in _effect.SecondaryEffects)
                        {
                            ExecuteEffect(_effectUser, secondaryEffect, _target, ref _effectResults);
                        }
                    }
                }
                else // If the effect failed
                    _effectResults.Add(new EFFECT_RESULT { targetUnitIndex = unitIndex, animationId = effect.AnimationId, didHit = false});
            }
            else if (_effect.GetType() == typeof(EffectAttachment)) //-------------------------------------EffectAttachment--------------------------------------------
            {
                var effect = _effect as EffectAttachment;
                var target = _target as UnitInstance;

                //Get the index of the target unit
                int unitIndex = GetUnitIndex(target);

                if (Calculator.DoesSucceed(_effectUser, target, effect)) // If the effect succeeded
                {
                    AttachEffect(effect.EffectToAttach, target);

                    _effectResults.Add(new EFFECT_RESULT { targetUnitIndex = unitIndex, animationId = _effect.AnimationId, didHit = true});
                }
                else // If the effect failed
                    _effectResults.Add(new EFFECT_RESULT { targetUnitIndex = unitIndex, animationId = effect.AnimationId, didHit = false });

                if (_effect.SecondaryEffects.Count > 0)
                {
                    foreach (Effect secondaryEffect in _effect.SecondaryEffects)
                    {
                        ExecuteEffect(_effectUser, secondaryEffect, _target, ref _effectResults);
                    }
                }
            }
            else if (_effect.GetType() == typeof(Heal)) //-------------------------------------------Heal---------------------------------------------
            {
                var effect = _effect as Heal;
                var target = _target as UnitInstance;

                //Get the index of the target unit
                int unitIndex = GetUnitIndex(target);

                if (Calculator.DoesSucceed(_effectUser, target, effect)) // If the effect succeeded
                {
                    int restoringAmount = Calculator.HealValue(_effectUser, effect, target, UnitLocation(_effectUser), UnitLocation(target));
                    RestoreHP(restoringAmount, target);

                    _effectResults.Add(new EFFECT_RESULT { targetUnitIndex = unitIndex, animationId = _effect.AnimationId, didHit = true, damageAmout = restoringAmount });
                }
                else // If the effect failed
                    _effectResults.Add(new EFFECT_RESULT { targetUnitIndex = unitIndex, animationId = effect.AnimationId, didHit = false });

                if (_effect.SecondaryEffects.Count > 0)
                {
                    foreach (Effect secondaryEffect in _effect.SecondaryEffects)
                    {
                        ExecuteEffect(_effectUser, secondaryEffect, _target, ref _effectResults);
                    }
                }
            }
        }

        /// <summary>
        /// PreCondition: _unit has been initialized successfully; _unit has been added to Units (list of UnitInstance) successfully.
        /// PostCondition: If _unit is registered in Units property, the corresponding index value will be returned. -1 will be returned if _unit was not found in Units.
        /// </summary>
        /// <param name="_unit"></param>
        /// <returns></returns>
        private int GetUnitIndex(UnitInstance _unit)
        {
            int unitIndex = 0;
            while (unitIndex < Units.Count)
            {
                if (Units[unitIndex] == _unit)
                    return unitIndex;

                unitIndex++;
            }

            return -1; // This will be returned when _unit was not found within Units
        }

        public void ApplyContinuousEffect()
        {
            int currentTurnPlayerIndex = -1;

            currentTurnPlayerIndex = 1; //implement later

            foreach(UnitInstance c in Units.Where(x => x.Owner == Players[currentTurnPlayerIndex]))
            {
                if(c.ContinuousEffects.Count > 0)
                {
                    foreach(ContinuousEffect ce in c.ContinuousEffects)
                    {
                        switch(ce.EffectType)
                        {
                            case eContinuousEffectType.POISON:
                                DealDamage(Calculator.MaxHP(c) / 10, c);
                                break;
                            default:
                                break;
                        }
                    }
                }
            }
        }

        public void ChangeTurn()
        {
            CurrentTurnPlayer = (CurrentTurnPlayer == Players[0]) ? Players[1] : Players[0];
            CurrentTurnPlayer.RemainingSP = CurrentTurnPlayer.MaxSP;
        }
    }

    public struct EFFECT_RESULT
    {
        public int targetUnitIndex;
        public int animationId;

        public bool didHit;

        public int damageAmout;
        public bool isCritical;
    }


    public enum eFieldDirection
    {
        POSITIVE_Y,
        POSITIVE_X,
        NEGATIVE_Y,
        NEGATIVE_X,
    }

    public enum eActionType
    {
        MOVE,
        ATTACK,
        GUARD,
        ITEM,
        ULTIMATE_SKILL,
        SKILL
    }
}
