﻿using EEANGame.TBSG.V1_0.CommonEnums;
using System;
using System.Collections.Generic;
using System.Linq;

namespace EEANGame.TBSG.V1_0.MainClassLib
{
    public static class CommandTranslator
    {
        public static List<string> DivideIntoTags(string _command)
        {
            string commandCopy = _command; //copy value to not accidentally modify the original string

            List<string> tags = new List<string>();

            while (commandCopy != "")
            {
                int countCharsInTag = 1; //the first character '<'

                for (int i = 2; i <= commandCopy.Length; i++)
                {
                    //ignore the first character in commandCopy which should be '<'
                    if (commandCopy[i - 1] != '<')
                        countCharsInTag++;
                    else
                        break;
                }

                tags.Add(commandCopy.Substring(0, countCharsInTag));
                commandCopy = commandCopy.Substring(countCharsInTag);
            }

            return tags;
        }

        public static Tag HierarchizeTags(List<string> _tags)
        {
            Tag t = new Tag(_tags[0]); //First tag will always be the root tag

            Tag currentTag = t;

            for (int i = 2; i <= _tags.Count; i++)
            {
                if (!_tags[i - 1].StartsWith("</"))
                {
                    if (_tags[i - 1].EndsWith("/>"))
                        currentTag.ChildrenTags.Add(new Tag(_tags[i - 1].Substring(0, _tags[i - 1].Length - 2) + ">", currentTag)); //Remove the "/"
                    else
                        currentTag.ChildrenTags.Add(new Tag(_tags[i - 1], currentTag));

                    if (!_tags[i - 1].EndsWith("/>"))
                        currentTag = currentTag.ChildrenTags.Last();
                }
                else
                    currentTag = currentTag.ParentTag;
            }

            return t;
        }

        public static object TranslateTagToValue(Tag _tag, UnitInstance _tagHolder, object _target)
        {
            if (_tag.ChildrenTags.Count != 0)
            {
                return TranslateComplexTagToValue(_tag, _tagHolder, _target);
            }
            else
            {
                return TranslateSimpleTagToValue(_tag, _tagHolder, _target);
            }

        }

        private static object TranslateComplexTagToValue(Tag _tag, UnitInstance _tagHolder, object _target)
        {
            List<object> tagValues = new List<object>();

            foreach (Tag tag in _tag.ChildrenTags)
            {
                tagValues.Add(TranslateTagToValue(tag, _tagHolder, _target));
            }

            var result = tagValues[0];

            try
            {
                switch (_tag.String)
                {
                    case "<Sum>":
                        for (int i = 2; i <= tagValues.Count; i++)
                        {
                            result = Calculator.Sum(result, tagValues[i - 1]);
                        }
                        result = Convert.ToDouble(result);
                        break;
                    case "<Subtract>":
                        for (int i = 2; i <= tagValues.Count; i++)
                        {
                            result = Calculator.Subtract(result, tagValues[i - 1]);
                        }
                        result = Convert.ToDouble(result);
                        break;
                    case "<Multiply>":
                        for (int i = 2; i <= tagValues.Count; i++)
                        {
                            result = Calculator.Multiply(result, tagValues[i - 1]);
                        }
                        result = Convert.ToDouble(result);
                        break;
                    case "<Divide>":
                        for (int i = 2; i <= tagValues.Count; i++)
                        {
                            result = Calculator.Divide(result, tagValues[i - 1]);
                        }
                        result = Convert.ToDouble(result);
                        break;
                }
            }
            catch (Exception ex)
            {
                return null;
            }

            return result;
        }

        private static object TranslateSimpleTagToValue(Tag _tag, UnitInstance _tagHolder, object _target)
        {
            if(!_tag.String.StartsWith("<Number"))
            {
                if(_target.GetType() == typeof(UnitInstance))
                {
                    var target = _target as UnitInstance;

                    switch(_tag.String)
                    {
                        case "<Target.Owner>":
                            return target.Owner; //usage example: identify whether character is enemy or ally by comparing owner
                        case "<Target.Name>":
                            return target.Level;
                        case "<Target.Specie>":
                            return target.SpecieTypes;
                        case "<Target.Element>":
                            return target.Elements;
                        case "<Target.MaxHP>":
                            return Calculator.MaxHP(target);
                        case "<Target.RemainingHP>":
                            return target.RemainingHP;
                        case "<Target.PhysicalStrength>":
                            return Calculator.PhysicalStrength(target);
                        case "<Target.PhysicalResistance>":
                            return Calculator.PhysicalResistance(target);
                        case "<Target.MagicalStrength>":
                            return Calculator.MagicalStrength(target);
                        case "<Target.MagicalResistance>":
                            return Calculator.MagicalResistance(target);
                        default:
                            return null;
                    }
                }
                else if(_target.GetType() == typeof(Tile))
                {
                    return null;
                }
                else
                {
                    switch (_tag.String)
                    {
                        //instance property values
                        case "<TagHolder.Owner>":
                            return _tagHolder.Owner; //usage example: identify whether character is enemy or ally by comparing owner
                        case "<TagHolder.Name>":
                            return _tagHolder.Level;
                        case "<TagHolder.Specie>":
                            return _tagHolder.SpecieTypes;
                        case "<TagHolder.Element>":
                            return _tagHolder.Elements;
                        case "<TagHolder.MaxHP>":
                            return Calculator.MaxHP(_tagHolder);
                        case "<TagHolder.RemainingHP>":
                            return _tagHolder.RemainingHP;
                        case "<TagHolder.PhysicalStrength>":
                            return Calculator.PhysicalStrength(_tagHolder);
                        case "<TagHolder.PhysicalResistance>":
                            return Calculator.PhysicalResistance(_tagHolder);
                        case "<TagHolder.MagicalStrength>":
                            return Calculator.MagicalStrength(_tagHolder);
                        case "<TagHolder.MagicalResistance>":
                            return Calculator.MagicalResistance(_tagHolder);

                        ////enum values
                        //case "<Specie.Aquatic>":
                        //    return eSpecie.AQUATIC;
                        //case "<Specie.Beast>":
                        //    return eSpecie.BEAST;
                        //case "<Specie.Bloodeater>":
                        //    return eSpecie.BLOODEATER;
                        //case "<Specie.Bug>":
                        //    return eSpecie.BUG;
                        //case "<Specie.Deity>":
                        //    return eSpecie.DEITY;
                        //case "<Specie.Demon>":
                        //    return eSpecie.DEMON;
                        //case "<Specie.Dragon>":
                        //    return eSpecie.DRAGON;
                        //case "<Specie.Humanoid>":
                        //    return eSpecie.HUMANOID;
                        //case "<Specie.Machine>":
                        //    return eSpecie.MACHINE;
                        //case "<Specie.Mineral>":
                        //    return eSpecie.MINERAL;
                        //case "<Specie.Plant>":
                        //    return eSpecie.PLANT;
                        //case "<Specie.Slime>":
                        //    return eSpecie.SLIME;
                        //case "<Specie.Spirit>":
                        //    return eSpecie.SPIRIT;
                        //case "<Specie.Winged>":
                        //    return eSpecie.WINGED;
                        //case "<Element.Black>":
                        //    return eElement.PURPLE;
                        //case "<Element.Blue>":
                        //    return eElement.BLUE;
                        //case "<Element.Green>":
                        //    return eElement.GREEN;
                        //case "<Element.Ocher>":
                        //    return eElement.OCHER;
                        //case "<Element.Red>":
                        //    return eElement.RED;
                        //case "<Element.White>":
                        //    return eElement.YELLOW;
                        default:
                            return null;
                    }
                }
            }
            else
            {
                string tagStringCopy = String.Copy(_tag.String);

                tagStringCopy = tagStringCopy.Substring(8, tagStringCopy.Length - 9); //Remove "<Number " and ">"

                return Convert.ToDouble(tagStringCopy);
            }
        }
    }

    public class Tag
    {
        public Tag(string _string)
        {
            String = _string;
            ChildrenTags = new List<Tag>();
            ParentTag = null;
        }

        public Tag(string _string, Tag _parent)
        {
            String = _string;
            ChildrenTags = new List<Tag>();
            ParentTag = _parent;
        }

        public Tag ParentTag { get; set; }

        public string String { get; set; }

        public List<Tag> ChildrenTags { get; set; }
    }
}
