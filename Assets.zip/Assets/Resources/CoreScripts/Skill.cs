﻿using EEANGame.TBSG.V1_0.CommonEnums;
using System.Collections.Generic;

namespace EEANGame.TBSG.V1_0.MainClassLib
{
    public class Skill
    {
        /// <summary>
        /// Ctor
        /// PreCondition: _spCost > 0; _effects.Count > 0; _animationId > 0;
        /// PostCondition: Will be initialized successfully.
        /// </summary>
        /// <param name="_id"></param>
        /// <param name="_name"></param>
        /// <param name="_type"></param>
        /// <param name="_spCost"></param>
        /// <param name="_effects"></param>
        /// <param name="_animationId"></param>
        public Skill(int _id, string _name, eSkillType _type, int _spCost, List<Effect> _effects, int _animationId)
        {
            Id = _id;
            Name = _name;
            Type = _type;

            if (_spCost < Rule.MIN_SP_COST)
                _spCost = Rule.MIN_SP_COST;
            else if (_spCost > Rule.MAX_SP)
                _spCost = Rule.MAX_SP;

            SPCost = _spCost;

            Effects = _effects;

            AnimationId = _animationId;
        }

        public int Id { get; set; }
        public string Name { get; set; }

        public eSkillType Type { get; set; }

        public int SPCost { get; set; }
        //public string AdditionalCost_Before { get; }
        //public string AdditionalCost_After { get; }

        public List<Effect> Effects { get; set; }

        public int AnimationId { get; set; }
    }
}
