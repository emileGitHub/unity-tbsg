﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace EEANGame.TBSG.V1_0.CommonEnums
{

    public enum eGender
    {
        UNDEFINABLE,
        MALE,
        FEMALE,
    }

    public enum eElement
    {
        NONE, //Default
        BLUE,
        RED,
        GREEN,
        OCHER,
        PURPLE,
        YELLOW
    }

    public enum eSpecie
    {
        NONE, //Default
        BEAST,
        BIRD,
        BUG,
        CRUSTACEAN,
        DEITY,
        DRAGON,
        FISH,
        HUMANOID,
        IMMORTAL,
        MACHINE,
        MAGICAL,
        MINERAL,
        MOLLUSCA,
        PLANT,
        SLIME,
        SPIRIT,
    }

    public enum eSkillType
    {
        ACTIVE,
        COUNTER,
        PASSIVE,
        ULTIMATE
    }

    public enum eTargetCharacterClassificaton
    {
        SELF,
        ALLY,
        ENEMY,
    }

    public enum eTargetEntityType
    {
        CHARACTER,
        ITEM,
        TILE
    }

    public enum eStatusType
    {

        EVASION,
        PRECISION,
    }

    public enum eDirection
    {
        FRONT,
        RIGHT,
        LEFT,
        BACK
    }

    public enum eItemType
    {
        TRAP,
        CURE
    }

    public enum eRarity
    {
        //The numbers express the max level of characters of the rarity
        NORMAL = 20,
        BRONZE = 40,
        SILVER = 60,
        GOLD = 80,
        PLATINUM = 100
    }

    public enum eContinuousEffectType
    {
        POISON,
        CONFUSION,
        ATTACK_BIND,
        MOVEMENT_BIND,
        GUARD_BIND,
        SKILL_BIND,
        ITEM_BIND,
        HEAL,

        //BASIC ATTRIBUTES
        MAXHP_RATE,
        PHYSTR_RATE,
        PHYRES_RATE,
        MAGSTR_RATE,
        MAGRES_RATE,
        CRITICALHIT_RATE,
        CRITICALRES_RATE,
        PRECISION_RATE,
        EVASION_RATE,

        //ELEMENT
        BLUESTR_RATE,
        GREENSTR_RATE,
        REDSTR_RATE,
        OCHERSTR_RATE,
        PURPLESTR_RATE,
        YELLOWSTR_RATE,
        ANTIBLUERES_RATE,
        ANTIGREENRES_RATE,
        ANTIREDRES_RATE,
        ANTIOCHERRES_RATE,
        ANTIPURPLERES_RATE,
        ANTIYELLOWRES_RATE,
        ANTIBLUESTR_RATE,
        ANTIGREENSTR_RATE,
        ANTIREDSTR_RATE,
        ANTIOCHERSTR_RATE,
        ANTIPURPLESTR_RATE,
        ANTIYELLOWSTR_RATE,

        //SPECIE
        ANTIBEASTSTR_RATE,
        ANTIBIRDSTR_RATE,
        ANTIBUGSTR_RATE,
        ANTICRUSTACEANSTR_RATE,
        ANTIDEITYSTR_RATE,
        ANTIDRAGONSTR_RATE,
        ANTIFISHSTR_RATE,
        ANTIHUMANOIDSTR_RATE,
        ANTIIMMORTALSTR_RATE,
        ANTIMACHINESTR_RATE,
        ANTIMAGICALSTR_RATE,
        ANTIMINERALSTR_RATE,
        ANTIMOLLUSCASTR_RATE,
        ANTIPLANTSTR_RATE,
        ANTISLIMESTR_RATE,
        ANTISPIRITSTR_RATE,
        ANTIBEASTRES_RATE,
        ANTIBIRDRES_RATE,
        ANTIBUGRES_RATE,
        ANTICRUSTACEANRES_RATE,
        ANTIDEITYRES_RATE,
        ANTIDRAGONRES_RATE,
        ANTIFISHRES_RATE,
        ANTIHUMANOIDRES_RATE,
        ANTIIMMORTALRES_RATE,
        ANTIMACHINERES_RATE,
        ANTIMAGICALRES_RATE,
        ANTIMINERALRES_RATE,
        ANTIMOLLUSCARES_RATE,
        ANTIPLANTRES_RATE,
        ANTISLIMERES_RATE,
        ANTISPIRITRES_RATE,

    }

    public enum eAttackClassification
    {
        PHYSIC,
        MAGIC
    }

    public enum eDurationType
    {
        TURNS,
        ACTIONS,
        NEAR_CONTINUOUS,
        CONTINUOUS,
    }

    public enum eWeaponType
    {
        ORDINARY,
        TRANSFORMABLE,
        LEVELABLE
    }

    public enum eWeaponClassification
    {
        UNCLASSIFIED,
        AX,
        BLUNT,
        BOOK,
        BOW,
        GLOVE,
        GUN,
        KATANA,
        KNIFE,
        MECH,
        MUSICAL_INSTRUMENT,
        NUCKLE,
        RAPIER,
        SCYTHE,
        SHIELD,
        SHOE,
        SNIPER_RIFLE,
        SPEAR,
        SWORD,
        THROWING,
        WAND,
        WHIP,
    }

    public enum eArmourClassification
    {
        EXTRALIGHT,
        LIGHT,
        HEAVY
    }

    public enum eAccessoryClassification
    {
        HEAD,
        NECK,
        WRIST,
        FINGER,
        ANKLE
    }

    public enum eTileType
    {
        NORMAL,
        BLUE,
        RED,
        GREEN,
        OCHER,
        PURPLE,
        YELLOW,
        HEAL
    }
}
