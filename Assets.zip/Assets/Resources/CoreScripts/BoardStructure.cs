﻿using System.Collections;
using System.Collections.Generic;
using System;
using EEANGame.TBSG.V1_0.MainClassLib;
using EEANGame.TBSG.V1_0.CommonEnums;

namespace EEANGame.TBSG.V1_0.MainClassLib
{
    public struct t_SOCKET
    {
        public eTileType Tile;
        public UnitInstance Unit;
        public Item TrapItem;
    }

    public class Board
    {
        /// <summary>
        /// Ctor
        /// PreCondition: _tileSet.Count > 0;
        /// PostCondition: All eTileType properties of Sockets in the Board will have an eTileType value assigned. The eTileType value for each socket will be randomly selected from those in _tileSet.
        /// </summary>
        /// <param name="_tileSet"></param>
        public Board(List<eTileType> _tileSet)
        {
            Sockets = new t_SOCKET[Rule.SIZE_OF_A_SIDE_OF_BOARD, Rule.SIZE_OF_A_SIDE_OF_BOARD];

            List<eTileType> tiles = Tile.GetRandomTileType(Rule.SIZE_OF_A_SIDE_OF_BOARD*Rule.SIZE_OF_A_SIDE_OF_BOARD, _tileSet);

            for (int x = 1; x <= Rule.SIZE_OF_A_SIDE_OF_BOARD; x++)
            {
                for(int y = 1; y <= Rule.SIZE_OF_A_SIDE_OF_BOARD; y++)
                {
                    Sockets[x - 1, y - 1].Tile = tiles[7*(x - 1) + (y - 1)];
                }
            }
        }

        /*--------------------------------------------
        Properties
        --------------------------------------------*/

        public t_SOCKET[,] Sockets { get; set; }


    }
}
