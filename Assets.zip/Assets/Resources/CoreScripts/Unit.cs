﻿using EEANGame.TBSG.V1_0.CommonEnums;
using System.Collections.Generic;

namespace EEANGame.TBSG.V1_0.MainClassLib
{

    public struct t_IMAGE
    {
        public int Id;
        public byte[] ImageAsByteArray;
    }

    public class UnitBase
    {

        /// <summary>
        /// Ctor
        /// PreCondition: _iconAsByteArray, _spriteAsByteArray has been initialized successfully; _specieTypes.Count > 0; _equipableWeaponTypes.Count > 0; _equipableArmourTypes.Count > 0; _equipableAccessoryTypes.Count > 0;
        /// _maxLvHP > 0; _maxLvPhyStr > 0; _maxLvPhyRes > 0; _maxLvMagStr > 0; _maxLvMarRes > 0;  _maxLvVit > 0; _skills.Count > 0;
        /// PostCondition: Will be initialized successfully.
        /// </summary>
        /// <param name="_id"></param>
        /// <param name="_iconAsByteArray"></param>
        /// <param name="_spriteAsByteArray"></param>
        /// <param name="_name"></param>
        /// <param name="_gender"></param>
        /// <param name="_rarity"></param>
        /// <param name="_specieTypes"></param>
        /// <param name="_elements"></param>
        /// <param name="_equipableWeaponTypes"></param>
        /// <param name="_equipableArmourTypes"></param>
        /// <param name="_equipableAccessoryTypes"></param>
        /// <param name="_maxLvHP"></param>
        /// <param name="_maxLvPhyStr"></param>
        /// <param name="_maxLvPhyRes"></param>
        /// <param name="_maxLvMagStr"></param>
        /// <param name="_maxLvMagRes"></param>
        /// <param name="_maxLvVit"></param>
        /// <param name="_skills"></param>
        public UnitBase(int _id, t_IMAGE _iconAsByteArray, t_IMAGE _spriteAsByteArray, string _name, eGender _gender, eRarity _rarity, List<eSpecie> _specieTypes, List<eElement> _elements,
                             List<eWeaponClassification> _equipableWeaponTypes, List<eArmourClassification> _equipableArmourTypes, List<eAccessoryClassification> _equipableAccessoryTypes,
                                int _maxLvHP, int _maxLvPhyStr, int _maxLvPhyRes, int _maxLvMagStr, int _maxLvMagRes, int _maxLvVit, List<Skill> _skills)
        {
            Id = _id;

            Name = _name;

            IconAsByteArray = _iconAsByteArray;
            SpriteAsByteArray = _spriteAsByteArray;

            //Assign Gender
            Gender = _gender;

            //Assign Rarity
            Rarity = _rarity;

            /*-----------------
            Assign Elements
            -----------------*/
            Elements = new List<eElement>();
            //Set Elements.Count to 2
            for (int i = 1; i <= 2; i++)
            {
                Elements.Add(eElement.NONE);
            }

            //Assign argument values
            for (int i = 1; i <= Elements.Count; i++)
            {
                if (_elements.Count < i) //Avoids IndexOutOfRangeException
                    Elements[i - 1] = eElement.NONE;
                else
                    Elements[i - 1] = _elements[i - 1];
            }

            //Remove repeating elements
            for (int i = 1; i <= Elements.Count - 1; i++)
            {
                int j = i + 1; //counter

                do
                {
                    if (Elements[i - 1] == eElement.NONE)
                        break;

                    if (Elements[i - 1] == Elements[j - 1])
                        Elements[j - 1] = eElement.NONE;

                    j++;

                } while (j <= Elements.Count);
            }

            /*-----------------
            Assign SpecieTypes
            -----------------*/
            SpecieTypes = new List<eSpecie>(3);

            //Set SpecieTypes.Count to 3
            for (int i = 1; i <= 3; i++)
            {
                SpecieTypes.Add(eSpecie.NONE);
            }

            //Assign argument values
            for (int i = 1; i <= SpecieTypes.Count - 1; i++)
            {
                if (i == 1)
                {
                    if (_specieTypes.Count < 1 || _specieTypes[i - 1] == eSpecie.NONE) //First part avoids IndexOutOfRangeException
                        SpecieTypes[i - 1] = eSpecie.HUMANOID; //Set to HUMANOID just to avoid having no SpecieType
                    else
                        SpecieTypes[i - 1] = _specieTypes[i - 1];
                }
                else
                {
                    if (_specieTypes.Count < i) //Avoids IndexOutOfRangeException
                        SpecieTypes[i - 1] = eSpecie.NONE;
                    else
                        SpecieTypes[i - 1] = _specieTypes[i - 1];
                }
            }

            //Remove repeating types
            for (int i = 1; i <= SpecieTypes.Count; i++)
            {
                int j = i + 1; //counter

                do
                {
                    if (SpecieTypes[i - 1] == eSpecie.NONE)
                        break;

                    if (SpecieTypes[i - 1] == SpecieTypes[j - 1])
                        SpecieTypes[j - 1] = eSpecie.NONE;

                    j++;

                } while (j <= SpecieTypes.Count);
            }

            if (_equipableWeaponTypes != null)
                EquipableWeaponTypes = _equipableWeaponTypes;
            else
                EquipableWeaponTypes = new List<eWeaponClassification>();

            if (_equipableArmourTypes != null)
                EquipableArmourTypes = _equipableArmourTypes;
            else
                EquipableArmourTypes = new List<eArmourClassification>();

            if (_equipableAccessoryTypes != null)
                EquipableAccessoryTypes = _equipableAccessoryTypes;
            else
                EquipableAccessoryTypes = new List<eAccessoryClassification>();


            //Assign Attribute Values at MAX Level
            MaxLevel_HP = _maxLvHP;
            MaxLevel_PhysicalStrength = _maxLvPhyStr;
            MaxLevel_PhysicalResistance = _maxLvPhyRes;
            MaxLevel_MagicalStrength = _maxLvMagStr;
            MaxLevel_MagicalResistance = _maxLvMagRes;
            MaxLevel_Vitality = _maxLvVit;

            //Assign Skills
            if (_skills != null)
                Skills = _skills;
            else
                Skills = new List<Skill>();
        }

        /*--------------------------------------------
        Properties
        --------------------------------------------*/

        //Base Properties
        public int Id { get; set; }
        public string Name { get; set; }

        public eGender Gender { get; set; }

        //Icon
        public t_IMAGE IconAsByteArray { get; set; }
        //Sprite
        public t_IMAGE SpriteAsByteArray { get; set; }

        //Rarity of the UnitBase
        public eRarity Rarity { get; set; }

        //Types
        public List<eElement> Elements { get; set; } //All can be eElement.NONE
        public List<eSpecie> SpecieTypes { get; set; } //At least One has to be other than eSpecieTypes.NONE

        //Equipable
        public List<eWeaponClassification> EquipableWeaponTypes { get; set; }
        public List<eArmourClassification> EquipableArmourTypes { get; set; }
        public List<eAccessoryClassification> EquipableAccessoryTypes { get; set; }

        //Attribute Values at MAX Level
        public int MaxLevel_HP { get; set; }
        public int MaxLevel_PhysicalStrength { get; set; }
        public int MaxLevel_PhysicalResistance { get; set; }
        public int MaxLevel_MagicalStrength { get; set; }
        public int MaxLevel_MagicalResistance { get; set; }
        public int MaxLevel_Vitality { get; set; }

        //Skills
        public List<Skill> Skills { get; set; }
    }

    public class IndividualUnitData : UnitBase
    {

        /// <summary>
        /// Ctor 1
        /// PreCondition: _iconAsByteArray, _spriteAsByteArray, and _owner have been initialized successfully; _specieTypes.Count > 0; _equipableWeaponTypes.Count > 0; _equipableArmourTypes.Count > 0; _equipableAccessoryTypes.Count > 0;
        /// _level > 0; _maxLvHP > 0; _maxLvPhyStr > 0; _maxLvPhyRes > 0; _maxLvMagStr > 0; _maxLvMarRes > 0; _maxLvVit > 0; _skills.Count > 0;
        /// PostCondition: Will be initialized successfully.
        /// </summary>
        /// <param name="_baseId"></param>
        /// <param name="_uniqueId"></param>
        /// <param name="_iconAsByteArray"></param>
        /// <param name="_spriteAsByteArray"></param>
        /// <param name="_name"></param>
        /// <param name="_gender"></param>
        /// <param name="_rarity"></param>
        /// <param name="_owner"></param>
        /// <param name="_nickname"></param>
        /// <param name="_specieTypes"></param>
        /// <param name="_elements"></param>
        /// <param name="_equipableWeaponTypes"></param>
        /// <param name="_equipableArmourTypes"></param>
        /// <param name="_equipableAccessoryTypes"></param>
        /// <param name="_level"></param>
        /// <param name="_maxLvHP"></param>
        /// <param name="_maxLvPhyStr"></param>
        /// <param name="_maxLvPhyRes"></param>
        /// <param name="_maxLvMagStr"></param>
        /// <param name="_maxLvMagRes"></param>
        /// <param name="_maxLvVit"></param>
        /// <param name="_skills"></param>
        public IndividualUnitData(int _baseId, int _uniqueId, t_IMAGE _iconAsByteArray, t_IMAGE _spriteAsByteArray, string _name, eGender _gender, eRarity _rarity,
            Player _owner, string _nickname, List<eSpecie> _specieTypes, List<eElement> _elements,
            List<eWeaponClassification> _equipableWeaponTypes, List<eArmourClassification> _equipableArmourTypes, List<eAccessoryClassification> _equipableAccessoryTypes,
            int _level, int _maxLvHP, int _maxLvPhyStr, int _maxLvPhyRes, int _maxLvMagStr, int _maxLvMagRes, int _maxLvVit, List<Skill> _skills) : base(_baseId, _iconAsByteArray, _spriteAsByteArray, _name, _gender, _rarity, _specieTypes, _elements, _equipableWeaponTypes, _equipableArmourTypes, _equipableAccessoryTypes, _maxLvHP, _maxLvPhyStr, _maxLvPhyRes, _maxLvMagStr, _maxLvMagRes, _maxLvVit, _skills)
        {
            UniqueId = _uniqueId;
            Owner = _owner;
            Nickname = _nickname;
            Level = _level;
        }

        /// <summary>
        /// Ctor 2
        /// PreCondition: _unitBase and _owner have been initialized successfully; _level > 0;
        /// PostCondition: Will be initialized successfully.
        /// </summary>
        /// <param name="_unitBase"></param>
        /// <param name="_uniqueId"></param>
        /// <param name="_owner"></param>
        /// <param name="_nickname"></param>
        /// <param name="_level"></param>
        public IndividualUnitData(UnitBase _unitBase, int _uniqueId, Player _owner, string _nickname, int _level) : base(_unitBase.Id, _unitBase.IconAsByteArray, _unitBase.SpriteAsByteArray, _unitBase.Name, _unitBase.Gender, _unitBase.Rarity, _unitBase.SpecieTypes, _unitBase.Elements, _unitBase.EquipableWeaponTypes, _unitBase.EquipableArmourTypes, _unitBase.EquipableAccessoryTypes, _unitBase.MaxLevel_HP, _unitBase.MaxLevel_PhysicalStrength, _unitBase.MaxLevel_PhysicalResistance, _unitBase.MaxLevel_MagicalStrength, _unitBase.MaxLevel_MagicalResistance, _unitBase.MaxLevel_Vitality, _unitBase.Skills)
        {
            UniqueId = _uniqueId;
            Owner = _owner;
            Nickname = _nickname;
            Level = _level;
        }

        public int UniqueId { get; set; }

        //Owner
        public Player Owner { get; set; }

        //User Defined Nickname
        public string Nickname { get; set; }

        //Basic Attributes
        public int Level { get; set; }
    }

    public class UnitInstance : IndividualUnitData
    {


        /// <summary>
        /// Ctor 1
        /// PreCondition: _iconAsByteArray, _spriteAsByteArray, _owner, _armour, _accessory, _ownerInstance have been initialized successfully; _specieTypes.Count > 0;
        /// _equipableWeaponTypes.Count > 0; _equipableArmourTypes.Count > 0; _equipableAccessoryTypes.Count > 0; 
        /// _level > 0; _maxLvHP > 0; _maxLvPhyStr > 0; _maxLvPhyRes > 0; _maxLvMagStr > 0; _maxLvMarRes > 0; _maxLvVit > 0; _max_skills.Count > 0;
        /// PostCondition: Will be initialized successfully.
        /// </summary>
        /// <param name="_baseId"></param>
        /// <param name="_uniqueId"></param>
        /// <param name="_iconAsByteArray"></param>
        /// <param name="_spriteAsByteArray"></param>
        /// <param name="_name"></param>
        /// <param name="_gender"></param>
        /// <param name="_rarity"></param>
        /// <param name="_owner"></param>
        /// <param name="_nickname"></param>
        /// <param name="_specieTypes"></param>
        /// <param name="_elements"></param>
        /// <param name="_equipableWeaponTypes"></param>
        /// <param name="_equipableArmourTypes"></param>
        /// <param name="_equipableAccessoryTypes"></param>
        /// <param name="_level"></param>
        /// <param name="_maxLvHP"></param>
        /// <param name="_maxLvPhyStr"></param>
        /// <param name="_maxLvPhyRes"></param>
        /// <param name="_maxLvMagStr"></param>
        /// <param name="_maxLvMagRes"></param>
        /// <param name="_maxLvVit"></param>
        /// <param name="_skills"></param>
        /// <param name="_weapons"></param>
        /// <param name="_armour"></param>
        /// <param name="_accessory"></param>
        /// <param name="_ownerInstance"></param>
        public UnitInstance(int _baseId, int _uniqueId, t_IMAGE _iconAsByteArray, t_IMAGE _spriteAsByteArray,
            string _name, eGender _gender, eRarity _rarity, Player _owner, string _nickname,
            List<eSpecie> _specieTypes, List<eElement> _elements, List<eWeaponClassification> _equipableWeaponTypes, List<eArmourClassification> _equipableArmourTypes, List<eAccessoryClassification> _equipableAccessoryTypes,
            int _level, int _maxLvHP, int _maxLvPhyStr, int _maxLvPhyRes, int _maxLvMagStr, int _maxLvMagRes, int _maxLvVit, List<Skill> _skills,
            List<UsableWeapon> _weapons, UsableArmour _armour, UsableAccessory _accessory, PlayerOnBoard _ownerInstance) : base(_baseId, _uniqueId, _iconAsByteArray, _spriteAsByteArray, _name, _gender, _rarity, _owner, _nickname, _specieTypes, _elements, _equipableWeaponTypes, _equipableArmourTypes, _equipableAccessoryTypes, _level, _maxLvHP, _maxLvPhyStr, _maxLvPhyRes, _maxLvMagStr, _maxLvMagRes, _maxLvVit, _skills)
        {
            isAlive = true;
            RemainingHP = Calculator.MaxHP(this);
            DirectionFacing = eDirection.FRONT;
            ContinuousEffects = new List<ContinuousEffect>();

            if (_weapons != null)
                Weapons = _weapons;
            else
                Weapons = new List<UsableWeapon>();

            Armour = _armour;
            Accessory = _accessory;

            if (_ownerInstance != null)
                OwnerInstance = _ownerInstance;
            else
                OwnerInstance = new PlayerOnBoard(-1, string.Empty, null, null, null, null, null, -1);
        }

        /// <summary>
        /// Ctor 2
        /// PreCondition: _unitBase, _armour, _accessory, and _ownerInstance have been initialized successfully; _weapons.Count > 0;
        /// PostCondition: Will be initialized successfully.
        /// </summary>
        /// <param name="_unitBase"></param>
        /// <param name="_weapons"></param>
        /// <param name="_armour"></param>
        /// <param name="_accessory"></param>
        /// <param name="_ownerInstance"></param>
        public UnitInstance(IndividualUnitData _unitBase, List<UsableWeapon> _weapons, UsableArmour _armour, UsableAccessory _accessory, PlayerOnBoard _ownerInstance) : base(_unitBase.Id, _unitBase.UniqueId, _unitBase.IconAsByteArray, _unitBase.SpriteAsByteArray, _unitBase.Name, _unitBase.Gender, _unitBase.Rarity, _unitBase.Owner, _unitBase.Nickname, _unitBase.SpecieTypes, _unitBase.Elements, _unitBase.EquipableWeaponTypes, _unitBase.EquipableArmourTypes, _unitBase.EquipableAccessoryTypes, _unitBase.Level, _unitBase.MaxLevel_HP, _unitBase.MaxLevel_PhysicalStrength, _unitBase.MaxLevel_PhysicalResistance, _unitBase.MaxLevel_MagicalStrength, _unitBase.MaxLevel_MagicalResistance, _unitBase.MaxLevel_Vitality, _unitBase.Skills)
        {
            isAlive = true;
            RemainingHP = Calculator.MaxHP(this);
            DirectionFacing = eDirection.FRONT;
            ContinuousEffects = new List<ContinuousEffect>();

            if (_weapons != null)
                Weapons = _weapons;
            else
                Weapons = new List<UsableWeapon>();

            Armour = _armour;
            Accessory = _accessory;

            if (_ownerInstance != null)
                OwnerInstance = _ownerInstance;
            else
                OwnerInstance = new PlayerOnBoard(-1, string.Empty, null, null, null, null, null, -1);
        }

        /*--------------------------------------------
        Properties
        --------------------------------------------*/
        public bool isAlive;

        private const int NUMBER_OF_SLOTS = 3;

        public int RemainingHP { get; set; }

        public List<ContinuousEffect> ContinuousEffects { get; set; }

        public List<UsableWeapon> Weapons { get; set; }
        public UsableArmour Armour { get; set; }
        public UsableAccessory Accessory { get; set; }

        public PlayerOnBoard OwnerInstance { get; set; }

        //DirectionFacing based on owner player
        public eDirection DirectionFacing { get; set; }
    }
}
