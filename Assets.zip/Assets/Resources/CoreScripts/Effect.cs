﻿using EEANGame.TBSG.V1_0.CommonEnums;
using System.Collections.Generic;

namespace EEANGame.TBSG.V1_0.MainClassLib
{
    public abstract class Effect
    {
        /// <summary>
        /// Ctor
        /// PreCondition: _targetArea.Count > 0; _timaesToApply > 0; _successProbability > 0; _secondaryEffects.Count > 0; _animationId > 0
        /// PostCondition: Will be initialized successfully.
        /// </summary>
        /// <param name="_targetArea"></param>
        /// <param name="_timesToApply"></param>
        /// <param name="_successProbability"></param>
        /// <param name="_secondaryEffects"></param>
        /// <param name="_animationId"></param>
        public Effect(List<_2DCoord> _targetArea, int _timesToApply, double _successProbability, List<Effect> _secondaryEffects, int _animationId)
        {
            //ActivationRequirementsLv1 = _activationRequirementsLv1;
            //ActivationRequirementsLv2 = _activationRequirementsLv2;
            //ActivationRequirementsLv3 = _activationRequirementsLv3;

            TargetArea = _targetArea;

            TimesToApply = _timesToApply;
            SuccessProbability = _successProbability;

            SecondaryEffects = _secondaryEffects;

            if (TargetArea == null)
                TargetArea = new List<_2DCoord>();

            if (SecondaryEffects == null)
                SecondaryEffects = new List<Effect>();

            AnimationId = _animationId;
        }

        //public ComplexCondition ActivationRequirementsLv1 { get; set; } //Requirements based on either effect user's properties or target's properties, or both of these combined.
        //public ComplexCondition ActivationRequirementsLv2 { get; set; } //Requirements based on the property(ies) of a (or several) character, trap item, or tile in the target area.
        //public ComplexCondition ActivationRequirementsLv3 { get; set; } //Requirements based on any information that can be retrieved from the current game.

        public List<_2DCoord> TargetArea { get; set; }

        public int TimesToApply { get; set; }
        public double SuccessProbability { get; set; }

        public List<Effect> SecondaryEffects { get; set; }

        public int AnimationId { get; set; }
    }

    public class Damage : Effect
    {

        /// <summary>
        /// Ctor
        /// PreCondition: _targetArea.Count > 0; _timesToApply > 0; _successProbability > 0; _secondaryEffects.Count > 0; _animationId > 0; _power > 0; _guardBreak > 0;
        /// PostCondition: Will be initialized successfully.
        /// </summary>
        /// <param name="_targetArea"></param>
        /// <param name="_timesToApply"></param>
        /// <param name="_successProbability"></param>
        /// <param name="_secondaryEffects"></param>
        /// <param name="_animationId"></param>
        /// <param name="_targetType"></param>
        /// <param name="_attackType"></param>
        /// <param name="_power"></param>
        /// <param name="_element"></param>
        /// <param name="_doesPreservePower"></param>
        /// <param name="_guardBreak"></param>
        public Damage(List<_2DCoord> _targetArea, int _timesToApply, double _successProbability, List<Effect> _secondaryEffects, int _animationId,
            eTargetCharacterClassificaton _targetType, eAttackClassification _attackType, int _power, eElement _element, bool _doesPreservePower, int _guardBreak) : base(_targetArea, _timesToApply, _successProbability, _secondaryEffects, _animationId)
        {
            TargetType = _targetType;
            AttackType = _attackType;
            Power = _power;
            Element = _element;
            DoesPreservePower = _doesPreservePower;
            GuardBreak = _guardBreak;
        }

        public eTargetCharacterClassificaton TargetType { get; set; }
        public eAttackClassification AttackType { get; set; }
        public bool IsDamageFixed { get; set; }
        public int Power { get; set; }
        public eElement Element { get; set; }
        public bool DoesPreservePower { get; set; }
        public int GuardBreak { get; set; }
    }

    public class EffectAttachment : Effect
    {
        /// <summary>
        /// Ctor
        /// PreCondition: _targetArea.Count > 0; _timesToApply > 0; _successProbability > 0; _secondaryEffects.Count > 0; _animationId > 0; _effectToAttach has been initialized successfully;
        /// PostCondition: Will be initialized successfully.
        /// </summary>
        /// <param name="_targetArea"></param>
        /// <param name="_timesToApply"></param>
        /// <param name="_successProbability"></param>
        /// <param name="_secondaryEffects"></param>
        /// <param name="_animationId"></param>
        /// <param name="_targetType"></param>
        /// <param name="_effectToAttach"></param>
        public EffectAttachment(List<_2DCoord> _targetArea, int _timesToApply, double _successProbability, List<Effect> _secondaryEffects, int _animationId,
            eTargetCharacterClassificaton _targetType, ContinuousEffect _effectToAttach) : base(_targetArea, _timesToApply, _successProbability, _secondaryEffects, _animationId)
        {
            TargetType = _targetType;
            EffectToAttach = _effectToAttach;
        }

        public eTargetCharacterClassificaton TargetType { get; set; }
        public ContinuousEffect EffectToAttach { get; set; } //This should not be modified, therefore, should be copied when attaching
    }

    public class ContinuousEffect //Poison, Confuse, Strength down, etc. This will be attached directly to Units
    {
        /// <summary>
        /// Ctor
        /// PreCondition:_value, _duration, and _applicant have been initialized successfully.
        /// PostCondition: Will be initialized successfully.
        /// </summary>
        /// <param name="_effectType"></param>
        /// <param name="_value"></param>
        /// <param name="_duration"></param>
        /// <param name="_applicant"></param>
        public ContinuousEffect(eContinuousEffectType _effectType, Tag _value, Duration _duration, UnitInstance _applicant)
        {
            EffectType = _effectType;
            Value = _value;
            Duration = _duration;
            Applicant = _applicant;
        }

        public eContinuousEffectType EffectType { get; set; }

        //Value might not be used
        public Tag Value { get; set; } //There is a function to decifrate the command stored in this property
        public Duration Duration { get; set; } //Counter

        public UnitInstance Applicant { get; set; }

        public ContinuousEffect Clone()
        {
            ContinuousEffect result = new ContinuousEffect(EffectType, Value, Duration, Applicant);

            return result; ////////////////////////////////////////////////////////////////////////////////////////////neeeds implementation
        }
    }



    //public class DamageCut : Effect
    //{
    //    public double cuttingRate { get; set; }
    //    public double refleftionRate { get; set; }
    //}

    //public class Move : Effect
    //{
    //    public int NumberOfTiles { get; set; }
    //}

    //public class Create : Effect
    //{
    //    public eItemType ProductType { get; set; }
    //    public string ProductName { get; set; }
    //    public int AmountToCreate { get; set; }
    //}

    //public class Summon : Effect
    //{
    //    public string ServantName { get; set; }
    //    public int AmountToSummon { get; set; }
    //}

    //public class Transform : Effect
    //{
    //    public string CharacterName { get; set; }
    //    public int Duration { get; set; }
    //}

    public class Heal : Effect
    {
        /// <summary>
        /// Ctor
        /// PreCondition: _targetArea.Count > 0; _timesToApply > 0; _successProbability > 0; _secondaryEffects.Count > 0; _animationId > 0; _power > 0;
        /// PostCondition: Will be initialized successfully.
        /// </summary>
        /// <param name="_targetArea"></param>
        /// <param name="_timesToApply"></param>
        /// <param name="_successProbability"></param>
        /// <param name="_secondaryEffects"></param>
        /// <param name="_animationId"></param>
        /// <param name="_targetType"></param>
        /// <param name="_power"></param>
        /// <param name="_doesPreservePower"></param>
        public Heal(List<_2DCoord> _targetArea, int _timesToApply, double _successProbability, List<Effect> _secondaryEffects, int _animationId,
            eTargetCharacterClassificaton _targetType, int _power, bool _doesPreservePower) : base(_targetArea, _timesToApply, _successProbability, _secondaryEffects, _animationId)
        {
            TargetType = _targetType;
            Power = _power;
            DoesPreservePower = _doesPreservePower;
        }

        public eTargetCharacterClassificaton TargetType { get; set; }
        public int Power { get; set; }
        public bool DoesPreservePower { get; set; }

    }

    //public class Cure : Effect
    //{
    //    public eAilmentType TargetAilment { get; set; }
    //    public int Value { get; set; }
    //}



    public class Duration
    {
        /// <summary>
        /// Ctor
        /// PreCondition: _durationCounters.Count > 0; _durationRestrictions has been initialized successfully;
        /// PostCondition: Will be initialized successfully.
        /// </summary>
        /// <param name="_durationCounters"></param>
        /// <param name="_durationRestrictions"></param>
        public Duration(List<t_DurationCounter> _durationCounters, ComplexCondition _durationRestrictions)
        {
            DurationCounters = _durationCounters;
            DurationRestrictions = _durationRestrictions;
        }

        //Can use either one or combine both properties
        public List<t_DurationCounter> DurationCounters { get; set; } 
        public ComplexCondition DurationRestrictions { get; set; }
    }

    public struct t_DurationCounter
    {
        public eDurationType DurationType;
        public int Counter;
    }
}
