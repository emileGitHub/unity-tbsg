﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace EEANGame.TBSG.V1_0.MainClassLib
{
    class CommandLoader
    {
        public void LoadCommand()
        {
            //To be implemented
        }
    }
}
