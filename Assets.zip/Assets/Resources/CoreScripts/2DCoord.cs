﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace EEANGame.TBSG.V1_0.MainClassLib
{
    public class _2DCoord
    {
        //ctor
        public _2DCoord(int _x, int _y)
        {
            X = _x;
            Y = _y;
        }

        /*--------------------------------------------
        Properties
        --------------------------------------------*/

        public int X { get; set; }
        public int Y { get; set; }


        public static _2DCoord operator +(_2DCoord _a, _2DCoord _b)
        {
            int x = _a.X + _b.X;
            int y = _a.Y + _b.Y;

            return new _2DCoord(x, y);
        }

        /// <summary>
        /// PreCondition: _coords is not null.
        /// PostCondition: A string representing an array of _2DCoords will be returned.
        /// </summary>
        /// <param name="_coords"></param>
        /// <returns></returns>
        public static string CoordsToString(List<_2DCoord> _coords)
        {
            string result = "";

            if(_coords != null)
            {
                foreach (_2DCoord coord in _coords)
                {
                    result += coord.X.ToString() + "," + coord.Y.ToString() + ";";
                }
            }

            return result;
        }

        /// <summary>
        /// PreCondition: _coordsString follows the acceptable format -> "x,y;...."
        /// PostCondition: 
        /// </summary>
        /// <param name="_coordsString"></param>
        /// <returns></returns>
        public static List<_2DCoord> StringToCoords(string _coordsString)
        {
            List<_2DCoord> result = new List<_2DCoord>();

            try
            {
                string[] separators = { ",", ";" };
                string[] coordStrings = _coordsString.Split(separators, StringSplitOptions.RemoveEmptyEntries);
                for (int i = 0; i < coordStrings.Length; i += 2)
                {
                    result.Add(new _2DCoord(Convert.ToInt32(coordStrings[i]), Convert.ToInt32(coordStrings[i + 1])));
                }
            }
            catch(Exception ex)
            {
            }

            return result;
        }

        /// <summary>
        /// PreCondition: _timesToRotate > 0;
        /// PostCondition: _2DCoord will be rotated _timesToRotate times to the towards the positive X; X and Y will be updated.
        /// </summary>
        /// <param name="_timesToRotate"></param>
        public void Rotate90DegreesAnticlockwise(int _timesToRotate)
        {
            while(_timesToRotate > 0)
            {
                double tmp = this.X;
                this.X = Convert.ToInt32(X * Math.Cos(90.0 * Rule.MULTIPLIER_FOR_ANGLE_TO_RADIAN) + Y * Math.Sin(90.0 * Rule.MULTIPLIER_FOR_ANGLE_TO_RADIAN));
                this.Y = Convert.ToInt32(Y * Math.Cos(90.0 * Rule.MULTIPLIER_FOR_ANGLE_TO_RADIAN) - tmp * Math.Sin(90.0 * Rule.MULTIPLIER_FOR_ANGLE_TO_RADIAN));

                _timesToRotate--;
            }
        }

        /// <summary>
        /// PreCondition: None.
        /// PostCondition: Values of X and Y will be swapped.
        /// </summary>
        public void InvertXY()
        {
            int tmp = this.X;
            this.X = this.Y;
            this.Y = tmp;
        }
    }
}
