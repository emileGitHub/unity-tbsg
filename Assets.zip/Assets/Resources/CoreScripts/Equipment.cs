﻿using EEANGame.TBSG.V1_0.CommonEnums;
using System.Collections.Generic;

namespace EEANGame.TBSG.V1_0.MainClassLib
{
    public abstract class Equipment
    {
        /// <summary>
        /// Ctor
        /// PreCondition: None.
        /// PostCondition: Will be initialized successfully.
        /// </summary>
        /// <param name="_id"></param>
        /// <param name="_name"></param>
        /// <param name="_rarity"></param>
        /// <param name="_skills"></param>
        public Equipment(int _id, string _name, eRarity _rarity, List<Skill> _skills)
        {
            Id = _id;
            Name = _name;
            Rarity = _rarity;

            if (_skills != null)
                Skills = _skills;
            else
                Skills = new List<Skill>();
        }

        public int Id { get; set; }
        public string Name { get; set; }

        public eRarity Rarity { get; set; }

        public List<Skill> Skills { get; set; }
    }

    public class Weapon : Equipment
    {
        /// <summary>
        /// Ctor
        /// PreCondition: _weaponClassifications.Count > 0; _mainWeaponSkills.Count > 0; _cost > 0;
        /// PostCondition: Will be initialized successfully.
        /// </summary>
        /// <param name="_id"></param>
        /// <param name="_name"></param>
        /// <param name="_rarity"></param>
        /// <param name="_skills"></param>
        /// <param name="_weaponType"></param>
        /// <param name="_weaponClassifications"></param>
        /// <param name="_mainWeaponSkills"></param>
        /// <param name="_cost"></param>
        /// <param name="_targetWeaponInCaseTypeIsTRANSFORMABLE"></param>
        public Weapon(int _id, string _name, eRarity _rarity, List<Skill> _skills,
                eWeaponType _weaponType, List<eWeaponClassification> _weaponClassifications, List<Skill> _mainWeaponSkills, int _cost,
                    List<Weapon> _targetWeaponInCaseTypeIsTRANSFORMABLE = null) : base(_id, _name, _rarity, _skills)
        {
            WeaponType = _weaponType;

            if (_weaponClassifications != null)
                WeaponClassifications = _weaponClassifications;
            else
                WeaponClassifications = new List<eWeaponClassification>();

            if (_mainWeaponSkills != null)
                MainWeaponSkills = _mainWeaponSkills;
            else
                MainWeaponSkills = new List<Skill>();

            Cost = _cost;

            if (WeaponType == eWeaponType.TRANSFORMABLE)
            {
                if (TransformableWeapons != null)
                    TransformableWeapons = _targetWeaponInCaseTypeIsTRANSFORMABLE;
                else
                    TransformableWeapons = new List<Weapon>();
            }
        }

        public eWeaponType WeaponType { get; set; }

        public List<eWeaponClassification> WeaponClassifications { get; set; }

        public List<Skill> MainWeaponSkills { get; set; }

        public int Cost { get; set; }

        //used if WeaponType == eWeaponType.TRANSFORMABLE
        public List<Weapon> TransformableWeapons { get; set; }
    }

    public class UsableWeapon : Weapon
    {
        /// <summary>
        /// Ctor 1
        /// PreCondition: _weaponClassifications.Count > 0; _mainWeaponSkills.Count > 0; _cost > 0;
        /// PostCondition: Will be initialized successfully.
        /// </summary>
        /// <param name="_id"></param>
        /// <param name="_name"></param>
        /// <param name="_rarity"></param>
        /// <param name="_uniqueSkills"></param>
        /// <param name="_weaponType"></param>
        /// <param name="_weaponClassifications"></param>
        /// <param name="_mainWeaponSkills"></param>
        /// <param name="_cost"></param>
        /// <param name="_uniqueId"></param>
        /// <param name="_levelInCaseTypeIsLEVELABLE"></param>
        /// <param name="_targetWeaponInCaseTypeIsTRANSFORMABLE"></param>
        public UsableWeapon(int _id, string _name, eRarity _rarity, List<Skill> _uniqueSkills, eWeaponType _weaponType, List<eWeaponClassification> _weaponClassifications, List<Skill> _mainWeaponSkills, int _cost,
                        int _uniqueId, int _levelInCaseTypeIsLEVELABLE = 1, List<Weapon> _targetWeaponInCaseTypeIsTRANSFORMABLE = null) : base(_id, _name, _rarity, _uniqueSkills, _weaponType, _weaponClassifications, _mainWeaponSkills, _cost, _targetWeaponInCaseTypeIsTRANSFORMABLE)
        {
            UniqueId = Id;

            if (_weaponType == eWeaponType.LEVELABLE)
                Level = _levelInCaseTypeIsLEVELABLE;
        }

        /// <summary>
        /// Ctor 2
        /// PreCondition: _baseWeapon has been initialized successfully;
        /// PostCondition: Will be initialized successfully.
        /// </summary>
        /// <param name="_baseWeapon"></param>
        /// <param name="_uniqueId"></param>
        /// <param name="_levelInCaseTypeIsLEVELABLE"></param>
        public UsableWeapon(Weapon _baseWeapon, int _uniqueId, int _levelInCaseTypeIsLEVELABLE) : base(_baseWeapon.Id, _baseWeapon.Name, _baseWeapon.Rarity, _baseWeapon.Skills, _baseWeapon.WeaponType, _baseWeapon.WeaponClassifications, _baseWeapon.MainWeaponSkills, _baseWeapon.Cost, _baseWeapon.TransformableWeapons)
        {
            UniqueId = Id;

            if (WeaponType == eWeaponType.LEVELABLE)
                Level = _levelInCaseTypeIsLEVELABLE;
        }

        public int UniqueId { get; set; }

        //used if WeaponType == eWeaponType.LEVELABLE
        public int Level { get; set; }
    }

    public class Armour : Equipment
    {
        /// <summary>
        /// Ctor
        /// PreCondition: _skills.Count > 0.        
        /// PostCondition: Will be initialized successfully.
        /// </summary>
        /// <param name="_id"></param>
        /// <param name="_name"></param>
        /// <param name="_rarity"></param>
        /// <param name="_skills"></param>
        /// <param name="_armourType"></param>
        /// <param name="_targetGender"></param>
        public Armour(int _id, string _name, eRarity _rarity, List<Skill> _skills,
            eArmourClassification _armourType, eGender _targetGender) : base(_id, _name, _rarity, _skills)
        {
            ArmourType = _armourType;
            TargetGender = _targetGender;
        }

        public eArmourClassification ArmourType { get; set; }

        public eGender TargetGender { get; set; }
    }

    public class UsableArmour : Armour
    {
        /// <summary>
        /// Ctor 1
        /// PreCondition: _skills.Count > 0;
        /// PostCondition: Will be initialized successfully.
        /// </summary>
        /// <param name="_id"></param>
        /// <param name="_name"></param>
        /// <param name="_rarity"></param>
        /// <param name="_skills"></param>
        /// <param name="_armourType"></param>
        /// <param name="_targetGender"></param>
        /// <param name="_uniqueId"></param>
        public UsableArmour(int _id, string _name, eRarity _rarity, List<Skill> _skills, eArmourClassification _armourType, eGender _targetGender,
                        int _uniqueId) : base(_id, _name, _rarity, _skills, _armourType, _targetGender)
        {
            UniqueId = _uniqueId;
        }

        /// <summary>
        /// Ctor 2
        /// PreCondition: _baseArmour has been initialized successfully.
        /// PostCondition: Will be initialized successfully.
        /// </summary>
        /// <param name="_baseArmour"></param>
        /// <param name="_uniqueId"></param>
        public UsableArmour(Armour _baseArmour, int _uniqueId) : base(_baseArmour.Id, _baseArmour.Name, _baseArmour.Rarity, _baseArmour.Skills, _baseArmour.ArmourType, _baseArmour.TargetGender)
        {
            UniqueId = _uniqueId;
        }

        public int UniqueId { get; set; }
    }

    public class Accessory : Equipment
    {
        /// <summary>
        /// Ctor
        /// PreCondition: _skills.Count > 0.
        /// PostCondition: Will be initialized successfully.
        /// </summary>
        /// <param name="_id"></param>
        /// <param name="_name"></param>
        /// <param name="_rarity"></param>
        /// <param name="_skills"></param>
        /// <param name="_accessoryType"></param>
        /// <param name="_targetGender"></param>
        public Accessory(int _id, string _name, eRarity _rarity, List<Skill> _skills,
            eAccessoryClassification _accessoryType, eGender _targetGender) : base(_id, _name, _rarity, _skills)
        {
            AccessoryType = _accessoryType;
            TargetGender = _targetGender;
        }

        public eAccessoryClassification AccessoryType { get; set; }

        public eGender TargetGender { get; set; }
    }

    public class UsableAccessory : Accessory
    {
        /// <summary>
        /// Ctor 1
        /// PreCondition: _skills.Count > 0;
        /// PostCondition: Will be initialized successfully.
        /// </summary>
        /// <param name="_id"></param>
        /// <param name="_name"></param>
        /// <param name="_rarity"></param>
        /// <param name="_skills"></param>
        /// <param name="_accessoryType"></param>
        /// <param name="_targetGender"></param>
        /// <param name="_uniqueId"></param>
        public UsableAccessory(int _id, string _name, eRarity _rarity, List<Skill> _skills, eAccessoryClassification _accessoryType, eGender _targetGender,
                         int _uniqueId) : base(_id, _name, _rarity, _skills, _accessoryType, _targetGender)
        {
            UniqueId = _uniqueId;
        }

        /// <summary>
        /// Ctor 2
        /// PreCondition: _baseAccessory has been initialized successfully.
        /// PostCondition: Will be initialized successfully.
        /// </summary>
        /// <param name="_baseAccessory"></param>
        /// <param name="_uniqueId"></param>
        public UsableAccessory(Accessory _baseAccessory, int _uniqueId) : base(_baseAccessory.Id, _baseAccessory.Name, _baseAccessory.Rarity, _baseAccessory.Skills, _baseAccessory.AccessoryType, _baseAccessory.TargetGender)
        {
            UniqueId = _uniqueId;
        }

        public int UniqueId { get; set; }
    }
}
