﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace EEANGame.TBSG.V1_0.MainClassLib
{
    public class ComplexCondition
    {
        public ComplexCondition()
        {
            ConditionSet = new List<List<Condition>>(); 
        }

        public bool IsTrue(UnitInstance _relationHolder, object _target)
        {
            if (ConditionSet.Count > 0)
            {
                foreach (var listOfRelation in ConditionSet.Select((v, i) => new { v, i }))
                {
                    if (InnerIsTrue(listOfRelation.i, _relationHolder, _target))
                        return true;
                }

                return false;
            }
            else
                return true;

        }

        private bool InnerIsTrue(int _innerListIndex, UnitInstance _relationHolder, object _target)
        {
            foreach(Condition relation in ConditionSet[_innerListIndex])
            {
                if (!relation.IsTrue(_relationHolder, _target))
                    return false;
            }

            return true;
        }

        public List<List<Condition>> ConditionSet; //List<Relation<Type>> represents the AND relationship between each Relation, and the List<Relation<Type>> instances have an OR relation in between.
        //Example:
        //A && (B || C)  (Where A, B, C are instances of Relation<T> class)
        //which means (A and B) or (A and C)
        //may be stored as
        //ConditionSet[0][0] == A
        //ConditionSet[0][1] == B
        //ConditionSet[1][0] == A
        //ConditionSet[1][1] == C

    }

    //public class Relation<T>
    //{
    //    public Relation(T a, eRelationType relationType, T b)
    //    {
    //        A = a;
    //        RelationType = relationType;
    //        B = b;
    //    }

    //    public bool IsTrue()
    //    {
    //        var comparableA = A as IComparable;
    //        var comparableB = B as IComparable;

    //        try
    //        {
    //            if (comparableA != null)
    //            {
    //                switch (RelationType)
    //                {
    //                    case eRelationType.EQUAL_TO:
    //                        return comparableA == comparableB;
    //                    case eRelationType.NOT_EQUAL_TO:
    //                        return comparableA != comparableB;
    //                    case eRelationType.GREATER_THAN:
    //                        return comparableA.CompareTo(comparableB) > 0; //throws exception if not able to compare
    //                    case eRelationType.SMALLER_THAN:
    //                        return comparableA.CompareTo(comparableB) < 0; //throws exception if not able to compare
    //                    case eRelationType.GREATER_THAN_OR_EQUAL_TO:
    //                        return comparableA.CompareTo(comparableB) >= 0;//throws exception if not able to compare
    //                    case eRelationType.SMALLER_THAN_OR_EQUAL_TO:
    //                        return comparableA.CompareTo(comparableB) <= 0;//throws exception if not able to compare
    //                    default:
    //                        return false;
    //                }
    //            }
    //            else
    //            {
    //                switch (RelationType)
    //                {
    //                    case eRelationType.EQUAL_TO:
    //                        return A.Equals(B);
    //                    case eRelationType.NOT_EQUAL_TO:
    //                        return !A.Equals(B);
    //                    default:
    //                        return false;
    //                }
    //            }

    //        }
    //        catch (Exception ex)
    //        {
    //            return false;
    //        }
    //    }

    //    private T A { get; }
    //    eRelationType RelationType { get; }
    //    private T B { get; }
    //}

    public class Condition
    {
        public Condition(Tag _a, eRelationType _relationType, Tag _b)
        {
            A = _a;
            RelationType = _relationType;
            B = _b;
        }

        public bool IsTrue(UnitInstance _relationHolder, object _target)
        {
            var valueA = CommandTranslator.TranslateTagToValue(A, _relationHolder, _target);
            var valueB = CommandTranslator.TranslateTagToValue(B, _relationHolder, _target);

            var comparableA = valueA as IComparable;
            var comparableB = valueB as IComparable;

            try
            {
                if (comparableA != null)
                {
                    switch (RelationType)
                    {
                        case eRelationType.EQUAL_TO:
                            return comparableA.CompareTo(comparableB) == 0;
                        case eRelationType.NOT_EQUAL_TO:
                            return comparableA.CompareTo(comparableA) != 0;
                        case eRelationType.GREATER_THAN:
                            return comparableA.CompareTo(comparableB) > 0; //throws exception if not able to compare
                        case eRelationType.SMALLER_THAN:
                            return comparableA.CompareTo(comparableB) < 0; //throws exception if not able to compare
                        case eRelationType.GREATER_THAN_OR_EQUAL_TO:
                            return comparableA.CompareTo(comparableB) >= 0;//throws exception if not able to compare
                        case eRelationType.SMALLER_THAN_OR_EQUAL_TO:
                            return comparableA.CompareTo(comparableB) <= 0;//throws exception if not able to compare
                        default:
                            return false;
                    }
                }
                else
                {
                    switch (RelationType)
                    {
                        case eRelationType.EQUAL_TO:
                            return A.Equals(B);
                        case eRelationType.NOT_EQUAL_TO:
                            return !A.Equals(B);
                        default:
                            return false;
                    }
                }

            }
            catch (Exception ex)
            {
                return false;
            }
        }

        private Tag A { get; set; }
        eRelationType RelationType { get; set; }
        private Tag B { get; set; }
    }


    public enum eRelationType
    {
        EQUAL_TO,
        NOT_EQUAL_TO,
        GREATER_THAN,
        SMALLER_THAN,
        GREATER_THAN_OR_EQUAL_TO,
        SMALLER_THAN_OR_EQUAL_TO
    }
}
