﻿using EEANGame.TBSG.V1_0.CommonEnums;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace EEANGame.TBSG.V1_0.MainClassLib.DBDataHandler.ForUnity
{
    using System.Collections;
    using UnityEngine;

    //Singleton Class
    public sealed class TxtDataHandler
    {
        private static TxtDataHandler Instance = new TxtDataHandler();

        public static TxtDataHandler GetInstance()
        {
            return Instance;
        }

        //private ctor
        private TxtDataHandler()
        {
            commonFilePath = @"Assets\Resources\Plugins";
        }

        //Properties
        private static string commonFilePath;

        #region Load
        public static MainClassLib.Player LoadPlayerData(string _userName, string _password)
        {
            try
            {
                string pTxtData = "";
                //Read data from Player.txt
                using (StreamReader sr = File.OpenText(commonFilePath + @"\Player.txt"))
                {
                    pTxtData = sr.ReadToEnd();
                }
                string[] rows = pTxtData.Split('\n');

                if (rows.Count() > 1) //if not only header row
                {
                    string[] pData;
                    for (int i = 1; i < rows.Count(); i++)
                    {
                        pData = rows[i].Split(';');
                        if (pData[2] == _userName && pData[3] == _password)
                        {
                            int playerId = Convert.ToInt32(pData[0]);
                            string playerName = pData[1];

                            Player player = new Player(playerId, playerName, null, null, null, null, null);

                            foreach (IndividualUnitData pc in LoadPlayableCharacterData(player))
                            {
                                player.UnitsData.Add(pc);
                            }

                            foreach (UsableWeapon uw in LoadUsableWeaponData(player))
                            {
                                player.WeaponsOwned.Add(uw);
                            }

                            foreach (UsableArmour ur in LoadUsableArmourData(player))
                            {
                                player.ArmoursOwned.Add(ur);
                            }

                            foreach (UsableAccessory ua in LoadUsableAccessoryData(player))
                            {
                                player.AccessoriesOwned.Add(ua);
                            }

                            foreach (Team t in LoadTeamData(player))
                            {
                                player.Teams.Add(t);
                            }

                            return player;
                        }
                    }
                }

                return null;
            }
            catch (Exception ex)
            {
                Debug.Log(ex.Message + ex.InnerException + ex.TargetSite);
                return null;
            }
        }

        //Pass _owner as parameter to use same instance for all playable characters owned
        private static List<IndividualUnitData> LoadPlayableCharacterData(Player _owner)
        {
            List<IndividualUnitData> result = new List<IndividualUnitData>();

            try
            {
                string pcTxtData = "";
                //Read data from Player.txt
                using (StreamReader sr = File.OpenText(commonFilePath + @"\PlayableCharacter.txt"))
                {
                    pcTxtData = sr.ReadToEnd();
                }
                string[] rows = pcTxtData.Split('\n');

                if (rows.Count() > 1) //if not only header row
                {
                    string[] pcData;
                    for (int i = 1; i < rows.Count(); i++)
                    {
                        if (rows[i] == "")
                            break;
                        pcData = rows[i].Split(';');
                        if (Convert.ToInt32(pcData[2]) == _owner.Id) // Owner Id matches
                        {
                            int playableCharacterId = Convert.ToInt32(pcData[0]);
                            int baseCharacterId = Convert.ToInt32(pcData[1]);
                            string nickname = pcData[3];
                            int level = Convert.ToInt32(pcData[4]);

                            MainClassLib.UnitBase character = LoadCharacterData(baseCharacterId);

                            result.Add(new MainClassLib.IndividualUnitData(character, playableCharacterId, _owner, nickname, level));
                        }
                    }
                }

                return result;
            }
            catch (Exception ex)
            {
                Debug.Log(ex.Message + ex.InnerException + ex.TargetSite);
                return null;
            }
        }

        public static MainClassLib.UnitBase LoadCharacterData(int _id)
        {
            try
            {
                string cTxtData = "";
                //Read data from Character.txt
                using (StreamReader sr = File.OpenText(commonFilePath + @"\Character.txt"))
                {
                    cTxtData = sr.ReadToEnd();
                }
                string[] rows = cTxtData.Split('\n');

                if (rows.Count() > 1) //if not only header row
                {
                    string[] cData;
                    for (int i = 1; i < rows.Count(); i++)
                    {
                        if (rows[i] == "")
                            break;
                        cData = rows[i].Split(';');
                        if (Convert.ToInt32(cData[0]) == _id)
                        {
                            int characterId = Convert.ToInt32(cData[0]);
                            string name = cData[1];
                            string genderString = cData[2];
                            int rarityInt = Convert.ToInt32(cData[3]);
                            string element1String = cData[4];
                            string element2String = cData[5];
                            string specie1String = cData[6];
                            string specie2String = cData[7];
                            string specie3String = cData[8];
                            int maxHPAtMaxLevel = Convert.ToInt32(cData[9]);
                            int phyStrAtMaxLevel = Convert.ToInt32(cData[10]);
                            int phyResAtMaxLevel = Convert.ToInt32(cData[11]);
                            int magStrAtMaxLevel = Convert.ToInt32(cData[12]);
                            int magResAtMaxLevel = Convert.ToInt32(cData[13]);
                            int vitAtMaxLevel = Convert.ToInt32(cData[14]);
                            int iconId = Convert.ToInt32(cData[15]);
                            int spriteId = Convert.ToInt32(cData[16]);

                            eGender gender = ToCorrespondingEnumValue<eGender>(genderString);

                            eRarity rarity = eRarity.NORMAL;
                            switch (rarityInt)
                            {
                                case 2:
                                    rarity = eRarity.BRONZE;
                                    break;
                                case 3:
                                    rarity = eRarity.SILVER;
                                    break;
                                case 4:
                                    rarity = eRarity.GOLD;
                                    break;
                                case 5:
                                    rarity = eRarity.PLATINUM;
                                    break;
                                default:
                                    break;
                            }

                            List<eSpecie> species = new List<eSpecie>();
                            species.Add(ToCorrespondingEnumValue<eSpecie>(specie1String));
                            species.Add(ToCorrespondingEnumValue<eSpecie>(specie2String));
                            species.Add(ToCorrespondingEnumValue<eSpecie>(specie3String));

                            List<eElement> elements = new List<eElement>();
                            elements.Add(ToCorrespondingEnumValue<eElement>(element1String));
                            elements.Add(ToCorrespondingEnumValue<eElement>(element2String));

                            //////////////////////////////////////////////////////////
                            //EquipableWeaponClassificaitons
                            //////////////////////////////////////////////////////////
                            List<eWeaponClassification> equipableWpnClasses = new List<eWeaponClassification>();
                            {
                                List<int> classificationIds = new List<int>();
                                {
                                    string mappingTxtData = "";
                                    //Read data from CharacterEquipableWeaponClassification.txt
                                    using (StreamReader sr = File.OpenText(commonFilePath + @"\CharacterEquipableWeaponClassification.txt"))
                                    {
                                        mappingTxtData = sr.ReadToEnd();
                                    }
                                    string[] mappingRows = mappingTxtData.Split('\n');

                                    if (mappingRows.Count() > 1) //if not only header row
                                    {
                                        string[] mappingData;
                                        for (int j = 1; j < mappingRows.Count(); j++)
                                        {
                                            if (mappingRows[j] == "")
                                                break;
                                            mappingData = mappingRows[j].Split(';');
                                            if (Convert.ToInt32(mappingData[0]) == characterId)
                                            {
                                                classificationIds.Add(Convert.ToInt32(mappingData[1]));
                                            }
                                        }
                                    }
                                }
                                {
                                    string wcTxtData = "";
                                    //Read data from WeaponClassification.txt
                                    using (StreamReader sr = File.OpenText(commonFilePath + @"\WeaponClassification.txt"))
                                    {
                                        wcTxtData = sr.ReadToEnd();
                                    }
                                    string[] wcRows = wcTxtData.Split('\n');

                                    if (wcRows.Count() > 1) //if not only header row
                                    {
                                        string[] wcData;
                                        for (int j = 1; j < wcRows.Count(); j++)
                                        {
                                            if (wcRows[j] == "")
                                                break;
                                            wcData = wcRows[j].Split(';');
                                            foreach (int classificaitonId in classificationIds)
                                            {
                                                if (Convert.ToInt32(wcData[0]) == classificaitonId)
                                                    equipableWpnClasses.Add(ToCorrespondingEnumValue<eWeaponClassification>(wcData[1]));
                                            }
                                        }
                                    }
                                }
                            }


                            //////////////////////////////////////////////////////////
                            //EquipableArmourClassificaitons
                            //////////////////////////////////////////////////////////
                            List<eArmourClassification> equipableArmrClasses = new List<eArmourClassification>();
                            {
                                List<int> classificationIds = new List<int>();
                                {
                                    string mappingTxtData = "";
                                    //Read data from CharacterEquipableWeaponClassification.txt
                                    using (StreamReader sr = File.OpenText(commonFilePath + @"\CharacterEquipableArmourClassification.txt"))
                                    {
                                        mappingTxtData = sr.ReadToEnd();
                                    }
                                    string[] mappingRows = mappingTxtData.Split('\n');

                                    if (mappingRows.Count() > 1) //if not only header row
                                    {
                                        string[] mappingData;
                                        for (int j = 1; j < mappingRows.Count(); j++)
                                        {
                                            if (mappingRows[j] == "")
                                                break;
                                            mappingData = mappingRows[j].Split(';');
                                            if (Convert.ToInt32(mappingData[0]) == characterId)
                                            {
                                                classificationIds.Add(Convert.ToInt32(mappingData[1]));
                                            }
                                        }
                                    }
                                }
                                {
                                    string rcTxtData = "";
                                    //Read data from CharacterEquipableWeaponClassification.txt
                                    using (StreamReader sr = File.OpenText(commonFilePath + @"\ArmourClassification.txt"))
                                    {
                                        rcTxtData = sr.ReadToEnd();
                                    }
                                    string[] rcRows = rcTxtData.Split('\n');

                                    if (rcRows.Count() > 1) //if not only header row
                                    {
                                        string[] rcData;
                                        for (int j = 1; j < rcRows.Count(); j++)
                                        {
                                            if (rcRows[j] == "")
                                                break;
                                            rcData = rcRows[j].Split(';');

                                            foreach (int classificaitonId in classificationIds)
                                            {
                                                if (Convert.ToInt32(rcData[0]) == classificaitonId)
                                                    equipableArmrClasses.Add(ToCorrespondingEnumValue<eArmourClassification>(rcData[1]));
                                            }
                                        }
                                    }
                                }
                            }

                            //////////////////////////////////////////////////////////
                            //EquipableAccessoryClassificaitons
                            //////////////////////////////////////////////////////////
                            List<eAccessoryClassification> equipableAcsrClasses = new List<eAccessoryClassification>();
                            {
                                List<int> classificationIds = new List<int>();
                                {
                                    string mappingTxtData = "";
                                    //Read data from CharacterEquipableWeaponClassification.txt
                                    using (StreamReader sr = File.OpenText(commonFilePath + @"\CharacterEquipableAccessoryClassification.txt"))
                                    {
                                        mappingTxtData = sr.ReadToEnd();
                                    }
                                    string[] mappingRows = mappingTxtData.Split('\n');

                                    if (mappingRows.Count() > 1) //if not only header row
                                    {
                                        string[] mappingData;
                                        for (int j = 1; j < mappingRows.Count(); j++)
                                        {
                                            if (mappingRows[j] == "")
                                                break;
                                            mappingData = mappingRows[j].Split(';');
                                            if (Convert.ToInt32(mappingData[0]) == characterId)
                                            {
                                                classificationIds.Add(Convert.ToInt32(mappingData[1]));
                                            }
                                        }
                                    }
                                }
                                {
                                    string acTxtData = "";
                                    //Read data from CharacterEquipableWeaponClassification.txt
                                    using (StreamReader sr = File.OpenText(commonFilePath + @"\AccessoryClassification.txt"))
                                    {
                                        acTxtData = sr.ReadToEnd();
                                    }
                                    string[] acRows = acTxtData.Split('\n');

                                    if (acRows.Count() > 1) //if not only header row
                                    {
                                        string[] acData;
                                        for (int j = 1; j < acRows.Count(); j++)
                                        {
                                            if (acRows[j] == "")
                                                break;
                                            acData = acRows[j].Split(';');

                                            foreach (int classificaitonId in classificationIds)
                                            {
                                                if (Convert.ToInt32(acData[0]) == classificaitonId)
                                                    equipableAcsrClasses.Add(ToCorrespondingEnumValue<eAccessoryClassification>(acData[1]));
                                            }
                                        }
                                    }
                                }
                            }

                            //////////////////////////////////////////////////////////
                            //Skills
                            //////////////////////////////////////////////////////////
                            List<MainClassLib.Skill> skills = new List<MainClassLib.Skill>();
                            {
                                string sTxtData = "";
                                //Read data from CharacterEquipableWeaponClassification.txt
                                using (StreamReader sr = File.OpenText(commonFilePath + @"\CharacterSkill.txt"))
                                {
                                    sTxtData = sr.ReadToEnd();
                                }
                                string[] sRows = sTxtData.Split('\n');

                                if (sRows.Count() > 1) //if not only header row
                                {
                                    string[] sData;
                                    for (int j = 1; j < sRows.Count(); j++)
                                    {
                                        if (sRows[j] == "")
                                            break;
                                        sData = sRows[j].Split(';');

                                        if (Convert.ToInt32(sData[0]) == characterId)
                                            skills.Add(LoadSkillData(Convert.ToInt32(sData[1])));
                                    }
                                }
                            }

                            //////////////////////////////////////////////////////////
                            //Icon
                            //////////////////////////////////////////////////////////
                            //t_IMAGE iconAsByteArray = new t_IMAGE { Id = iconId, ImageAsByteArray = LoadImageBytes("CharacterIconAsByteArray.txt", iconId) };
                            t_IMAGE iconAsByteArray = new t_IMAGE { Id = iconId, ImageAsByteArray = null };

                            //////////////////////////////////////////////////////////
                            //Sprite
                            //////////////////////////////////////////////////////////
                            //t_IMAGE spriteAsByteArray = new t_IMAGE { Id = spriteId, ImageAsByteArray = LoadImageBytes("CharacterSpriteAsByteArray.txt", spriteId) };
                            t_IMAGE spriteAsByteArray = new t_IMAGE { Id = spriteId, ImageAsByteArray = null };


                            return new UnitBase(characterId, iconAsByteArray, spriteAsByteArray, name, gender, rarity, species, elements, equipableWpnClasses, equipableArmrClasses, equipableAcsrClasses, maxHPAtMaxLevel, phyStrAtMaxLevel, phyResAtMaxLevel, magStrAtMaxLevel, magResAtMaxLevel, vitAtMaxLevel, skills);
                        }
                    }
                }

                return null;
            }
            catch (Exception ex)
            {
                Debug.Log(ex.Message + ex.InnerException + ex.TargetSite);
                return null;
            }
        }

        //public static byte[] LoadImageBytes(string _fileName, int _imageId)
        //{
        //    string imageTxt = "";
        //    //Read data from CharacterSkill.txt
        //    using (StreamReader sr = File.OpenText(commonFilePath + @"\" + _fileName))
        //    {
        //        imageTxt = sr.ReadToEnd();
        //    }

        //    string[] txt_byteArrays = CustomTxtSplitting(imageTxt);

        //    //Decode
        //    return Convert.FromBase64String(txt_byteArrays[_imageId]);
        //}

        /// <summary>
        /// Set _transformableWeaponsAlreadySet to new List<Weapon> when using the method from outside of the method
        /// </summary>
        /// <param name="_id"></param>
        /// <param name="_transformableWeapon"></param>
        /// <returns></returns>
        private static MainClassLib.Weapon LoadWeaponData(int _id, ref List<Weapon> _transformableWeaponsAlreadyCreated)
        {
            try
            {
                //used to avoid infinite loop when adding transformable weapons to the transformable weapons
                if (_transformableWeaponsAlreadyCreated == null)
                    _transformableWeaponsAlreadyCreated = new List<Weapon>();

                string wTxtData = "";
                //Read data from CharacterEquipableWeaponClassification.txt
                using (StreamReader sr = File.OpenText(commonFilePath + @"\Weapon.txt"))
                {
                    wTxtData = sr.ReadToEnd();
                }
                string[] rows = wTxtData.Split('\n');

                if (rows.Count() > 1) //if not only header row
                {
                    string[] wData;
                    for (int i = 1; i < rows.Count(); i++)
                    {
                        wData = rows[i].Split(';');
                        if (Convert.ToInt32(wData[0]) == _id)
                        {
                            int weaponId = Convert.ToInt32(wData[0]);
                            string name = wData[1];
                            int rarityInt = Convert.ToInt32(wData[2]);
                            string weaponTypeString = wData[3];
                            int cost = Convert.ToInt32(wData[4]);
                            int iconId = Convert.ToInt32(wData[5]);

                            eRarity rarity = eRarity.NORMAL;
                            switch (rarityInt)
                            {
                                case 2:
                                    rarity = eRarity.BRONZE;
                                    break;
                                case 3:
                                    rarity = eRarity.SILVER;
                                    break;
                                case 4:
                                    rarity = eRarity.GOLD;
                                    break;
                                case 5:
                                    rarity = eRarity.PLATINUM;
                                    break;
                                default:
                                    break;
                            }

                            eWeaponType weaponType = ToCorrespondingEnumValue<eWeaponType>(weaponTypeString);

                            //////////////////////////////////////////////////////////
                            //WeaponClassificaitons
                            //////////////////////////////////////////////////////////
                            List<eWeaponClassification> weaponClassifications = new List<eWeaponClassification>();
                            {
                                List<int> classificationIds = new List<int>();
                                {
                                    string mappingTxtData = "";
                                    //Read data from CharacterEquipableWeaponClassification.txt
                                    using (StreamReader sr = File.OpenText(commonFilePath + @"\WeaponWeaponClassification.txt"))
                                    {
                                        mappingTxtData = sr.ReadToEnd();
                                    }
                                    string[] mappingRows = mappingTxtData.Split('\n');

                                    if (mappingRows.Count() > 1) //if not only header row
                                    {
                                        string[] mappingData;
                                        for (int j = 1; j < mappingRows.Count(); j++)
                                        {
                                            mappingData = mappingRows[j].Split(';');
                                            if (Convert.ToInt32(mappingData[0]) == weaponId)
                                            {
                                                classificationIds.Add(Convert.ToInt32(mappingData[1]));
                                            }
                                        }
                                    }
                                }
                                {
                                    string wcTxtData = "";
                                    //Read data from CharacterEquipableWeaponClassification.txt
                                    using (StreamReader sr = File.OpenText(commonFilePath + @"\WeaponClassification.txt"))
                                    {
                                        wcTxtData = sr.ReadToEnd();
                                    }
                                    string[] wcRows = wcTxtData.Split('\n');

                                    if (wcRows.Count() > 1) //if not only header row
                                    {
                                        string[] wcData;
                                        for (int j = 1; j < wcRows.Count(); j++)
                                        {
                                            wcData = wcRows[j].Split(';');

                                            foreach (int classificaitonId in classificationIds)
                                            {
                                                if (Convert.ToInt32(wcData[0]) == classificaitonId)
                                                    weaponClassifications.Add(ToCorrespondingEnumValue<eWeaponClassification>(wcData[1]));
                                            }
                                        }
                                    }
                                }
                            }

                            //////////////////////////////////////////////////////////
                            //BaseSkills
                            //////////////////////////////////////////////////////////
                            List<MainClassLib.Skill> baseSkills = new List<MainClassLib.Skill>();
                            {
                                string sTxtData = "";
                                //Read data from CharacterEquipableWeaponClassification.txt
                                using (StreamReader sr = File.OpenText(commonFilePath + @"\WeaponBaseSkill.txt"))
                                {
                                    sTxtData = sr.ReadToEnd();
                                }
                                string[] sRows = sTxtData.Split('\n');

                                if (sRows.Count() > 1) //if not only header row
                                {
                                    string[] sData;
                                    for (int j = 1; j < sRows.Count(); j++)
                                    {
                                        sData = sRows[j].Split(';');

                                        if (Convert.ToInt32(sData[0]) == weaponId)
                                            baseSkills.Add(LoadSkillData(Convert.ToInt32(sData[1])));
                                    }
                                }
                            }

                            //////////////////////////////////////////////////////////
                            //MainSkills
                            //////////////////////////////////////////////////////////
                            List<MainClassLib.Skill> mainSkills = new List<MainClassLib.Skill>();
                            {
                                string sTxtData = "";
                                //Read data from CharacterEquipableWeaponClassification.txt
                                using (StreamReader sr = File.OpenText(commonFilePath + @"\WeaponMainSkill.txt"))
                                {
                                    sTxtData = sr.ReadToEnd();
                                }
                                string[] sRows = sTxtData.Split('\n');

                                if (sRows.Count() > 1) //if not only header row
                                {
                                    string[] sData;
                                    for (int j = 1; j < sRows.Count(); j++)
                                    {
                                        sData = sRows[j].Split(';');

                                        if (Convert.ToInt32(sData[0]) == weaponId)
                                            mainSkills.Add(LoadSkillData(Convert.ToInt32(sData[1])));
                                    }
                                }
                            }

                            //Weapon to return eventually
                            MainClassLib.Weapon result = new MainClassLib.Weapon(weaponId, name, rarity, baseSkills, weaponType, weaponClassifications, mainSkills, cost);

                            _transformableWeaponsAlreadyCreated.Add(result);

                            //////////////////////////////////////////////////////////
                            //TransformableWeapons
                            //////////////////////////////////////////////////////////
                            {
                                List<int> transformableWeaponIds = new List<int>();
                                {
                                    string mappingTxtData = "";
                                    //Read data from CharacterEquipableWeaponClassification.txt
                                    using (StreamReader sr = File.OpenText(commonFilePath + @"\WeaponTransformableWeapon.txt"))
                                    {
                                        mappingTxtData = sr.ReadToEnd();
                                    }
                                    string[] mappingRows = mappingTxtData.Split('\n');

                                    if (mappingRows.Count() > 1) //if not only header row
                                    {
                                        string[] mappingData;
                                        for (int j = 1; j < mappingRows.Count(); j++)
                                        {
                                            mappingData = mappingRows[j].Split(';');
                                            if (Convert.ToInt32(mappingData[0]) == weaponId)
                                            {
                                                transformableWeaponIds.Add(Convert.ToInt32(mappingData[1]));
                                            }
                                        }
                                    }
                                }
                                {
                                    string twTxtData = "";
                                    //Read data from CharacterEquipableWeaponClassification.txt
                                    using (StreamReader sr = File.OpenText(commonFilePath + @"\Weapon.txt"))
                                    {
                                        twTxtData = sr.ReadToEnd();
                                    }
                                    string[] twRows = twTxtData.Split('\n');

                                    if (twRows.Count() > 1) //if not only header row
                                    {
                                        string[] twData;
                                        for (int j = 1; j < twRows.Count(); j++)
                                        {
                                            twData = twRows[j].Split(';');

                                            foreach (int transformableWeaponId in transformableWeaponIds)
                                            {
                                                if (Convert.ToInt32(twData[0]) == transformableWeaponId)
                                                {
                                                    foreach (MainClassLib.Weapon existingWeapon in _transformableWeaponsAlreadyCreated)
                                                    {
                                                        if (transformableWeaponId == existingWeapon.Id)
                                                            result.TransformableWeapons.Add(existingWeapon);
                                                        else
                                                            result.TransformableWeapons.Add(LoadWeaponData(transformableWeaponId, ref _transformableWeaponsAlreadyCreated));
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                            return result;
                        }
                    }
                }

                return null;
            }
            catch (Exception ex)
            {
                Debug.Log(ex.Message + ex.InnerException + ex.TargetSite);
                return null;
            }
        }

        private static List<UsableWeapon> LoadUsableWeaponData(Player _owner)
        {
            try
            {
                List<UsableWeapon> result = new List<UsableWeapon>();
                string uwTxtData = "";
                //Read data from CharacterEquipableWeaponClassification.txt
                using (StreamReader sr = File.OpenText(commonFilePath + @"\UsableWeapon.txt"))
                {
                    uwTxtData = sr.ReadToEnd();
                }
                string[] rows = uwTxtData.Split('\n');

                if (rows.Count() > 1) //if not only header row
                {
                    string[] uwData;
                    for (int i = 1; i < rows.Count(); i++)
                    {
                        if (rows[i] == "")
                            break;
                        uwData = rows[i].Split(';');

                        if (Convert.ToInt32(uwData[2]) == _owner.Id) // Owner Id matches
                        {
                            int usableWeaponId = Convert.ToInt32(uwData[0]);
                            int baseWeaponId = Convert.ToInt32(uwData[1]);
                            int level = Convert.ToInt32(uwData[3]);

                            List<Weapon> dummyForReferenceArgument = new List<Weapon>();
                            MainClassLib.Weapon weapon = LoadWeaponData(baseWeaponId, ref dummyForReferenceArgument);

                            result.Add(new MainClassLib.UsableWeapon(weapon, usableWeaponId, level));
                        }
                    }
                }

                return result;
            }
            catch (Exception ex)
            {
                Debug.Log(ex.Message + ex.InnerException + ex.TargetSite);
                return null;
            }
        }

        public static MainClassLib.Armour LoadArmourData(int _id)
        {
            try
            {
                string rTxtData = "";
                //Read data from CharacterEquipableWeaponClassification.txt
                using (StreamReader sr = File.OpenText(commonFilePath + @"\Armour.txt"))
                {
                    rTxtData = sr.ReadToEnd();
                }
                string[] rows = rTxtData.Split('\n');

                if (rows.Count() > 1) //if not only header row
                {
                    string[] rData;
                    for (int i = 1; i < rows.Count(); i++)
                    {
                        if (rows[i] == "")
                            break;
                        rData = rows[i].Split(';');
                        if (Convert.ToInt32(rData[0]) == _id)
                        {
                            int armourId = Convert.ToInt32(rData[0]);
                            string name = rData[1];
                            string armourClassificationString = rData[2];
                            string targetGenderString = rData[3];
                            int rarityInt = Convert.ToInt32(rData[4]);
                            int iconId = Convert.ToInt32(rData[5]);

                            eRarity rarity = eRarity.NORMAL;
                            switch (rarityInt)
                            {
                                case 2:
                                    rarity = eRarity.BRONZE;
                                    break;
                                case 3:
                                    rarity = eRarity.SILVER;
                                    break;
                                case 4:
                                    rarity = eRarity.GOLD;
                                    break;
                                case 5:
                                    rarity = eRarity.PLATINUM;
                                    break;
                                default:
                                    break;
                            }

                            eArmourClassification armourClassification = ToCorrespondingEnumValue<eArmourClassification>(armourClassificationString);

                            eGender targetGender = ToCorrespondingEnumValue<eGender>(targetGenderString);

                            //////////////////////////////////////////////////////////
                            //Skills
                            //////////////////////////////////////////////////////////
                            List<MainClassLib.Skill> skills = new List<MainClassLib.Skill>();
                            {
                                string sTxtData = "";
                                //Read data from CharacterEquipableWeaponClassification.txt
                                using (StreamReader sr = File.OpenText(commonFilePath + @"\ArmourSkill.txt"))
                                {
                                    sTxtData = sr.ReadToEnd();
                                }
                                string[] sRows = sTxtData.Split('\n');

                                if (sRows.Count() > 1) //if not only header row
                                {
                                    string[] sData;
                                    for (int j = 1; j < sRows.Count(); j++)
                                    {
                                        if (sRows[j] == "")
                                            break;
                                        sData = sRows[j].Split(';');

                                        if (Convert.ToInt32(sData[0]) == armourId)
                                            skills.Add(LoadSkillData(Convert.ToInt32(sData[1])));
                                    }
                                }
                            }
                            return new Armour(armourId, name, rarity, skills, armourClassification, targetGender);
                        }
                    }
                }

                return null;
            }
            catch (Exception ex)
            {
                Debug.Log(ex.Message + ex.InnerException + ex.TargetSite);
                return null;
            }
        }

        private static List<UsableArmour> LoadUsableArmourData(Player _owner)
        {
            try
            {
                List<UsableArmour> result = new List<UsableArmour>();
                string urTxtData = "";
                //Read data from CharacterEquipableWeaponClassification.txt
                using (StreamReader sr = File.OpenText(commonFilePath + @"\UsableArmour.txt"))
                {
                    urTxtData = sr.ReadToEnd();
                }
                string[] rows = urTxtData.Split('\n');

                if (rows.Count() > 1) //if not only header row
                {
                    string[] urData;
                    for (int i = 1; i < rows.Count(); i++)
                    {
                        if (rows[i] == "")
                            break;
                        urData = rows[i].Split(';');
                        if (Convert.ToInt32(urData[2]) == _owner.Id) // Owner Id matches
                        {
                            int usableArmourId = Convert.ToInt32(urData[0]);
                            int baseArmourId = Convert.ToInt32(urData[1]);

                            MainClassLib.Armour armour = LoadArmourData(baseArmourId);

                            result.Add(new MainClassLib.UsableArmour(armour, usableArmourId));
                        }
                    }
                }

                return result;
            }
            catch (Exception ex)
            {
                Debug.Log(ex.Message + ex.InnerException + ex.TargetSite);
                return null;
            }
        }

        public static MainClassLib.Accessory LoadAccessoryData(int _id)
        {
            try
            {
                string aTxtData = "";
                //Read data from CharacterEquipableWeaponClassification.txt
                using (StreamReader sr = File.OpenText(commonFilePath + @"\Weapon.txt"))
                {
                    aTxtData = sr.ReadToEnd();
                }
                string[] rows = aTxtData.Split('\n');

                if (rows.Count() > 1) //if not only header row
                {
                    string[] aData;
                    for (int i = 1; i < rows.Count(); i++)
                    {
                        if (rows[i] == "")
                            break;
                        aData = rows[i].Split(';');
                        if (Convert.ToInt32(aData[0]) == _id)
                        {
                            int accessoryId = Convert.ToInt32(aData[0]);
                            string name = aData[1];
                            string accessoryClassificationString = aData[2];
                            string targetGenderString = aData[3];
                            int rarityInt = Convert.ToInt32(aData[4]);
                            int iconId = Convert.ToInt32(aData[5]);

                            eRarity rarity = eRarity.NORMAL;
                            switch (rarityInt)
                            {
                                case 2:
                                    rarity = eRarity.BRONZE;
                                    break;
                                case 3:
                                    rarity = eRarity.SILVER;
                                    break;
                                case 4:
                                    rarity = eRarity.GOLD;
                                    break;
                                case 5:
                                    rarity = eRarity.PLATINUM;
                                    break;
                                default:
                                    break;
                            }

                            eAccessoryClassification accessoryClassification = ToCorrespondingEnumValue<eAccessoryClassification>(accessoryClassificationString);

                            eGender targetGender = ToCorrespondingEnumValue<eGender>(targetGenderString);

                            //////////////////////////////////////////////////////////
                            //BaseSkills
                            //////////////////////////////////////////////////////////
                            List<MainClassLib.Skill> skills = new List<MainClassLib.Skill>();
                            {
                                string sTxtData = "";
                                //Read data from CharacterEquipableWeaponClassification.txt
                                using (StreamReader sr = File.OpenText(commonFilePath + @"\WeaponBaseSkill.txt"))
                                {
                                    sTxtData = sr.ReadToEnd();
                                }
                                string[] sRows = sTxtData.Split('\n');

                                if (sRows.Count() > 1) //if not only header row
                                {
                                    string[] sData;
                                    for (int j = 1; j < sRows.Count(); j++)
                                    {
                                        if (sRows[i] == "")
                                            break;
                                        sData = sRows[j].Split(';');

                                        if (Convert.ToInt32(sData[0]) == accessoryId)
                                            skills.Add(LoadSkillData(Convert.ToInt32(sData[1])));
                                    }
                                }
                            }
                            return new Accessory(accessoryId, name, rarity, skills, accessoryClassification, targetGender);
                        }
                    }
                }

                return null;
            }
            catch (Exception ex)
            {
                Debug.Log(ex.Message + ex.InnerException + ex.TargetSite);
                return null;
            }
        }

        private static List<UsableAccessory> LoadUsableAccessoryData(Player _owner)
        {
            try
            {
                List<UsableAccessory> result = new List<UsableAccessory>();
                string uaTxtData = "";
                //Read data from CharacterEquipableWeaponClassification.txt
                using (StreamReader sr = File.OpenText(commonFilePath + @"\WeaponMainSkill.txt"))
                {
                    uaTxtData = sr.ReadToEnd();
                }
                string[] rows = uaTxtData.Split('\n');

                if (rows.Count() > 1) //if not only header row
                {
                    string[] uaData;
                    for (int i = 1; i < rows.Count(); i++)
                    {
                        if (rows[i] == "")
                            break;
                        uaData = rows[i].Split(';');

                        if (Convert.ToInt32(uaData[2]) == _owner.Id) // Owner Id matches
                        {
                            int usableAccessoryId = Convert.ToInt32(uaData[0]);
                            int baseAccessoryId = Convert.ToInt32(uaData[1]);

                            MainClassLib.Accessory accessory = LoadAccessoryData(baseAccessoryId);

                            result.Add(new MainClassLib.UsableAccessory(accessory, usableAccessoryId));
                        }
                    }
                }

                return result;
            }
            catch (Exception ex)
            {
                Debug.Log(ex.Message + ex.InnerException + ex.TargetSite);
                return null;
            }
        }

        public static MainClassLib.Skill LoadSkillData(int _id)
        {
            try
            {
                string sTxtData = "";
                //Read data from CharacterEquipableWeaponClassification.txt
                using (StreamReader sr = File.OpenText(commonFilePath + @"\Skill.txt"))
                {
                    sTxtData = sr.ReadToEnd();
                }
                string[] rows = sTxtData.Split('\n');

                if (rows.Count() > 1) //if not only header row
                {
                    string[] sData;
                    for (int i = 1; i < rows.Count(); i++)
                    {
                        if (rows[i] == "")
                            break;
                        sData = rows[i].Split(';');
                        if (Convert.ToInt32(sData[0]) == _id)
                        {
                            int skillId = Convert.ToInt32(sData[0]);
                            string name = sData[1];
                            string skillTypeString = sData[2];
                            int cost = Convert.ToInt32(sData[3]);
                            int animationId = Convert.ToInt32(sData[4]);

                            eSkillType skillType = ToCorrespondingEnumValue<eSkillType>(skillTypeString);

                            //////////////////////////////////////////////////////////
                            //Effects
                            //////////////////////////////////////////////////////////
                            List<MainClassLib.Effect> effects = new List<MainClassLib.Effect>();
                            {
                                string mappingTxtData = "";
                                //Read data from CharacterEquipableWeaponClassification.txt
                                using (StreamReader sr = File.OpenText(commonFilePath + @"\SkillEffect.txt"))
                                {
                                    mappingTxtData = sr.ReadToEnd();
                                }
                                string[] mappingRows = mappingTxtData.Split('\n');

                                if (mappingRows.Count() > 1) //if not only header row
                                {
                                    string[] mappingData;
                                    for (int j = 1; j < mappingRows.Count(); j++)
                                    {
                                        if (mappingRows[j] == "")
                                            break;
                                        mappingData = mappingRows[j].Split(';');

                                        if (Convert.ToInt32(mappingData[0]) == skillId)
                                            effects.Add(LoadEffectData(Convert.ToInt32(mappingData[1])));
                                    }
                                }
                            }
                            return new Skill(skillId, name, skillType, cost, effects, animationId);
                        }
                    }
                }

                return null;
            }
            catch (Exception ex)
            {
                Debug.Log(ex.Message + ex.InnerException + ex.TargetSite);
                return null;
            }
        }

        public static MainClassLib.Effect LoadEffectData(int _id)
        {
            try
            {
                string baseEffectTxtData = "";
                //Read data from CharacterEquipableWeaponClassification.txt
                using (StreamReader sr = File.OpenText(commonFilePath + @"\Effect.txt"))
                {
                    baseEffectTxtData = sr.ReadToEnd();
                }
                string[] rows = baseEffectTxtData.Split('\n');

                if (rows.Count() > 1) //if not only header row
                {
                    string[] baseEffectData;
                    for (int i = 1; i < rows.Count(); i++)
                    {
                        if (rows[i] == "")
                            break;
                        baseEffectData = rows[i].Split(';');
                        if (Convert.ToInt32(baseEffectData[0]) == _id)
                        {
                            int effectId = Convert.ToInt32(baseEffectData[0]);
                            int timesToApply = Convert.ToInt32(baseEffectData[1]);
                            double successRate = Convert.ToDouble(baseEffectData[2]);
                            string effectsClassification = baseEffectData[3];
                            int animationId = Convert.ToInt32(baseEffectData[4]);

                            //////////////////////////////////////////////////////////
                            //TargetArea
                            //////////////////////////////////////////////////////////
                            List<MainClassLib._2DCoord> targetArea = new List<MainClassLib._2DCoord>();
                            {
                                List<int> coordIds = new List<int>();
                                {
                                    string mappingTxtData = "";
                                    //Read data from CharactersSkills.txt
                                    using (StreamReader sr = File.OpenText(commonFilePath + @"\EffectTargetArea.txt"))
                                    {
                                        mappingTxtData = sr.ReadToEnd();
                                    }
                                    string[] mappingRows = mappingTxtData.Split('\n');

                                    if (mappingRows.Count() > 1) //if not only header row
                                    {
                                        string[] mappingData;
                                        for (int j = 1; j < mappingRows.Count(); j++)
                                        {
                                            if (mappingRows[j] == "")
                                                break;
                                            mappingData = mappingRows[j].Split(';');

                                            if (Convert.ToInt32(mappingData[0]) == effectId)
                                                coordIds.Add(Convert.ToInt32(mappingData[1]));
                                        }
                                    }
                                }
                                {
                                    string cTxtData = "";
                                    //Read data from CharactersSkills.txt
                                    using (StreamReader sr = File.OpenText(commonFilePath + @"\Coord.txt"))
                                    {
                                        cTxtData = sr.ReadToEnd();
                                    }
                                    string[] cRows = cTxtData.Split('\n');

                                    if (cRows.Count() > 1) //if not only header row
                                    {
                                        string[] cData;
                                        for (int j = 1; j < cRows.Count(); j++)
                                        {
                                            if (cRows[j] == "")
                                                break;
                                            cData = cRows[j].Split(',');

                                            foreach (int coordId in coordIds)
                                            {
                                                if (Convert.ToInt32(cData[0]) == coordId)
                                                {
                                                    int x = Convert.ToInt32(cData[1]);
                                                    int y = Convert.ToInt32(cData[2]);

                                                    targetArea.Add(new _2DCoord(x, y));
                                                }
                                            }
                                        }
                                    }
                                }
                            }

                            //////////////////////////////////////////////////////////
                            //SecondaryEffects
                            //////////////////////////////////////////////////////////
                            List<MainClassLib.Effect> secondaryEffects = new List<MainClassLib.Effect>();
                            {
                                string mappingTxtData = "";
                                //Read data from CharacterEquipableWeaponClassification.txt
                                using (StreamReader sr = File.OpenText(commonFilePath + @"\EffectSecondaryEffect.txt"))
                                {
                                    mappingTxtData = sr.ReadToEnd();
                                }
                                string[] mappingRows = mappingTxtData.Split('\n');

                                if (mappingRows.Count() > 1) //if not only header row
                                {
                                    string[] mappingData;
                                    for (int j = 1; j < mappingRows.Count(); j++)
                                    {
                                        if (mappingRows[j] == "")
                                            break;
                                        mappingData = mappingRows[j].Split(';');
                                        if (Convert.ToInt32(mappingData[0]) == effectId)
                                            secondaryEffects.Add(LoadEffectData(Convert.ToInt32(mappingData[1])));
                                    }
                                }
                            }

                            //Remove escape sequence
                            if (effectsClassification.Contains("\n") || effectsClassification.Contains("\r") || effectsClassification.Contains("\t"))
                                effectsClassification = effectsClassification.Substring(0, effectsClassification.Length - 1);


                            switch (effectsClassification)
                            {
                                /*-----------------
                                   Damage Effect
                                -----------------*/
                                case "Damage":
                                    {
                                        string eTxtData = "";
                                        //Read data from CharacterEquipableWeaponClassification.txt
                                        using (StreamReader sr = File.OpenText(commonFilePath + @"\DamageEffect.txt"))
                                        {
                                            eTxtData = sr.ReadToEnd();
                                        }
                                        string[] eRows = eTxtData.Split('\n');

                                        if (eRows.Count() > 1) //if not only header row
                                        {
                                            string[] eData;
                                            for (int j = 1; j < eRows.Count(); j++)
                                            {
                                                if (eRows[j] == "")
                                                    break;
                                                eData = eRows[j].Split(';');

                                                if (Convert.ToInt32(eData[0]) == effectId)
                                                {
                                                    string targetCharacterClassificationString = eData[1];
                                                    string attackTypeString = eData[2];
                                                    string elementString = eData[3];
                                                    int power = Convert.ToInt32(eData[4]);
                                                    bool doesPreservePower;
                                                    if (eData[5] == "True")
                                                        doesPreservePower = true;
                                                    else
                                                        doesPreservePower = false;
                                                    int guardBreakability = Convert.ToInt32(eData[6]);

                                                    eTargetCharacterClassificaton targetClassification = ToCorrespondingEnumValue<eTargetCharacterClassificaton>(targetCharacterClassificationString);

                                                    eAttackClassification attackType = ToCorrespondingEnumValue<eAttackClassification>(attackTypeString);

                                                    eElement element = ToCorrespondingEnumValue<eElement>(elementString);

                                                    return new MainClassLib.Damage(targetArea, timesToApply, successRate, secondaryEffects, animationId, targetClassification, attackType, power, element, doesPreservePower, guardBreakability);
                                                }
                                            }
                                        }
                                        return null;
                                    }

                                /*----------------------------
                                   Effect Attachment Effect
                                ----------------------------*/
                                case "EffectAttachment":
                                    {
                                        string eTxtData = "";
                                        //Read data from CharacterEquipableWeaponClassification.txt
                                        using (StreamReader sr = File.OpenText(commonFilePath + @"\EffectAttachmentEffect.txt"))
                                        {
                                            eTxtData = sr.ReadToEnd();
                                        }
                                        string[] eRows = eTxtData.Split('\n');

                                        if (eRows.Count() > 1) //if not only header row
                                        {
                                            string[] eData;
                                            for (int j = 1; j < eRows.Count(); j++)
                                            {
                                                if (eRows[j] == "")
                                                    break;
                                                eData = eRows[j].Split(';');
                                                if (Convert.ToInt32(eData[0]) == effectId)
                                                {
                                                    string targetCharacterClassificationString = eData[1];
                                                    int continuousEffectId = Convert.ToInt32(eData[2]);

                                                    eTargetCharacterClassificaton targetClassification = ToCorrespondingEnumValue<eTargetCharacterClassificaton>(targetCharacterClassificationString);

                                                    ContinuousEffect effectToAttach = LoadContinuousEffectData(continuousEffectId);

                                                    return new MainClassLib.EffectAttachment(targetArea, timesToApply, successRate, secondaryEffects, animationId, targetClassification, effectToAttach);
                                                }

                                            }
                                        }
                                        return null;
                                    }



                                /*-----------------
                                   Heal Effect
                                -----------------*/
                                case "Heal":
                                    {
                                        string eTxtData = "";
                                        //Read data from CharacterEquipableWeaponClassification.txt
                                        using (StreamReader sr = File.OpenText(commonFilePath + @"\HealEffect.txt"))
                                        {
                                            eTxtData = sr.ReadToEnd();
                                        }
                                        string[] eRows = eTxtData.Split('\n');

                                        if (eRows.Count() > 1) //if not only header row
                                        {
                                            string[] eData;
                                            for (int j = 1; j < eRows.Count(); j++)
                                            {
                                                if (eRows[j] == "")
                                                    break;
                                                eData = eRows[j].Split(';');

                                                if (Convert.ToInt32(eData[0]) == effectId)
                                                {
                                                    string targetCharacterClassificationString = eData[1];
                                                    int power = Convert.ToInt32(eData[2]);
                                                    bool doesPreservePower;
                                                    if (eData[3] == "True")
                                                        doesPreservePower = true;
                                                    else
                                                        doesPreservePower = false;

                                                    eTargetCharacterClassificaton targetClassification = ToCorrespondingEnumValue<eTargetCharacterClassificaton>(targetCharacterClassificationString);

                                                    return new MainClassLib.Heal(targetArea, timesToApply, successRate, secondaryEffects, animationId, targetClassification, power, doesPreservePower);
                                                }
                                            }
                                        }
                                        return null;
                                    }

                                /*------------
                                    Error
                                ------------*/
                                default:
                                    return null;
                            }
                        }
                    }
                }

                return null;
            }
            catch (Exception ex)
            {
                Debug.Log(ex.Message + ex.InnerException + ex.TargetSite);
                return null;
            }
        }

        public static ContinuousEffect LoadContinuousEffectData(int _id)
        {
            try
            {
                string ceTxtData = "";
                //Read data from Coord.txt
                using (StreamReader sr = File.OpenText(commonFilePath + @"\ContinuousEffect.txt"))
                {
                    ceTxtData = sr.ReadToEnd();
                }
                string[] rows = ceTxtData.Split('\n');

                for (int i = 1; i < rows.Count(); i++)
                {
                    if (rows[i] == "")
                        break;
                    string[] ceData = rows[i].Split(';');

                    if (Convert.ToInt32(ceData[0]) == _id)
                    {
                        string continuousEffectTypeString = ceData[1];

                        eContinuousEffectType continuousEffectType = ToCorrespondingEnumValue<eContinuousEffectType>(continuousEffectTypeString);

                        return new ContinuousEffect(continuousEffectType, null, null, null);
                    }
                }

                return null;
            }
            catch (Exception ex)
            {
                Debug.Log(ex.Message + ex.InnerException + ex.TargetSite);
                return null;
            }
        }

        public static List<Team> LoadTeamData(Player _owner)
        {
            try
            {
                List<Team> result = new List<Team>();

                string tTxtData = "";
                //Read data from Coord.txt
                using (StreamReader sr = File.OpenText(commonFilePath + @"\Team.txt"))
                {
                    tTxtData = sr.ReadToEnd();
                }
                string[] rows = tTxtData.Split('\n');

                for (int i = 1; i < rows.Count(); i++)
                {
                    if (rows[i] == "")
                        break;
                    string[] tData = rows[i].Split(';');

                    if (Convert.ToInt32(tData[1]) == _owner.Id)
                    {
                        List<MainClassLib.t_MemberSet> memberSets = new List<t_MemberSet>();

                        int teamId = Convert.ToInt32(tData[0]);
                        int member1Id = Convert.ToInt32(tData[2]);
                        int member1armrId = Convert.ToInt32(tData[3]);
                        int member1acsrId = Convert.ToInt32(tData[4]);
                        int member2Id = Convert.ToInt32(tData[5]);
                        int member2armrId = Convert.ToInt32(tData[6]);
                        int member2acsrId = Convert.ToInt32(tData[7]);
                        int member3Id = Convert.ToInt32(tData[8]);
                        int member3armrId = Convert.ToInt32(tData[9]);
                        int member3acsrId = Convert.ToInt32(tData[10]);
                        int member4Id = Convert.ToInt32(tData[11]);
                        int member4armrId = Convert.ToInt32(tData[12]);
                        int member4acsrId = Convert.ToInt32(tData[13]);
                        int member5Id = Convert.ToInt32(tData[14]);
                        int member5armrId = Convert.ToInt32(tData[15]);
                        int member5acsrId = Convert.ToInt32(tData[16]);

                        List<UsableWeapon> member1weapons = new List<UsableWeapon>();
                        List<UsableWeapon> member2weapons = new List<UsableWeapon>();
                        List<UsableWeapon> member3weapons = new List<UsableWeapon>();
                        List<UsableWeapon> member4weapons = new List<UsableWeapon>();
                        List<UsableWeapon> member5weapons = new List<UsableWeapon>();

                        /////////////////////
                        //Member 1
                        /////////////////////
                        {

                            string mTxtData = "";
                            //Read data from Coord.txt
                            using (StreamReader sr = File.OpenText(commonFilePath + @"\TeamMember1Weapon.txt"))
                            {
                                mTxtData = sr.ReadToEnd();
                            }
                            string[] mRows = mTxtData.Split('\n');

                            for (int j = 1; j < mRows.Count(); j++)
                            {
                                if (mRows[i] == "")
                                    break;
                                string[] mData = mRows[j].Split(';');
                                if (Convert.ToInt32(mData[0]) == teamId)
                                {
                                    int usableWeaponId = Convert.ToInt32(mData[1]);

                                    member1weapons.Add(_owner.WeaponsOwned.Where(w => w.UniqueId == usableWeaponId).FirstOrDefault());
                                }
                            }
                            memberSets.Add(new t_MemberSet
                            {
                                Member = _owner.UnitsData.Where(c => c.UniqueId == member1Id).FirstOrDefault(),
                                Weapons = member1weapons,
                                Armour = _owner.ArmoursOwned.Where(a => a.UniqueId == member1armrId).FirstOrDefault(),
                                Accessory = _owner.AccessoriesOwned.Where(a => a.UniqueId == member1acsrId).FirstOrDefault()
                            });
                        }


                        /////////////////////
                        //Member 2
                        /////////////////////
                        {
                            string mTxtData = "";
                            //Read data from Coord.txt
                            using (StreamReader sr = File.OpenText(commonFilePath + @"\TeamMember2Weapon.txt"))
                            {
                                mTxtData = sr.ReadToEnd();
                            }
                            string[] mRows = mTxtData.Split('\n');

                            for (int j = 1; j < mRows.Count(); j++)
                            {
                                if (mRows[i] == "")
                                    break;
                                string[] mData = mRows[j].Split(';');
                                if (Convert.ToInt32(mData[0]) == teamId)
                                {
                                    int usableWeaponId = Convert.ToInt32(mData[1]);

                                    member2weapons.Add(_owner.WeaponsOwned.Where(w => w.UniqueId == usableWeaponId).FirstOrDefault());
                                }
                            }
                            memberSets.Add(new t_MemberSet
                            {
                                Member = _owner.UnitsData.Where(c => c.UniqueId == member2Id).FirstOrDefault(),
                                Weapons = member2weapons,
                                Armour = _owner.ArmoursOwned.Where(a => a.UniqueId == member2armrId).FirstOrDefault(),
                                Accessory = _owner.AccessoriesOwned.Where(a => a.UniqueId == member2acsrId).FirstOrDefault()
                            });
                        }

                        /////////////////////
                        //Member 3
                        /////////////////////
                        {
                            string mTxtData = "";
                            //Read data from Coord.txt
                            using (StreamReader sr = File.OpenText(commonFilePath + @"\TeamMember3Weapon.txt"))
                            {
                                mTxtData = sr.ReadToEnd();
                            }
                            string[] mRows = mTxtData.Split('\n');

                            for (int j = 1; j < mRows.Count(); j++)
                            {
                                if (mRows[i] == "")
                                    break;
                                string[] mData = mRows[j].Split(';');
                                if (Convert.ToInt32(mData[0]) == teamId)
                                {
                                    int usableWeaponId = Convert.ToInt32(mData[1]);

                                    member3weapons.Add(_owner.WeaponsOwned.Where(w => w.UniqueId == usableWeaponId).FirstOrDefault());
                                }
                            }
                            memberSets.Add(new t_MemberSet
                            {
                                Member = _owner.UnitsData.Where(c => c.UniqueId == member3Id).FirstOrDefault(),
                                Weapons = member3weapons,
                                Armour = _owner.ArmoursOwned.Where(a => a.UniqueId == member3armrId).FirstOrDefault(),
                                Accessory = _owner.AccessoriesOwned.Where(a => a.UniqueId == member3acsrId).FirstOrDefault()
                            });
                        }

                        /////////////////////
                        //Member 4
                        /////////////////////
                        {
                            string mTxtData = "";
                            //Read data from Coord.txt
                            using (StreamReader sr = File.OpenText(commonFilePath + @"\TeamMember4Weapon.txt"))
                            {
                                mTxtData = sr.ReadToEnd();
                            }
                            string[] mRows = mTxtData.Split('\n');

                            for (int j = 1; j < mRows.Count(); j++)
                            {
                                if (mRows[i] == "")
                                    break;
                                string[] mData = mRows[j].Split(';');
                                if (Convert.ToInt32(mData[0]) == teamId)
                                {
                                    int usableWeaponId = Convert.ToInt32(mData[1]);

                                    member4weapons.Add(_owner.WeaponsOwned.Where(w => w.UniqueId == usableWeaponId).FirstOrDefault());
                                }
                            }
                            memberSets.Add(new t_MemberSet
                            {
                                Member = _owner.UnitsData.Where(c => c.UniqueId == member4Id).FirstOrDefault(),
                                Weapons = member4weapons,
                                Armour = _owner.ArmoursOwned.Where(a => a.UniqueId == member4armrId).FirstOrDefault(),
                                Accessory = _owner.AccessoriesOwned.Where(a => a.UniqueId == member4acsrId).FirstOrDefault()
                            });
                        }

                        /////////////////////
                        //Member 5
                        /////////////////////
                        {
                            string mTxtData = "";
                            //Read data from Coord.txt
                            using (StreamReader sr = File.OpenText(commonFilePath + @"\TeamMember5Weapon.txt"))
                            {
                                mTxtData = sr.ReadToEnd();
                            }
                            string[] mRows = mTxtData.Split('\n');

                            for (int j = 1; j < mRows.Count(); j++)
                            {
                                if (mRows[i] == "")
                                    break;
                                string[] mData = mRows[j].Split(';');
                                if (Convert.ToInt32(mData[0]) == teamId)
                                {
                                    int usableWeaponId = Convert.ToInt32(mData[1]);

                                    member5weapons.Add(_owner.WeaponsOwned.Where(w => w.UniqueId == usableWeaponId).FirstOrDefault());
                                }
                            }
                            memberSets.Add(new t_MemberSet
                            {
                                Member = _owner.UnitsData.Where(c => c.UniqueId == member5Id).FirstOrDefault(),
                                Weapons = member5weapons,
                                Armour = _owner.ArmoursOwned.Where(a => a.UniqueId == member5armrId).FirstOrDefault(),
                                Accessory = _owner.AccessoriesOwned.Where(a => a.UniqueId == member5acsrId).FirstOrDefault()
                            });
                        }

                        result.Add(new Team(memberSets));
                    }
                }

                return result;
            }
            catch (Exception ex)
            {
                Debug.Log(ex.Message + ex.InnerException + ex.TargetSite);
                return null;
            }
        }
        #endregion

        #region Save
        public static bool SaveTeamData(Team _newTeam, int _playerId, int _teamNum)
        {
            try
            {
                string tTxtData = "";
                //Read data from Coord.txt
                using (StreamReader sr = File.OpenText(commonFilePath + @"\Team.txt"))
                {
                    tTxtData = sr.ReadToEnd();
                }
                string[] rows = tTxtData.Split('\n');

                string newTxtData = rows[0] + "\n";

                int searchedTeamNum = 0; 
                for (int i = 1; i < rows.Count(); i++)
                {
                    if (rows[i] == "")
                        break;
                    string[] tData = rows[i].Split(';');

                    if (Convert.ToInt32(tData[1]) == _playerId)
                        searchedTeamNum++;

                    if(searchedTeamNum == _teamNum)
                    {
                        newTxtData += tData[0].ToString() + ";"
                                    + tData[1].ToString() + ";"
                                    + _newTeam.MemberSets[0].Member.UniqueId.ToString() + ";"
                                    + tData[3].ToString() + ";"
                                    + tData[4].ToString() + ";"
                                    + _newTeam.MemberSets[1].Member.UniqueId.ToString() + ";"
                                    + tData[6].ToString() + ";"
                                    + tData[7].ToString() + ";"
                                    + _newTeam.MemberSets[2].Member.UniqueId.ToString() + ";"
                                    + tData[9].ToString() + ";"
                                    + tData[10].ToString() + ";"
                                    + _newTeam.MemberSets[3].Member.UniqueId.ToString() + ";"
                                    + tData[12].ToString() + ";"
                                    + tData[13].ToString() + ";"
                                    + _newTeam.MemberSets[4].Member.UniqueId.ToString() + ";"
                                    + tData[15].ToString() + ";"
                                    + tData[16].ToString() + "\n";
                    }
                    else
                        newTxtData += rows[i] + "\n";
                }

                using (StreamWriter sw = new StreamWriter(commonFilePath + @"\Team.txt"))
                {
                    sw.Write(newTxtData);
                }

                return true;

            }
            catch (Exception ex)
            {
                Debug.Log(ex.Message + ex.InnerException + ex.TargetSite);
                return false;
            }
        }
        #endregion

        /// <summary>
        /// PreCondition: There is an enum value named _name within the T enum type. (T is checked whether it is enum or not internally)
        /// PostCondition: Corresponding enum value of type T will be returned.
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="_name"></param>
        /// <returns></returns>
        public static T ToCorrespondingEnumValue<T>(string _name)
        {
            if (typeof(T).IsEnum)
            {
                foreach (T e in Enum.GetValues(typeof(T)))
                {
                    if (_name == e.ToString())
                        return e;
                }
            }

            return default(T);
        }

        private static string[] CustomTxtSplitting(string _text)
        {
            if (_text != null && _text != "")
            {
                List<string> result = new List<string>();

                do
                {
                    if (_text.StartsWith("<Line>"))
                    {
                        _text = _text.Substring(6, _text.Length - 6); //Remove "<Line>"

                        string block = "";
                        do
                        {
                            block += _text.Substring(0, 1);
                            _text = _text.Substring(1, _text.Length - 1);
                        } while (!_text.StartsWith("</Line>"));

                        if (_text.StartsWith("</Line>"))
                            _text = _text.Substring(7, _text.Length - 7); //Remove "</Line>"

                        result.Add(block);
                    }
                } while (_text != "");

                return result.ToArray();
            }
            else
                return null;
        }
    }
}