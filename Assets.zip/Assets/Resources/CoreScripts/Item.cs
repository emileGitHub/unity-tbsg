﻿using System.Collections.Generic;

namespace EEANGame.TBSG.V1_0.MainClassLib
{
    public abstract class Item
    {
        /// <summary>
        /// Ctor
        /// PreCondition: None.
        /// PostCondition: Will be initialized successfully.
        /// </summary>
        /// <param name="_id"></param>
        /// <param name="_icon"></param>
        /// <param name="_name"></param>
        public Item(int _id, int _icon, string _name)
        {
            Id = _id;
            Icon = _icon;
            Name = _name;
        }

        public int Id { get; set; }
        public int Icon { get; set; } // To be implemented
        public string Name { get; set; }

        public int Cost { get; set; }
        public List<Effect> Effect { get; set; }
    }
}
