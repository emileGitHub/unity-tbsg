﻿using System;
using System.Collections.Generic;

namespace EEANGame.TBSG.V1_0.MainClassLib
{
    public class Team
    {
        /// <summary>
        /// Ctor
        /// PreCondition: _memberSets.Count == Rule.MAX_MEMBERS_PER_TEAM
        /// PostCondition: Will be initialized successfully.
        /// </summary>
        /// <param name="_memberSets"></param>
        public Team(List<t_MemberSet> _memberSets)
        {
            try
            {
                //Assign sets of members and equipments
                if (_memberSets.Count >= Rule.MAX_MEMBERS_PER_TEAM)
                    MemberSets = new t_MemberSet[Rule.MAX_MEMBERS_PER_TEAM];
                else
                    MemberSets = new t_MemberSet[_memberSets.Count];

                    if (_memberSets.Count >= MemberSets.Length)
                {
                    for (int i = 1; i <= MemberSets.Length; i++)
                    {
                        MemberSets[i - 1] = _memberSets[i - 1];
                    }
                }
                else
                {
                    for (int i = 1; i <= _memberSets.Count; i++)
                    {
                        MemberSets[i - 1] = _memberSets[i - 1];
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("No Membersets found! This is not an acceptable implementation.\n" + ex.Message);
            }
        }

        /*--------------------------------------------
        Properties
        --------------------------------------------*/
        public t_MemberSet[] MemberSets; //nullable

    }

    public struct t_MemberSet
    {
        public IndividualUnitData Member;
        public List<UsableWeapon> Weapons;
        public UsableArmour Armour;
        public UsableAccessory Accessory;
    }
}
