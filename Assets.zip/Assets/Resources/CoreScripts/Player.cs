﻿using System.Collections.Generic;
using System;
using UnityEngine;

namespace EEANGame.TBSG.V1_0.MainClassLib
{
    public class Player
    {
        /// <summary>
        /// Ctor
        /// PreCondition: _id > 0; _teams.Count > 0; _unitData.Count > 0;
        /// PostCondition: All Properties will be initialized properly.
        /// </summary>
        /// <param name="_id"></param>
        /// <param name="_name"></param>
        /// <param name="_unitData"></param>
        /// <param name="_weaponsOwned"></param>
        /// <param name="_armoursOwned"></param>
        /// <param name="_accessoriesOwned"></param>
        /// <param name="_teams"></param>
        public Player(int _id, string _name, List<IndividualUnitData> _unitData, List<UsableWeapon> _weaponsOwned, List<UsableArmour> _armoursOwned, List<UsableAccessory> _accessoriesOwned, List<Team> _teams)
        {
            //Assign Id
            Id = _id;

            //Assign Name
            Name = _name;

            //Assign Playable Units Owned
            if (_unitData != null)
                UnitsData = _unitData;
            else
                UnitsData = new List<IndividualUnitData>();

            //Assign Weapons Owned
            if (_weaponsOwned != null)
                WeaponsOwned = _weaponsOwned;
            else
                WeaponsOwned = new List<UsableWeapon>();

            //Assign Armours Owned
            if (_armoursOwned != null)
                ArmoursOwned = _armoursOwned;
            else
                ArmoursOwned = new List<UsableArmour>();

            //Assign Accessories Owned
            if (_accessoriesOwned != null)
                AccessoriesOwned = _accessoriesOwned;
            else
                AccessoriesOwned = new List<UsableAccessory>();


            //Assign Teams Owned
            if (_teams != null)
                Teams = _teams;
            else
                Teams = new List<Team>();
         }

        /*--------------------------------------------
        Properties
        --------------------------------------------*/

        //Base Properties
        public int Id { get; set; }
        public string Name { get; set; }

        //Playable Units Owned
        public List<IndividualUnitData> UnitsData { get; set; }

        //Equipments Owned
        public List<UsableWeapon> WeaponsOwned { get; set; }
        public List<UsableArmour> ArmoursOwned { get; set; }
        public List<UsableAccessory> AccessoriesOwned { get; set; }

        //Items Owned
        //To be implemented...

        //Sets of Playable Units Owned
        public List<Team> Teams { get; set; }
    }

    public class PlayerOnBoard : Player
    {
        /// <summary>
        /// Ctor1
        /// PreCondition: _id > 0; _unitData.Count > 0; _teams.Count > _teamIndex; _teams.Count > 0;
        /// PostCondition: Will be initialized successfully.
        /// </summary>
        /// <param name="_id"></param>
        /// <param name="_name"></param>
        /// <param name="_unitData"></param>
        /// <param name="_weaponsOwned"></param>
        /// <param name="_armoursOwned"></param>
        /// <param name="_accessoriesOwned"></param>
        /// <param name="_teams"></param>
        /// <param name="_teamIndex"></param>
        public PlayerOnBoard(int _id, string _name, List<IndividualUnitData> _unitData, List<UsableWeapon> _weaponsOwned, List<UsableArmour> _armoursOwned, List<UsableAccessory> _accessoriesOwned, List<Team> _teams,
            int _teamIndex) : base(_id, _name, _unitData, _weaponsOwned, _armoursOwned, _accessoriesOwned, _teams)
        {
            //Assign Allied Units
            AlliedUnits = new List<UnitInstance>();

            try
            {
                if (this.Teams.Count > _teamIndex && _teamIndex >= 0)
                {
                    if (Teams[_teamIndex].MemberSets.Length <= 0)
                        Debug.Log("No units in team!");
                    else
                    {
                        foreach (t_MemberSet ms in this.Teams[_teamIndex].MemberSets)
                        {
                            AlliedUnits.Add(new UnitInstance(ms.Member, ms.Weapons, ms.Armour, ms.Accessory, this));
                        }
                    }

                }
                else if (Teams.Count > 0)
                {
                    if (Teams[0].MemberSets.Length <= 0)
                        Debug.Log("No units in team!");
                    else
                    {
                        foreach (t_MemberSet ms in this.Teams[0].MemberSets)
                        {
                            AlliedUnits.Add(new UnitInstance(ms.Member, ms.Weapons, ms.Armour, ms.Accessory, this));
                        }
                    }
                }
                else
                    Debug.Log("No teams found!");

                //ID of Unit Currently Selected
                SelectedUnitIndex = -1; //Meaning none of the characters is selected
            }
            catch (Exception ex)
            {
                Debug.Log("PlayerOnBoard: at Ctor1() " + ex.Message);
            }
        }

        /// <summary>
        /// Ctor2
        /// PreCondition: _playerBase has been initialized successfully; Teams.Count > _teamIndex;
        /// PostCondition: Will be initialized successfully.
        /// </summary>
        /// <param name="_id"></param>
        /// <param name="_name"></param>
        /// <param name="_unitData"></param>
        /// <param name="_weaponsOwned"></param>
        /// <param name="_armoursOwned"></param>
        /// <param name="_accessoriesOwned"></param>
        /// <param name="_teams"></param>
        /// <param name="_teamIndex"></param>
        public PlayerOnBoard(Player _playerBase, int _teamIndex, bool _isPlayer1) : base(_playerBase.Id, _playerBase.Name, _playerBase.UnitsData, _playerBase.WeaponsOwned, _playerBase.ArmoursOwned, _playerBase.AccessoriesOwned, _playerBase.Teams)
        {
            IsPlayer1 = _isPlayer1;

            //Assign Allied Units
            AlliedUnits = new List<UnitInstance>();
            try
            {
                if (this.Teams.Count > _teamIndex && _teamIndex >= 0)
                {
                    if (Teams[_teamIndex].MemberSets.Length <= 0)
                        Debug.Log("No units in team!");
                    else
                    {
                        foreach (t_MemberSet ms in this.Teams[_teamIndex].MemberSets)
                        {
                            AlliedUnits.Add(new UnitInstance(ms.Member, ms.Weapons, ms.Armour, ms.Accessory, this));
                        }
                    }

                }
                else if (Teams.Count > 0)
                {
                    if (Teams[0].MemberSets.Length <= 0)
                        Debug.Log("No units in team!");
                    else
                    {
                        foreach (t_MemberSet ms in this.Teams[0].MemberSets)
                        {
                            AlliedUnits.Add(new UnitInstance(ms.Member, ms.Weapons, ms.Armour, ms.Accessory, this));
                        }
                    }
                }
                else
                    Debug.Log("No teams found!");
            }
            catch (Exception ex)
            {
                Debug.Log("PlayerOnBoard: at Ctor2() " + ex.Message);
            }

            //ID of Unit Currently Selected
            SelectedUnitIndex = -1; //Meaning none of the characters is selected
        }

        /*--------------------------------------------
        Properties
        --------------------------------------------*/
        public bool IsPlayer1 { get; set; }

        public List<UnitInstance> AlliedUnits { get; set; }

        public int SelectedUnitIndex { get; set; } //Id of the unit in AlliedUnits

        public int MaxSP { get; set; } // Will be initialized & handled explicitly by Field
        public int RemainingSP { get; set; } // Will be initialized & handled explicitly by Field
    }
}
