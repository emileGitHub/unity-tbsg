﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace EEANGame.TBSG.V1_0.MainClassLib
{
    public static class Rule
    {
        public const double DEFAULT_CRITICAL_RATE = 0.05;
        public const int MIN_SP_COST = 1;
        public const int MAX_SP = 7;
        public const int MIN_BASE_ATTRIBUTE_VALUE = 1;
        public const int MAX_BASE_ATTRIBUTE_VALUE = 999;
        public const int MAX_BASE_HP_VALUE = 9999;
        public const int MAX_ACUMULATED_LEVEL = 300; //20+40+60+80+100
        public const int SIZE_OF_A_SIDE_OF_BOARD = 7;
        public const int MAX_MEMBERS_PER_TEAM = 6;
        public const int DAMAGE_BASE_VALUE = 50;
        public const double MULTIPLIER_FOR_ELEMENT_MATCH = 2.0;
        public const double MULTIPLIER_FOR_EFFECTIVE_ELEMENT = 2.0;
        public const double MULTIPLIER_FOR_INEFFECTIVE_ELEMENT = 0.5;
        public const double MULTIPLIER_FOR_CRITICALHIT = 2.0;
        public const double MULTIPLIER_FOR_TILETYPEMATCH = 2.0;
        public const double MULTIPLIER_FOR_ANGLE_TO_RADIAN = (Math.PI / 180);
        public const double MAX_EQUIPABLE_WEAPON_TOTAL_COST = 3;
        public const int SP_AT_INITIALIZATION = 7;
        public const double POW_ADJUSTMENT_CONST_A = 19 / 9999;
        public const double POW_ADJUSTMENT_CONST_B = 1.0D - POW_ADJUSTMENT_CONST_A;
    }
}
