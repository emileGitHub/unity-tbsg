﻿using EEANGame.TBSG.V1_0.CommonEnums;
using System;
using System.Collections.Generic;
using System.Linq;

namespace EEANGame.TBSG.V1_0.MainClassLib
{
    public static class Calculator
    {
        /// <summary>
        /// PreCondition: _character has been initialized successfully.
        /// PostCondition: MaxHp of _character is calculated and returned as int.
        /// </summary>
        /// <param name="_character"></param>
        /// <returns></returns>
        public static int MaxHP(IndividualUnitData _character)
        {
            double levelRate = 1.0D * AcumulatedLevel(_character.Rarity, _character.Level) / (Rule.MAX_ACUMULATED_LEVEL);

            return Convert.ToInt32(_character.MaxLevel_HP * levelRate);
        }
        /// <summary>
        /// PreCondition: _character has been initialized successfully.
        /// PostCondition: Physical Strength of _character is calculated and returned as int.
        /// </summary>
        /// <param name="_character"></param>
        /// <returns></returns>
        public static int PhysicalStrength(IndividualUnitData _character)
        {
            double levelRate = 1.0D * AcumulatedLevel(_character.Rarity, _character.Level) / (Rule.MAX_ACUMULATED_LEVEL);

            return Convert.ToInt32(_character.MaxLevel_PhysicalStrength * levelRate);
        }
        /// <summary>
        /// PreCondition: _character has been initialized successfully.
        /// PostCondition: Physical Resistance of _character is calculated and returned as int.
        /// </summary>
        /// <param name="_character"></param>
        /// <returns></returns>
        public static int PhysicalResistance(IndividualUnitData _character)
        {
            double levelRate = 1.0D * AcumulatedLevel(_character.Rarity, _character.Level) / (Rule.MAX_ACUMULATED_LEVEL);

            return Convert.ToInt32(_character.MaxLevel_PhysicalResistance * levelRate);
        }
        /// <summary>
        /// PreCondition: _character has been initialized successfully.
        /// PostCondition: Magical Strength of _character is calculated and returned as int.
        /// </summary>
        /// <param name="_character"></param>
        /// <returns></returns>
        public static int MagicalStrength(IndividualUnitData _character)
        {
            double levelRate = 1.0D * AcumulatedLevel(_character.Rarity, _character.Level) / (Rule.MAX_ACUMULATED_LEVEL);

            return Convert.ToInt32(_character.MaxLevel_MagicalStrength * levelRate);
        }
        /// <summary>
        /// PreCondition: _character has been initialized successfully.
        /// PostCondition: Magical Resistance of _character is calculated and returned as int.
        /// </summary>
        /// <param name="_character"></param>
        /// <returns></returns>
        public static int MagicalResistance(IndividualUnitData _character)
        {
            double levelRate = 1.0D * AcumulatedLevel(_character.Rarity, _character.Level) / (Rule.MAX_ACUMULATED_LEVEL);

            return Convert.ToInt32(_character.MaxLevel_MagicalResistance * levelRate);
        }
        /// <summary>
        /// PreCondition: _character has been initialized successfully.
        /// PostCondition: Vitality of _character is calculated and returned as int.
        /// </summary>
        /// <param name="_character"></param>
        /// <returns></returns>
        public static int Vitality(IndividualUnitData _character)
        {
            double levelRate = 1.0D * AcumulatedLevel(_character.Rarity, _character.Level) / (Rule.MAX_ACUMULATED_LEVEL);

            return Convert.ToInt32(_character.MaxLevel_Vitality * levelRate);
        }
        /// <summary>
        /// PreCondition: _currentLevel > 0.
        /// PostCondition: Acumulated Level will be calculated based on _rarity and _currentLevel and the value will be returned as int.
        /// </summary>
        /// <param name="_rarity"></param>
        /// <param name="_currentLevel"></param>
        /// <returns></returns>
        private static int AcumulatedLevel(eRarity _rarity, int _currentLevel)
        {
            switch (_rarity)
            {
                case eRarity.NORMAL:
                    return _currentLevel;
                case eRarity.BRONZE:
                    return _currentLevel + Convert.ToInt32(eRarity.NORMAL);
                case eRarity.SILVER:
                    return _currentLevel + Convert.ToInt32(eRarity.NORMAL) + Convert.ToInt32(eRarity.BRONZE);
                case eRarity.GOLD:
                    return _currentLevel + Convert.ToInt32(eRarity.NORMAL) + Convert.ToInt32(eRarity.BRONZE) + Convert.ToInt32(eRarity.SILVER);
                case eRarity.PLATINUM:
                    return _currentLevel + Convert.ToInt32(eRarity.NORMAL) + Convert.ToInt32(eRarity.BRONZE) + Convert.ToInt32(eRarity.SILVER) + Convert.ToInt32(eRarity.GOLD);
                default:
                    return 0;
            }
        }

        /// <summary>
        /// PreCondition: _attacker, _defender, _effect, and _board have been initialized successfully; _attacker and _defender are assigned to a _board.Sockets[,]; X,Y values of _attackerCoord and _defenderCoord match the X,Y values in corresponding Sockets;
        /// PostCondition: An int value representing the damage will be returned.
        /// </summary>
        /// <param name="_attacker"></param>
        /// <param name="_effect"></param>
        /// <param name="_defender"></param>
        /// <param name="_attackerCoord"></param>
        /// <param name="_defenderCoord"></param>
        /// <param name="_board"></param>
        /// <param name="_isCritical"></param>
        /// <returns></returns>
        public static int Damage(UnitInstance _attacker, Damage _effect, UnitInstance _defender, _2DCoord _attackerCoord, _2DCoord _defenderCoord, Board _board, ref bool _isCritical)
        {
            double damage = Convert.ToDouble(Rule.DAMAGE_BASE_VALUE);

            double strength = 0;
            double resistance = 0;

            if (_effect.AttackType == eAttackClassification.PHYSIC)
            {
                strength = PhysicalStrength(_attacker);
                resistance = PhysicalResistance(_defender);

                foreach (ContinuousEffect ce in _attacker.ContinuousEffects.Where(x => x.EffectType == eContinuousEffectType.PHYSTR_RATE))
                {
                    strength *= 1.2;
                }

                foreach (ContinuousEffect ce in _defender.ContinuousEffects.Where(x => x.EffectType == eContinuousEffectType.PHYRES_RATE))
                {
                    resistance *= 1.2;
                }
            }
            else
            {
                strength = MagicalStrength(_attacker);
                resistance = MagicalResistance(_defender);

                foreach (ContinuousEffect ce in _attacker.ContinuousEffects.Where(x => x.EffectType == eContinuousEffectType.MAGSTR_RATE))
                {
                    strength *= 1.2;
                }

                foreach (ContinuousEffect ce in _defender.ContinuousEffects.Where(x => x.EffectType == eContinuousEffectType.MAGRES_RATE))
                {
                    resistance *= 1.2;
                }
            }

            damage *= (Convert.ToDouble(strength) / resistance) * (Convert.ToDouble(strength) / Rule.MAX_BASE_ATTRIBUTE_VALUE); //use double to avoid unexpected round ups
            
            damage *= CorrectionRate_Power(_attackerCoord, _effect, _defenderCoord);

            damage *= DamageCorrectionRate_Element(_attacker, _effect.Element, _defender);

                        //Based on relation ship between tile type and unit/effect
            damage *= CorrectionRate_TileType(_attacker, _effect, _board.Sockets[_attackerCoord.X, _attackerCoord.Y].Tile);

            if (IsCritical(_attacker, _defender, _effect))
            {
                damage *= Rule.MULTIPLIER_FOR_CRITICALHIT;
                _isCritical = true;
            }
            else
                _isCritical = false;

            return Convert.ToInt32(damage);
        }

        public static int HealValue(UnitInstance _effectUser, Heal _effect, UnitInstance _target, _2DCoord _effectUserCoord, _2DCoord _targetCoord)
        {
            double restoringHp = 0.05D * (Vitality(_effectUser) + 1) * (Vitality(_target) + 1);

            restoringHp *= CorrectionRate_Power(_effectUserCoord, _effect, _targetCoord);

            if (IsCritical(_effectUser, _target, _effect)) //to be implemented
                restoringHp *= Rule.MULTIPLIER_FOR_CRITICALHIT;

            return Convert.ToInt32(restoringHp);
        }


        // Example:
        // 0 represents the initial position and other numbers show the distance.
        // 3 3 3 3 3 3 3
        // 3 2 2 2 2 2 3
        // 3 2 1 1 1 2 3
        // 3 2 1 0 1 2 3
        // 3 2 1 1 1 2 3
        // 3 2 2 2 2 2 3
        // 3 3 3 3 3 3 3
        /// <summary>
        /// PreCondition: _initialCoord and _targetCoord are not null.
        /// PostCondition: The distance between _initialCoord and _targetCoord will be returned. The distance will be calculated as in the example in the comments above.
        /// </summary>
        /// <param name="_character1"></param>
        /// <param name="_character2"></param>
        /// <returns></returns>
        private static int Distance(_2DCoord _initialCoord, _2DCoord _targetCoord)
        {
            int distance = 0;

            for(int i = Rule.SIZE_OF_A_SIDE_OF_BOARD - 1; i >= 1; i--)
            {
                if (Math.Abs(_initialCoord.X - _targetCoord.X) <= i && Math.Abs(_initialCoord.Y - _targetCoord.Y) <= i)
                    distance = i;
            }

            return distance;
        }

        private static double CorrectionRate_Power(_2DCoord _effectUserCoord, Damage _effect, _2DCoord _targetCharacterCoord)
        {
            double power = 0.0;

            if (_effect.Power > 0)
                power = Rule.POW_ADJUSTMENT_CONST_A * Math.Pow(power, 2) + Rule.POW_ADJUSTMENT_CONST_B;

            int distance = Distance(_effectUserCoord, _targetCharacterCoord);

            if (!_effect.DoesPreservePower)
                power *= (10.0 - (distance - 1)) / 10;

            return power;
        }
        private static double CorrectionRate_Power(_2DCoord _effectUserCoord, Heal _effect, _2DCoord _targetCharacterCoord)
        {
            double power = 0.0;

            if (_effect.Power > 0)
                power = Rule.POW_ADJUSTMENT_CONST_A * Math.Pow(power, 2) + Rule.POW_ADJUSTMENT_CONST_B;

            int distance = Distance(_effectUserCoord, _targetCharacterCoord);

            if (!_effect.DoesPreservePower)
                power *= (10.0 - (distance - 1)) / 10;

            return power;
        }

        /// <summary>
        /// Returns element effectiveness as double
        /// Example:
        /// If the returned value is 2.0, it means that the effect will be twice as effective against the target
        /// </summary>
        /// <param name="_effectUserElement"></param>
        /// <param name=""></param>
        /// <returns></returns>
        /// 
        public static double DamageCorrectionRate_Element(UnitInstance _attacker, eElement _effectElement, UnitInstance _defender)
        {
            double correctionRate = 1.0;

            if (DoesElementMatch(_attacker.Elements, _effectElement))
                correctionRate *= Rule.MULTIPLIER_FOR_ELEMENT_MATCH;

            switch (_effectElement)
            {
                case eElement.PURPLE:
                    foreach (ContinuousEffect ce in _attacker.ContinuousEffects.Where(x => x.EffectType == eContinuousEffectType.PURPLESTR_RATE))
                    {
                        correctionRate *= 1.2;
                    }
                    break;
                case eElement.BLUE:
                    foreach (ContinuousEffect ce in _attacker.ContinuousEffects.Where(x => x.EffectType == eContinuousEffectType.BLUESTR_RATE))
                    {
                        correctionRate *= 1.2;
                    }
                    break;
                case eElement.GREEN:
                    foreach (ContinuousEffect ce in _attacker.ContinuousEffects.Where(x => x.EffectType == eContinuousEffectType.GREENSTR_RATE))
                    {
                        correctionRate *= 1.2;
                    }
                    break;
                case eElement.OCHER:
                    foreach (ContinuousEffect ce in _attacker.ContinuousEffects.Where(x => x.EffectType == eContinuousEffectType.OCHERSTR_RATE))
                    {
                        correctionRate *= 1.2;
                    }
                    break;
                case eElement.RED:
                    foreach (ContinuousEffect ce in _attacker.ContinuousEffects.Where(x => x.EffectType == eContinuousEffectType.REDSTR_RATE))
                    {
                        correctionRate *= 1.2;
                    }
                    break;
                case eElement.YELLOW:
                    foreach (ContinuousEffect ce in _attacker.ContinuousEffects.Where(x => x.EffectType == eContinuousEffectType.YELLOWSTR_RATE))
                    {
                        correctionRate *= 1.2;
                    }
                    break;
                default:
                    break;
            }

            correctionRate *= ElementEffectiveness(_attacker, _effectElement, _defender);

            return correctionRate;
        }

        /// <summary>
        /// PreCondition: _attacker and _defender have been initialized successfully.
        /// PostCondition: A double value representing the effectiveness of the effect will be returned based on the element properties of _attacker and _defender.
        /// </summary>
        /// <param name="_attacker"></param>
        /// <param name="_effectElement"></param>
        /// <param name="_defender"></param>
        /// <returns></returns>
        private static double ElementEffectiveness(UnitInstance _attacker, eElement _effectElement, UnitInstance _defender)
        {
            double effectiveness = 1.0;

            int effectiveCount = 0;
            int ineffectiveCount = 0;

            //Effect base effectiveness
            foreach (eElement targetElement in _defender.Elements)
            {
                switch (_effectElement)
                {
                    case eElement.BLUE:
                        if (targetElement == eElement.RED)
                            effectiveCount++;
                        else if (targetElement == eElement.OCHER)
                            ineffectiveCount++;
                        break;
                    case eElement.RED:
                        if (targetElement == eElement.GREEN)
                            effectiveCount++;
                        else if (targetElement == eElement.BLUE)
                            ineffectiveCount++;
                        break;
                    case eElement.GREEN:
                        if (targetElement == eElement.OCHER)
                            effectiveCount++;
                        else if (targetElement == eElement.RED)
                            ineffectiveCount++;
                        break;
                    case eElement.OCHER:
                        if (targetElement == eElement.BLUE)
                            effectiveCount++;
                        else if (targetElement == eElement.GREEN)
                            ineffectiveCount++;
                        break;
                    case eElement.PURPLE:
                        if (targetElement == eElement.YELLOW)
                            effectiveCount++;
                        break;
                    case eElement.YELLOW:
                        if (targetElement == eElement.PURPLE)
                            effectiveCount++;
                        break;
                }
            }

            if (effectiveCount > ineffectiveCount)
                effectiveness = Rule.MULTIPLIER_FOR_EFFECTIVE_ELEMENT * (effectiveCount - ineffectiveCount);
            else if (effectiveCount < ineffectiveCount)
                effectiveness =  Rule.MULTIPLIER_FOR_INEFFECTIVE_ELEMENT * (ineffectiveCount - effectiveCount);

            //Additional resistance
            switch (_effectElement)
            {
                case eElement.PURPLE:
                    foreach (ContinuousEffect ce in _defender.ContinuousEffects.Where(x => x.EffectType == eContinuousEffectType.ANTIPURPLERES_RATE))
                    {
                        effectiveness /= 1.2;
                    }
                    break;
                case eElement.BLUE:
                    foreach (ContinuousEffect ce in _defender.ContinuousEffects.Where(x => x.EffectType == eContinuousEffectType.ANTIBLUERES_RATE))
                    {
                        effectiveness /= 1.2;
                    }
                    break;
                case eElement.GREEN:
                    foreach (ContinuousEffect ce in _defender.ContinuousEffects.Where(x => x.EffectType == eContinuousEffectType.ANTIGREENRES_RATE))
                    {
                        effectiveness /= 1.2;
                    }
                    break;
                case eElement.OCHER:
                    foreach (ContinuousEffect ce in _defender.ContinuousEffects.Where(x => x.EffectType == eContinuousEffectType.ANTIOCHERRES_RATE))
                    {
                        effectiveness /= 1.2;
                    }
                    break;
                case eElement.RED:
                    foreach (ContinuousEffect ce in _defender.ContinuousEffects.Where(x => x.EffectType == eContinuousEffectType.ANTIREDRES_RATE))
                    {
                        effectiveness /= 1.2;
                    }
                    break;
                case eElement.YELLOW:
                    foreach (ContinuousEffect ce in _defender.ContinuousEffects.Where(x => x.EffectType == eContinuousEffectType.ANTIYELLOWRES_RATE))
                    {
                        effectiveness /= 1.2;
                    }
                    break;
                default:
                    break;
            }

            //Additional strength
            foreach (eElement targetElement in _defender.Elements)
            {
                switch (targetElement)
                {
                    case eElement.PURPLE:
                        foreach (ContinuousEffect ce in _attacker.ContinuousEffects.Where(x => x.EffectType == eContinuousEffectType.ANTIPURPLESTR_RATE))
                        {
                            effectiveness *= 1.2;
                        }
                        break;
                    case eElement.BLUE:
                        foreach (ContinuousEffect ce in _attacker.ContinuousEffects.Where(x => x.EffectType == eContinuousEffectType.ANTIBLUESTR_RATE))
                        {
                            effectiveness *= 1.2;
                        }
                        break;
                    case eElement.GREEN:
                        foreach (ContinuousEffect ce in _attacker.ContinuousEffects.Where(x => x.EffectType == eContinuousEffectType.ANTIGREENRES_RATE))
                        {
                            effectiveness *= 1.2;
                        }
                        break;
                    case eElement.OCHER:
                        foreach (ContinuousEffect ce in _attacker.ContinuousEffects.Where(x => x.EffectType == eContinuousEffectType.ANTIOCHERSTR_RATE))
                        {
                            effectiveness *= 1.2;
                        }
                        break;
                    case eElement.RED:
                        foreach (ContinuousEffect ce in _attacker.ContinuousEffects.Where(x => x.EffectType == eContinuousEffectType.ANTIREDSTR_RATE))
                        {
                            effectiveness *= 1.2;
                        }
                        break;
                    case eElement.YELLOW:
                        foreach (ContinuousEffect ce in _attacker.ContinuousEffects.Where(x => x.EffectType == eContinuousEffectType.ANTIYELLOWSTR_RATE))
                        {
                            effectiveness *= 1.2;
                        }
                        break;
                    default:
                        break;
                }
            }

            return effectiveness;
        }

        /// <summary>
        /// PreCondition: _unitElements is not null.
        /// PostCondition: Compares each eElement in _unitElements with _targetElement and returns true if at least one matches.
        /// </summary>
        /// <param name="_unitElements"></param>
        /// <param name="_targetElement"></param>
        /// <returns></returns>
        private static bool DoesElementMatch(List<eElement> _unitElements, eElement _targetElement)
        {
            foreach (eElement e in _unitElements)
            {
                if (e == _targetElement)
                    return true;
            }

            return false;
        }

        private static double CorrectionRate_TileType(UnitInstance _unit, Effect _effect, eTileType _tileType)
        {
            switch(_tileType)
            {
                case eTileType.BLUE:
                    if (DoesElementMatch(_unit.Elements, eElement.BLUE))
                        return Rule.MULTIPLIER_FOR_TILETYPEMATCH;
                    break;
                case eTileType.RED:
                    if (DoesElementMatch(_unit.Elements, eElement.RED))
                        return Rule.MULTIPLIER_FOR_TILETYPEMATCH;
                    break;
                case eTileType.GREEN:
                    if (DoesElementMatch(_unit.Elements, eElement.GREEN))
                        return Rule.MULTIPLIER_FOR_TILETYPEMATCH;
                    break;
                case eTileType.OCHER:
                    if (DoesElementMatch(_unit.Elements, eElement.OCHER))
                        return Rule.MULTIPLIER_FOR_TILETYPEMATCH;
                    break;
                case eTileType.PURPLE:
                    if (DoesElementMatch(_unit.Elements, eElement.PURPLE))
                        return Rule.MULTIPLIER_FOR_TILETYPEMATCH;
                    break;
                case eTileType.YELLOW:
                    if (DoesElementMatch(_unit.Elements, eElement.YELLOW))
                        return Rule.MULTIPLIER_FOR_TILETYPEMATCH;
                    break;
                case eTileType.HEAL:
                    if (_effect is Heal)
                        return Rule.MULTIPLIER_FOR_TILETYPEMATCH;
                    break;
                default: //case eTileType.NORMAL
                    return 1.0;
            }

            return 1.0;
        }

        /// <summary>
        /// PreCondition: _attacker and _defender have been initialized successfully.
        /// PostCondition: Returns damage correction rate based on specie as double
        /// Example:
        /// If the returned value is 2.0, it means that the effect will be twice as effective against _defender
        /// </summary>
        /// <param name="_attacker"></param>
        /// <param name="_defender"></param>
        /// <returns></returns>
        public static double DamageCorrectionRate_Specie(UnitInstance _attacker, UnitInstance _defender)
        {
            double correctionRate = 1.0;

            foreach (eSpecie specie in _defender.SpecieTypes)
            {
                switch(specie)
                {
                    case eSpecie.BEAST:
                        foreach(ContinuousEffect ce in _attacker.ContinuousEffects.Where(x => x.EffectType == eContinuousEffectType.ANTIBEASTSTR_RATE))
                        {
                            correctionRate *= 1.2;
                        }
                        break;
                    case eSpecie.BIRD:
                        foreach (ContinuousEffect ce in _attacker.ContinuousEffects.Where(x => x.EffectType == eContinuousEffectType.ANTIBIRDSTR_RATE))
                        {
                            correctionRate *= 1.2;
                        }
                        break;
                    case eSpecie.BUG:
                        foreach (ContinuousEffect ce in _attacker.ContinuousEffects.Where(x => x.EffectType == eContinuousEffectType.ANTIBUGSTR_RATE))
                        {
                            correctionRate *= 1.2;
                        }
                        break;
                    case eSpecie.CRUSTACEAN:
                        foreach (ContinuousEffect ce in _attacker.ContinuousEffects.Where(x => x.EffectType == eContinuousEffectType.ANTICRUSTACEANSTR_RATE))
                        {
                            correctionRate *= 1.2;
                        }
                        break;
                    case eSpecie.DEITY:
                        foreach (ContinuousEffect ce in _attacker.ContinuousEffects.Where(x => x.EffectType == eContinuousEffectType.ANTIDEITYSTR_RATE))
                        {
                            correctionRate *= 1.2;
                        }
                        break;
                    case eSpecie.DRAGON:
                        foreach (ContinuousEffect ce in _attacker.ContinuousEffects.Where(x => x.EffectType == eContinuousEffectType.ANTIDRAGONSTR_RATE))
                        {
                            correctionRate *= 1.2;
                        }
                        break;
                    case eSpecie.FISH:
                        foreach (ContinuousEffect ce in _attacker.ContinuousEffects.Where(x => x.EffectType == eContinuousEffectType.ANTIFISHSTR_RATE))
                        {
                            correctionRate *= 1.2;
                        }
                        break;
                    case eSpecie.HUMANOID:
                        foreach (ContinuousEffect ce in _attacker.ContinuousEffects.Where(x => x.EffectType == eContinuousEffectType.ANTIHUMANOIDSTR_RATE))
                        {
                            correctionRate *= 1.2;
                        }
                        break;
                    case eSpecie.IMMORTAL:
                        foreach (ContinuousEffect ce in _attacker.ContinuousEffects.Where(x => x.EffectType == eContinuousEffectType.ANTIIMMORTALSTR_RATE))
                        {
                            correctionRate *= 1.2;
                        }
                        break;
                    case eSpecie.MACHINE:
                        foreach (ContinuousEffect ce in _attacker.ContinuousEffects.Where(x => x.EffectType == eContinuousEffectType.ANTIMACHINESTR_RATE))
                        {
                            correctionRate *= 1.2;
                        }
                        break;
                    case eSpecie.MAGICAL:
                        foreach (ContinuousEffect ce in _attacker.ContinuousEffects.Where(x => x.EffectType == eContinuousEffectType.ANTIMAGICALSTR_RATE))
                        {
                            correctionRate *= 1.2;
                        }
                        break;
                    case eSpecie.MINERAL:
                        foreach (ContinuousEffect ce in _attacker.ContinuousEffects.Where(x => x.EffectType == eContinuousEffectType.ANTIMINERALSTR_RATE))
                        {
                            correctionRate *= 1.2;
                        }
                        break;
                    case eSpecie.MOLLUSCA:
                        foreach (ContinuousEffect ce in _attacker.ContinuousEffects.Where(x => x.EffectType == eContinuousEffectType.ANTIMOLLUSCASTR_RATE))
                        {
                            correctionRate *= 1.2;
                        }
                        break;
                    case eSpecie.PLANT:
                        foreach (ContinuousEffect ce in _attacker.ContinuousEffects.Where(x => x.EffectType == eContinuousEffectType.ANTIPLANTSTR_RATE))
                        {
                            correctionRate *= 1.2;
                        }
                        break;
                    case eSpecie.SLIME:
                        foreach (ContinuousEffect ce in _attacker.ContinuousEffects.Where(x => x.EffectType == eContinuousEffectType.ANTISLIMESTR_RATE))
                        {
                            correctionRate *= 1.2;
                        }
                        break;
                    case eSpecie.SPIRIT:
                        foreach (ContinuousEffect ce in _attacker.ContinuousEffects.Where(x => x.EffectType == eContinuousEffectType.ANTISPIRITSTR_RATE))
                        {
                            correctionRate *= 1.2;
                        }
                        break;
                    default:
                        break;
                }
            }

            foreach (eSpecie specie in _attacker.SpecieTypes)
            {
                switch (specie)
                {
                    case eSpecie.BEAST:
                        foreach (ContinuousEffect ce in _attacker.ContinuousEffects.Where(x => x.EffectType == eContinuousEffectType.ANTIBEASTRES_RATE))
                        {
                            correctionRate *= 1.2;
                        }
                        break;
                    case eSpecie.BIRD:
                        foreach (ContinuousEffect ce in _attacker.ContinuousEffects.Where(x => x.EffectType == eContinuousEffectType.ANTIBIRDRES_RATE))
                        {
                            correctionRate *= 1.2;
                        }
                        break;
                    case eSpecie.BUG:
                        foreach (ContinuousEffect ce in _attacker.ContinuousEffects.Where(x => x.EffectType == eContinuousEffectType.ANTIBUGRES_RATE))
                        {
                            correctionRate *= 1.2;
                        }
                        break;
                    case eSpecie.CRUSTACEAN:
                        foreach (ContinuousEffect ce in _attacker.ContinuousEffects.Where(x => x.EffectType == eContinuousEffectType.ANTICRUSTACEANRES_RATE))
                        {
                            correctionRate *= 1.2;
                        }
                        break;
                    case eSpecie.DEITY:
                        foreach (ContinuousEffect ce in _attacker.ContinuousEffects.Where(x => x.EffectType == eContinuousEffectType.ANTIDEITYRES_RATE))
                        {
                            correctionRate *= 1.2;
                        }
                        break;
                    case eSpecie.DRAGON:
                        foreach (ContinuousEffect ce in _attacker.ContinuousEffects.Where(x => x.EffectType == eContinuousEffectType.ANTIDRAGONRES_RATE))
                        {
                            correctionRate *= 1.2;
                        }
                        break;
                    case eSpecie.FISH:
                        foreach (ContinuousEffect ce in _attacker.ContinuousEffects.Where(x => x.EffectType == eContinuousEffectType.ANTIFISHRES_RATE))
                        {
                            correctionRate *= 1.2;
                        }
                        break;
                    case eSpecie.HUMANOID:
                        foreach (ContinuousEffect ce in _attacker.ContinuousEffects.Where(x => x.EffectType == eContinuousEffectType.ANTIHUMANOIDRES_RATE))
                        {
                            correctionRate *= 1.2;
                        }
                        break;
                    case eSpecie.IMMORTAL:
                        foreach (ContinuousEffect ce in _attacker.ContinuousEffects.Where(x => x.EffectType == eContinuousEffectType.ANTIIMMORTALRES_RATE))
                        {
                            correctionRate *= 1.2;
                        }
                        break;
                    case eSpecie.MACHINE:
                        foreach (ContinuousEffect ce in _attacker.ContinuousEffects.Where(x => x.EffectType == eContinuousEffectType.ANTIMACHINERES_RATE))
                        {
                            correctionRate *= 1.2;
                        }
                        break;
                    case eSpecie.MAGICAL:
                        foreach (ContinuousEffect ce in _attacker.ContinuousEffects.Where(x => x.EffectType == eContinuousEffectType.ANTIMAGICALRES_RATE))
                        {
                            correctionRate *= 1.2;
                        }
                        break;
                    case eSpecie.MINERAL:
                        foreach (ContinuousEffect ce in _attacker.ContinuousEffects.Where(x => x.EffectType == eContinuousEffectType.ANTIMINERALRES_RATE))
                        {
                            correctionRate *= 1.2;
                        }
                        break;
                    case eSpecie.MOLLUSCA:
                        foreach (ContinuousEffect ce in _attacker.ContinuousEffects.Where(x => x.EffectType == eContinuousEffectType.ANTIMOLLUSCARES_RATE))
                        {
                            correctionRate *= 1.2;
                        }
                        break;
                    case eSpecie.PLANT:
                        foreach (ContinuousEffect ce in _attacker.ContinuousEffects.Where(x => x.EffectType == eContinuousEffectType.ANTIPLANTRES_RATE))
                        {
                            correctionRate *= 1.2;
                        }
                        break;
                    case eSpecie.SLIME:
                        foreach (ContinuousEffect ce in _attacker.ContinuousEffects.Where(x => x.EffectType == eContinuousEffectType.ANTISLIMERES_RATE))
                        {
                            correctionRate *= 1.2;
                        }
                        break;
                    case eSpecie.SPIRIT:
                        foreach (ContinuousEffect ce in _attacker.ContinuousEffects.Where(x => x.EffectType == eContinuousEffectType.ANTISPIRITRES_RATE))
                        {
                            correctionRate *= 1.2;
                        }
                        break;
                    default:
                        break;
                }
            }

            return correctionRate;
        }

        /// <summary>
        /// PreCondition: _attacker, _defender, and _effect have been initialized successfully.
        /// PostCondition: Correct boolean value whether _effect succeeded or not will be returned.
        /// </summary>
        /// <param name="_attacker"></param>
        /// <param name="_defender"></param>
        /// <param name="_effect"></param>
        /// <returns></returns>
        public static bool DoesSucceed(UnitInstance _attacker, UnitInstance _defender, Effect _effect)
        {
            double successRate = 1.0 * _effect.SuccessProbability;

            if (successRate <= 0.0000)
                return false;
            else if (successRate >= 1.0000)
                return true;
            else
            {
                int rangeNumber = Convert.ToInt32(successRate * 10000);

                Random.Random.randInit();
                int randomNumber = Random.Random.getRand(1, 10000);

                if (randomNumber < rangeNumber)
                    return true;
                else
                    return false;
            }
        }

        /// <summary>
        /// PreCondition: _attacker, _defender, and _effect have been initialized successfully.
        /// PostCondition: A boolean value representing whether the action(or skill) was critical will be returned based on the properties of _attacker, _defender, and _effect.
        /// </summary>
        /// <param name="_attacker"></param>
        /// <param name="_defender"></param>
        /// <param name="_effect"></param>
        /// <returns></returns>
        public static bool IsCritical(UnitInstance _attacker, UnitInstance _defender, Damage _effect)
        {
            double criticalRate = Rule.DEFAULT_CRITICAL_RATE;

            if (criticalRate <= 0.0000)
                return false;
            else if (criticalRate >= 1.0000)
                return true;
            else
            {
                int rangeNumber = Convert.ToInt32(criticalRate * 10000);

                Random.Random.randInit();
                int randomNumber = Random.Random.getRand(1, 10000);

                if (randomNumber < rangeNumber)
                    return true;
                else
                    return false;
            }
        }

        /// <summary>
        /// PreCondition: _attacker, _defender, and _effect have been initialized successfully.
        /// PostCondition: A boolean value representing whether the action(or skill) was critical will be returned based on the properties of _attacker, _defender, and _effect.
        /// </summary>
        /// <param name="_attacker"></param>
        /// <param name="_defender"></param>
        /// <param name="_effect"></param>
        /// <returns></returns>
        public static bool IsCritical(UnitInstance _attacker, UnitInstance _defender, Heal _effect)
        {
            double criticalRate = Rule.DEFAULT_CRITICAL_RATE;

            if (criticalRate <= 0.0000)
                return false;
            else if (criticalRate >= 1.0000)
                return true;
            else
            {
                int rangeNumber = Convert.ToInt32(criticalRate * 10000);

                Random.Random.randInit();
                int randomNumber = Random.Random.getRand(1, 10000);

                if (randomNumber < rangeNumber)
                    return true;
                else
                    return false;
            }
        }

        //_a and _b will be calculated as double
        public static object Sum(object _a, object _b)
        {
            try
            {
                double a = Convert.ToDouble(_a);
                double b = Convert.ToDouble(_b);

                return a + b;
            }
            catch (Exception ex)
            {
                return null;
            }
        }
        public static object Subtract(object _a, object _b)
        {
            try
            {
                double a = Convert.ToDouble(_a);
                double b = Convert.ToDouble(_b);

                return a - b;
            }
            catch (Exception ex)
            {
                return null;
            }
        }
        public static object Multiply(object _a, object _b)
        {
            try
            {
                double a = Convert.ToDouble(_a);
                double b = Convert.ToDouble(_b);

                return a * b;
            }
            catch (Exception ex)
            {
                return null;
            }
        }
        public static object Divide(object _a, object _b)
        {
            try
            {
                double a = Convert.ToDouble(_a);
                double b = Convert.ToDouble(_b);

                return a / b;
            }
            catch (Exception ex)
            {
                return null;
            }
        }
    }

    public enum eEffectiveness
    {
        EFFECTIVE,
        INEFFECTIVE
    }



}
