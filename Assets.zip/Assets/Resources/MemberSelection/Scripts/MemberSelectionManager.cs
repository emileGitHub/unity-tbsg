﻿using EEANGame.TBSG.V1_0.MainClassLib;
using EEANGame.ImageConverter.ForUnity;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using System;
using UnityEngine.SceneManagement;

[RequireComponent(typeof(InformationPanelManager))]
[RequireComponent(typeof(InformationPanelManager_Unit))]
public class MemberSelectionManager : MonoBehaviour {

    public GameObject UnitIcon;
    private Transform Panel;

    InformationPanelManager_Unit InformationPanelManager_Unit;

	// Use this for initialization
	void Awake () {
        Panel = this.transform.Find("DynamicGrid").Find("Panel");
        InformationPanelManager_Unit = this.GetComponent<InformationPanelManager_Unit>();

        bool isAlreadyMember = false; // Represents whether the unit is already a member of the selected team.
        foreach(IndividualUnitData unit in PlayerDataManager.Player.UnitsData)
        {
            isAlreadyMember = false; // Re-initialize it with the value "false"

            foreach(t_MemberSet memberSet in PlayerDataManager.Player.Teams[MemberSelectionIntermediary.TeamNum - 1].MemberSets)
            {
                if (unit == memberSet.Member)
                {
                    isAlreadyMember = true;
                    break;
                }
            }

            if (!isAlreadyMember)
            {
                GameObject unitIconClone = Instantiate(UnitIcon, Panel); // Create a unit icon as child element of Panel
                unitIconClone.name = unit.UniqueId.ToString(); // Set game object name as the id of corresponding unit
                unitIconClone.GetComponent<Image>().sprite = UnitIconManager.Icons[unit.IconAsByteArray.Id - 1]; // Set Sprite that corresponds to the unit
                unitIconClone.transform.Find("Frame").GetComponent<Image>().sprite = FrameSpriteManager.FrameSpriteForCorrespondingRarity(unit.Rarity); // Set frame Sprite that corrensponds to the rarity of the unit 
                unitIconClone.gameObject.GetComponent<Button>().onClick.AddListener(() => SwapCharacters(unit.UniqueId)); // Set SwapCharacters() function to the button
                unitIconClone.transform.Find("Info").GetComponent<Button>().onClick.AddListener(() => InformationPanelManager_Unit.InstantiateInfoPanel(unit.UniqueId));
            }
        }
	}

    /// <summary>
    /// PreCondition: _unitId is a valid Id (A unit with the same _unitId exists)
    /// PostCondition: The specific member in the selected team will be swapped with the unit that corresponds to _unitId
    /// </summary>
    /// <param name="_unitId"></param>
    public void SwapCharacters(int _unitId)
    {
        try
        {
            int teamNum = MemberSelectionIntermediary.TeamNum;
            int memberNum = MemberSelectionIntermediary.MemberNum;

            PlayerDataManager.Player.Teams[teamNum - 1].MemberSets[memberNum - 1].Member = PlayerDataManager.Player.UnitsData.Find(x => x.UniqueId == _unitId); // Swaps units

            SceneManager.LoadScene("TeamCustomization"); // Returns to TeamCustomization Scene
        }
        catch(Exception ex)
        {
            Debug.Log(ex.Message);
        }
    }
}
