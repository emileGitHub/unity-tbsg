﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MemberSelectionIntermediary : MonoBehaviour {

    public static int TeamNum;
    public static int MemberNum;

    private TeamCustomizationManager tcmScript;

    // Use this for initialization
    void Awake()
    {
        DontDestroyOnLoad(this); // Properties will be shared between several scenes

        tcmScript = this.transform.root.GetComponent<TeamCustomizationManager>();

        TeamNum = 1; // Set default value
        MemberNum = 0; //Set default value
    }

    public void SelectMember1()
    {
        TeamNum = tcmScript.CurrentTeamIndex + 1;
        MemberNum = 1;
    }

    public void SelectMember2()
    {
        TeamNum = tcmScript.CurrentTeamIndex + 1;
        MemberNum = 2;
    }

    public void SelectMember3()
    {
        TeamNum = tcmScript.CurrentTeamIndex + 1;
        MemberNum = 3;
    }

    public void SelectMember4()
    {
        TeamNum = tcmScript.CurrentTeamIndex + 1;
        MemberNum = 4;
    }

    public void SelectMember5()
    {
        TeamNum = tcmScript.CurrentTeamIndex + 1;
        MemberNum = 5;
    }
}
