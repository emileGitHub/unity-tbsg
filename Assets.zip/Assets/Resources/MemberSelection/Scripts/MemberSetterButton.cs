﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using System;
using UnityEngine.SceneManagement;

public class MemberSetterButton : MonoBehaviour
{
    private Button Button;

    private void Awake()
    {
        Button = this.GetComponent<Button>();
        Button.onClick = new Button.ButtonClickedEvent();

    }

    public void SetMember()
    {
        PlayerDataManager.Player.Teams[MemberSelectionIntermediary.TeamNum - 1].MemberSets[MemberSelectionIntermediary.MemberNum - 1].Member = PlayerDataManager.Player.UnitsData.Find(c => c.UniqueId == Convert.ToInt32(this.name));
        SceneManager.LoadScene("TeamCustomization");
    }
}
