﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Networking;
using UnityEngine.SceneManagement;

[RequireComponent(typeof(NetworkLobbyManager))]
[RequireComponent(typeof(NetworkManagerHUD))]
public class LobbyManager
    : NetworkBehaviour {

    //// Use this for initialization
    //void Awake () {

    //    SceneManager.sceneLoaded += OnSceneLoadEnd;

    //    //To be implemented
    //}

    //private void OnSceneLoadEnd(Scene scene, LoadSceneMode mode)
    //{
    //    if(this.gameObject != null)
    //    {
    //        this.GetComponent<NetworkManagerHUD>().enabled = true;
    //    }
    //}

    public void ShutDown()
    {
        this.transform.parent = null;
        NetworkLobbyManager.Shutdown();
        //this.GetComponent<NetworkLobbyManager>().dontDestroyOnLoad = false;
        Destroy(this.gameObject);
    }
}
