﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class LoadingSceneIdentifier : MonoBehaviour {

    private static LoadingSceneIdentifier instance;

    public static string SceneName;

    //Use this for initialization
    private void Awake()
    {
        if (instance == null)
        {
            instance = this;
            SceneName = "Title"; // Set Title scene as the default scene to load
            DontDestroyOnLoad(this.gameObject);
        }
        else if (instance != this)
        {
            Destroy(this.gameObject); // Avoid having multiple components of the same type
        }
    }
}
