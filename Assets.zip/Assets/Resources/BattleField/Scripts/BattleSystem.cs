﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using EEANGame.TBSG.V1_0.MainClassLib;
using UnityEngine.Networking;
using EEANGame.TBSG.V1_0.CommonEnums;
using System;
using UnityEngine.UI;

public class BattleSystem : NetworkBehaviour {

    private TileMapManager TileMapScript;
    private TileMaskManager TileMaskScript;
    private GameObject GameBoardSet;
    private Transform BaseTile;
    private float TileSizeX;
    private float TileSizeZ;
    private AnimationController AnimationController;
    private BattleUIManager UIManagerScript;

    private GameObject[] Players;
    private List<PlayerController> PlayerControllers;

    [SerializeField] public GameObject UnitPrefab;
    private List<GameObject> Units;
    private List<GameObject> Player1_Units;
    private List<GameObject> Player2_Units;

    [SyncVar]
    public bool isScaleAdjusted;
    [SyncVar]
    public Vector3 UnitScale;

    private List<eTileType> tileSet;
    public Field FieldInstance;

    private Text LoadingStatus;

    [SyncVar]
    public bool isInitialized;

    [SyncVar]
    public bool arePlayersSet;
    private bool areTileDataSet;
    private bool isFieldSet;
    private bool isBoardSet;
    private bool areUnitsSet;

    [SyncVar]
    public bool isMatchEnd;
    public bool isPlayer1Winner;


    // Use this for Initialization of simple properties
    public override void OnStartServer()
    {
        isInitialized = false;
        arePlayersSet = false;
        areTileDataSet = false;
        isFieldSet = false;
        isBoardSet = false;
        areUnitsSet = false;
        isMatchEnd = false;
        isScaleAdjusted = false;
        LoadingStatus = GameObject.Find("LoadingStatus").GetComponent<Text>();
        GameBoardSet = GameObject.Find("TBSGBoard");
        TileMapScript = GameBoardSet.GetComponent<TileMapManager>();
        TileMaskScript = GameBoardSet.GetComponent<TileMaskManager>();
        BaseTile = GameBoardSet.transform.Find("Tile0");
        AnimationController = GameObject.Find("AnimationController").GetComponent<AnimationController>();
        UIManagerScript = GameObject.Find("BattleUIManager").GetComponent<BattleUIManager>();
        MeshRenderer mr = BaseTile.GetComponent<MeshRenderer>();
        TileSizeX = mr.bounds.size.x;
        TileSizeZ = mr.bounds.size.z;
        Units = new List<GameObject>();
        Player1_Units = new List<GameObject>();
        Player2_Units = new List<GameObject>();
    }

    // Use this for detailed initialization
    // Update() is being used to make sure that all Player Instances are created before the detailed initialization
    void Update()
    {
        if (isServer && !isInitialized)
            Initialize();

        if (isServer && isInitialized)
        {
            if (FieldInstance.IsMatchEnd)
                EndMatch();

            FieldInstance.UpdateCharactersLiveStatus();
            SyncUnitStatus_All();
            SyncData();
            CheckTurn(false);
        }
    }

    private void Initialize()
    {
        try
        {
            Debug.Log("BattleSystem: Start Initialization on server.");

            if(!arePlayersSet)
            {
                LoadingStatus.text = "Loading Player Data On Server";
                if (Players == null || Players.Length < 2)
                    Players = GameObject.FindGameObjectsWithTag("Player");

                if (Players.Length < 2) // if not all Players have been spawned
                    return; // Stop Initialization

                PlayerControllers = new List<PlayerController>(); // Get the primary script of each Player Object
                foreach (GameObject player in Players)
                {
                    PlayerControllers.Add(player.GetComponent<PlayerController>());
                }

                if (!SetPlayOrder()) // If failed to set Playing Order
                    return;

                //if it reached this code, all went right
                arePlayersSet = true;
            }

            if (!areTileDataSet)
            {
                LoadingStatus.text = "Loading Tile Data On Server";
                tileSet = new List<eTileType>(); // Define the set of tiles available --- repetition of tiles will increase the probability that the board contains the specific tile
                tileSet.Add(eTileType.NORMAL);
                tileSet.Add(eTileType.NORMAL);
                tileSet.Add(eTileType.NORMAL);
                tileSet.Add(eTileType.NORMAL);
                tileSet.Add(eTileType.BLUE);
                tileSet.Add(eTileType.RED);
                tileSet.Add(eTileType.GREEN);
                tileSet.Add(eTileType.OCHER);
                tileSet.Add(eTileType.PURPLE);
                tileSet.Add(eTileType.YELLOW);
                tileSet.Add(eTileType.HEAL);

                if (tileSet != null && tileSet.Count > 0)
                    areTileDataSet = true;
                else
                    return;
            }

            if (!isFieldSet)
            {
                LoadingStatus.text = "Setting Up Field On Server";
                FieldInstance = Field.NewField(PlayerControllers[0].PlayerData as Player, 0, PlayerControllers[1].PlayerData as Player, 1, tileSet);
                if (FieldInstance == null) // if FieldInstance was not created successfully
                    return;
                //Assign Values from core script to my properties
                PlayerControllers[0].MaxSP = FieldInstance.Players[0].MaxSP;
                PlayerControllers[0].RemainingSP = FieldInstance.Players[0].RemainingSP;
                PlayerControllers[0].SelectedAlliedUnitId = FieldInstance.Players[0].SelectedUnitIndex;
                PlayerControllers[1].MaxSP = FieldInstance.Players[1].MaxSP;
                PlayerControllers[1].RemainingSP = FieldInstance.Players[1].RemainingSP;
                PlayerControllers[1].SelectedAlliedUnitId = FieldInstance.Players[1].SelectedUnitIndex;

                if (FieldInstance != null)
                    isFieldSet = true;
                else
                    return;
            }

            if(!isBoardSet)
            {
                LoadingStatus.text = "Setting Up Board On Server";
                isBoardSet = SetUpBoard();

                if (!isBoardSet) //if failed to set up board
                    return;
            }

            if(!areUnitsSet)
            {
                LoadingStatus.text = "Setting Up Units On Server";
                Units.Clear(); // Reset List in case it already contains game objects
                foreach (UnitInstance unit in FieldInstance.Players[0].AlliedUnits) // Spawn Units owned by Player 1
                {
                    if (!SpawnUnit(unit, 0))
                        return;
                }

                foreach (UnitInstance unit in FieldInstance.Players[1].AlliedUnits) // Spawn Units owned by Player 2
                {
                    if (!SpawnUnit(unit, 1))
                        return;
                }

                //if it reached this code, all went right
                areUnitsSet = true;
            }

            if(arePlayersSet
                && areTileDataSet
                && isFieldSet
                && isBoardSet
                && areUnitsSet)
            {
                isInitialized = true;
                Debug.Log("BattleSystem: End Initialization on server.");
            }
        }
        catch (Exception ex)
        {
            Debug.Log("BattleSystem: at Initialize()" + ex.Message);
        }
    }

    private void SyncData()
    {
        for(int i = 0; i < PlayerControllers.Count; i++)
        {
            int maxSP = FieldInstance.Players[i].MaxSP;
            int remainingSP = FieldInstance.Players[i].RemainingSP;
            int selectedAlliedUnitId = FieldInstance.Players[i].SelectedUnitIndex;

            if (PlayerControllers[i].MaxSP != maxSP
                || PlayerControllers[i].RemainingSP != remainingSP
                || PlayerControllers[i].SelectedAlliedUnitId != selectedAlliedUnitId)
            {
                //Update properties on server
                PlayerControllers[i].MaxSP = maxSP;
                PlayerControllers[i].RemainingSP = remainingSP;
                PlayerControllers[i].SelectedAlliedUnitId = selectedAlliedUnitId;
            }
        }
    }

    private void CheckTurn(bool _isExplicitCall)
    {
        int currentPlayerIndex = PlayerControllers[0].isMyTurn ? 0 : 1;
        int otherPlayerIndex = currentPlayerIndex == 0 ? 1 : 0;

        if (PlayerControllers[currentPlayerIndex].RemainingSP == 0 || _isExplicitCall)
            ChangeTurn(currentPlayerIndex, otherPlayerIndex);
    }

    private void ChangeTurn(int _currentPlayerIndex, int _nextPlayerIndex)
    {
        FieldInstance.ChangeTurn();
        FieldInstance.ApplyContinuousEffect();
        PlayerControllers[_currentPlayerIndex].isMyTurn = !PlayerControllers[_currentPlayerIndex].isMyTurn;
        PlayerControllers[_nextPlayerIndex].isMyTurn = !PlayerControllers[_nextPlayerIndex].isMyTurn;
    }

    //To be accessed from external script
    public void ChangeTurn()
    {
        CheckTurn(true);
    }

    public void Concede()
    {
        int currentPlayerIndex = PlayerControllers[0].isMyTurn ? 0 : 1;
        int currentPlayerId = PlayerControllers[currentPlayerIndex].PlayerId;

        FieldInstance.EndMatch(FieldInstance.Players[currentPlayerId - 1]);
    }

    private void EndMatch()
    {
        isMatchEnd = true;

        isPlayer1Winner = FieldInstance.IsPlayer1Winner;
    }

    private bool SetUpBoard()
    {
        try
        {
            Debug.Log("BattleSystem: Start Board Set Up.");
            if (!TileMapScript.SyncVarInitialization())
                return false;
            Debug.Log("BattleSystem: End Board Set Up.");
            return true;
        }
        catch (Exception ex)
        {
            Debug.Log("BattleSystem: at SetUpBoard() " + ex.Message);
            return false;
        }
    }

    private bool SpawnUnit(UnitInstance _unit, int _playerIndex)
    {
        try
        {
            Debug.Log("BattleSystem: Start Unit Creation.");

            GameObject Unit = Instantiate(UnitPrefab, new Vector3(0, 0, 0), Quaternion.identity);

            _2DCoord coord = FieldInstance.UnitLocation(_unit); // Get location as logical 2D Coordinate (x, y) --- this is not Unity coordinate
            Unit.transform.position = GetActualPosition(Unit, coord); // Get and Set the actual position in the Unity world

            //Return false if not succeeded
            if (!Unit.GetComponent<UnitController>()
                .SyncVarInitialization(FieldInstance.Units.IndexOf(_unit),
                                       FieldInstance.Players[_playerIndex].AlliedUnits.IndexOf(_unit),
                                       _playerIndex + 1,
                                       _unit.SpriteAsByteArray.Id,
                                       _unit.IconAsByteArray.Id,
                                       _unit.DirectionFacing,
                                       _unit.Nickname,
                                       _unit.Name,
                                       Convert.ToInt32(_unit.Elements[0]),
                                       Convert.ToInt32(_unit.Elements[1]),
                                       Convert.ToInt32(_unit.SpecieTypes[0]),
                                       Convert.ToInt32(_unit.SpecieTypes[1]),
                                       Convert.ToInt32(_unit.SpecieTypes[2]),
                                       _unit.Level,
                                       Calculator.MaxHP(_unit),
                                       _unit.RemainingHP,
                                       Calculator.PhysicalStrength(_unit),
                                       Calculator.PhysicalResistance(_unit),
                                       Calculator.MagicalStrength(_unit),
                                       Calculator.MagicalResistance(_unit),
                                       Calculator.Vitality(_unit),
                                       GetSkillNames(_unit)))
            {
                Destroy(Unit); // destroy not to leave the unsynced instance in unity world
                return false;
            }

            Unit.name = _unit.Nickname; //To make it easier to identify on editor

            if (_playerIndex == 0)
                Player1_Units.Add(Unit);
            else
                Player2_Units.Add(Unit);

            Units.Add(Unit);

            Debug.Log("BattleSystem: End Unit Creation.");

            Debug.Log("BattleSystem: Spawn Unit on clients.");
            NetworkServer.Spawn(Unit);
            return true;
        }
        catch (Exception ex)
        {
            Debug.Log("BattleSystem: at SpawnUnit() " + ex.Message);
            return false;
        }
    }

    public void InitializeUnitScale(GameObject _unit)
    {
        try
        {
            Debug.Log("BattleSystem: Start InitializeUnitScale()");
            MeshRenderer mr = BaseTile.GetComponent<MeshRenderer>();

            Vector3 tileSize = mr.bounds.size;

            Vector3 currentUnitSpriteSize = _unit.GetComponent<SpriteRenderer>().sprite.bounds.size;
            Vector3 currentUnitSpriteScale = _unit.transform.lossyScale;

            float scale = 0;

            if (currentUnitSpriteSize.x != 0)
                scale = currentUnitSpriteScale.x * tileSize.x / currentUnitSpriteSize.x;

            UnitScale = new Vector3(scale, scale, scale);

            isScaleAdjusted = true;
            Debug.Log("BattleSystem: End InitializeUnitScale()");
        }
        catch (Exception ex)
        {
            Debug.Log("BattleSystem: at InitializeUnitScale() " + ex.Message);
        }
    }

    private Vector3 GetActualPosition(GameObject _unit, _2DCoord _coord)
    {
        try
        {
            Vector3 unitSize = _unit.GetComponent<SpriteRenderer>().bounds.size;

            int tileNum = _coord.Y * Rule.SIZE_OF_A_SIDE_OF_BOARD + _coord.X;
            Transform tile = GameObject.Find("Tile" + tileNum.ToString()).transform;

            MeshRenderer mr = tile.GetComponent<MeshRenderer>();

            float adjustmentValueY = mr.bounds.size.y;

            float x = tile.position.x;
            float y = tile.position.y + adjustmentValueY;
            float z = tile.position.z;

            return new Vector3(x, y, z);
        }
        catch(Exception ex)
        {
            Debug.Log("BattleSystem: at GetActualPosition() " + ex.Message);
            return new Vector3(-1, -1, -1);
        }
    }

    [Server]
    public List<string> GetSkillNames(UnitInstance _unit)
    {
        List<string> skillNames = new List<string>();

        foreach(Skill skill in _unit.Skills)
        {
            skillNames.Add(skill.Name);
        }

        return skillNames;
    }

    private Vector3 GetActualPosition(_2DCoord _coord)
    {
        try
        {
            int tileNum = _coord.Y * Rule.SIZE_OF_A_SIDE_OF_BOARD + _coord.X;
            Transform tile = GameObject.Find("Tile" + tileNum.ToString()).transform;

            MeshRenderer mr = tile.GetComponent<MeshRenderer>();

            float adjustmentValueY = mr.bounds.size.y;

            float x = tile.position.x;
            float y = tile.position.y + adjustmentValueY;
            float z = tile.position.z;

            return new Vector3(x, y, z);
        }
        catch (Exception ex)
        {
            Debug.Log("BattleSystem: at GetActualPosition() " + ex.Message);
            return new Vector3(-1, -1, -1);
        }
    }

    [Server]
    public void RotateUnit()
    {
        try
        {
            PlayerOnBoard pob = FieldInstance.CurrentTurnPlayer;
            UnitInstance unit = pob.AlliedUnits[pob.SelectedUnitIndex];

            eDirection nextDirection;
            switch (unit.DirectionFacing)
            {
                case eDirection.FRONT:
                    nextDirection = eDirection.RIGHT;
                    break;
                case eDirection.RIGHT:
                    nextDirection = eDirection.BACK;
                    break;
                case eDirection.BACK:
                    nextDirection = eDirection.LEFT;
                    break;
                default: // case eDirection.LEFT:
                    nextDirection = eDirection.FRONT;
                    break;
            }

            FieldInstance.ChangeDirectionFacing(unit, nextDirection);

            int unitIndex = FieldInstance.Units.IndexOf(pob.AlliedUnits[pob.SelectedUnitIndex]);
            GameObject Unit = Units[unitIndex];

            Unit.GetComponent<UnitController>()
                .Rpc_UpdateDirection(unit.DirectionFacing);
        }
        catch(Exception ex)
        {
            Debug.Log("BattleSystem: at RotateUnit() " + ex.Message);
        }
    }

    [Server]
    public void MoveUnit(eDirection _direction)
    {
        try
        {
            PlayerOnBoard pob = FieldInstance.CurrentTurnPlayer;
            UnitInstance unit = pob.AlliedUnits[pob.SelectedUnitIndex];

            FieldInstance.MoveUnit(unit, _direction);

            int unitIndex = FieldInstance.Units.IndexOf(pob.AlliedUnits[pob.SelectedUnitIndex]);
            GameObject Unit = Units[unitIndex];

            UnitController UnitController = Unit.GetComponent<UnitController>();

            UnitController.Rpc_UpdateDirection(unit.DirectionFacing);
            UnitController.Rpc_Move(GetActualPosition(Unit, FieldInstance.UnitLocation(unit)));
        }
        catch (Exception ex)
        {
            Debug.Log("BattleSystem: at MoveUnit() " + ex.Message);
        }
    }

    [Server]
    public void Attack()
    {
        try
        {
            PlayerOnBoard pob = FieldInstance.CurrentTurnPlayer;
            UnitInstance unit = pob.AlliedUnits[pob.SelectedUnitIndex];

            GameObject Unit = new GameObject();
            if (pob == FieldInstance.Players[0])
                Unit = Player1_Units
                        .Find(u => u.GetComponent<UnitController>().Unit_PrivateId == pob.SelectedUnitIndex);
            else // if (pob == FieldInstance.Players[1])
                Unit = Player2_Units
                    .Find(u => u.GetComponent<UnitController>().Unit_PrivateId == pob.SelectedUnitIndex);

            UnitController UnitController = Unit.GetComponent<UnitController>();

            List<EFFECT_RESULT> results = FieldInstance.RequestAttack(unit);
            if (results.Count > 0)
                AnimationController.SkillAnimation(UnitController.Unit_PublicId, results);
        }
        catch (Exception ex)
        {
            Debug.Log("BattleSystem: at Attack() " + ex.Message);
        }
    }
    [Server]
    public void Skill(string _skillName)
    {
        try
        {
            PlayerOnBoard pob = FieldInstance.CurrentTurnPlayer;
            UnitInstance unit = pob.AlliedUnits[pob.SelectedUnitIndex];

            GameObject Unit = new GameObject();
            if (pob.IsPlayer1)
                Unit = Player1_Units
                        .Find(u => u.GetComponent<UnitController>().Unit_PrivateId == pob.SelectedUnitIndex);
            else
                Unit = Player2_Units
                    .Find(u => u.GetComponent<UnitController>().Unit_PrivateId == pob.SelectedUnitIndex);

            UnitController UnitController = Unit.GetComponent<UnitController>();

            Skill skill = unit.Skills.Find(x => x.Name == _skillName);

            List<EFFECT_RESULT> effectResults = FieldInstance.RequestSkillUse(unit, skill);
            if (effectResults.Count > 0)
            {
                AnimationController.SkillAnimation(UnitController.Unit_PublicId, effectResults);
            }
        }
        catch (Exception ex)
        {
            Debug.Log("BattleSystem: at Attack() " + ex.Message);
        }
    }

    [Server]
    public void RequestSkillCost(int _playerId, int _unitId, string _skillName)
    {
        int playerIndex = _playerId - 1; // _playerId is one-based and playerIndex needs to be zero-based

        PlayerOnBoard pob = FieldInstance.Players[playerIndex];
        UnitInstance unit = pob.AlliedUnits[_unitId];

        int requiredSP = unit.Skills.Find(x => x.Name == _skillName).SPCost;

        UIManagerScript.Rpc_UpdateSkillCostCatcher(requiredSP);
    }

    [Server]
    private void SyncUnitStatus_All()
    {
        try
        {
            foreach (GameObject Unit in Player1_Units)
            {
                UnitController UnitController = Unit.GetComponent<UnitController>();

                UnitInstance unit = FieldInstance.Players[0].AlliedUnits[UnitController.Unit_PrivateId];

                UnitController.Rpc_SyncStatus(Calculator.MaxHP(unit), unit.RemainingHP, unit.isAlive);
            }

            foreach (GameObject Unit in Player2_Units)
            {
                UnitController UnitController = Unit.GetComponent<UnitController>();

                UnitInstance unit = FieldInstance.Players[1].AlliedUnits[UnitController.Unit_PrivateId];

                UnitController.Rpc_SyncStatus(Calculator.MaxHP(unit), unit.RemainingHP, unit.isAlive);
            }
        }
        catch (Exception ex)
        {
            Debug.Log("BattleSystem: at SyncUnitStatus_All() " + ex.Message);
        }
    }

    [Server]
    public void ChangeUnit(int _playerId, int _unitId)
    {
        try
        {
            int internalPlayerId = _playerId - 1;

            PlayerOnBoard pob = FieldInstance.Players[internalPlayerId];

            FieldInstance.ChangeSelectedUnit(pob, _unitId);
            Debug.Log("Selected Unit has been changed");

            SyncData();

            Debug.Log("Unit Selection Info was Synced!");
        }
        catch (Exception ex)
        {
            Debug.Log("BattleSystem: at ChangeUnit() " + ex.Message);
        }
    }

    [Server]
    public void UpdateMovableArea(int _playerId, int _unitId)
    {
        try
        {
            int playerIndex = _playerId - 1; // _playerId is one-based and playerIndex needs to be zero-based

            PlayerOnBoard pob = FieldInstance.Players[playerIndex];
            UnitInstance unit = pob.AlliedUnits[_unitId];

            string coordsString = _2DCoord.CoordsToString(FieldInstance.GetMovableArea(unit));

            TileMaskScript.Rpc_DisplayTargetArea(coordsString);
        }
        catch (Exception ex)
        {
            Debug.Log("BattleSystem: at GetMovableArea() " + ex.Message);
        }
    }

    [Server]
    public void UpdateAttackTargetArea(int _playerId, int _unitId)
    {
        try
        {
            int playerIndex = _playerId - 1; // _playerId is one-based and playerIndex needs to be zero-based

            PlayerOnBoard pob = FieldInstance.Players[playerIndex];
            UnitInstance unit = pob.AlliedUnits[_unitId];

            string coordsString = _2DCoord.CoordsToString(FieldInstance.GetAttackTargetAreas(unit));

            TileMaskScript.Rpc_DisplayTargetArea(coordsString);
        }
        catch (Exception ex)
        {
            Debug.Log("BattleSystem: at GetAttackTargetArea() " + ex.Message);
        }
    }

    [Server]
    public void DisplaySkillTargetArea(int _playerId, int _unitId, int _skillIndex)
    {
        try
        {
            int playerIndex = _playerId - 1; // _playerId is one-based and playerIndex needs to be zero-based

            PlayerOnBoard pob = FieldInstance.Players[playerIndex];
            UnitInstance unit = pob.AlliedUnits[_unitId];

            if(_skillIndex >= 0 && unit.Skills.Count > _skillIndex)
            {
                string skillName = unit.Skills[_skillIndex].Name;

                List<string> result = new List<string>();
                foreach (List<_2DCoord> targetArea in FieldInstance.GetSkillTargetAreas(unit, unit.Skills.Find(x => x.Name == skillName)))
                {
                    result.Add(_2DCoord.CoordsToString(targetArea));
                }

                TileMaskScript.Rpc_DisplayTargetArea(result[0]); // Later implementation: Enable it to return multiple target areas.
            }
        }
        catch (Exception ex)
        {
            Debug.Log("BattleSystem: at DisplaySkillTargetArea() " + ex.Message);
        }
    }

    //[Server]
    //public List<List<_2DCoord>> GetSkillTargetAreas(int _playerId, int _unitId)
    //{
    //    try
    //    {
    //        int internalPlayerId = _playerId - 1; // _playerId starts from 1 in unity side, whereas it starts from 0 in core script side

    //        PlayerOnBoard pob = FieldInstance.Players[internalPlayerId];
    //        UnitInstance unit = pob.AlliedUnits[_unitId];

    //        return FieldInstance.GetMovableArea(unit);
    //    }
    //    catch (Exception ex)
    //    {
    //        Debug.Log("BattleSystem: at GetMovableArea() " + ex.Message);
    //        return null;
    //    }
    //}

    [Server]
    public void UnselectUnits(int _playerId)
    {
        try
        {
            int internalPlayerId = _playerId - 1; // _playerId starts from 1 in unity side, whereas it starts from 0 in core script side

            PlayerOnBoard pob = FieldInstance.Players[internalPlayerId];

            FieldInstance.UnselectUnits(pob);
        }
        catch (Exception ex)
        {
            Debug.Log("BattleSystem: at UnselectUnits() " + ex.Message);
        }
    }

    public bool SetPlayOrder()
    {
        try
        {
            int randNum = Random.Random.getRand(1, 10); //Randomly select which Player will start playing first
            if (randNum > 5)
            {
                //Change player order in list
                GameObject tmp = Players[0];
                Players[0] = Players[1];
                Players[1] = tmp;
            }
            //else if (randNum <= 5)
                //Do nothing;
                

            PlayerControllers[0].PlayerId = 1; // Player 1
            PlayerControllers[0].isMyTurn = true; // Starts first
            PlayerControllers[1].PlayerId = 2; // Player 2
            PlayerControllers[1].isMyTurn = false; // Starts after Player 1

            return true;
        }
        catch(Exception ex)
        {
            Debug.Log("BattleSystem: at SetPlayOrder() " + ex.Message);
            return false;
        }
    }
}
