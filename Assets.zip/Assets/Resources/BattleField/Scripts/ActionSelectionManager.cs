﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class ActionSelectionManager : MonoBehaviour {

    private Image Move_Image;
    private Image Attack_Image;
    private Image Guard_Image;
    private Image Item_Image;
    private Image USkill_Image;
    private Image Skill_Image;

    public Sprite AttackIconActive;
    public Sprite GuardIconActive;
    public Sprite MoveIconActive;
    public Sprite SkillIconActive;
    public Sprite ItemIconActive;
    public Sprite USkillIconActive;

    public Sprite AttackIconDisabled;
    public Sprite GuardIconDisabled;
    public Sprite MoveIconDisabled;
    public Sprite SkillIconDisabled;
    public Sprite ItemIconDisabled;
    public Sprite USkillIconDisabled;

    public eActionType CurrentActionSelected { get; private set; }

    // Use this for initialization
    void Awake()
    {
        Move_Image = this.transform.Find("Move").GetComponent<Image>();
        Attack_Image = this.transform.Find("Attack").GetComponent<Image>();
        Guard_Image = this.transform.Find("Guard").GetComponent<Image>();
        Item_Image = this.transform.Find("Item").GetComponent<Image>();
        USkill_Image = this.transform.Find("U-Skill").GetComponent<Image>();
        Skill_Image = this.transform.Find("Skill").GetComponent<Image>();

        Guard_Image.sprite = GuardIconDisabled;
        Item_Image.sprite = ItemIconDisabled;
        USkill_Image.sprite = USkillIconDisabled;

        Move_Image.transform.GetComponent<Button>().onClick.AddListener(() => ChangeSelection(eActionType.MOVE));
        Attack_Image.transform.GetComponent<Button>().onClick.AddListener(() => ChangeSelection(eActionType.ATTACK));
        //Guard_Image.transform.GetComponent<Button>().onClick.AddListener(() => ChangeSelection(eActionType.GUARD));
        //Item_Image.transform.GetComponent<Button>().onClick.AddListener(() => ChangeSelection(eActionType.ITEM));
        //USkill_Image.transform.GetComponent<Button>().onClick.AddListener(() => ChangeSelection(eActionType.USKILL));
        Skill_Image.transform.GetComponent<Button>().onClick.AddListener(() => ChangeSelection(eActionType.SKILL));

        CurrentActionSelected = eActionType.MOVE;

        UpdateUI();
    }

    //public void ChangeSelection(bool _toLeft)
    //{
    //    try
    //    {
    //        if (_toLeft)
    //        {
    //            switch (CurrentActionSelected)
    //            {
    //                default: //case eActionType.MOVE
    //                    CurrentActionSelected = eActionType.ATTACK;
    //                    break;
    //                case eActionType.ATTACK:
    //                    CurrentActionSelected = eActionType.GUARD;
    //                    break;
    //                case eActionType.GUARD:
    //                    CurrentActionSelected = eActionType.ITEM;
    //                    break;
    //                case eActionType.ITEM:
    //                    CurrentActionSelected = eActionType.USKILL;
    //                    break;
    //                case eActionType.USKILL:
    //                    CurrentActionSelected = eActionType.SKILL;
    //                    break;
    //                case eActionType.SKILL:
    //                    CurrentActionSelected = eActionType.MOVE;
    //                    break;
    //            }
    //        }
    //        else
    //        {
    //            switch (CurrentActionSelected)
    //            {
    //                default: //case eActionType.MOVE
    //                    CurrentActionSelected = eActionType.SKILL;
    //                    break;
    //                case eActionType.ATTACK:
    //                    CurrentActionSelected = eActionType.MOVE;
    //                    break;
    //                case eActionType.GUARD:
    //                    CurrentActionSelected = eActionType.ATTACK;
    //                    break;
    //                case eActionType.ITEM:
    //                    CurrentActionSelected = eActionType.GUARD;
    //                    break;
    //                case eActionType.USKILL:
    //                    CurrentActionSelected = eActionType.ITEM;
    //                    break;
    //                case eActionType.SKILL:
    //                    CurrentActionSelected = eActionType.USKILL;
    //                    break;
    //            }
    //        }

    //        UpdateUI();
    //    }
    //    catch (Exception ex)
    //    {
    //        Debug.Log("ActionSelector: at ChangeSelection() " + ex.Message);
    //    }
    //}

    public void ChangeSelection(eActionType _action)
    {
        if (CurrentActionSelected != _action)
        {
            CurrentActionSelected = _action;
            UpdateUI();
        }
    }

    private void UpdateUI()
    {
        try
        {
            MinimizeAll();

            switch (CurrentActionSelected)
            {
                default: //case eActionType.MOVE
                    {
                        Move_Image.transform.localScale = new Vector3(1.5f, 1.5f, 1.5f);
                    }
                    break;
                case eActionType.ATTACK:
                    {
                        Attack_Image.transform.localScale = new Vector3(1.5f, 1.5f, 1.5f);
                    }
                    break;
                case eActionType.GUARD:
                    {
                        Guard_Image.transform.localScale = new Vector3(1.5f, 1.5f, 1.5f);
                    }
                    break;
                case eActionType.ITEM:
                    {
                        Item_Image.transform.localScale = new Vector3(1.5f, 1.5f, 1.5f);
                    }
                    break;
                case eActionType.USKILL:
                    {
                        USkill_Image.transform.localScale = new Vector3(1.5f, 1.5f, 1.5f);
                    }
                    break;
                case eActionType.SKILL:
                    {
                        Skill_Image.transform.localScale = new Vector3(1.5f, 1.5f, 1.5f);
                    }
                    break;

            }
        }
        catch (Exception ex)
        {
            Debug.Log("ActionSelector: at UpdateUI() " + ex.Message);
        }
    }

    private void MinimizeAll()
    {
        Vector3 minimizedScale = new Vector3(1f, 1f, 1f);

        Move_Image.transform.localScale = minimizedScale;
        Attack_Image.transform.localScale = minimizedScale;
        Guard_Image.transform.localScale = minimizedScale;
        Item_Image.transform.localScale = minimizedScale;
        USkill_Image.transform.localScale = minimizedScale;
        Skill_Image.transform.localScale = minimizedScale;
    }
}

public enum eActionType
{
    ATTACK,
    GUARD,
    MOVE,
    ITEM,
    SKILL,
    USKILL
}
