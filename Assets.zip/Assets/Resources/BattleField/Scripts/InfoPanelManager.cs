﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class InfoPanelManager : MonoBehaviour
{
    private BattleSystem mainScript;
    private LocalPlayerIdentifier LocalPlayerIdentifier;

    public List<GameObject> InfoPanels { get; private set; }
    private Transform Canvas;

    private bool isInitialized;

    // Use this for initialization
    void Awake()
    {
        isInitialized = false;
    }

    // Update is called once per frame
    void Update()
    {
        if (!isInitialized)
            Inititalize();

        if (isInitialized)
        {
        }
    }

    private void Inititalize()
    {
        try
        {
            if (InfoPanels == null)
                InfoPanels = new List<GameObject>();

            if (Canvas == null)
                Canvas = GameObject.Find("Canvas").transform;

            if (mainScript == null)
                mainScript = GameObject.Find("BattleSystemController").GetComponent<BattleSystem>();

            if (LocalPlayerIdentifier == null)
                LocalPlayerIdentifier = GameObject.Find("LocalPlayerIdentifier").GetComponent<LocalPlayerIdentifier>();

            if (mainScript != null && LocalPlayerIdentifier != null)
                isInitialized = true;

        }
        catch (Exception ex)
        {
            Debug.Log("InfoPanelManager: at Initialize() " + ex.Message);
        }
    }

    public void AddInfoPanel(GameObject _infoPanel)
    {
        if(_infoPanel != null)
            InfoPanels.Add(_infoPanel);
    }

    public void RemoveInfoPanel(GameObject _infoPanel)
    {
        if(InfoPanels.Exists(x => x == _infoPanel))
            InfoPanels.Remove(_infoPanel);
    }
}

