﻿using EEANGame.TBSG.V1_0.MainClassLib;
using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Networking;

public class PlayerController : NetworkBehaviour {

    public object PlayerData;

    [SyncVar]
    public bool isMyTurn;

    [SyncVar]
    public int PlayerId;

    [SyncVar(hook = "SyncMaxSP")]
    public int MaxSP;
    [SyncVar(hook = "SyncRemainingSP")]
    public int RemainingSP;
    [SyncVar(hook = "SyncSelectedAlliedUnitId")]
    public int SelectedAlliedUnitId; // Synced with Field.Players[].AlliedUnit[index]

    public SyncListCoord2D SyncList_Area; // Represents the area to be highlighted

    private bool isInitialized;

    private BattleSystem mainScript;
    private GameObject boardSet;
    private GameObject board;

    // Use this for initialization
    void Awake()
    {
        try
        {
            Debug.Log("PlayerController: Awake");
            isInitialized = false;

            //SyncList_Areas = new SyncListStruct<AREAS2D>();
            SyncList_Area = new SyncListCoord2D();

            PlayerData = PlayerDataManager.Player;
        }
        catch (Exception ex)
        {
            Debug.Log("PlayerController: at Awake() " + ex.Message);
        }
    }

    private void Update()
    {
        if (!isInitialized)
            Initialize();
    }

    public void Initialize()
    {
        try
        {
            if (mainScript == null)
                mainScript = GameObject.Find("BattleSystemController").GetComponent<BattleSystem>();

            if (mainScript.arePlayersSet)
            {
                if (isLocalPlayer)
                {
                    GameObject.Find("LocalPlayerIdentifier").GetComponent<LocalPlayerIdentifier>().InitializeExplicit(this.gameObject);

                    if (PlayerId == 2)
                        isInitialized = SetPlayer2CameraPosition(); // this function will return true if succeeded to change camera's position
                    else
                        isInitialized = true;
                }
                else //if it is not LocalPlayer
                    isInitialized = true; //There is nothing else to do
            }
        }
        catch (Exception ex)
        {
            Debug.Log("PlayerController: at Initialize() " + ex.Message);
        }
    }

    private bool SetPlayer2CameraPosition()
    {
        try
        {
            boardSet = GameObject.Find("TBSGBoard");
            board = GameObject.Find("GameBoard");

            if (boardSet.GetComponent<TileMapManager>().isInitialized)
            {
                Debug.Log("PlayerController: Set Camera Position for Player 2");

                GameObject mc = GameObject.Find("Main Camera");
                Vector3 mcPosition = mc.transform.position;
                Vector3 mcOriginalAngles = mc.transform.rotation.eulerAngles;


                MeshRenderer mr = board.GetComponent<MeshRenderer>();
                Vector3 mrCenter = mr.bounds.center;

                mc.transform.rotation = Quaternion.Euler(new Vector3(0f, 0f, 0f)); // Set all to 0f to move camera's position correctly
                mc.transform.position += new Vector3(2 * (mrCenter.x - mcPosition.x), 0, 2 * (mrCenter.z - mcPosition.z)); // Move camera to a "symmetrical point" with respect to the "center of the board"
                mc.transform.rotation = Quaternion.Euler(new Vector3(mcOriginalAngles.x, mcOriginalAngles.y + 180f, mcOriginalAngles.z));

                Debug.Log("PlayerController: End InitializeExplicit (For Player2)");
                return true;          
            }

            return false; // Will not reach this line if all succeeded
        }
        catch (Exception ex)
        {
            Debug.Log("PlayerController: at SetPlayer2CameraPosition() " + ex.Message);
            return false;
        }
    }

    [Client]
    public void SyncMaxSP(int _maxSP)
    {
        MaxSP = _maxSP;
        Debug.Log("MaxSP synced!");
    }
    [Client]
    public void SyncRemainingSP(int _remainingSP)
    {
        RemainingSP = _remainingSP;
        Debug.Log("RemainingSP synced!");
    }
    [Client]
    public void SyncSelectedAlliedUnitId(int _selectedAlliedUnitId)
    {
        SelectedAlliedUnitId = _selectedAlliedUnitId;
        Debug.Log("SelectedAlliedUnitId synced!");
    }
}
