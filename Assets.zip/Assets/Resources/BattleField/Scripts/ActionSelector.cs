﻿//using System;
//using System.Collections;
//using System.Collections.Generic;
//using UnityEngine;
//using UnityEngine.UI;

//public class ActionSelector : MonoBehaviour
//{

//    public GameObject SkillMenu;
//    public GameObject ItemMenu;
//    public GameObject USkillMenu;

//    public Sprite AttackIconActive;
//    public Sprite GuardIconActive;
//    public Sprite MoveIconActive;
//    public Sprite SkillIconActive;
//    public Sprite ItemIconActive;
//    public Sprite USkillIconActive;

//    public Sprite AttackIconDisabled;
//    public Sprite GuardIconDisabled;
//    public Sprite MoveIconDisabled;
//    public Sprite SkillIconDisabled;
//    public Sprite ItemIconDisabled;
//    public Sprite USkillIconDisabled;

//    private Image SelectedActionImage;
//    private Image SelectableActionLImage;
//    private Image SelectableActionRImage;

//    //private GameObject MoveUI;
//    //private GameObject AttackUI;

//    public eActionType CurrentActionSelected { get; private set; }

//    // Use this for initialization
//    void Awake()
//    {
//        Transform ActionSelector = this.transform.parent.Find("ActionSelector");

//        SelectedActionImage = ActionSelector.Find("SelectedAction").GetComponent<Image>();
//        SelectableActionLImage = ActionSelector.Find("SelectableActionL").GetComponent<Image>();
//        SelectableActionRImage = ActionSelector.Find("SelectableActionR").GetComponent<Image>();

//        //MoveUI = GameObject.Find("Action_Move").gameObject;

//        CurrentActionSelected = eActionType.MOVE;

//        UpdateUI();
//    }

//    public void ChangeSelection(bool _toLeft)
//    {
//        try
//        {
//            if (_toLeft)
//            {
//                switch (CurrentActionSelected)
//                {
//                    default: //case eActionType.MOVE
//                        CurrentActionSelected = eActionType.ATTACK;
//                        break;
//                    case eActionType.ATTACK:
//                        CurrentActionSelected = eActionType.GUARD;
//                        break;
//                    case eActionType.GUARD:
//                        CurrentActionSelected = eActionType.ITEM;
//                        break;
//                    case eActionType.ITEM:
//                        CurrentActionSelected = eActionType.USKILL;
//                        break;
//                    case eActionType.USKILL:
//                        CurrentActionSelected = eActionType.SKILL;
//                        break;
//                    case eActionType.SKILL:
//                        CurrentActionSelected = eActionType.MOVE;
//                        break;
//                }
//            }
//            else
//            {
//                switch (CurrentActionSelected)
//                {
//                    default: //case eActionType.MOVE
//                        CurrentActionSelected = eActionType.SKILL;
//                        break;
//                    case eActionType.ATTACK:
//                        CurrentActionSelected = eActionType.MOVE;
//                        break;
//                    case eActionType.GUARD:
//                        CurrentActionSelected = eActionType.ATTACK;
//                        break;
//                    case eActionType.ITEM:
//                        CurrentActionSelected = eActionType.GUARD;
//                        break;
//                    case eActionType.USKILL:
//                        CurrentActionSelected = eActionType.ITEM;
//                        break;
//                    case eActionType.SKILL:
//                        CurrentActionSelected = eActionType.USKILL;
//                        break;
//                }
//            }

//            UpdateUI();
//        }
//        catch (Exception ex)
//        {
//            Debug.Log("ActionSelector: at ChangeSelection() " + ex.Message);
//        }
//    }

//    private void UpdateUI()
//    {
//        try
//        {
//            SpriteState st = new SpriteState();

//            switch (CurrentActionSelected)
//            {
//                default: //case eActionType.MOVE
//                    {
//                        SelectedActionImage.sprite = MoveIconActive;
//                        st.disabledSprite = MoveIconDisabled;
//                        SelectableActionLImage.sprite = AttackIconActive;
//                        SelectableActionRImage.sprite = SkillIconActive;

//                        //DisableAll();
//                        //MoveUI.SetActive(true);
//                    }
//                    break;
//                case eActionType.ATTACK:
//                    {
//                        SelectedActionImage.sprite = AttackIconActive;
//                        st.disabledSprite = AttackIconDisabled;
//                        SelectableActionLImage.sprite = GuardIconDisabled;
//                        SelectableActionRImage.sprite = MoveIconActive;

//                        //DisableAll();
//                        //AttackUI.SetActive(true);
//                    }
//                    break;
//                case eActionType.GUARD:
//                    {
//                        SelectedActionImage.sprite = GuardIconDisabled;
//                        //st.disabledSprite = GuardIconDisabled;
//                        SelectableActionLImage.sprite = ItemIconDisabled;
//                        SelectableActionRImage.sprite = AttackIconActive;
//                    }
//                    break;
//                case eActionType.ITEM:
//                    {
//                        SelectedActionImage.sprite = ItemIconDisabled;
//                        //st.disabledSprite = MoveIconDisabled;
//                        SelectableActionLImage.sprite = USkillIconDisabled;
//                        SelectableActionRImage.sprite = GuardIconDisabled;
//                    }
//                    break;
//                case eActionType.USKILL:
//                    {
//                        SelectedActionImage.sprite = USkillIconDisabled;
//                        //st.disabledSprite = MoveIconDisabled;
//                        SelectableActionLImage.sprite = SkillIconActive;
//                        SelectableActionRImage.sprite = ItemIconDisabled;
//                    }
//                    break;
//                case eActionType.SKILL:
//                    {
//                        SelectedActionImage.sprite = SkillIconActive;
//                        //st.disabledSprite = MoveIconDisabled;
//                        SelectableActionLImage.sprite = MoveIconActive;
//                        SelectableActionRImage.sprite = USkillIconDisabled;
//                    }
//                    break;

//            }
//        }
//        catch (Exception ex)
//        {
//            Debug.Log("ActionSelector: at UpdateUI() " + ex.Message);
//        }
//    }

//    //private void DisableAll()
//    //{
//    //    MoveUI.SetActive(false);
//    //}
//}

//public enum eActionType
//{
//    ATTACK,
//    GUARD,
//    MOVE,
//    ITEM,
//    SKILL,
//    USKILL
//}
