﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ParticleDisposer : MonoBehaviour {

    private float startTime;

    public float LifeSpan;

	// Use this for initialization
	void Awake () {
        startTime = Time.realtimeSinceStartup;
	}
	
	// Update is called once per frame
	void Update () {
        if (Time.realtimeSinceStartup - startTime > LifeSpan)
            Destroy(this.gameObject);
	}
}
