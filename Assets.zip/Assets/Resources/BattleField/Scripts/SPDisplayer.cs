﻿using EEANGame.TBSG.V1_0.MainClassLib;
using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SPDisplayer : MonoBehaviour {

    public Material ActiveStoneMaterial;
    public Material InactiveStoneMaterial;

    private bool isInitialized;
    private BattleSystem mainScript;
    private LocalPlayerIdentifier LocalPlayerIdentifier;
    private int LocalPlayerId;

    private MeshRenderer[] spObjectsMR;

    private int latestRemainingSP;
    private int latestMaxSP;

    // Use this for initialization
    void Awake()
    {
        isInitialized = false;
    }

    // Update is called once per frame
    void Update()
    {
        if (!isInitialized)
            Initialize();

        if (isInitialized)
        {
            if (LocalPlayerIdentifier.PlayerController.MaxSP != latestMaxSP
                || LocalPlayerIdentifier.PlayerController.RemainingSP != latestRemainingSP)
            {
                latestMaxSP = LocalPlayerIdentifier.PlayerController.MaxSP;
                latestRemainingSP = LocalPlayerIdentifier.PlayerController.RemainingSP;

                UpdateSPGraphic();
            }
        }
    }

    private void Initialize()
    {
        try
        {
            if (mainScript == null)
                mainScript = GameObject.Find("BattleSystemController").GetComponent<BattleSystem>();

            if (mainScript.isInitialized)
            {
                if (LocalPlayerIdentifier == null)
                    LocalPlayerIdentifier = GameObject.Find("LocalPlayerIdentifier").GetComponent<LocalPlayerIdentifier>();

                if (LocalPlayerIdentifier.isInitialized)
                {
                    LocalPlayerId = LocalPlayerIdentifier.PlayerController.PlayerId;

                    latestMaxSP = LocalPlayerIdentifier.PlayerController.MaxSP;
                    latestRemainingSP = LocalPlayerIdentifier.PlayerController.RemainingSP;

                    spObjectsMR = new MeshRenderer[Rule.MAX_SP];
                    for(int i = 0; i < spObjectsMR.Length; i++)
                    {
                        spObjectsMR[i] = this.transform.Find("SkillStone" + LocalPlayerId.ToString() + "_" + (i + 1).ToString()).GetComponent<MeshRenderer>();
                    }

                    UpdateSPGraphic();

                    isInitialized = true;
                }
            }
        }
        catch (Exception ex)
        {
            Debug.Log("SPTextManager: at Initialize() " + ex.Message);
        }
    }

    private void UpdateSPGraphic()
    {
        for(int i = 0; i < latestRemainingSP; i++)
        {
            spObjectsMR[i].material = ActiveStoneMaterial;
        }

        for(int i = latestRemainingSP; i < spObjectsMR.Length; i++)
        {
            spObjectsMR[i].material = InactiveStoneMaterial;
        }

        //Implement more features
    }
}
