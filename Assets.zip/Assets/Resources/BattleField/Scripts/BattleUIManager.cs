﻿using EEANGame.TBSG.V1_0.CommonEnums;
using EEANGame.TBSG.V1_0.MainClassLib;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Reflection;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.EventSystems;
using UnityEngine.Networking;
using UnityEngine.UI;

#if Unity_Editor
using UnityEditor.Events;
#endif

public class BattleUIManager : NetworkBehaviour {

    public GameObject SelectionMarkerPrefab;
    public GameObject ButtonPrefab;

    public bool isInitialized { get; private set; }
    private bool isEnd;

    private BattleSystem mainScript;
    private ActionSelectionManager ActionSelectionManagerScript;
    private GameObject unitRotation;
    private GameObject action_move;
    private GameObject action_attack;
    private GameObject action_skill;
    private GameObject endTurn;
    private GameObject concede;
    private GameObject matchEndPanel;
    private GameObject settingsPanel;
    private GameObject rulesPanel;


    private LocalPlayerIdentifier LocalPlayerIdentifier;
    //private TileMaskManager TileMaskScript;

    private List<UnitController> UnitControllers;


    private GameObject UnitSelectionMarker;

    public bool showHPBar;
    public int SelectedSkillIndex;
    // Use this for initialization
    void Awake()
    {
        isInitialized = false;
        isEnd = false;
        LocalPlayerIdentifier = GameObject.Find("LocalPlayerIdentifier").GetComponent<LocalPlayerIdentifier>();
        //TileMaskScript = GameObject.Find("TBSGBoard").GetComponent<TileMaskManager>();
        UnitControllers = new List<UnitController>();
        UnitSelectionMarker = GameObject.Find("SelectionMarker");
        matchEndPanel = GameObject.Find("MatchEndPanel");
        settingsPanel = GameObject.Find("SettingsPanel");
        rulesPanel = GameObject.Find("RulesAndInfoPanel");
        matchEndPanel.SetActive(false);
        settingsPanel.SetActive(false);
        rulesPanel.SetActive(true);
    }

    void Update()
    {
        if (!isInitialized)
            Initialize();

        if (isInitialized && LocalPlayerIdentifier.isInitialized)
        {
            if(!mainScript.isMatchEnd)
            {
                if (LocalPlayerIdentifier.PlayerController.isMyTurn)
                {

                    if (!unitRotation.activeSelf)
                        unitRotation.SetActive(true);

                    if (!endTurn.activeSelf)
                        endTurn.SetActive(true);

                    if (!concede.activeSelf)
                        concede.SetActive(true);

                    switch (ActionSelectionManagerScript.CurrentActionSelected)
                    {
                        default: // case eActionType.MOVE:
                            {
                                int playerId = LocalPlayerIdentifier.PlayerController.PlayerId;
                                int unitId = LocalPlayerIdentifier.PlayerController.SelectedAlliedUnitId;
                                if (!action_move.activeSelf)
                                {
                                    DeactivateAllActionUI();

                                    action_move.SetActive(true);
                                }
                                RequestMovableArea(playerId, unitId);
                            }
                            break;
                        case eActionType.ATTACK:
                            {
                                int playerId = LocalPlayerIdentifier.PlayerController.PlayerId;
                                int unitId = LocalPlayerIdentifier.PlayerController.SelectedAlliedUnitId;
                                if (!action_attack.activeSelf)
                                {
                                    DeactivateAllActionUI();

                                    action_attack.SetActive(true);
                                }
                                RequestAttackTargetArea(playerId, unitId);
                            }
                            break;
                        case eActionType.GUARD:
                            DeactivateAllActionUI();
                            break;
                        case eActionType.ITEM:
                            DeactivateAllActionUI();
                            break;
                        case eActionType.USKILL:
                            DeactivateAllActionUI();
                            break;
                        case eActionType.SKILL:
                            {
                                if (!action_skill.activeSelf)
                                {
                                    DeactivateAllActionUI();

                                    action_skill.SetActive(true);
                                    UpdateSkillActionUI();
                                }
                                else
                                    DisplaySkillTargetArea(SelectedSkillIndex);
                            }
                            break;
                    }
                }
                else
                {
                    DeactivateAll();
                }
            }
            else
            {
                if(!isEnd)
                {
                    DeactivateAll();
                    matchEndPanel.SetActive(true);
                    Text matchEndText = matchEndPanel.transform.Find("Image").Find("Text").GetComponent<Text>();

                    string winnerText = "You are the winner!!";
                    string loserText = "You have lost...";

                    if (mainScript.isPlayer1Winner)
                        matchEndText.text = (LocalPlayerIdentifier.PlayerController.PlayerId == 1) ? winnerText : loserText;
                    else
                        matchEndText.text = (LocalPlayerIdentifier.PlayerController.PlayerId == 1) ? loserText : winnerText;

                    isEnd = true;
                }
            }
        }
    }

    private void Initialize()
    {
        try
        {
            mainScript = GameObject.Find("BattleSystemController").GetComponent<BattleSystem>();

            if (mainScript.isInitialized)
            {
                Debug.Log("BattleUIManager: Start Initialize.");

                NetworkManagerHUD nmHUD = GameObject.Find("LobbyManager").GetComponent<NetworkManagerHUD>();
                if (nmHUD.isActiveAndEnabled)
                    nmHUD.enabled = false;

                GameObject ActionSelectionManager = GameObject.Find("ActionSelector");
                if(ActionSelectionManager == null)
                {
                    Debug.Log("BattleUIManager: ActionSelector object not found");
                    return;
                }
                ActionSelectionManagerScript = ActionSelectionManager.GetComponent<ActionSelectionManager>();
                if (ActionSelectionManagerScript == null)
                {
                    Debug.Log("BattleUIManager: Action Selector Script not found");
                    return;
                }

                unitRotation = GameObject.Find("UnitRotation");
                if (unitRotation == null)
                {
                    Debug.Log("BattleUIManager: Unit Rotation not found");
                    return;
                }

                action_move = GameObject.Find("Action_Move");
                if (action_move == null)
                {
                    Debug.Log("BattleUIManager: Action Move not found");
                    return;
                }

                action_attack = GameObject.Find("Action_Attack");
                if (action_attack == null)
                {
                    Debug.Log("BattleUIManager: Action Attack not found");
                    return;
                }

                action_skill = GameObject.Find("Action_Skill");
                if (action_skill == null)
                {
                    Debug.Log("BattleUIManager: Action Skill not found");
                    return;
                }

                endTurn = GameObject.Find("EndTurn");
                if (endTurn == null)
                {
                    Debug.Log("BattleUIManager: End Turn not found");
                    return;
                }

                concede = GameObject.Find("Concede");
                if (concede == null)
                {
                    Debug.Log("BattleUIManager: Concede not found");
                    return;
                }

                //UpdateSelectionMarker();

                if (!LocalPlayerIdentifier.isInitialized)
                    return;
                GameObject[] Units = GameObject.FindGameObjectsWithTag("Unit");
                UnitControllers.Clear(); // Reset List before adding new values
                foreach (GameObject unit in Units)
                {
                    UnitController uc = unit.GetComponent<UnitController>();

                    if (!uc.isInitialized)
                        return;

                    UnitControllers.Add(uc);
                }

                DeactivateAllActionUI();
                action_move.SetActive(true);

                isInitialized = true;
                Debug.Log("BattleUIManager: End Initialize.");
            }
        }
        catch (Exception ex)
        {
            Debug.Log("BattleUIManager: " + ex.Message);
        }
    }

    //private void UpdateSelectionMarker()
    //{
    //    try
    //    {
    //        GameObject[] units = GameObject.FindGameObjectsWithTag("Unit");

    //        foreach (GameObject unit in units)
    //        {
    //            UnitController uc = unit.GetComponent<UnitController>();

    //            if (uc.isInitialized)
    //            {
    //                if (uc.Id_OwnerPlayer == LocalPlayerIdentifier.PlayerController.PlayerId
    //                    && uc.Unit_PublicId == LocalPlayerIdentifier.PlayerController.SelectedAlliedUnitId
    //                    && UnitSelectionMarker.transform.parent != unit)
    //                {
    //                    UnitSelectionMarker.transform.SetParent(unit.transform);
    //                    UnitSelectionMarker.transform.localPosition = new Vector3(0.25f, 0.8f, 0);
    //                }
    //            }
    //        }
    //    }
    //    catch (Exception ex)
    //    {
    //        Debug.Log("BattleUIManager: " + ex.Message);
    //    }
    //}

    private void UpdateSkillActionUI()
    {
        Transform skillPanel = action_skill.transform.Find("Panel");

        //Remove and Destroy old buttons
        int NumOfButtons = skillPanel.childCount;
        for(int i = NumOfButtons - 1; i >= 0; i--)
        {
            Transform oldButton = skillPanel.GetChild(i);
            oldButton.SetParent(null); // Remove buttons
            Destroy(oldButton.gameObject);
        }

        UnitController uc = UnitControllers.Find(x => x.Unit_PrivateId == LocalPlayerIdentifier.PlayerController.SelectedAlliedUnitId);

        for (int i = 0; i < uc.SyncList_SkillName.Count; i++)
        {
            GameObject button = Instantiate(ButtonPrefab, skillPanel);
            string skillName = uc.SyncList_SkillName[i];
            button.transform.Find("Text").GetComponent<Text>().text = skillName;
            button.gameObject.name = skillName;
            button.transform.Find("RequiredSP").Find("Amount").GetComponent<Text>().text = RequestSkillCost(LocalPlayerIdentifier.PlayerController.PlayerId, uc.Unit_PrivateId, skillName).ToString();

            int indexCopy = i; // Otherwise all buttons will have the latest i value.
            button.GetComponent<Button>().onClick.AddListener(() => UpdateSkillSelection(skillPanel, indexCopy));
        }

        UpdateSkillSelection(skillPanel, 0);
    }

    private void UpdateSkillSelection(Transform _skillPanel, int _skillIndex)
    {

        Debug.Log("BattleUIManager: at UpdateSkillSelection -> CurrentSkillIndex: " + SelectedSkillIndex.ToString() + " TargetSkillIndex:" + _skillIndex.ToString());

        //Set current selected button's color
        if(SelectedSkillIndex >= 0 && _skillPanel.childCount > SelectedSkillIndex)
        {
            _skillPanel.GetChild(SelectedSkillIndex).GetComponent<Image>().color = Color.white;
        }

        //Change selected button, change its color, 
        if(_skillPanel.childCount > _skillIndex)
        {
            SelectedSkillIndex = _skillIndex;
            Transform button = _skillPanel.GetChild(SelectedSkillIndex);
            button.GetComponent<Image>().color = new Color(0, 0, 1, 0.3f);

            DisplaySkillTargetArea(SelectedSkillIndex);
        }
    }

    private void DeactivateAllActionUI()
    {
        if(action_move.activeSelf)
            action_move.SetActive(false);

        if(action_attack.activeSelf)
            action_attack.SetActive(false);

        if (action_skill.activeSelf)
            action_skill.SetActive(false);
    }

    private void DeactivateAll()
    {
        if(unitRotation.activeSelf)
            unitRotation.SetActive(false);

        if (endTurn.activeSelf)
            endTurn.SetActive(false);

        if (concede.activeSelf)
            concede.SetActive(false);

        DeactivateAllActionUI();
    }

    #region To be accessed from external components (e.g. Button)
    public void Attack()
    {
        LocalPlayerIdentifier.PlayerCommands.Cmd_Attack();
    }

    public void ExecuteSkill()
    {
        Transform skillPanel = action_skill.transform.Find("Panel");

        if(SelectedSkillIndex >= 0 && skillPanel.childCount > SelectedSkillIndex)
        {
            string skillName = skillPanel.GetChild(SelectedSkillIndex).name;
            Debug.Log("Button clicked: Executing Skill(" + skillName + ").");
            LocalPlayerIdentifier.PlayerCommands.Cmd_Skill(skillName);
        }
    }

    public void RotateUnit()
    {
        LocalPlayerIdentifier.PlayerCommands.Cmd_RotateUnit();

        int playerId = LocalPlayerIdentifier.PlayerController.PlayerId;
        int unitId = LocalPlayerIdentifier.PlayerController.SelectedAlliedUnitId;

        switch(ActionSelectionManagerScript.CurrentActionSelected)
        {
            case eActionType.MOVE:
                RequestMovableArea(playerId, unitId);
                break;
            case eActionType.ATTACK:
                RequestAttackTargetArea(playerId, unitId);
                break;
            case eActionType.SKILL:
                DisplaySkillTargetArea(SelectedSkillIndex);
                break;
            default:
                break;
        }
    }
    public void MoveUnitForward()
    {
        LocalPlayerIdentifier.PlayerCommands.Cmd_MoveUnit(eDirection.FRONT);

        int playerId = LocalPlayerIdentifier.PlayerController.PlayerId;
        int unitId = LocalPlayerIdentifier.PlayerController.SelectedAlliedUnitId;
        RequestMovableArea(playerId, unitId);
    }
    public void MoveUnitLeft()
    {
        LocalPlayerIdentifier.PlayerCommands.Cmd_MoveUnit(eDirection.LEFT);

        int playerId = LocalPlayerIdentifier.PlayerController.PlayerId;
        int unitId = LocalPlayerIdentifier.PlayerController.SelectedAlliedUnitId;
        RequestMovableArea(playerId, unitId);
    }
    public void MoveUnitBackward()
    {
        LocalPlayerIdentifier.PlayerCommands.Cmd_MoveUnit(eDirection.BACK);

        int playerId = LocalPlayerIdentifier.PlayerController.PlayerId;
        int unitId = LocalPlayerIdentifier.PlayerController.SelectedAlliedUnitId;
        RequestMovableArea(playerId, unitId);
    }
    public void MoveUnitRight()
    {
        LocalPlayerIdentifier.PlayerCommands.Cmd_MoveUnit(eDirection.RIGHT);

        int playerId = LocalPlayerIdentifier.PlayerController.PlayerId;
        int unitId = LocalPlayerIdentifier.PlayerController.SelectedAlliedUnitId;
        RequestMovableArea(playerId, unitId);
    }
    public void ChangeUnit()
    {
        LocalPlayerIdentifier.PlayerCommands.Cmd_ChangeUnit(LocalPlayerIdentifier.PlayerController.PlayerId, -1);

        if(action_skill.activeSelf)
            UpdateSkillActionUI();
    }

    public void ChangeUnit(int _playerId, int _unitId)
    {
        Debug.Log("Calling ChangeUnit()");
        LocalPlayerIdentifier.PlayerCommands.Cmd_ChangeUnit(_playerId, _unitId);

        OnSelectedUnitChanged();
    }

    private void OnSelectedUnitChanged()
    {
            //Get the updated id
            int playerId = LocalPlayerIdentifier.PlayerController.PlayerId;
            int unitId = LocalPlayerIdentifier.PlayerController.SelectedAlliedUnitId;

            switch (ActionSelectionManagerScript.CurrentActionSelected)
            {
                case eActionType.MOVE:
                    RequestMovableArea(playerId, unitId);
                    break;
                case eActionType.ATTACK:
                    RequestAttackTargetArea(playerId, unitId);
                    break;
                case eActionType.SKILL:
                    {
                        if (action_skill.activeSelf)
                            UpdateSkillActionUI();
                    }
                    break;
                default:
                    break;
            }
    }

    public void UnselectUnits(int _playerId)
    {
        LocalPlayerIdentifier.PlayerCommands.Cmd_UnselectUnits(_playerId);
    }

    public void RequestMovableArea(int _playerId, int _unitId)
    {
        LocalPlayerIdentifier.PlayerCommands.Cmd_RequestMovableArea(_playerId, _unitId);
    }

    public void RequestAttackTargetArea(int _playerId, int _unitId)
    {
        LocalPlayerIdentifier.PlayerCommands.Cmd_RequestAttackTargetArea(_playerId, _unitId);
    }

    public void DisplaySkillTargetArea(int _skillIndex)
    {
        int playerId = LocalPlayerIdentifier.PlayerController.PlayerId;
        int unitId = LocalPlayerIdentifier.PlayerController.SelectedAlliedUnitId;

        LocalPlayerIdentifier.PlayerCommands.Cmd_DisplaySkillTargetArea(playerId, unitId, _skillIndex);
    }

    private int SkillCostCatcher;
    public int RequestSkillCost(int _playerId, int _unitId, string _skillName)
    {
        LocalPlayerIdentifier.PlayerCommands.Cmd_RequestSkillCost(_playerId, _unitId, _skillName);

        return SkillCostCatcher;
    }
    [ClientRpc]
    public void Rpc_UpdateSkillCostCatcher(int _sp)
    {
        SkillCostCatcher = _sp;
    }

    public void InvertHPBarOnStatus()
    {
        showHPBar = !showHPBar;
    }
    
    public void EndTurn()
    {
        LocalPlayerIdentifier.PlayerCommands.Cmd_EndTurn();
    }

    public void Concede()
    {
        LocalPlayerIdentifier.PlayerCommands.Cmd_Concede();
    }

    public void ReturnToLobby()
    {
        NetworkLobbyManager NLM = GameObject.Find("LobbyManager").GetComponent<NetworkLobbyManager>();
        NLM.ServerReturnToLobby();
    }

    public void OpenSettingsPanel()
    {
        settingsPanel.SetActive(true);
    }

    public void CloseSettingsPanel()
    {
        settingsPanel.SetActive(false);
    }

    public void OpenRulesPanel()
    {
        rulesPanel.SetActive(true);
    }

    public void CloseRulesPanel()
    {
        rulesPanel.SetActive(false);
    }
    #endregion
}
