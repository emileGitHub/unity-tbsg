﻿using EEANGame.TBSG.V1_0.MainClassLib;
using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Networking;

public class AnimationController : NetworkBehaviour {

    private ParticleSet ParticleSet;
    public int TimesToFlicker;
    public float UnitHitFlickeringInterval;
    public float AnimationInterval1;

    private LocalPlayerIdentifier LocalPlayerIdentifier;

    //Use this for initialization
    void Awake()
    {
        try
        {
            ParticleSet = GameObject.Find("ParticleSet").GetComponent<ParticleSet>();
            LocalPlayerIdentifier = GameObject.Find("LocalPlayerIdentifier").GetComponent<LocalPlayerIdentifier>();

            //Required for Update() to avoid not being called
            if (!this.gameObject.activeSelf)
                this.gameObject.SetActive(true);
        }
        catch (Exception ex)
        {
            Debug.Log("UnitController: at Awake()" + ex.Message);
        }
    }

    [Server]
    public void SkillAnimation(int _skillUserUnitId, List<EFFECT_RESULT> _effectResults)
    {
        foreach (EFFECT_RESULT er in _effectResults)
        {
            Rpc_EffectAnimation(_skillUserUnitId, er);
        }
    }

    [ClientRpc]
    public void Rpc_EffectAnimation(int _skillUserUnitId, EFFECT_RESULT _effectResult)
    {
        try
        {
            List<GameObject> Units = new List<GameObject>(GameObject.FindGameObjectsWithTag("Unit"));
            GameObject TargetUnit = Units.Find(x => x.GetComponent<UnitController>().Unit_PublicId == _effectResult.targetUnitIndex);
            SpriteRenderer sr = TargetUnit.GetComponent<SpriteRenderer>();

            Vector3 effectPosition;
            if (LocalPlayerIdentifier.PlayerController.PlayerId == 1)
                effectPosition = TargetUnit.transform.position + sr.bounds.size  / 2 + new Vector3(0, 0.001f, 0);
            else // if (LocalPlayerIdentifier.PlayerController.PlayerId == 2)
                effectPosition = TargetUnit.transform.position + (sr.bounds.size / 2) - new Vector3(sr.bounds.size.x, 0, 0) + new Vector3(0, 0.001f, 0);

            //Execute ParticleSystem-based animation
            StartCoroutine(SkillEffectAnimation(_effectResult.animationId, effectPosition));

            if(_effectResult.didHit)
            {
                //Execute UnitSprite-based animation
                StartCoroutine("UnitHitAnimation", sr);
            }

            //Execute Text-based animation
            TargetUnit.transform.Find("HPBar").GetComponent<HPBarController>().HPModificationAnimation(_effectResult.damageAmout, _effectResult.isCritical, _effectResult.didHit);
        }
        catch (Exception ex)
        {
            Debug.Log("UnitController: at Rpc_EffectAnimation" + ex.Message);
        }
    }

    public IEnumerator UnitHitAnimation(SpriteRenderer _sr)
    {
        for (int i = 0; i < TimesToFlicker; i++)
        {
            _sr.color = new Color(1f, 1f, 1f, 0f);

            yield return new WaitForSecondsRealtime(UnitHitFlickeringInterval);

            _sr.color = new Color(1f, 1f, 1f, 1f);

            yield return new WaitForSecondsRealtime(UnitHitFlickeringInterval);
        }
    }

    public IEnumerator SkillEffectAnimation(int _animationId, Vector3 _position)
    {
        GameObject particle = Instantiate(ParticleSet.Prefabs[_animationId], GameObject.Find("RootObject").transform);
        float angle = 0;
        particle.transform.Rotate(new Vector3(0, angle, 0));
        particle.transform.localScale = new Vector3(15f, 15f, 10f);
        particle.transform.localPosition = _position;

        yield return new WaitForSecondsRealtime(AnimationInterval1);
    }
}
