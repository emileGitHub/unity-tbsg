﻿using EEANGame.ImageConverter.ForUnity;
using EEANGame.TBSG.V1_0.CommonEnums;
using EEANGame.TBSG.V1_0.MainClassLib;
using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Networking;
using UnityEngine.UI;

[RequireComponent(typeof(MeshFilter))]
[RequireComponent(typeof(MeshRenderer))]
[RequireComponent(typeof(MeshCollider))]
public class TileMaskManager : NetworkBehaviour
{
    public const int sizeX = Rule.SIZE_OF_A_SIDE_OF_BOARD;
    public const int sizeZ = Rule.SIZE_OF_A_SIDE_OF_BOARD;

    private BattleSystem mainScript;
    private LocalPlayerIdentifier LocalPlayerIdentifier;
    private BattleUIManager uiManagerScript;
    private ActionSelectionManager ActionSelectionManagerScript;

    public Material Default_Material;
    public Material TargetingTile_Material_Movement;
    public Material TargetingTile_Material_Attack;
    public Material TargetingTile_Material_Skill;


    //private int Id_lastUnitSelected;

    public bool isInitialized { get; private set; }

    // Use this for initialization
    void Awake()
    {
        try
        {
            isInitialized = false;

            //Id_lastUnitSelected = -1;
        }
        catch (Exception ex)
        {
            Debug.Log("TileMap: at Awake() " + ex.Message);
        }
    }


    #region Client Side Code
    void Update()
    {
        if (isClient && !isInitialized)
            Initialize();

        if (isInitialized)
        {

        }
    }

    public void Initialize()
    {
        try
        {
            if (mainScript == null)
                mainScript = GameObject.Find("BattleSystemController").GetComponent<BattleSystem>();

            if (mainScript.isInitialized)
            {
                Debug.Log("TileMaskManager: Start Initialize.");

                if (LocalPlayerIdentifier == null)
                    LocalPlayerIdentifier = GameObject.Find("LocalPlayerIdentifier").GetComponent<LocalPlayerIdentifier>();
                if (LocalPlayerIdentifier == null || !LocalPlayerIdentifier.isInitialized)
                    return;

                if (uiManagerScript == null)
                    uiManagerScript = GameObject.Find("BattleUIManager").GetComponent<BattleUIManager>();
                if (uiManagerScript == null || !uiManagerScript.isInitialized)
                    return;

                //if (uiManagerScript.isInitialized) -> ActionSelectionManager has been Initialized
                ActionSelectionManagerScript = GameObject.Find("ActionSelector").GetComponent<ActionSelectionManager>();

                if (!ResetMaterial())
                    return;

                isInitialized = true;
                Debug.Log("TileMaskManager: End Initialize.");
            }
        }
        catch (Exception ex)
        {
            Debug.Log("TileMap: at Initialize() " + ex.Message);
        }
    }

    [ClientRpc]
    public void Rpc_DisplayTargetArea(string _coordsString)
    {
        ResetMaterial();

        UpdateTargetingMaterial(_2DCoord.StringToCoords(_coordsString));
    }
    #endregion

    #region Common Code

    public bool ResetMaterial()
    {
        try
        {
            for (int z = 1; z <= sizeZ; z++)
            {
                for (int x = 1; x <= sizeX; x++)
                {
                    int tileNum = sizeZ * (z - 1) + (x - 1);

                    string tileObjectName = "Tile" + tileNum.ToString();

                    MeshRenderer TileMaskMeshRenderer = this.transform.Find(tileObjectName).Find("TileMask").GetComponent<MeshRenderer>();

                    TileMaskMeshRenderer.material = Default_Material;
                }
            }

            return true;
        }
        catch (Exception ex)
        {
            Debug.Log("TileMap: at ResetMaterial(). " + ex.Message);
            return false;
        }
    }

    public bool UpdateTargetingMaterial(List<_2DCoord> _area)
    {
        try
        {
            foreach(_2DCoord coord in _area)
            {
                if(coord.X >= 0 && coord.Y < sizeX
                    && coord.Y >= 0 && coord.Y < sizeZ)
                {
                    int tileNum = sizeZ * coord.Y + coord.X;
                    string tileObjectName = "Tile" + tileNum.ToString();

                    MeshRenderer TileMaskMeshRenderer = this.transform.Find(tileObjectName).Find("TileMask").GetComponent<MeshRenderer>();

                    switch(ActionSelectionManagerScript.CurrentActionSelected)
                    {
                        case eActionType.MOVE:
                            TileMaskMeshRenderer.material = TargetingTile_Material_Movement;
                            break;
                        case eActionType.ATTACK:
                            TileMaskMeshRenderer.material = TargetingTile_Material_Attack;
                            break;
                        case eActionType.SKILL:
                            TileMaskMeshRenderer.material = TargetingTile_Material_Skill;
                            break;
                        default:
                            break;
                    }

                }
            }

            return true;
        }
        catch (Exception ex)
        {
            Debug.Log("TileMap: at UpdateTargetingMaterial(). " + ex.Message);
            return false;
        }
    }
    #endregion
}

//public struct AREAS2D
//{
//    public COORD2D[] Coords;
//}

public class SyncListCoord2D : SyncListStruct<COORD2D>{}

public struct COORD2D
{
    public int X;
    public int Y;
}

