﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[RequireComponent(typeof(UnitController))]
public class UnitClickManager : MonoBehaviour {

    private InfoPanelManager InfoPanelManager_Central;
    private InfoPanelManager_Unit InfoPanelManager_Unit;
    private UnitController UnitController;
    private BattleUIManager uiManagerScript;

    private float lastClickTime;

	// Use this for initialization
	void Start () {
        lastClickTime = 0;
        InfoPanelManager_Central = GameObject.Find("InfoPanelManager").GetComponent<InfoPanelManager>();
        InfoPanelManager_Unit = GameObject.Find("InfoPanelManager").GetComponent<InfoPanelManager_Unit>();
        UnitController = this.GetComponent<UnitController>();
        uiManagerScript = GameObject.Find("BattleUIManager").GetComponent<BattleUIManager>();
    }
	
	// Update is called once per frame
	void Update () {

    }


    private void OnMouseDown()
    {
        //Vector2 pos = new Vector2(Input.mousePosition.x, Input.mousePosition.y);
        //RaycastHit2D hitInfo = Physics2D.Raycast(Camera.main.ScreenToWorldPoint(pos), Vector2.zero);
        //// RaycastHit2D can be either true or null, but has an implicit conversion to bool, so we can use it like this
        //if (hitInfo)
        //{

        //}

        if(InfoPanelManager_Central.InfoPanels.Count == 0)
        {
            if (Time.timeSinceLevelLoad - lastClickTime < 0.5f) // it is double click
            {
                //Code for double click event
                Debug.Log(this.transform.gameObject.name + " DoubleClicked");
                InfoPanelManager_Unit.InstantiateInfoPanel(UnitController);
            }
            else // it is single click
            {
                //Code for single click event
                Debug.Log(this.transform.gameObject.name + " Clicked");

                if (this.transform.parent.gameObject == UnitController.LocalPlayerIdentifier.LocalPlayer)
                {
                    if (UnitController.LocalPlayerIdentifier.PlayerController.SelectedAlliedUnitId != UnitController.Unit_PrivateId)
                        uiManagerScript.ChangeUnit(UnitController.LocalPlayerIdentifier.PlayerController.PlayerId, UnitController.Unit_PrivateId);
                    else
                        uiManagerScript.UnselectUnits(UnitController.LocalPlayerIdentifier.PlayerController.PlayerId);
                }
            }

            lastClickTime = Time.timeSinceLevelLoad;
        }
    }
}
