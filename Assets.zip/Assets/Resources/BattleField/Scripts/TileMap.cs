﻿using EEANGame.ImageConverter.ForUnity;
using EEANGame.TBSG.V1_0.CommonEnums;
using EEANGame.TBSG.V1_0.MainClassLib;
using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Networking;
using UnityEngine.UI;

[RequireComponent(typeof(MeshFilter))]
[RequireComponent(typeof(MeshRenderer))]
[RequireComponent(typeof(MeshCollider))]
public class TileMap : NetworkBehaviour
{
    public Texture2D NormalTile;
    public Texture2D BlueTile;
    public Texture2D RedTile;
    public Texture2D GreenTile;
    public Texture2D OcherTile;
    public Texture2D BlackTile;
    public Texture2D WhiteTile;
    public Texture2D HealTile;

    public const int sizeX = Rule.SIZE_OF_A_SIDE_OF_BOARD;
    public const int sizeZ = Rule.SIZE_OF_A_SIDE_OF_BOARD;
    public const float tileSize = 1.0f;

    private BattleSystem mainScript;

    private Texture2D texture;

    public bool isInitialized { get; private set; }

    private Text LoadingStatus;
    
    [SerializeField]
    public SyncListInt SyncList_TileIdArray = new SyncListInt();

    // Use this for initialization
    void Awake()
    {
        try
        {
            isInitialized = false;
            LoadingStatus = GameObject.Find("LoadingStatus").GetComponent<Text>();

            //Required for Update() to avoid not being called
            if (!this.isActiveAndEnabled)
                this.enabled = true;
        }
        catch (Exception ex)
        {
            Debug.Log("TileMap: at Awake() " + ex.Message);
        }
    }


    #region Client Side Code
    void Update()
    {
        if (isClient && !isInitialized)
            Initialize();
    }

    public void Initialize()
    {
        try
        {
            if (mainScript == null)
                mainScript = GameObject.Find("BattleSystemController").GetComponent<BattleSystem>();

            if (mainScript.isInitialized)
            {
                Debug.Log("TileMap (Script): Start Initialize.");
                LoadingStatus.text = "Initializing Board TileMap";

                if (!BuildMesh())
                    return;

                isInitialized = true;
                Debug.Log("TileMap (Script): End Initialize.");
            }
        }
        catch(Exception ex)
        {
            Debug.Log("TileMap: at Initialize() " + ex.Message);
        }
    }
    #endregion

    #region Server Side Code
    [Server]
    public bool InitializeExplicit()
    {
        try
        {
            mainScript = GameObject.Find("BattleSystemController").GetComponent<BattleSystem>();

            if (!mainScript.isInitialized)
            {
                Debug.Log("TileMap: Start InitializeExplicit.");
                LoadingStatus.text = "Initializing Board TileMap On Server";

                if (!InitializeTileIdArray())
                    return false;

                BuildMesh();

                isInitialized = true;
                Debug.Log("TileMap: End InitializeExplicit.");
                return true;
            }

            return false;
        }
        catch (Exception ex)
        {
            Debug.Log("TileMap: at InitializeExplicit() " + ex.Message);
            return false;
        }
    }

    [Server]
    public bool InitializeTileIdArray()
    {
        try
        {
            SyncList_TileIdArray.Clear();

            for(int z = 1; z <= sizeZ; z++)
            {
                for(int x = 1; x <= sizeX; x++)
                {
                    int tileId = Convert.ToInt32(mainScript.FieldInstance.Board.Sockets[x - 1, z - 1].Tile);


                    //Not Syncing Correctly Some times
                    Debug.Log("TileMap: at InitializeTileIdList(). Tile[" + (x - 1).ToString() + "][" + (z - 1).ToString() + "]");
                    SyncList_TileIdArray.Add(tileId); //Set ids on host
                    Debug.Log("TileMap: at InitializeTileIdList(). -> TileId(" + tileId.ToString() + " has been added to SyncListInt on host.)");
                    Rpc_AddTileId(tileId); //Sync all clients
                }
            }

            return true;
        }
        catch (Exception ex)
        {
            Debug.Log("TileMap: at InitializeTileIdList(). " + ex.Message);
            return false;
        }
    }

    [ClientRpc]
    public void Rpc_AddTileId(int _id)
    {
        try
        {
            SyncList_TileIdArray.Add(_id);
            Debug.Log("TileMap: at Rpc_AddTileId(). -> TileId(" + _id.ToString() + " has been added to SyncListInt on client.)");
        }
        catch (Exception ex)
        {
            Debug.Log("TileMap: at Rpc_AddTileId(). " + ex.Message);
        }
    }

    #endregion

    #region Common Code
    public bool BuildTexture()
    {
        try
        {
            Debug.Log("TileMap: Start Building Texture.");

            Debug.Log("TileMap: at BuildTexture() SyncList_TileIdArray.Count = " + SyncList_TileIdArray.Count.ToString());
            if (SyncList_TileIdArray.Count <= 0)
                return false;

            int textureWidth = sizeX * NormalTile.width;
            int textureHeight = sizeZ * NormalTile.height;
            texture = new Texture2D(textureWidth, textureHeight);

            for (int z = 1; z <= sizeZ; z++)
            {
                for (int x = 1; x <= sizeX; x++)
                {
                    Color[] c;

                    eTileType tileType = eTileType.NORMAL;
                    foreach(eTileType e in Enum.GetValues(typeof(eTileType)))
                    {
                        if (Convert.ToInt32(e) == SyncList_TileIdArray[sizeZ * (z - 1) + (x - 1)])
                        {
                            tileType = e;
                            break;
                        }
                    }

                    switch (tileType)
                    {
                        default: //case eTileType.NORMAL
                            c = NormalTile.GetPixels();
                            break;
                        case eTileType.BLUE:
                            c = BlueTile.GetPixels();
                            break;
                        case eTileType.RED:
                            c = RedTile.GetPixels();
                            break;
                        case eTileType.GREEN:
                            c = GreenTile.GetPixels();
                            break;
                        case eTileType.OCHER:
                            c = OcherTile.GetPixels();
                            break;
                        case eTileType.PURPLE:
                            c = BlackTile.GetPixels();
                            break;
                        case eTileType.YELLOW:
                            c = WhiteTile.GetPixels();
                            break;
                        case eTileType.HEAL:
                            c = HealTile.GetPixels();
                            break;
                    }

                    texture.SetPixels((x - 1) * NormalTile.width, (z - 1) * NormalTile.height, NormalTile.width, NormalTile.height, c);
                }
            }

            texture.filterMode = FilterMode.Point;
            texture.Apply();

            MeshRenderer mr = GetComponent<MeshRenderer>();
            mr.material.mainTexture = texture;
            Debug.Log("TileMap: End Building Texture.");
            return true;
        }
        catch (Exception ex)
        {
            Debug.Log("TileMap: at BuildTexture() " + ex.Message);
            return false;
        }
    }

    public bool BuildMesh()
    {
        try
        {
            Debug.Log("TileMap: Start Building Mesh.");

            int numTiles = sizeX * sizeZ;
            int numTris = numTiles * 2;

            int vSizeX = sizeX + 1;
            int vSizeZ = sizeZ + 1;
            int numVerts = vSizeX * vSizeZ;

            //Generate the mesh data
            Vector3[] vertices = new Vector3[numVerts];
            Vector3[] normals = new Vector3[numVerts];
            Vector2[] uv = new Vector2[numVerts];

            int[] triangles = new int[numTris * 3];

            for (int z = 1; z <= vSizeZ; z++)
            {
                for (int x = 1; x <= vSizeX; x++)
                {
                    vertices[(z - 1) * vSizeX + (x - 1)] = new Vector3((x - 1) * tileSize, 0, (z - 1) * tileSize);
                    normals[(z - 1) * vSizeX + (x - 1)] = Vector3.up;
                    uv[(z - 1) * vSizeX + (x - 1)] = new Vector2(vertices[(z - 1) * vSizeX + (x - 1)].x / sizeX, vertices[(z - 1) * vSizeX + (x - 1)].z / sizeZ);
                }
            }

            for (int z = 1; z <= sizeZ; z++)
            {
                for (int x = 1; x <= sizeX; x++)
                {
                    int squareIndex = (z - 1) * sizeX + (x - 1);
                    int triIndex = squareIndex * 6;
                    triangles[triIndex + 0] = (z - 1) * vSizeX + (x - 1) + 0;
                    triangles[triIndex + 1] = (z - 1) * vSizeX + (x - 1) + vSizeX + 0;
                    triangles[triIndex + 2] = (z - 1) * vSizeX + (x - 1) + vSizeX + 1;

                    triangles[triIndex + 3] = (z - 1) * vSizeX + (x - 1) + vSizeX + 1;
                    triangles[triIndex + 4] = (z - 1) * vSizeX + (x - 1) + 1;
                    triangles[triIndex + 5] = (z - 1) * vSizeX + (x - 1) + 0;

                }
            }

            //Create Mesh
            Mesh mesh = new Mesh();
            mesh.vertices = vertices;
            mesh.triangles = triangles;
            mesh.normals = normals;
            mesh.uv = uv;


            MeshFilter mesh_filter = GetComponent<MeshFilter>();
            MeshCollider mesh_collider = GetComponent<MeshCollider>();

            mesh_filter.mesh = mesh;
            mesh_collider.sharedMesh = mesh;

            Debug.Log("TileMap: End Building Mesh.");
            if (!BuildTexture())
                return false;

            return true;
        }
        catch (Exception ex)
        {
            Debug.Log("TileMap: at BuildMesh() " + ex.Message);
            return false;
        }
    }

    #endregion
}
