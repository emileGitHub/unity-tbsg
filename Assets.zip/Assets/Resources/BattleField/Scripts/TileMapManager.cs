﻿using EEANGame.ImageConverter.ForUnity;
using EEANGame.TBSG.V1_0.CommonEnums;
using EEANGame.TBSG.V1_0.MainClassLib;
using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Networking;
using UnityEngine.UI;

[RequireComponent(typeof(MeshFilter))]
[RequireComponent(typeof(MeshRenderer))]
[RequireComponent(typeof(MeshCollider))]
public class TileMapManager : NetworkBehaviour
{
    public Material NormalTile;
    public Material BlueTile;
    public Material RedTile;
    public Material GreenTile;
    public Material OcherTile;
    public Material PurpleTile;
    public Material YellowTile;
    public Material HealTile;

    public const int sizeX = Rule.SIZE_OF_A_SIDE_OF_BOARD;
    public const int sizeZ = Rule.SIZE_OF_A_SIDE_OF_BOARD;

    private BattleSystem mainScript;
    public bool isInitialized { get; private set; }

    private Text LoadingStatus;

    [SerializeField]
    public SyncListInt SyncList_TileId = new SyncListInt();

    // Use this for initialization
    void Awake()
    {
        try
        {
            isInitialized = false;
            LoadingStatus = GameObject.Find("LoadingStatus").GetComponent<Text>();
        }
        catch (Exception ex)
        {
            Debug.Log("TileMap: at Awake() " + ex.Message);
        }
    }


    #region Client Side Code
    void Update()
    {
        if (isClient && !isInitialized)
            Initialize();
    }

    public void Initialize()
    {
        try
        {
            if (mainScript == null)
                mainScript = GameObject.Find("BattleSystemController").GetComponent<BattleSystem>();

            if (mainScript.isInitialized)
            {
                Debug.Log("TileMap (Script): Start Initialize.");
                LoadingStatus.text = "Initializing Board TileMap";

                ApplyMaterialToTiles();

                isInitialized = true;
                Debug.Log("TileMap (Script): End Initialize.");
            }
        }
        catch (Exception ex)
        {
            Debug.Log("TileMap: at Initialize() " + ex.Message);
        }
    }

    public bool ApplyMaterialToTiles()
    {
        try
        {
            for (int z = 1; z <= sizeZ; z++)
            {
                for (int x = 1; x <= sizeX; x++)
                {
                    int tileNum = sizeZ * (z - 1) + (x - 1);

                    eTileType tileType = eTileType.NORMAL;
                    foreach (eTileType e in Enum.GetValues(typeof(eTileType)))
                    {
                        if (Convert.ToInt32(e) == SyncList_TileId[tileNum])
                        {
                            tileType = e;
                            break;
                        }
                    }

                    string tileObjectName = "Tile" + tileNum.ToString();

                    MeshRenderer TileObjectMeshRenderer = this.transform.Find(tileObjectName).GetComponent<MeshRenderer>();

                    switch (tileType)
                    {
                        default: //case eTileType.NORMAL
                            TileObjectMeshRenderer.material = NormalTile;
                            break;
                        case eTileType.BLUE:
                            TileObjectMeshRenderer.material = BlueTile;
                            break;
                        case eTileType.RED:
                            TileObjectMeshRenderer.material = RedTile;
                            break;
                        case eTileType.GREEN:
                            TileObjectMeshRenderer.material = GreenTile;
                            break;
                        case eTileType.OCHER:
                            TileObjectMeshRenderer.material = OcherTile;
                            break;
                        case eTileType.PURPLE:
                            TileObjectMeshRenderer.material = PurpleTile;
                            break;
                        case eTileType.YELLOW:
                            TileObjectMeshRenderer.material = YellowTile;
                            break;
                        case eTileType.HEAL:
                            TileObjectMeshRenderer.material = HealTile;
                            break;
                    }

                }
            }

            return true;
        }
        catch (Exception ex)
        {
            Debug.Log("TileMap: at ApplyMaterialToTiles(). " + ex.Message);
            return false;
        }
    }
    #endregion

    #region Server Side Code
    [Server]
    public bool SyncVarInitialization()
    {
        try
        {
            mainScript = GameObject.Find("BattleSystemController").GetComponent<BattleSystem>();

            if (!mainScript.isInitialized)
            {
                Debug.Log("TileMap: Start SyncVar Initialization.");
                LoadingStatus.text = "Initializing Board TileMap On Server";

                if (!InitializeTileIdList())
                    return false;

                Debug.Log("TileMap: End SyncVar Initialization.");
                return true;
            }

            return false;
        }
        catch (Exception ex)
        {
            Debug.Log("TileMap: at SyncVarInitialization() " + ex.Message);
            return false;
        }
    }

    [Server]
    public bool InitializeTileIdList()
    {
        try
        {
            Rpc_ClearTileIdList();

            for (int z = 0; z < sizeZ; z++)
            {
                for (int x = 0; x < sizeX; x++)
                {
                    int tileId = Convert.ToInt32(mainScript.FieldInstance.Board.Sockets[x, z].Tile);

                    Debug.Log("TileMap: at InitializeTileIdList(). Tile[" + x.ToString() + "][" + z.ToString() + "]");
                    Rpc_AddTileId(tileId);
                }
            }

            return true;
        }
        catch (Exception ex)
        {
            Debug.Log("TileMap: at InitializeTileIdList(). " + ex.Message);
            return false;
        }
    }
    #endregion

    #region Client Rpc

    [ClientRpc]
    public void Rpc_AddTileId(int _id)
    {
        try
        {
            SyncList_TileId.Add(_id);
            Debug.Log("TileMap: at Rpc_AddTileId(). -> TileId(" + _id.ToString() + " has been added to SyncListInt.)");
        }
        catch (Exception ex)
        {
            Debug.Log("TileMap: at Rpc_AddTileId(). " + ex.Message);
        }
    }

    [ClientRpc]
    public void Rpc_ClearTileIdList()
    {
        SyncList_TileId.Clear();
    }

    [ClientRpc]
    public void Rpc_ChangeTile(int _boardCoordX, int _boardCoordY, int _tileId)
    {
        if (_boardCoordX >= 0 && _boardCoordX < sizeX
            && _boardCoordY >= 0 && _boardCoordY < sizeZ)
        {
            int index = sizeX * _boardCoordY + _boardCoordX;
            SyncList_TileId[index] = _tileId;
        }
    }

    #endregion
}

