﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// Use this class to access to the Local Player
/// </summary>
public class LocalPlayerIdentifier : MonoBehaviour
{

    public bool isInitialized;

    private BattleSystem mainScript;
    public GameObject LocalPlayer { get; private set; }
    public PlayerController PlayerController { get; private set; }
    public PlayerCommands PlayerCommands { get; private set; }

    // Use this for initialization
    void Awake()
    {
        isInitialized = false;
    }

    public void InitializeExplicit(GameObject _localPlayer)
    {
        try
        {
            if (!isInitialized)
            {
                LocalPlayer = _localPlayer;
                PlayerController = LocalPlayer.GetComponent<PlayerController>();
                PlayerCommands = LocalPlayer.GetComponent<PlayerCommands>();

                if (LocalPlayer != null)
                    isInitialized = true; // Initialization has completed successfully
            }
        }
        catch (Exception ex)
        {
            Debug.Log("LocalPlayerIdentifier: at InitializeExplicit() " + ex.Message);
        }
    }
}
