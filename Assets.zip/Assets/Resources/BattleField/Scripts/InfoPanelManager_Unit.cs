﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

[RequireComponent(typeof(InfoPanelManager))]
public class InfoPanelManager_Unit : MonoBehaviour {

    private BattleSystem mainScript;
    private LocalPlayerIdentifier LocalPlayerIdentifier;

    InfoPanelManager mainInfoPanelManager;

    [SerializeField]
    public GameObject UnitInfoPanelPrefab;

    private List<GameObject> InfoPanels;
    private Transform Canvas;

    private Text NickName;

    private Text NameText;
    private Text Level;
    private Text MaxHPText;
    private Text PhyStrText;
    private Text PhyResText;
    private Text MagStrText;
    private Text MagResText;

    private bool isInitialized;

    //Use this for initialization

    void Awake()
    {
        mainInfoPanelManager = this.transform.GetComponent<InfoPanelManager>();
        isInitialized = false;
        //NameText = this.transform.Find("Name").GetComponent<Text>();
        //HPText = this.transform.Find("HP").GetComponent<Text>();
        //PhyStrText = this.transform.Find("PhyStr").GetComponent<Text>();
        //PhyResText = this.transform.Find("PhyRes").GetComponent<Text>();
        //MagStrText = this.transform.Find("MagStr").GetComponent<Text>();
        //MagResText = this.transform.Find("MagRes").GetComponent<Text>();
    }

    // Update is called once per frame
    void Update()
    {
        if (!isInitialized)
            Inititalize();

        if (isInitialized)
        {
            //UpdateTexts();
        }
    }

    private void Inititalize()
    {
        try
        {
            if (InfoPanels == null)
                InfoPanels = new List<GameObject>();

            if (Canvas == null)
                Canvas = GameObject.Find("Canvas").transform;

            if (mainScript == null)
                mainScript = GameObject.Find("BattleSystemController").GetComponent<BattleSystem>();

            if (LocalPlayerIdentifier == null)
                LocalPlayerIdentifier = GameObject.Find("LocalPlayerIdentifier").GetComponent<LocalPlayerIdentifier>();

            if (mainScript != null && LocalPlayerIdentifier != null)
                isInitialized = true;

        }
        catch (Exception ex)
        {
            Debug.Log("UnitDataDisplayer: at Initialize() " + ex.Message);
        }
    }

    public void InstantiateInfoPanel(UnitController _unitControllerScript)
    {
        GameObject infoPanel = Instantiate(UnitInfoPanelPrefab, Canvas, false);
        infoPanel.transform.Find("BackGround").Find("CloseButton").GetComponent<Button>().onClick.AddListener(() => RemoveInfoPanel());
        //RectTransform rt = infoPanel.GetComponent<RectTransform>();
        InfoPanels.Add(infoPanel);
        mainInfoPanelManager.AddInfoPanel(infoPanel);

        UpdateInfoPanel(infoPanel, _unitControllerScript);
    }

    private void UpdateInfoPanel(GameObject _infoPanel, UnitController _unitControllerScript)
    {
        Transform infoPanelBG = _infoPanel.transform.Find("BackGround");

        infoPanelBG.Find("UnitNickname").GetComponent<Text>().text = _unitControllerScript.Nickname;

        Transform unitCard = infoPanelBG.Find("UnitCard");
        unitCard.Find("NamePlate").Find("Name").GetComponent<Text>().text = _unitControllerScript.Name;
        unitCard.Find("Level").GetComponent<Text>().text = _unitControllerScript.Level.ToString();
        unitCard.Find("MaxHP").Find("Amount").GetComponent<Text>().text = _unitControllerScript.MaxHP.ToString();
        unitCard.Find("PhyStr").Find("Amount").GetComponent<Text>().text = _unitControllerScript.PhyStr.ToString();
        unitCard.Find("PhyRes").Find("Amount").GetComponent<Text>().text = _unitControllerScript.PhyRes.ToString();
        unitCard.Find("MagStr").Find("Amount").GetComponent<Text>().text = _unitControllerScript.MagStr.ToString();
        unitCard.Find("MagRes").Find("Amount").GetComponent<Text>().text = _unitControllerScript.MagRes.ToString();
        unitCard.Find("Vit").Find("Amount").GetComponent<Text>().text = _unitControllerScript.Vit.ToString();
        unitCard.Find("Graphic").GetComponent<Image>().sprite = UnitIconManager.Icons[_unitControllerScript.UnitIconId - 1];

        int element1_index = _unitControllerScript.Element1 - 1;
        int element2_index = _unitControllerScript.Element2 - 1;
        int specie1_index = _unitControllerScript.Specie1 - 1;
        int specie2_index = _unitControllerScript.Specie2 - 1;
        int specie3_index = _unitControllerScript.Specie3 - 1;

        Transform E1 = unitCard.Find("ElementIcon1");
        Transform E2 = unitCard.Find("ElementIcon2");
        Transform S1 = unitCard.Find("SpecieIcon1");
        Transform S2 = unitCard.Find("SpecieIcon2");
        Transform S3 = unitCard.Find("SpecieIcon3");

        if (element1_index < 0)
            E1.GetComponent<CanvasRenderer>().SetAlpha(0);
        else
        {
            E1.GetComponent<CanvasRenderer>().SetAlpha(1f);
            E1.GetComponent<Image>().sprite = ElementIconSet.Icons[element1_index];
        }

        if (element2_index < 0)
            E2.GetComponent<CanvasRenderer>().SetAlpha(0);
        else
        {
            E2.GetComponent<CanvasRenderer>().SetAlpha(1f);
            E2.GetComponent<Image>().sprite = ElementIconSet.Icons[element2_index];
        }

        if (specie1_index < 0)
            S1.GetComponent<CanvasRenderer>().SetAlpha(0);
        else
        {
            S1.GetComponent<CanvasRenderer>().SetAlpha(1f);
            S1.GetComponent<Image>().sprite = SpecieIconSet.Icons[specie1_index];
        }

        if (specie2_index < 0)
            S2.GetComponent<CanvasRenderer>().SetAlpha(0);
        else
        {
            S2.GetComponent<CanvasRenderer>().SetAlpha(1f);
            S2.GetComponent<Image>().sprite = SpecieIconSet.Icons[specie2_index];
        }

        if (specie3_index < 0)
            S3.GetComponent<CanvasRenderer>().SetAlpha(0);
        else
        {
            S3.GetComponent<CanvasRenderer>().SetAlpha(1f);
            S3.GetComponent<Image>().sprite = SpecieIconSet.Icons[specie3_index];
        }
    }

    //private void UpdateTexts()
    //{
    //    try
    //    {
    //        if (mainScript.isInitialized)
    //        {
    //            if (LocalPlayerIdentifier.isInitialized)
    //            {
    //                GameObject[] units = GameObject.FindGameObjectsWithTag("Unit");

    //                foreach (GameObject unit in units)
    //                {
    //                    UnitController uc = unit.GetComponent<UnitController>();

    //                    if (uc.isInitialized)
    //                    {
    //                        if (uc.Id_OwnerPlayer == LocalPlayerIdentifier.PlayerController.PlayerId
    //                            && uc.Unit_PublicId == LocalPlayerIdentifier.PlayerController.SelectedAlliedUnitId)
    //                        {
    //                            NameText.text = uc.Name;
    //                            HPText.text = "HP: " + uc.RemainingHP.ToString() + "/" + uc.MaxHP.ToString();
    //                            PhyStrText.text = "Phy-Str: " + uc.PhyStr.ToString();
    //                            PhyResText.text = "Phy-Res: " + uc.PhyRes.ToString();
    //                            MagStrText.text = "Mag-Str: " + uc.MagStr.ToString();
    //                            MagResText.text = "Mag-Res: " + uc.MagRes.ToString();
    //                        }
    //                    }
    //                }
    //            }
    //        }
    //    }
    //    catch (Exception ex)
    //    {
    //        Debug.Log("UnitDataDisplayer: at UpdateTexts() " + ex.Message);
    //    }

    //}

    //Remove newest info panel
    public void RemoveInfoPanel()
    {
        GameObject infoPanel = InfoPanels[InfoPanels.Count - 1];
        mainInfoPanelManager.RemoveInfoPanel(infoPanel);
        InfoPanels.Remove(infoPanel);
        Destroy(infoPanel);
    }
}
