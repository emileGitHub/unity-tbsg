﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class HPBarController : MonoBehaviour {

    public UnitController UnitController { get; private set; }
    private bool isInitialized;
    private bool isRotationAdjusted;
    private int remainingHP; // Actual hp remaining
    private float remainingHP_rate; // Value between 0 and 1

    private SpriteRenderer MySpriteRenderer;

    private Transform RemainingAmount;
    private SpriteRenderer SpriteRenderer_RemainingAmount;

    public GameObject DamageTextPrefab;

    private BattleUIManager BattleUIManager;

    private LocalPlayerIdentifier LocalPlayerIdentifier;

	// Use this for initialization
	void Awake () {
        isInitialized = false;
        isRotationAdjusted = false;
        UnitController = this.transform.parent.GetComponent<UnitController>();
        MySpriteRenderer = this.GetComponent<SpriteRenderer>();
        RemainingAmount = this.transform.Find("RemainingAmount");
        SpriteRenderer_RemainingAmount = RemainingAmount.GetComponent<SpriteRenderer>();
        BattleUIManager = GameObject.Find("BattleUIManager").GetComponent<BattleUIManager>();

        LocalPlayerIdentifier = GameObject.Find("LocalPlayerIdentifier").GetComponent<LocalPlayerIdentifier>();
    }
	
	// Update is called once per frame
	void Update () {
        if (!isInitialized)
            Initialize();

        if(isInitialized)
        {
            if (BattleUIManager.showHPBar && !MySpriteRenderer.enabled)
            {
                MySpriteRenderer.enabled = true;
                SpriteRenderer_RemainingAmount.enabled = true;
            }
            else if (!BattleUIManager.showHPBar && MySpriteRenderer.enabled)
            {
                MySpriteRenderer.enabled = false;
                SpriteRenderer_RemainingAmount.enabled = false;
            }

            UpdateHP();
        }
    }

    private void Initialize()
    {
        try
        {
            if (LocalPlayerIdentifier.isInitialized)
            {
                if(!isRotationAdjusted)
                {
                    if (LocalPlayerIdentifier.PlayerController.PlayerId == 2)
                        this.transform.Rotate(0, 180f, 0);

                    isRotationAdjusted = true;
                }
            }
            else
                return;

            if (UnitController.isInitialized)
            {
                SpriteRenderer unit_sr = this.transform.parent.GetComponent<SpriteRenderer>();
                Vector3 unitSize = unit_sr.bounds.size;

                SpriteRenderer my_sr = this.transform.GetComponent<SpriteRenderer>();
                Vector3 mySize = my_sr.bounds.size;

                float scale = 0;

                if(mySize.x != 0) // Assuming that the sprite is a square (x == y)
                    scale = unitSize.x / mySize.x;

                this.transform.localScale = new Vector3(scale - 0.02f, scale / 8, scale); // Subtracting 0.02 from x scale so that it would not be making contact with the HP bar on its side

                float x = 0.25f;
                float y = 0.6f;

                if (UnitController.LocalPlayerIdentifier.PlayerController.PlayerId == 2)
                {
                    this.transform.Rotate(new Vector3(0, 180f, 0));
                }

                this.transform.localPosition = new Vector3(x, y, 0);

                remainingHP = UnitController.RemainingHP;

                if (UnitController.MaxHP != 0)
                    remainingHP_rate = (float)UnitController.RemainingHP / (float)UnitController.MaxHP;
                else
                    remainingHP_rate = -1f;

                isInitialized = true;
            }
        }
        catch(Exception ex)
        {
            Debug.Log("HPBarController: at Initialize() " + ex.Message);
        }
    }

    private void UpdateHP()
    {
        if (remainingHP != UnitController.RemainingHP)
        {
            remainingHP = UnitController.RemainingHP;
            remainingHP_rate = (float)UnitController.RemainingHP / (float)UnitController.MaxHP;

            RemainingAmount.localScale = new Vector3(remainingHP_rate, 1f, 1f);

            Vector3 currentScale = RemainingAmount.localScale;
            Vector3 currentPos = RemainingAmount.localPosition;
            RemainingAmount.localPosition = new Vector3(-5.12f * (1 - currentScale.x), currentPos.y, currentPos.z); // -5.12f adjusted the position the best
        }
    }

    public void HPModificationAnimation(int _modificationAmount, bool _isCritical, bool _didHit)
    {
        GameObject damageText = Instantiate(DamageTextPrefab, this.transform);
        damageText.transform.localPosition = new Vector3(0, 0, 0);
        damageText.transform.localScale = new Vector3(1, 8, 1);

        string textColorTag = "";

        if(_didHit)
        {
            if (_modificationAmount > 0)
            {
                if (_isCritical)
                    textColorTag = "<color=pink>";
                else
                    textColorTag = "<color=green>";
            }
            else if (_modificationAmount < 0)
            {
                _modificationAmount *= -1;

                if (_isCritical)
                    textColorTag = "<color=yellow>";
                else
                    textColorTag = "<color=red>";
            }
            else
                textColorTag = "<color=gray>";

            damageText.GetComponent<DamageTextManager>().MyTextMesh.text = textColorTag + _modificationAmount.ToString() + "</color>";
        }
        else
        {
            damageText.GetComponent<DamageTextManager>().MyTextMesh.text = "<color=gray>Miss!!</color>";
        }

    }
}
