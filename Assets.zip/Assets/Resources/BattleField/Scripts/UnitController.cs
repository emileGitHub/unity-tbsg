﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using EEANGame.ImageConverter.ForUnity;
using UnityEngine.Networking;
using EEANGame.TBSG.V1_0.MainClassLib.DBDataHandler.ForUnity;
using System;
using EEANGame.TBSG.V1_0.CommonEnums;
using EEANGame.TBSG.V1_0.MainClassLib;
using UnityEngine.UI;

[RequireComponent(typeof(SpriteRenderer))]
[RequireComponent(typeof(BoxCollider2D))]
public class UnitController : NetworkBehaviour
{
    [SyncVar]
    public int Unit_PublicId; // Two or more Units cannot have same id
    [SyncVar]
    public int Unit_PrivateId; // Units of same Player cannot have same id
    [SyncVar]
    public int Id_OwnerPlayer;
    [SyncVar]
    public int UnitSpriteId;
    [SyncVar]
    public int UnitIconId;
    [SyncVar] 
    public string DirectionFacing; // Sync enum value as string
    [SyncVar]
    public string Nickname;
    [SyncVar]
    public string Name;
    [SyncVar]
    public int Element1;
    [SyncVar]
    public int Element2;
    [SyncVar]
    public int Specie1;
    [SyncVar]
    public int Specie2;
    [SyncVar]
    public int Specie3;
    [SyncVar]
    public int Level;
    [SyncVar]
    public int MaxHP;
    [SyncVar]
    public int RemainingHP;
    [SyncVar]
    public int PhyStr;
    [SyncVar]
    public int PhyRes;
    [SyncVar]
    public int MagStr;
    [SyncVar]
    public int MagRes;
    [SyncVar]
    public int Vit;
    [SyncVar]
    public bool IsAlive;

    [SerializeField]
    public SyncListString SyncList_SkillName = new SyncListString();

    public List<Sprite> UnitSprites;

    private int PreviousSpriteIndex;
    private int CurrentSpriteIndex;

    private const int NUM_COLUMNS = 6;
    private const int NUM_ROWS = 4;
    public List<Sprite> AnimationSprites { get; private set; }

    private BattleSystem mainScript;

    private SpriteRenderer spriteRenderer;
    private BoxCollider2D collider;

    private Text LoadingStatus;

    public LocalPlayerIdentifier LocalPlayerIdentifier { get; private set; }

    //private ParticleSet ParticleSet;

    public bool isInitialized { get; private set; }
    private bool isRotationAdjusted { get; set; }

    private int UpdateRate;

    //Testing Properties
    public float BaseBoundsSizeX;
    public float BaseBoundsSizeY;
    public float BaseBoundsSizeZ;
    public float SpriteBoundsSizeX;
    public float SpriteBoundsSizeY;
    public float SpriteBoundsSizeZ;

    // Use this for initialization
    void Awake()
    {
        try
        {
            isInitialized = false;
            isRotationAdjusted = false;
            UpdateRate = 0;
            LoadingStatus = GameObject.Find("LoadingStatus").GetComponent<Text>();
            LocalPlayerIdentifier = GameObject.Find("LocalPlayerIdentifier").GetComponent<LocalPlayerIdentifier>();
            //ParticleSet = GameObject.Find("ParticleSet").GetComponent<ParticleSet>();

            spriteRenderer = this.transform.GetComponent<SpriteRenderer>();
            collider = this.transform.GetComponent<BoxCollider2D>();

            //Required for Update() to avoid not being called
            if (!this.isActiveAndEnabled)
                this.enabled = true;
        }
        catch(Exception ex)
        {
            Debug.Log("UnitController: at Awake()" + ex.Message);
        }
    }

    #region Client Side Code
    void Update()
    {
        if (isClient && !isInitialized)
            Initialize();

        if (isClient && LocalPlayerIdentifier.isInitialized && !isRotationAdjusted)
        {
            GameObject[] players = GameObject.FindGameObjectsWithTag("Player");

            PlayerController pc = players[0].GetComponent<PlayerController>();

            if(LocalPlayerIdentifier.PlayerController.PlayerId == 2)
            {
                this.transform.position += new Vector3(7f, 0, 0);
                this.transform.Rotate(0, 180f, 0);
                isRotationAdjusted = true;
            }

            BaseBoundsSizeX = spriteRenderer.bounds.size.x;
            BaseBoundsSizeY = spriteRenderer.bounds.size.y;
            BaseBoundsSizeZ = spriteRenderer.bounds.size.z;
            SpriteBoundsSizeX = spriteRenderer.sprite.bounds.size.x;
            SpriteBoundsSizeY = spriteRenderer.sprite.bounds.size.y;
            SpriteBoundsSizeZ = spriteRenderer.sprite.bounds.size.z;
        }

        if (isInitialized && !IsAlive)
            this.transform.localPosition= new Vector3(500, 500, -500);//Send object out of screen
    }

    [Client]
    void FixedUpdate()
    {
        if (isInitialized)
        {
            if (UpdateRate >= 50/2)
                UpdateRate = 0;

            UpdateRate++;

            if (UpdateRate >= 50/2) //Call method every 25 FixedUpdates --- Fixed Update is set to 0.02 (50 per second)
                SpriteAnimation();
        }
    }

    private void Initialize()
    {
        try
        {
            if (mainScript == null)
                mainScript = GameObject.Find("BattleSystemController").GetComponent<BattleSystem>();

            if (mainScript.isInitialized && LocalPlayerIdentifier.isInitialized)
            {
                Debug.Log("UnitController: Start Initializae.");
                LoadingStatus.text = "Initializing Unit";

                GameObject[] players = GameObject.FindGameObjectsWithTag("Player");

                foreach (GameObject player in players)
                {
                    PlayerController playerController = player.GetComponent<PlayerController>();

                    if (playerController.PlayerId == Id_OwnerPlayer)
                    {
                        this.transform.parent = player.transform;
                        break;
                    }
                }

                if (this.transform.parent == null)
                {
                    Debug.Log("UnitController: parent object not set");
                    return;
                }

                PreviousSpriteIndex = 2;
                CurrentSpriteIndex = 1;

                if (!LoadSprites())
                {
                    Debug.Log("UnitController: error at LoadSprites()");
                    return;
                }

                if (!SetInitialSprite())
                {
                    Debug.Log("UnitController: error at SetInitialSprite()");
                    return;
                }

                if (!AdjustScale())
                {
                    Debug.Log("UnitController: error at AdjustScale()");
                    return;
                }

                float positionAdjustmentValue = spriteRenderer.bounds.size.x / 2;
                if (LocalPlayerIdentifier.PlayerController.PlayerId == 1)
                    positionAdjustmentValue *= -1;

                this.transform.position += new Vector3(positionAdjustmentValue, 0, 0);

                isInitialized = true;
                LoadingStatus.text = "End Unit Initialization";
                Debug.Log("UnitController: End Initialize.");
            }
        }
        catch (Exception ex)
        {
            Debug.Log("UnitController: at Initialize() " + ex.Message);
        }
    }

    private bool AdjustScale()
    {
        try
        {
            this.transform.localScale = mainScript.UnitScale;
            return AdjustCollider(); ;
        }
        catch (Exception ex)
        {
            Debug.Log("UnitController: at AdjustScale() " + ex.Message);
            return false;
        }
    }

    private bool AdjustCollider()
    {
        try
        {
            collider.size = spriteRenderer.sprite.bounds.size;
            collider.offset = new Vector2(collider.size.x / 2, collider.size.y / 2);
            return true;
        }
        catch (Exception ex)
        {
            Debug.Log("UnitController: at AdjustCollider() " + ex.Message);
            return false;
        }
    }

    private bool LoadSprites()
    {
        try
        {
            AnimationSprites = SpriteSplitter.SpriteToMultipleSprites(UnitSprites[UnitSpriteId - 1], NUM_COLUMNS, NUM_ROWS);

            if (AnimationSprites.Count != NUM_COLUMNS * NUM_ROWS)
                return false;

            return true;
        }
        catch (Exception ex)
        {
            Debug.Log("UnitController: at LoadSprites() " + ex.Message);
            return false;
        }
    }

    private bool SetInitialSprite()
    {
        try
        {
            spriteRenderer.sprite = AnimationSprites[CurrentSpriteIndex];

            return true;
        }
        catch (Exception ex)
        {
            Debug.Log("UnitController: at SetInitialSprite() " + ex.Message);
            return false;
        }
    }

    [Client]
    private void ChangeSprite(int _index)
    {
        try
        {
            spriteRenderer.sprite = AnimationSprites[_index];
            PreviousSpriteIndex = CurrentSpriteIndex;
            CurrentSpriteIndex = _index;
        }
        catch (Exception ex)
        {
            Debug.Log("UnitController: at ChangeSprite() " + ex.Message);
        }
    }

    [Client]
    private void SpriteAnimation()
    {
        try
        {
            switch (ToActualDirection(TxtDataHandler.ToCorrespondingEnumValue<eDirection>(DirectionFacing)))
            {
                case eDirection.BACK:
                    {
                        const int ROW_INDEX = 0;
                        switch (CurrentSpriteIndex)
                        {
                            default:
                                ChangeSprite(NUM_COLUMNS * ROW_INDEX + 1);
                                break;
                            case NUM_COLUMNS * ROW_INDEX + 0:
                            case NUM_COLUMNS * ROW_INDEX + 2:
                                ChangeSprite(NUM_COLUMNS * ROW_INDEX + 1);
                                break;
                            case NUM_COLUMNS * ROW_INDEX + 1:
                                if (PreviousSpriteIndex == CurrentSpriteIndex - 1)
                                    ChangeSprite(CurrentSpriteIndex + 1);
                                else // if (PreviousSpriteIndex == CurrentSpriteIndex + 1)
                                    ChangeSprite(CurrentSpriteIndex - 1);
                                break;
                        }
                    }
                    break;
                case eDirection.LEFT:
                    {
                        const int ROW_INDEX = 1;
                        switch (CurrentSpriteIndex)
                        {
                            default:
                                ChangeSprite(NUM_COLUMNS * ROW_INDEX + 1);
                                break;
                            case NUM_COLUMNS * ROW_INDEX + 0:
                            case NUM_COLUMNS * ROW_INDEX + 2:
                                ChangeSprite(NUM_COLUMNS * ROW_INDEX + 1);
                                break;
                            case NUM_COLUMNS * ROW_INDEX + 1:
                                if (PreviousSpriteIndex == CurrentSpriteIndex - 1)
                                    ChangeSprite(CurrentSpriteIndex + 1);
                                else // if (PreviousSpriteIndex == CurrentSpriteIndex + 1)
                                    ChangeSprite(CurrentSpriteIndex - 1);
                                break;
                        }
                    }
                    break;
                case eDirection.FRONT:
                    {
                        const int ROW_INDEX = 2;
                        switch (CurrentSpriteIndex)
                        {
                            default:
                                ChangeSprite(NUM_COLUMNS * ROW_INDEX + 1);
                                break;
                            case NUM_COLUMNS * ROW_INDEX + 0:
                            case NUM_COLUMNS * ROW_INDEX + 2:
                                ChangeSprite(NUM_COLUMNS * ROW_INDEX + 1);
                                break;
                            case NUM_COLUMNS * ROW_INDEX + 1:
                                if (PreviousSpriteIndex == CurrentSpriteIndex - 1)
                                    ChangeSprite(CurrentSpriteIndex + 1);
                                else // if (PreviousSpriteIndex == CurrentSpriteIndex + 1)
                                    ChangeSprite(CurrentSpriteIndex - 1);
                                break;
                        }
                    }
                    break;
                case eDirection.RIGHT:
                    {
                        const int ROW_INDEX = 3;
                        switch (CurrentSpriteIndex)
                        {
                            default:
                                ChangeSprite(NUM_COLUMNS * ROW_INDEX + 1);
                                break;
                            case NUM_COLUMNS * ROW_INDEX + 0:
                            case NUM_COLUMNS * ROW_INDEX + 2:
                                ChangeSprite(NUM_COLUMNS * ROW_INDEX + 1);
                                break;
                            case NUM_COLUMNS * ROW_INDEX + 1:
                                if (PreviousSpriteIndex == CurrentSpriteIndex - 1)
                                    ChangeSprite(CurrentSpriteIndex + 1);
                                else // if (PreviousSpriteIndex == CurrentSpriteIndex + 1)
                                    ChangeSprite(CurrentSpriteIndex - 1);
                                break;
                        }
                    }
                    break;
                default:
                    break;
            }
        }
        catch (Exception ex)
        {
            Debug.Log("UnitController: at SpriteAnimation() " + ex.Message);
        }
    }

    private eDirection ToActualDirection(eDirection _playerBasedDirection)
    {
        try
        {
            if (LocalPlayerIdentifier.isInitialized)
            {
                if (LocalPlayerIdentifier.PlayerController.PlayerId != Id_OwnerPlayer)
                {
                    switch (_playerBasedDirection)
                    {
                        case eDirection.LEFT:
                            return eDirection.RIGHT;
                        case eDirection.RIGHT:
                            return eDirection.LEFT;
                        case eDirection.BACK:
                            return eDirection.FRONT;
                        default: // case eDirection.FRONT
                            return eDirection.BACK;
                    }
                }
            }
            //else
            return _playerBasedDirection;
        }
        catch (Exception ex)
        {
            Debug.Log("UnitController: at ToActualDirection() " + ex.Message);
            return _playerBasedDirection;
        }
    }
    #endregion

    #region Server/Host Side Code
    [Server]
    public bool SyncVarInitialization(int _publicId, int _privateId, int _ownerId, int _spriteId, int _iconId, eDirection _directionFacing, string _nickname, string _name, int _element1, int _element2, int _specie1, int _specie2, int _specie3, int _level, int _maxHP, int _remainingHP, int _phyStr, int _phyRes, int _magStr, int _magRes, int _vit, List<string> _skillNames)
    {
        try
        {
            mainScript = GameObject.Find("BattleSystemController").GetComponent<BattleSystem>();

            if (!mainScript.isInitialized && LocalPlayerIdentifier.isInitialized)
            {
                Debug.Log("UnitController (Script): Start SyncVar Initialization.");

                spriteRenderer = this.transform.GetComponent<SpriteRenderer>();

                Unit_PublicId = _publicId;
                Unit_PrivateId = _privateId;
                Id_OwnerPlayer = _ownerId;
                UnitSpriteId = _spriteId;
                UnitIconId = _iconId;
                DirectionFacing = _directionFacing.ToString();
                Nickname = _nickname;
                Name = _name;
                Element1 = _element1;
                Element2 = _element2;
                Specie1 = _specie1;
                Specie2 = _specie2;
                Specie3 = _specie3;
                Level = _level;
                MaxHP = _maxHP;
                RemainingHP = _remainingHP;
                PhyStr = _phyStr;
                PhyRes = _phyRes;
                MagStr = _magStr;
                MagRes = _magRes;
                Vit = _vit;
                IsAlive = true;

                SyncList_SkillName.Clear();
                foreach (string skillName in _skillNames)
                {
                    SyncList_SkillName.Add(skillName);
                }

                if (!mainScript.isScaleAdjusted)
                    mainScript.InitializeUnitScale(this.gameObject);
                if (!mainScript.isScaleAdjusted)
                    return false;

                Debug.Log("UnitController (Script): End SyncVar Initialization.");
                return true;
            }

            return false;
        }
        catch (Exception ex)
        {
            Debug.Log("UnitController: at SyncVarInitialization() " + ex.Message);
            return false;
        }
    }
    #endregion

    #region Client Rpc
    [ClientRpc]
    public void Rpc_UpdateDirection(eDirection _direction)
    {
        DirectionFacing = _direction.ToString();
    }

    [ClientRpc]
    public void Rpc_Move(Vector3 _nextPosition)
    {
        //float seconds = 2.0f;
        //float startingTime = Time.timeSinceLevelLoad;
        //float difference = Time.timeSinceLevelLoad - startingTime;
        //float timeRate = difference / seconds;

        //while (this.transform.position != _nextPosition)
        //{
        //    this.transform.position = Vector3.Lerp(this.transform.position, _nextPosition, timeRate);
        //}

        SpriteAnimation(); // Rotate Unit Before Moving Position

        float positionAdjustmentValue = spriteRenderer.bounds.size.x / 2;
        if (LocalPlayerIdentifier.PlayerController.PlayerId == 1)
            positionAdjustmentValue *= -1;

        _nextPosition += new Vector3(positionAdjustmentValue, 0, 0);

        if (this.transform.position != _nextPosition)
            this.transform.position = _nextPosition;
    }

    [ClientRpc]
    public void Rpc_SyncStatus(int _maxHP, int _remainingHP, bool _isAlive)
    {
        MaxHP = _maxHP;
        RemainingHP = _remainingHP;
        IsAlive = _isAlive;
    }
    #endregion
}
