package eean_games.main;

public interface IDeepCopyable<T>
{
	T DeepCopy();
}
