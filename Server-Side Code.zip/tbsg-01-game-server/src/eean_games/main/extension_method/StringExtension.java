package eean_games.main.extension_method;

public class StringExtension 
{
	public static String CoalesceNull(String _string) { return (_string != null) ? _string : null; }
}
