package eean_games.main.extension_method;

public enum eCopyType {
    None,
    Shallow,
    Deep
}
