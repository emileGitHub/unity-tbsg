package eean_games.main;

public enum eSortType {
    Descending,
    Ascending
}
