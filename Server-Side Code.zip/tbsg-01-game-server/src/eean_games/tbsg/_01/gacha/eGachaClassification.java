package eean_games.tbsg._01.gacha;

public enum eGachaClassification {
    Unit,
    Weapon,
    Armour,
    Accessory,
    SkillItem,
    SkillMaterial,
    ItemMaterial,
    EquipmentMaterial,
    EvolutionMaterial
}
