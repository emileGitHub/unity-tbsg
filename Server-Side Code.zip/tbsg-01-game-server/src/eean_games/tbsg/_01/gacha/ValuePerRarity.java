package eean_games.tbsg._01.gacha;

import eean_games.tbsg._01.enumerable.eRarity;

public class ValuePerRarity 
{
    public int Platinum;
    public int Gold;
    public int Silver;
    public int Bronze;
    public int Normal;

    public int getTotalValue() { return Normal + Bronze + Silver + Gold + Platinum; }
    public eRarity OccurenceValueToRarity(int _value)
    {
        if (_value < 1 || _value > getTotalValue())
            return eRarity.values()[0];

        if (_value > getTotalValue() - Platinum)
            return eRarity.Platinum;
        else if (_value > getTotalValue() - Platinum - Gold)
            return eRarity.Gold;
        else if (_value > Normal + Bronze)
            return eRarity.Silver;
        else if (_value > Normal)
            return eRarity.Bronze;
        else
            return eRarity.Normal;
    }
}
