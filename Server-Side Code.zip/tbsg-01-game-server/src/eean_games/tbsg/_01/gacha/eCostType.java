package eean_games.tbsg._01.gacha;

public enum eCostType {
    Money,
    Gem
}
