package eean_games.tbsg._01.gacha;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

import eean_games.main.MTRandom;
import eean_games.main.extension_method.ArrayExtension;
import eean_games.main.extension_method.ListExtension;
import eean_games.main.extension_method.StringExtension;
import eean_games.main.extension_method.eCopyType;
import eean_games.tbsg._01.enumerable.eRarity;

public class Gacha
{
    public Gacha(int _id, String _title, eGachaClassification _gachaType, List<GachaObjectInfo> _gachaObjectInfos, ValuePerRarity _defaultDispensationValues, List<AlternativeDispensationInfo> _alternativeDispensationInfos, eCostType _costType, int _costValue, Byte[] _bannerImageAsBytes, Byte[] _gachaSceneBackgroundImageAsBytes)
    {
        Id = _id;
        Title = StringExtension.CoalesceNull(_title);
        
        GachaType = _gachaType;

        m_gachaObjectInfos = ListExtension.CoalesceNullAndReturnCopyOptionally(_gachaObjectInfos, eCopyType.Shallow);

        DefaultDispensationValues = _defaultDispensationValues;

        m_alternativeDispensationInfos = ListExtension.CoalesceNullAndReturnCopyOptionally(_alternativeDispensationInfos, eCopyType.Shallow);

        CostType = _costType;
        CostValue = _costValue;

        m_bannerImageAsBytes = ArrayExtension.CoalesceNullAndReturnCopyOptionally(_bannerImageAsBytes, eCopyType.Deep, Byte.class);
        m_gachaSceneBackgroundImageAsBytes = ArrayExtension.CoalesceNullAndReturnCopyOptionally(_gachaSceneBackgroundImageAsBytes, eCopyType.Deep, Byte.class);
    }

    //Public Read-only Fields
    public final int Id;
    public final String Title;

    public final eGachaClassification GachaType;

    public final ValuePerRarity DefaultDispensationValues;

    public final eCostType CostType;
    public final int CostValue;
    //End Public Read-only Fields

    //Getters
    public List<GachaObjectInfo> getGachaObjectInfos() { return Collections.unmodifiableList(m_gachaObjectInfos); }
    
    public List<AlternativeDispensationInfo> getAlternativeDispensationInfos() { return Collections.unmodifiableList(m_alternativeDispensationInfos); }
    
    public List<Byte> getBannerImageAsBytes() { return Collections.unmodifiableList(Arrays.asList(m_bannerImageAsBytes)); }
    public List<Byte> getGachaSceneBackgroundImageAsBytes() { return Collections.unmodifiableList(Arrays.asList(m_gachaSceneBackgroundImageAsBytes)); }
    //End Getters
    
    //Private Read-only Fields
    private final List<GachaObjectInfo> m_gachaObjectInfos;
    private final List<AlternativeDispensationInfo> m_alternativeDispensationInfos;

    private final Byte[] m_bannerImageAsBytes;
    private final Byte[] m_gachaSceneBackgroundImageAsBytes;
    //End Private Read-only Fields
    
    //Public Methods
    @SuppressWarnings("static-access")
	public List<Object> DispenseObjects(int _timesToDispense)
    {
        List<Object> results = new ArrayList<Object>();

        for (int i = 1; i <= _timesToDispense; i++)
        {
        	final int index = i;
            ValuePerRarity dispensationValues = (!m_alternativeDispensationInfos.stream().anyMatch(x -> x.ApplyAtXthDispension == index)) ? DefaultDispensationValues : m_alternativeDispensationInfos.stream().filter(x -> x.ApplyAtXthDispension == index).findFirst().get().RatioPerRarity;

            int referenceNumber = dispensationValues.getTotalValue(); //Initialize referenceNumber for rarity selection.

            MTRandom.randInit();
            int occurencePosition = MTRandom.getRand(1, referenceNumber); //Get the number used to select the rarity of the Object.

            eRarity targetRarity = dispensationValues.OccurenceValueToRarity(occurencePosition);

            referenceNumber = 0; //Re-set referenceNumber for unit selection.
            List<GachaObjectInfo> gachaObjectInfosOfGivenRarity = m_gachaObjectInfos.stream().filter(x -> x.Object.getRarity() == targetRarity).collect(Collectors.toList());
            for (GachaObjectInfo goInfo : gachaObjectInfosOfGivenRarity)
            {
                referenceNumber += goInfo.RelativeOccurenceValue;
            }
            occurencePosition = MTRandom.getRand(1, referenceNumber); //Get the number used to select the Object.

            Object obj = new Object();
            int accumulatedRelativeOccurenceValue = 0;
            for (GachaObjectInfo goInfo : gachaObjectInfosOfGivenRarity)
            {
                accumulatedRelativeOccurenceValue += goInfo.RelativeOccurenceValue;

                if (occurencePosition <= accumulatedRelativeOccurenceValue)
                    obj = GenerateObject(goInfo.Object);

                if (obj == null)
                    return null;

                results.add(obj);

                break;
            }
        }

        return results;
    }
    //End Public Methods

    //Private Methods
    public Object GenerateObject(Object _objectBase)
    {
        Object result = new Object();

        switch (GachaType)
        {
            default: // case Unit
            	// Code to try adding a new unit to the database and pass its data to the client.
                break;
        }

        return result;
    }
    //End Private Methods
}
