package eean_games.tbsg._01.gacha;

import eean_games.tbsg._01.IRarityMeasurable;

public class GachaObjectInfo 
{
    public IRarityMeasurable Object;
    public int RelativeOccurenceValue;
}
