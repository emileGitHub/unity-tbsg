package eean_games.tbsg._01.gacha;

public class AlternativeDispensationInfo 
{
    public int ApplyAtXthDispension;
    public ValuePerRarity RatioPerRarity;
}
