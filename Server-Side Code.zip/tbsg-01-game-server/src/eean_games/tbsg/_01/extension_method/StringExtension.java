package eean_games.tbsg._01.extension_method;

public class StringExtension 
{
    @SuppressWarnings("rawtypes")
	public static Class ToCorrespondingEnumType(String _string)
    {
        try
        {
            String nameSpace = "eean_games.tbsg._01.enums;";

            Class result = Class.forName(nameSpace + "." + _string);
            
            if (result.isEnum())
            	return result;
            
            return null;
        }
        catch (Exception ex)
        {
            return null;
        }
    }

    @SuppressWarnings({ "unchecked", "rawtypes" })
	public static Object ToCorrespondingEnumValue(String _string, String _enumClassString)
    {
        try
        {
            Class enumClass = ToCorrespondingEnumType(_enumClassString);
            
            return Enum.valueOf(enumClass, _string);
        }
        catch (Exception ex)
        {
            return null;
        }
    }
}
