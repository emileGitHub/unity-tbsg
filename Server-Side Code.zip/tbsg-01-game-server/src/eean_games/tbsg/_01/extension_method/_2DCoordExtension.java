package eean_games.tbsg._01.extension_method;

import eean_games.main.CoreValues;
import eean_games.main._2DCoord;

public class _2DCoordExtension {
	public static int ToIndex(_2DCoord _coord) { return CoreValues.SIZE_OF_A_SIDE_OF_BOARD * _coord.Y + _coord.X; }
}
