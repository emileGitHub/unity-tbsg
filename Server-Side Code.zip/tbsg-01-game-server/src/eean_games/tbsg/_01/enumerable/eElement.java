package eean_games.tbsg._01.enumerable;

public enum eElement {
    None, //Default
    Blue,
    Red,
    Green,
    Ocher,
    Purple,
    Yellow
}
