package eean_games.tbsg._01.enumerable;

public enum eEffectiveness {
    Effective,
    Neutral,
    Ineffective
}
