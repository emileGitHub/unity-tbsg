package eean_games.tbsg._01.enumerable;

public enum eStringMatchType {
    Equals,
    Contains,
    StartsWith,
    EndsWith
}
