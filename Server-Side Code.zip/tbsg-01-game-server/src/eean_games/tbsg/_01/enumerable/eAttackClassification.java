package eean_games.tbsg._01.enumerable;

public enum eAttackClassification {
    Physic,
    Magic
}
