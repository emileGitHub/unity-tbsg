package eean_games.tbsg._01.enumerable;

public enum eAccessoryClassification {
    Head,
    Face,
    Ear,
    Neck,
    Body,
    Arm,
    Wrist,
    Hand,
    Finger,
    Leg,
    Ankle
}
