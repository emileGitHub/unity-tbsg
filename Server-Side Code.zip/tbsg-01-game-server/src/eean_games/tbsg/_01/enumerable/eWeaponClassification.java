package eean_games.tbsg._01.enumerable;

public enum eWeaponClassification {
    Unclassified,
    Ax,
    Blunt,
    Book,
    Bow,
    Glove,
    Gun,
    Katana,
    Knife,
    Mech,
    MusicalInstrument,
    Nuckle,
    Rapier,
    Scythe,
    Shield,
    Shoe,
    SniperRifle,
    Spear,
    Sword,
    Throwing,
    Wand,
    Whip
}
