package eean_games.tbsg._01.enumerable;

public enum eGender {
    Undefinable,
    Male,
    Female
}
