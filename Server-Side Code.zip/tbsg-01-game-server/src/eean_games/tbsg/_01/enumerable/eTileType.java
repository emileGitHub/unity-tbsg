package eean_games.tbsg._01.enumerable;

public enum eTileType {
    Normal,
    Blue,
    Red,
    Green,
    Ocher,
    Purple,
    Yellow,
    Heal
}
