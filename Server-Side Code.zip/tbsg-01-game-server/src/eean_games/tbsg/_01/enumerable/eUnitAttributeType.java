package eean_games.tbsg._01.enumerable;

public enum eUnitAttributeType {
    Level,
    MaxHP,
    RemainingHP,
    PhyStr,
    PhyRes,
    MagStr,
    MagRes,
    Vitality
}
