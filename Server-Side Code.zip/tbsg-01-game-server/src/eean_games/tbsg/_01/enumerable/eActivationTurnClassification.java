package eean_games.tbsg._01.enumerable;

public enum eActivationTurnClassification {
    OnAnyTurn,
    OnMyTurn,
    OnOpponentTurn
}
