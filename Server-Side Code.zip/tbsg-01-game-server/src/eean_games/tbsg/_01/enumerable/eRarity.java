package eean_games.tbsg._01.enumerable;

public enum eRarity {
    //The numbers express the max level of characters of the rarity
    Normal(20),
    Bronze(40),
    Silver(60),
    Gold(80),
    Platinum(100);
	
	private int numericValue;
	
	private eRarity(int _numericValue) {
		numericValue = _numericValue;
	}
	
	public int numericValue() {
		return numericValue;
	}
}
