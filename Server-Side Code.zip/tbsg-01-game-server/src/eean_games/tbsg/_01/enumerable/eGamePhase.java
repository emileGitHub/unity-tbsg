package eean_games.tbsg._01.enumerable;

public enum eGamePhase {
    BeginningOfMatch,
    BeginningOfTurn,
    DuringTurn,
    EndOfTurn
}
