package eean_games.tbsg._01.enumerable;

public enum eArmourClassification {
    ExtraLight,
    Light,
    Heavy
}
