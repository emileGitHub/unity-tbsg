package eean_games.tbsg._01.enumerable;

public enum eWeaponType {
    Ordinary,
    Transformable,
    Levelable,
    LevelableTransformable
}
