package eean_games.tbsg._01;

import eean_games.tbsg._01.enumerable.eRarity;

public interface IRarityMeasurable {
	eRarity getRarity();
}
