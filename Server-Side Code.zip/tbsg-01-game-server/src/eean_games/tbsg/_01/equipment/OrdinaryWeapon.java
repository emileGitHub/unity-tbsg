package eean_games.tbsg._01.equipment;

import java.util.List;

import eean_games.main.IDeepCopyable;
import eean_games.tbsg._01.enumerable.eRarity;
import eean_games.tbsg._01.enumerable.eWeaponClassification;
import eean_games.tbsg._01.enumerable.eWeaponType;
import eean_games.tbsg._01.skill.Skill;
import eean_games.tbsg._01.status_effect.StatusEffectData;

public class OrdinaryWeapon extends Weapon implements IDeepCopyable<Weapon>
{
    public OrdinaryWeapon(int _id, String _name, byte[] _iconAsBytes, eRarity _rarity, List<StatusEffectData> _statusEffectsData, List<eWeaponClassification> _weaponClassifications, Skill _mainWeaponSkill, int _uniqueId)
    {
    	super(_id, _name, _iconAsBytes, _rarity, _statusEffectsData, eWeaponType.Ordinary, _weaponClassifications, _mainWeaponSkill, _uniqueId);
    }
    public OrdinaryWeapon(WeaponData _weaponData, int _uniqueId)
    {
    	super(_weaponData, _uniqueId);
    }

    //Public Methods
    public OrdinaryWeapon DeepCopy() { return DeepCopyInternally(); }
    //End Public Methods

    //Protected Methods
    @Override
    protected OrdinaryWeapon DeepCopyInternally() { return (OrdinaryWeapon)super.DeepCopyInternally(); }
    //End Protected Methods
}
