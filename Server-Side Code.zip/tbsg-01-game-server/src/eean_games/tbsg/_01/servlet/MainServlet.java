package eean_games.tbsg._01.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import eean_games.main.CoreValues;
import eean_games.tbsg._01.DataLoader;
import eean_games.tbsg._01.MatchDataContainer;
import eean_games.tbsg._01.SharedGameDataContainer;
import eean_games.tbsg._01.player.Player;

/**
 * Servlet implementation class MainServlet
 */
@WebServlet("/MainServlet")
public class MainServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public MainServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		try 
		{
			//-------------------------------Connection----------------------------------------
			Class.forName("com.mysql.jdbc.Driver");
			
			Connection con = DriverManager
					.getConnection("jdbc:mysql://localhost:3306/GameDB", "tbsg-01", "Chocochan311206@4");
			//---------------------------------------------------------------------------------
			
			String query;
			PreparedStatement statement;
			
			int recordsAffected;
			ResultSet resultSet;
			
			String subject = request.getParameter("subject");
			if (subject == null)
				return;
			
			System.out.println("Received post request:" + subject);
			
			String result = "";
			switch(subject)
			{
				case "CheckConnection":
					break; //Return empty String. The client would not receive any result if a connection error occurs.
			
				case "CheckUserNameValidity":
					{
						String userName = request.getParameter("userName");
						
						query = "select Id from Players where UserName=?";
						statement = con.prepareStatement(query);
						statement.setString(1, userName);
						
						resultSet = statement.executeQuery();
						if (!resultSet.next())
							result = "valid";
						else
							result = "invalid";
					}
					break;
				
				case "CheckPlayerCredentialsValidity":
					{	
						String userName = request.getParameter("userName");
						String password = request.getParameter("password");
						
						query = "select Id from Players where UserName=? AND Password=?";
						statement = con.prepareStatement(query);
						statement.setString(1, userName);
						statement.setString(2, password);
						
						resultSet = statement.executeQuery();
						if (resultSet.next())
							result = "valid";	
						else
						{
							query = "select Id from Players where UserName=?";
							statement = con.prepareStatement(query);
							statement.setString(1, userName);
							
							resultSet = statement.executeQuery();
							if(resultSet.next())
								result = "wrongPassword";
							else
								result = "noAccount";
						}
					}
					break;
				
				case "CreateAccount":
					{
						String userName = request.getParameter("userName");
						String password = request.getParameter("password");
						String playerName = request.getParameter("playerName");
						String securityQuestion = request.getParameter("securityQuestion");
						String answer = request.getParameter("answer");
						int gems = CoreValues.GEMS_TO_GIVE_TO_NEW_PLAYER;
						int gold = CoreValues.GOLD_TO_GIVE_TO_NEW_PLAYER;
						
						query = "insert into Players (UserName, Password, PlayerName, SecurityQuestion, Answer, GemsOwned, GoldOwned) values (?, ?, ?, ?, ?, ?, ?)";
						statement = con.prepareStatement(query);
						statement.setString(1, userName);
						statement.setString(2, password);
						statement.setString(3, playerName);
						statement.setString(4, securityQuestion);
						statement.setString(5, answer);
						statement.setInt(6, gems);
						statement.setInt(7, gold);

						recordsAffected = statement.executeUpdate();
						
						if (recordsAffected != 0)
							result = "success";
						else
							result = "failure";
					}
					break;
				
				case "LoadCoreGameData":
					{
						String userName = request.getParameter("userName");
						String password = request.getParameter("password");
						
						query = "select Id from Players where UserName=? AND Password=?";
						statement = con.prepareStatement(query);
						statement.setString(1, userName);
						statement.setString(2, password);
						
						resultSet = statement.executeQuery();
						if (resultSet.next())
						{
							int id = resultSet.getInt("Id");
							
							result = SharedGameDataContainer.getAllDataAsResponseString();
							result = result + DataLoader.getPlayerDataAsResponseString(id);
						}
						else
							result = "invalidCredentials";
					}
					break;
				
				case "StartMatching":
					{
						String playerIdString = request.getParameter("playerId");
						int playerId = Integer.parseInt(playerIdString);
						String teamIndexString = request.getParameter("teamIndex");
						int teamIndex = Integer.parseInt(teamIndexString);
						
						Player player = SharedGameDataContainer.getPlayers().stream().filter(x -> x.Id == playerId).findFirst().get();
						
						result = MatchDataContainer.assignPlayerToMatch(player, teamIndex);
					}
					break;
				
				case "CheckMatchingStatus":
					{
						String playerIdString = request.getParameter("playerId");
						int playerId = Integer.parseInt(playerIdString);
						
						Player player = SharedGameDataContainer.getPlayers().stream().filter(x -> x.Id == playerId).findFirst().get();
						
						if (MatchDataContainer.hasPlayerBeenAssignedToMatch(player))
							result = "matched";
						else
							result = "matching";
					}
					break;
					
				case "GetMatchInfo":
					{
						String playerIdString = request.getParameter("playerId");
						int playerId = Integer.parseInt(playerIdString);
						
						result = DataLoader.getMatchDataAsResponseString(playerId);
					}
					break;
					
				case "GetPlayerInfo":
					{
						String playerIdString = request.getParameter("playerId");
						int playerId = Integer.parseInt(playerIdString);
						
						result = DataLoader.getMatchPlayerInfoAsResponseString(playerId);
					}
					break;
				
				case "GetOpponentInfo":
					{
						String playerIdString = request.getParameter("playerId");
						int playerId = Integer.parseInt(playerIdString);
						
						result = DataLoader.getMatchOpponentInfoAsResponseString(playerId);
					}
					break;
					
				case "ChangeUnit":
					{
						String playerIdString = request.getParameter("playerId");
						int playerId = Integer.parseInt(playerIdString);
						String unitIndexString = request.getParameter("unitIndex");
						int unitIndex = Integer.parseInt(unitIndexString);
						
						MatchDataContainer.ChangeUnit(playerId, unitIndex);
					}
					break;
					
				case "ChangeTurn":
					{
						String playerIdString = request.getParameter("playerId");
						int playerId = Integer.parseInt(playerIdString);
						
						MatchDataContainer.ChangeTurn(playerId);
					}
					break;
				
				case "Concede":
					{
						String playerIdString = request.getParameter("playerId");
						int playerId = Integer.parseInt(playerIdString);
						
						MatchDataContainer.Concede(playerId);
					}
					break;
					
				case "GetMissingEventLogs":
					{
						String playerIdString = request.getParameter("playerId");
						int playerId = Integer.parseInt(playerIdString);
						String latestLogIndexString = request.getParameter("latestLogIndex");
						int latestLogIndex = Integer.parseInt(latestLogIndexString);
						
						result = DataLoader.getMissingEventLogsAsResponseString(playerId, latestLogIndex);
					}
					break;
					
				case "GetMovableAndSelectableArea":
					{
						String playerIdString = request.getParameter("playerId");
						int playerId = Integer.parseInt(playerIdString);
						
						result = DataLoader.getMovableAndSelectableAreaAsResponseString(playerId);
					}
					break;
				
				case "GetAttackTargetableAndSelectableArea":
					{
						String playerIdString = request.getParameter("playerId");
						int playerId = Integer.parseInt(playerIdString);
						
						result = DataLoader.getAttackTargetableAndSelectableAreaAsResponseString(playerId);
					}
					break;
				
				case "GetSkillTargetableAndSelectableArea":
					{
						String playerIdString = request.getParameter("playerId");
						int playerId = Integer.parseInt(playerIdString);
						String skillName = request.getParameter("skillName");
						
						result = DataLoader.getSkillTargetableAndSelectableAreaAsResponseString(playerId, skillName);
					}
					break;
					
				default:
					break;
			}
			
			PrintWriter printWriter = response.getWriter();
			printWriter.flush();
			printWriter.print(result);
			
			doGet(request, response);
			
			System.out.println("Response: " + result);
			
			con.close();
		} 
		catch (Exception ex) 
		{
			ex.printStackTrace();
		}
	}

}
