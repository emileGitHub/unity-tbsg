package eean_games.tbsg._01.item;

import java.util.Map;

import eean_games.main.extension_method.MapExtension;
import eean_games.main.extension_method.eCopyType;

public class ItemSet 
{
	public ItemSet(int _id, Map<Item, Integer> _quantityPerItem)
	{
		Id = _id;
		quantityPerItem = MapExtension.CoalesceNullAndReturnCopyOptionally(_quantityPerItem, eCopyType.Shallow);
	}
	
	//Public Read-only Fields
    public final int Id;
    //End Public Read-only Fields
    
    //Public Fields
    public Map<Item, Integer> quantityPerItem;
    //End Public Fields
}
