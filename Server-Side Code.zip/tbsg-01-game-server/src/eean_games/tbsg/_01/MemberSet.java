package eean_games.tbsg._01;

import eean_games.tbsg._01.equipment.Accessory;
import eean_games.tbsg._01.equipment.Armour;
import eean_games.tbsg._01.equipment.Weapon;
import eean_games.tbsg._01.unit.Unit;

public class MemberSet
{
	public MemberSet(int _id, Unit _member)
	{
		this(_id, _member, null, null, null, null);
	}
	public MemberSet(int _id, Unit _member, Weapon _mainWeapon, Weapon _subWeapon, Armour _armour, Accessory _accessory)
	{
		Id = _id;
		Member = _member;
		MainWeapon = _mainWeapon;
		SubWeapon = _subWeapon;
		Armour = _armour;
		Accessory = _accessory;
	}
	
	//Public Read-only Fields
    public final int Id;
    //End Public Read-only Fields
    
    //Public Fields
    public Unit Member;
    public Weapon MainWeapon;
    public Weapon SubWeapon;
    public Armour Armour;
    public Accessory Accessory;
    //End Public Fields
}
