package eean_games.tbsg._01;

public class TargetInfo 
{
	public TargetInfo(String _name, String _nickname, String _ownerName)
	{
		name = _name;
		nickname = _nickname;
		ownerName = _ownerName;
	}
	
	public String name;
	public String nickname;
	public String ownerName;
}
