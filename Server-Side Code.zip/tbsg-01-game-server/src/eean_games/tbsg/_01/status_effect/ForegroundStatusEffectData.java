package eean_games.tbsg._01.status_effect;

import eean_games.main.IDeepCopyable;
import eean_games.tbsg._01.ComplexCondition;
import eean_games.tbsg._01.enumerable.eActivationTurnClassification;
import eean_games.tbsg._01.enumerable.eEventTriggerTiming;

public abstract class ForegroundStatusEffectData extends StatusEffectData implements IDeepCopyable<StatusEffectData>
{
    public ForegroundStatusEffectData(int _id, DurationData _duration, ComplexCondition _activationCondition, byte[] _iconAsBytes,
        eActivationTurnClassification _activationTurnClassification, eEventTriggerTiming _eventTriggerTiming, int _animationId)
    {
    	super(_id, _duration, _activationCondition, _iconAsBytes);
    	
        ActivationTurnClassification = _activationTurnClassification;
        EventTriggerTiming = _eventTriggerTiming;
        AnimationId = _animationId;
    }
    
    //Public Read-only Fields
    public final eActivationTurnClassification ActivationTurnClassification;
    public final eEventTriggerTiming EventTriggerTiming;
    public final int AnimationId;
    //End Public Read-only Fields

    //Public Methods
    public ForegroundStatusEffectData DeepCopy() { return DeepCopyInternally(); }
    //End Public Methods

    //Protected Methods
    @Override
    protected ForegroundStatusEffectData DeepCopyInternally() { return (ForegroundStatusEffectData)super.DeepCopyInternally(); }
    //End Protected Methods
}
