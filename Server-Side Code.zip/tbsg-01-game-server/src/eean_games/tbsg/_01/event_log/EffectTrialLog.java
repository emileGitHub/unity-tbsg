package eean_games.tbsg._01.event_log;

import java.math.BigDecimal;

public abstract class EffectTrialLog extends AutomaticEventLog
{
    public EffectTrialLog(BigDecimal _eventTurn,
        int _animationId, boolean _didSucceed)
    {
    	super(_eventTurn);
    	
        AnimationId = _animationId;

        DidSucceed = _didSucceed;
    }

    //Public Read-only Fields
    public final int AnimationId;

    public final boolean DidSucceed;
    //End Public Read-only Fields
}
