package eean_games.tbsg._01.event_log;

import java.math.BigDecimal;

import eean_games.main._2DCoord;
import eean_games.tbsg._01.extension_method.NullPreventionAssignmentMethods;

public class ActionLog_Move extends ActionLog
{
    public ActionLog_Move(BigDecimal _actionTurn, int _actorId, String _actorName, String _actorNickname,
        _2DCoord _initialCoord, _2DCoord _eventualCoord)
    {
    	super(_actionTurn, _actorId, _actorName, _actorNickname);
    	
        InitialCoord = NullPreventionAssignmentMethods.CoalesceNullAndReturnCopyOptionally(_initialCoord, true);
        EventualCoord = NullPreventionAssignmentMethods.CoalesceNullAndReturnCopyOptionally(_eventualCoord, true);
    }

    //Public Read-only Fields
    public final _2DCoord InitialCoord;
    public final _2DCoord EventualCoord;
    //End Public Read-only Fields
}
