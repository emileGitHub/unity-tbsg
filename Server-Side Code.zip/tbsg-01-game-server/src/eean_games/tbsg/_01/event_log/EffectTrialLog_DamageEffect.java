package eean_games.tbsg._01.event_log;

import java.math.BigDecimal;

import eean_games.tbsg._01.enumerable.eEffectiveness;

public class EffectTrialLog_DamageEffect extends EffectTrialLog_UnitTargetingEffect
{
    public EffectTrialLog_DamageEffect(BigDecimal _eventTurn, int _animationId, boolean _didSucceed, int _targetId, String _targetName, String _targetNickname, int _targetLocationTileIndex,
        boolean _wasImmune, boolean _wasCritical, eEffectiveness _effectiveness, int _value, int _remainingHPAfterModification)
    {
    	super(_eventTurn, _animationId, _didSucceed, _targetId, _targetName, _targetNickname, _targetLocationTileIndex);
    	
        WasImmune = _wasImmune;
        WasCritical = _wasCritical;
        Effectiveness = _effectiveness;

        Value = _value;
        RemainingHPAfterModification = _remainingHPAfterModification;
    }

    //Public Read-only Fields
    public final boolean WasImmune;
    public final boolean WasCritical;
    public final eEffectiveness Effectiveness;

    public final int Value;
    public final int RemainingHPAfterModification;
    //End Public Read-only Fields
}