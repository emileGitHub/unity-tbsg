package eean_games.tbsg._01;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import eean_games.main.CoreFunctions;
import eean_games.main.CoreValues;
import eean_games.main.MTRandom;
import eean_games.main._2DCoord;
import eean_games.main.eRelationType;
import eean_games.main.extension_method.BigDecimalExtension;
import eean_games.tbsg._01.effect.DamageEffect;
import eean_games.tbsg._01.effect.Effect;
import eean_games.tbsg._01.effect.HealEffect;
import eean_games.tbsg._01.effect.IComplexTargetSelectionEffect;
import eean_games.tbsg._01.effect.StatusEffectAttachmentEffect;
import eean_games.tbsg._01.effect.TileSwapEffect;
import eean_games.tbsg._01.effect.UnitSwapEffect;
import eean_games.tbsg._01.effect.UnitTargetingEffect;
import eean_games.tbsg._01.enumerable.eAttackClassification;
import eean_games.tbsg._01.enumerable.eEffectiveness;
import eean_games.tbsg._01.enumerable.eElement;
import eean_games.tbsg._01.enumerable.eEventTriggerTiming;
import eean_games.tbsg._01.enumerable.eModificationMethod;
import eean_games.tbsg._01.enumerable.eRarity;
import eean_games.tbsg._01.enumerable.eStatusType;
import eean_games.tbsg._01.enumerable.eTileType;
import eean_games.tbsg._01.equipment.LevelableWeapon;
import eean_games.tbsg._01.skill.ActiveSkill;
import eean_games.tbsg._01.skill.PassiveSkill;
import eean_games.tbsg._01.skill.Skill;
import eean_games.tbsg._01.status_effect.BuffStatusEffect;
import eean_games.tbsg._01.status_effect.BuffStatusEffectData;
import eean_games.tbsg._01.status_effect.DamageStatusEffect;
import eean_games.tbsg._01.status_effect.DamageStatusEffectData;
import eean_games.tbsg._01.status_effect.DebuffStatusEffect;
import eean_games.tbsg._01.status_effect.DebuffStatusEffectData;
import eean_games.tbsg._01.status_effect.ForegroundStatusEffect;
import eean_games.tbsg._01.status_effect.ForegroundStatusEffectData;
import eean_games.tbsg._01.status_effect.HealStatusEffect;
import eean_games.tbsg._01.status_effect.HealStatusEffectData;
import eean_games.tbsg._01.status_effect.TargetRangeModStatusEffect;
import eean_games.tbsg._01.status_effect.TargetRangeModStatusEffectData;
import eean_games.tbsg._01.unit.Unit;
import eean_games.tbsg._01.unit.UnitInstance;

public final class Calculator
{
    //Public Methods
    public static int RequiredTotalExperienceForLevelUp(int _level)
    {
        int requiredExp = CoreValues.REQUIRED_EXPERIENCE_FOR_FIRST_LEVEL_UP;

        for (int i = 2; i <= _level; i++)
        {
            int tmpExp = BigDecimalExtension.multiply(CoreValues.LEVEL_EXPERIENCE_MULTIPLIER, requiredExp).intValue();
            if (tmpExp != requiredExp)
                requiredExp = tmpExp;
            else
                requiredExp++;
        }

        return requiredExp;
    }

    //The amount of Exp gained after becoming the current level
    public static int LevelExperience(int _accumulatedExp)
    {
        if (_accumulatedExp < 0)
            return -1;

        int accumulatedRequiredExpForLevel = 0;
        int level = Level(_accumulatedExp);

        for (int i = 2; i <= level; i++)
        {
            accumulatedRequiredExpForLevel += RequiredTotalExperienceForLevelUp(i - 1);
        }

        return _accumulatedExp - accumulatedRequiredExpForLevel;
    }

    public static int Level(Unit _unit)
    {
        if (_unit == null)
            return -1;

        return Level(_unit.getAccumulatedExperience());
    }
    public static int Level(int _accumulatedExp)
    {
        int actualLevel = AccumulatedLevel(_accumulatedExp);

        int maxLevel_normal = eRarity.Normal.numericValue();
        int maxLevel_bronze = eRarity.Bronze.numericValue();
        int maxLevel_silver = eRarity.Silver.numericValue();
        int maxLevel_gold = eRarity.Gold.numericValue();

        if (actualLevel > maxLevel_normal) //It must be eRarity.Bronze or higher
            actualLevel -= maxLevel_normal;

        if (actualLevel > maxLevel_bronze) //It must be eRarity.Silver or higher
            actualLevel -= maxLevel_bronze;

        if (actualLevel > maxLevel_silver) //It must be eRarity.Gold or higher
            actualLevel -= maxLevel_silver;

        if (actualLevel > maxLevel_gold) //It must be eRarity.Platinum
            actualLevel -= maxLevel_gold;

        return actualLevel;
    }
    private static int AccumulatedLevel(int _accumulatedExp)
    {
        int accumulatedRequiredExpForLevel = 0;
        int accumulatedRequiredExpForNextLevel = 0;

        int maxAccumulatedLevel = MaxAccumulatedLevelForRarity(eRarity.Platinum);
        
        for (int i = 1; i < maxAccumulatedLevel; i++)
        {
            accumulatedRequiredExpForLevel = accumulatedRequiredExpForNextLevel;
            accumulatedRequiredExpForNextLevel += RequiredTotalExperienceForLevelUp(i);

            if (_accumulatedExp >= accumulatedRequiredExpForLevel && _accumulatedExp < accumulatedRequiredExpForNextLevel)
                return i;
        }

        if (_accumulatedExp < 0)
            return -1;
        else
            return maxAccumulatedLevel;
    }
    private static int AccumulatedLevel(eRarity _rarity, int _actualLevel)
    {
        int maxLevel_normal = eRarity.Normal.numericValue();
        int maxLevel_bronze = eRarity.Bronze.numericValue();
        int maxLevel_silver = eRarity.Silver.numericValue();
        int maxLevel_gold = eRarity.Gold.numericValue();
        int maxLevel_platinum = eRarity.Platinum.numericValue();

        switch (_rarity)
        {
            default: //Normal
                {
                    if (_actualLevel > maxLevel_normal)
                        return -1;
                    return _actualLevel;
                }
            case Bronze:
                {
                    if (_actualLevel > maxLevel_bronze)
                        return -1;
                    return _actualLevel + maxLevel_normal;
                }
            case Silver:
                {
                    if (_actualLevel > maxLevel_silver)
                        return -1;
                    return _actualLevel + maxLevel_normal + maxLevel_bronze;
                }
            case Gold:
                {
                    if (_actualLevel > maxLevel_gold)
                        return -1;
                    return _actualLevel + maxLevel_normal + maxLevel_bronze + maxLevel_silver;
                }
            case Platinum:
                {
                    if (_actualLevel > maxLevel_platinum)
                        return -1;
                    return _actualLevel + maxLevel_normal + maxLevel_bronze + maxLevel_silver + maxLevel_gold;
                }
        }
    }
    private static int MaxAccumulatedLevelForRarity(eRarity _rarity)
    {
        switch (_rarity)
        {
            default: //eRarity.Normal
                return AccumulatedLevel(_rarity, eRarity.Normal.numericValue());
            case Bronze:
                return AccumulatedLevel(_rarity, eRarity.Bronze.numericValue());
            case Silver:
                return AccumulatedLevel(_rarity, eRarity.Silver.numericValue());
            case Gold:
                return AccumulatedLevel(_rarity, eRarity.Gold.numericValue());
            case Platinum:
                return AccumulatedLevel(_rarity, eRarity.Platinum.numericValue());
        }
    }

    public static int MaxHP(Unit _unit)
    {
        if (_unit == null)
            return -1;

        BigDecimal levelRate = BigDecimalExtension.divide(AccumulatedLevel(_unit.getAccumulatedExperience()), MaxAccumulatedLevelForRarity(_unit.BaseInfo.getRarity()));

        return BigDecimalExtension.multiply(levelRate, _unit.BaseInfo.MaxLevel_HP).intValue();
    }
    public static int MaxHP(UnitInstance _unit, BattleSystemCore _system)
    {
        if (_unit == null || _system == null)
            return -1;

        return MaxHP_ActualDefinition(_unit, _system, null, null, null, null, null, null, null, false);
    }
    public static int MaxHP(UnitInstance _unit, BattleSystemCore _system, UnitInstance _skillUser, ActiveSkill _skill, Effect _effect, List<_2DCoord> _targetArea, List<Object> _targets, Object _target, Object _target2ForComplexTargetSelectionEffect, boolean _isTarget2CurrentTarget)
    {
        if (_unit == null
            || _system == null
            || _skill == null
            || _effect == null
            || _targetArea == null)
        {
            return -1;
        }

        return MaxHP_ActualDefinition(_unit, _system, _skillUser, _skill, _effect, _targetArea, _targets, _target, _target2ForComplexTargetSelectionEffect, _isTarget2CurrentTarget);
    }
    private static int MaxHP_ActualDefinition(UnitInstance _unit, BattleSystemCore _system, UnitInstance _skillUser, ActiveSkill _skill, Effect _effect, List<_2DCoord> _targetArea, List<Object> _targets, Object _target, Object _target2ForComplexTargetSelectionEffect, boolean _isTarget2CurrentTarget)
    {
        BigDecimal levelRate = BigDecimalExtension.divide(AccumulatedLevel(_unit.getAccumulatedExperience()), MaxAccumulatedLevelForRarity(_unit.BaseInfo.getRarity()));

        BigDecimal maxHP = BigDecimalExtension.multiply(levelRate, _unit.BaseInfo.MaxLevel_HP);

        maxHP = ApplyBuffAndDebuffStatusEffects_Simple(maxHP, _system, _unit, eStatusType.MaxHP, _skillUser, _skill, _effect, _targetArea, _targets, _target, _target2ForComplexTargetSelectionEffect, _isTarget2CurrentTarget);

        return maxHP.intValue();
    }

    public static int PhysicalStrength(Unit _unit)
    {
        if (_unit == null)
            return -1;

        BigDecimal levelRate = BigDecimalExtension.divide(AccumulatedLevel(_unit.getAccumulatedExperience()), MaxAccumulatedLevelForRarity(_unit.BaseInfo.getRarity()));

        return BigDecimalExtension.multiply(levelRate, _unit.BaseInfo.MaxLevel_PhysicalStrength).intValue();
    }
    public static int PhysicalStrength(UnitInstance _unit, BattleSystemCore _system)
    {
        if (_unit == null || _system == null)
            return -1;

        return PhysicalStrength_ActualDefinition(_unit, _system, null, null, null, null, null, null, null, false);
    }
    public static int PhysicalStrength(UnitInstance _unit, BattleSystemCore _system, UnitInstance _skillUser, ActiveSkill _skill, Effect _effect, List<_2DCoord> _targetArea, List<Object> _targets, Object _target, Object _target2ForComplexTargetSelectionEffect, boolean _isTarget2CurrentTarget)
    {
        if (_unit == null
            || _system == null
            || _skill == null
            || _effect == null
            || _targetArea == null)
        {
            return -1;
        }

        return PhysicalStrength_ActualDefinition(_unit, _system, _skillUser, _skill, _effect, _targetArea, _targets, _target, _target2ForComplexTargetSelectionEffect, _isTarget2CurrentTarget);
    }
    private static int PhysicalStrength_ActualDefinition(UnitInstance _unit, BattleSystemCore _system, UnitInstance _skillUser, ActiveSkill _skill, Effect _effect, List<_2DCoord> _targetArea, List<Object> _targets, Object _target, Object _target2ForComplexTargetSelectionEffect, boolean _isTarget2CurrentTarget)
    {
        BigDecimal levelRate = BigDecimalExtension.divide(AccumulatedLevel(_unit.getAccumulatedExperience()), MaxAccumulatedLevelForRarity(_unit.BaseInfo.getRarity()));

        BigDecimal phyStr = BigDecimalExtension.multiply(levelRate, _unit.BaseInfo.MaxLevel_PhysicalStrength);

        phyStr = ApplyBuffAndDebuffStatusEffects_Simple(phyStr, _system, _unit, eStatusType.PhyStr, _skillUser, _skill, _effect, _targetArea, _targets, _target, _target2ForComplexTargetSelectionEffect, _isTarget2CurrentTarget);

        return phyStr.intValue();
    }

    /// <summary>
    /// PreCondition: _character has been initialized successfully.
    /// PostCondition: Physical Resistance of _character is calculated and returned as int.
    /// </summary>
    /// <param name="_unit"></param>
    /// <returns></returns>
    public static int PhysicalResistance(Unit _unit)
    {
        if (_unit == null)
            return -1;

        BigDecimal levelRate = BigDecimalExtension.divide(AccumulatedLevel(_unit.getAccumulatedExperience()), MaxAccumulatedLevelForRarity(_unit.BaseInfo.getRarity()));

        return BigDecimalExtension.multiply(levelRate, _unit.BaseInfo.MaxLevel_PhysicalResistance).intValue();
    }
    public static int PhysicalResistance(UnitInstance _unit, BattleSystemCore _system)
    {
        if (_unit == null || _system == null)
            return -1;

        return PhysicalResistance_ActualDefinition(_unit, _system, null, null, null, null, null, null, null, false);
    }
    public static int PhysicalResistance(UnitInstance _unit, BattleSystemCore _system, UnitInstance _skillUser, ActiveSkill _skill, Effect _effect, List<_2DCoord> _targetArea, List<Object> _targets, Object _target, Object _target2ForComplexTargetSelectionEffect, boolean _isTarget2CurrentTarget)
    {
        if (_unit == null
            || _system == null
            || _skill == null
            || _effect == null
            || _targetArea == null)
        {
            return -1;
        }

        return PhysicalResistance_ActualDefinition(_unit, _system, _skillUser, _skill, _effect, _targetArea, _targets, _target, _target2ForComplexTargetSelectionEffect, _isTarget2CurrentTarget);
    }
    private static int PhysicalResistance_ActualDefinition(UnitInstance _unit, BattleSystemCore _system, UnitInstance _skillUser, ActiveSkill _skill, Effect _effect, List<_2DCoord> _targetArea, List<Object> _targets, Object _target, Object _target2ForComplexTargetSelectionEffect, boolean _isTarget2CurrentTarget)
    {
        BigDecimal levelRate = BigDecimalExtension.divide(AccumulatedLevel(_unit.getAccumulatedExperience()), MaxAccumulatedLevelForRarity(_unit.BaseInfo.getRarity()));

        BigDecimal phyRes = BigDecimalExtension.multiply(levelRate, _unit.BaseInfo.MaxLevel_PhysicalResistance);

        phyRes = ApplyBuffAndDebuffStatusEffects_Simple(phyRes, _system, _unit, eStatusType.PhyRes, _skillUser, _skill, _effect, _targetArea, _targets, _target, _target2ForComplexTargetSelectionEffect, _isTarget2CurrentTarget);

        return phyRes.intValue();
    }

    /// <summary>
    /// PreCondition: _character has been initialized successfully.
    /// PostCondition: Magical Strength of _character is calculated and returned as int.
    /// </summary>
    /// <param name="_unit"></param>
    /// <returns></returns>
    public static int MagicalStrength(Unit _unit)
    {
        if (_unit == null)
            return -1;

        BigDecimal levelRate = BigDecimalExtension.divide(AccumulatedLevel(_unit.getAccumulatedExperience()), MaxAccumulatedLevelForRarity(_unit.BaseInfo.getRarity()));

        return BigDecimalExtension.multiply(levelRate, _unit.BaseInfo.MaxLevel_MagicalStrength).intValue();
    }
    public static int MagicalStrength(UnitInstance _unit, BattleSystemCore _system)
    {
        if (_unit == null || _system == null)
            return -1;

        return MagicalStrength_ActualDefinition(_unit, _system, null, null, null, null, null, null, null, false);
    }
    public static int MagicalStrength(UnitInstance _unit, BattleSystemCore _system, UnitInstance _skillUser, ActiveSkill _skill, Effect _effect, List<_2DCoord> _targetArea, List<Object> _targets, Object _target, Object _target2ForComplexTargetSelectionEffect, boolean _isTarget2CurrentTarget)
    {
        if (_unit == null
            || _system == null
            || _skill == null
            || _effect == null
            || _targetArea == null)
        {
            return -1;
        }

        return MagicalResistance_ActualDefinition(_unit, _system, _skillUser, _skill, _effect, _targetArea, _targets, _target, _target2ForComplexTargetSelectionEffect, _isTarget2CurrentTarget);
    }
    private static int MagicalStrength_ActualDefinition(UnitInstance _unit, BattleSystemCore _system, UnitInstance _skillUser, ActiveSkill _skill, Effect _effect, List<_2DCoord> _targetArea, List<Object> _targets, Object _target, Object _target2ForComplexTargetSelectionEffect, boolean _isTarget2CurrentTarget)
    {
        BigDecimal levelRate = BigDecimalExtension.divide(AccumulatedLevel(_unit.getAccumulatedExperience()), MaxAccumulatedLevelForRarity(_unit.BaseInfo.getRarity()));

        BigDecimal magStr = BigDecimalExtension.multiply(levelRate, _unit.BaseInfo.MaxLevel_MagicalStrength);

        magStr = ApplyBuffAndDebuffStatusEffects_Simple(magStr, _system, _unit, eStatusType.MagStr, _skillUser, _skill, _effect, _targetArea, _targets, _target, _target2ForComplexTargetSelectionEffect, _isTarget2CurrentTarget);

        return magStr.intValue();
    }

    /// <summary>
    /// PreCondition: _character has been initialized successfully.
    /// PostCondition: Magical Resistance of _character is calculated and returned as int.
    /// </summary>
    /// <param name="_unit"></param>
    /// <returns></returns>
    public static int MagicalResistance(Unit _unit)
    {
        if (_unit == null)
            return -1;

        BigDecimal levelRate = BigDecimalExtension.divide(AccumulatedLevel(_unit.getAccumulatedExperience()), MaxAccumulatedLevelForRarity(_unit.BaseInfo.getRarity()));

        return BigDecimalExtension.multiply(levelRate, _unit.BaseInfo.MaxLevel_MagicalResistance).intValue();
    }
    public static int MagicalResistance(UnitInstance _unit, BattleSystemCore _system)
    {
        if (_unit == null || _system == null)
            return -1;

        return MagicalResistance_ActualDefinition(_unit, _system, null, null, null, null, null, null, null, false);
    }
    public static int MagicalResistance(UnitInstance _unit, BattleSystemCore _system, UnitInstance _skillUser, ActiveSkill _skill, Effect _effect, List<_2DCoord> _targetArea, List<Object> _targets, Object _target, Object _target2ForComplexTargetSelectionEffect, boolean _isTarget2CurrentTarget)
    {
        if (_unit == null
            || _system == null
            || _skill == null
            || _effect == null
            || _targetArea == null)
        {
            return -1;
        }

        return MagicalResistance_ActualDefinition(_unit, _system, _skillUser, _skill, _effect, _targetArea, _targets, _target, _target2ForComplexTargetSelectionEffect, _isTarget2CurrentTarget);
    }
    private static int MagicalResistance_ActualDefinition(UnitInstance _unit, BattleSystemCore _system, UnitInstance _skillUser, ActiveSkill _skill, Effect _effect, List<_2DCoord> _targetArea, List<Object> _targets, Object _target, Object _target2ForComplexTargetSelectionEffect, boolean _isTarget2CurrentTarget)
    {
        BigDecimal levelRate = BigDecimalExtension.divide(AccumulatedLevel(_unit.getAccumulatedExperience()), MaxAccumulatedLevelForRarity(_unit.BaseInfo.getRarity()));

        BigDecimal magRes = BigDecimalExtension.multiply(levelRate, _unit.BaseInfo.MaxLevel_MagicalResistance);

        magRes = ApplyBuffAndDebuffStatusEffects_Simple(magRes, _system, _unit, eStatusType.MagRes, _skillUser, _skill, _effect, _targetArea, _targets, _target, _target2ForComplexTargetSelectionEffect, _isTarget2CurrentTarget);

        return magRes.intValue();
    }

    /// <summary>
    /// PreCondition: _character has been initialized successfully.
    /// PostCondition: Vitality of _character is calculated and returned as int.
    /// </summary>
    /// <param name="_unit"></param>
    /// <returns></returns>
    public static int Vitality(Unit _unit)
    {
        if (_unit == null)
            return -1;

        BigDecimal levelRate = BigDecimalExtension.divide(AccumulatedLevel(_unit.getAccumulatedExperience()), MaxAccumulatedLevelForRarity(_unit.BaseInfo.getRarity()));

        return BigDecimalExtension.multiply(levelRate, _unit.BaseInfo.MaxLevel_Vitality).intValue();
    }
    public static int Vitality(UnitInstance _unit, BattleSystemCore _system)
    {
        if (_unit == null || _system == null)
            return -1;

        return Vitality_ActualDefinition(_unit, _system, null, null, null, null, null, null, null, false);
    }
    public static int Vitality(UnitInstance _unit, BattleSystemCore _system, UnitInstance _skillUser, ActiveSkill _skill, Effect _effect, List<_2DCoord> _targetArea, List<Object> _targets, Object _target, Object _target2ForComplexTargetSelectionEffect, boolean _isTarget2CurrentTarget)
    {
        if (_unit == null
            || _system == null
            || _skill == null
            || _effect == null
            || _targetArea == null)
        {
            return -1;
        }

        return Vitality_ActualDefinition(_unit, _system, _skillUser, _skill, _effect, _targetArea, _targets, _target, _target2ForComplexTargetSelectionEffect, _isTarget2CurrentTarget);
    }
    private static int Vitality_ActualDefinition(UnitInstance _unit, BattleSystemCore _system, UnitInstance _skillUser, ActiveSkill _skill, Effect _effect, List<_2DCoord> _targetArea, List<Object> _targets, Object _target, Object _target2ForComplexTargetSelectionEffect, boolean _isTarget2CurrentTarget)
    {
        BigDecimal levelRate = BigDecimalExtension.divide(AccumulatedLevel(_unit.getAccumulatedExperience()), MaxAccumulatedLevelForRarity(_unit.BaseInfo.getRarity()));

        BigDecimal vit = BigDecimalExtension.multiply(levelRate, _unit.BaseInfo.MaxLevel_Vitality);

        vit = ApplyBuffAndDebuffStatusEffects_Simple(vit, _system, _unit, eStatusType.Vit, _skillUser, _skill, _effect, _targetArea, _targets, _target, _target2ForComplexTargetSelectionEffect, _isTarget2CurrentTarget);

        return vit.intValue();
    }

    public static BigDecimal Precision(UnitInstance _unit, BattleSystemCore _system)
    {
        if (_unit == null || _system == null)
            return BigDecimal.ZERO;

        BigDecimal pre = BigDecimal.ONE;

        pre = ApplyBuffAndDebuffStatusEffects_Simple(pre, _system, _unit, eStatusType.Pre);

        return pre;
    }
    public static BigDecimal Precision(UnitInstance _unit, BattleSystemCore _system, UnitInstance _skillUser, ActiveSkill _skill, Effect _effect, List<_2DCoord> _targetArea, List<Object> _targets, Object _target, Object _target2ForComplexTargetSelectionEffect, boolean _isTarget2CurrentTarget)
    {
        if (_unit == null
            || _system == null
            || _skill == null
            || _effect == null
            || _targetArea == null)
        {
            return BigDecimal.ZERO;
        }

        BigDecimal pre = BigDecimal.ONE;

        pre = ApplyBuffAndDebuffStatusEffects_Simple(pre, _system, _unit, eStatusType.Pre, _skillUser, _skill, _effect, _targetArea, _targets, _target, _target2ForComplexTargetSelectionEffect, _isTarget2CurrentTarget);

        return pre;
    }

    public static BigDecimal Evasion(UnitInstance _unit, BattleSystemCore _system)
    {
        if (_unit == null || _system == null)
            return BigDecimal.ZERO;

        BigDecimal eva = BigDecimal.ONE;

        eva = ApplyBuffAndDebuffStatusEffects_Simple(eva, _system, _unit, eStatusType.Eva);

        return eva;
    }
    public static BigDecimal Evasion(UnitInstance _unit, BattleSystemCore _system, UnitInstance _skillUser, ActiveSkill _skill, Effect _effect, List<_2DCoord> _targetArea, List<Object> _targets, Object _target, Object _target2ForComplexTargetSelectionEffect, boolean _isTarget2CurrentTarget)
    {
        if (_unit == null
            || _system == null
            || _skillUser == null
            || _skill == null
            || _effect == null
            || _targetArea == null
            || _targets == null)
        {
            return BigDecimal.ZERO;
        }

        BigDecimal eva = BigDecimal.ONE;

        eva = ApplyBuffAndDebuffStatusEffects_Simple(eva, _system, _unit, eStatusType.Eva, _skillUser, _skill, _effect, _targetArea, _targets, _target, _target2ForComplexTargetSelectionEffect, _isTarget2CurrentTarget);

        boolean isUnitEqualToTarget = false;
        if (_skill.BaseInfo.getEffect() instanceof UnitTargetingEffect)
        {
            if (_target != null && _unit == _target)
            {
                if (_skill.BaseInfo.getEffect() instanceof IComplexTargetSelectionEffect)
                {
                    if (!_isTarget2CurrentTarget)
                        isUnitEqualToTarget = true;
                }
                else
                    isUnitEqualToTarget = true;
            }

            if (_target2ForComplexTargetSelectionEffect != null && _unit == _target2ForComplexTargetSelectionEffect)
            {
                if (_skill.BaseInfo.getEffect() instanceof IComplexTargetSelectionEffect && _isTarget2CurrentTarget)
                    isUnitEqualToTarget = true;
            }
        }

        if (isUnitEqualToTarget)
        {
            //If _effect is positive to _unit, change the value of eva to its reciprocal. That is, increase _unit's probability to evade the _effect if eva is low and be hit by it if eva is high. Use it as dexterity : this particular case.
            if (IsEffectPositiveForTarget(_unit, _effect, _system))
                eva = BigDecimalExtension.Reciprocal(eva);
        }

        return eva;
    }

    private static boolean IsEffectPositiveForTarget(UnitInstance _target, Effect _effect, BattleSystemCore _system)
    {
        boolean isEffectPositive = false;

        //Set of all possible positive effects
        if (_effect instanceof HealEffect)
            isEffectPositive = true;
        else if (_effect instanceof StatusEffectAttachmentEffect)
        {
        	StatusEffectAttachmentEffect detailedEffect = (StatusEffectAttachmentEffect)_effect;

            if (detailedEffect.getDataOfStatusEffectToAttach() instanceof BuffStatusEffectData
                || detailedEffect.getDataOfStatusEffectToAttach() instanceof HealStatusEffectData)
            {
                isEffectPositive = true;
            }
            else if (detailedEffect.getDataOfStatusEffectToAttach() instanceof TargetRangeModStatusEffectData)
            {
            	TargetRangeModStatusEffectData statusEffectData = (TargetRangeModStatusEffectData)(detailedEffect.getDataOfStatusEffectToAttach());

                if (statusEffectData.ModificationMethod == eModificationMethod.Add // The method of target range modification is addition
                    || (statusEffectData.ModificationMethod == eModificationMethod.Overwrite && RelativeTargetArea(_target, statusEffectData.IsMovementRangeClassification, _system).size() > TargetArea.GetTargetArea(statusEffectData.IsMovementRangeClassification ? _target.BaseInfo.MovementRangeClassification : _target.BaseInfo.NonMovementActionRangeClassification).size()))// OR the method is Overwrite and the total number of targetable coords : the effect's target area is greater than the current target area
                    isEffectPositive = true;
            }
        }
        //End of set of possible postive effects

        return isEffectPositive;
    }

    public static int MaxNumOfTargets(UnitInstance _skillUser, ActiveSkill _skill, List<_2DCoord> _targetArea, BattleSystemCore _system)
    {
        BigDecimal maxNumOfTargets = _skill.BaseInfo.getMaxNumberOfTargets().ToValue(BigDecimal.class, _system, _skillUser, _skill, _targetArea);

        if (_skill.BaseInfo.getEffect() instanceof UnitSwapEffect || _skill.BaseInfo.getEffect() instanceof TileSwapEffect)
            maxNumOfTargets = new BigDecimal("2");

        maxNumOfTargets = ApplyBuffAndDebuffStatusEffects_Simple(maxNumOfTargets, _system, _skillUser, eStatusType.NumOfTargets, _skillUser, _skill, _targetArea);

        return maxNumOfTargets.intValue();
    }

    public static List<_2DCoord> RelativeTargetArea(UnitInstance _unit, boolean _isMovementRangeClassification, BattleSystemCore _system)
    {
        return RelativeTargetArea(_unit, _isMovementRangeClassification, _system, null);
    }
    public static List<_2DCoord> RelativeTargetArea(UnitInstance _unit, boolean _isMovementRangeClassification, BattleSystemCore _system, ActiveSkill _skill)
    {
        List<_2DCoord> relativeTargetArea;
        if (_isMovementRangeClassification)
            relativeTargetArea = TargetArea.GetTargetArea(_unit.BaseInfo.MovementRangeClassification);
        else
            relativeTargetArea = TargetArea.GetTargetArea(_unit.BaseInfo.NonMovementActionRangeClassification);

        if (_skill == null)
            relativeTargetArea = ApplyTargetRangeModStatusEffects(relativeTargetArea, _unit, _isMovementRangeClassification, _system);
        else
        	relativeTargetArea = ApplyTargetRangeModStatusEffects(relativeTargetArea, _unit, _isMovementRangeClassification, _system, _skill, _skill.BaseInfo.getEffect()); // _skill.Effect will actually not be used.

        return relativeTargetArea;
    }

    /// <summary>
    /// PreCondition: _attacker, _defender, _effect, and _board have been initialized successfully; _attacker and _defender are assigned to a _board.Sockets[,]; X,Y values of _attackerCoord and _defenderCoord match the X,Y values : corresponding Sockets;
    /// PostCondition: An int value representing the damage will be returned.
    /// </summary>
    /// <param name="_attacker"></param>
    /// <param name="_effect"></param>
    /// <param name="_defender"></param>
    /// <param name="_attackerCoord"></param>
    /// <param name="_defenderCoord"></param>
    /// <param name="_board"></param>
    /// <param name="isCritical"></param>
    /// <returns></returns>
    public static DamageInfo Damage(BattleSystemCore _system, UnitInstance _attacker, _2DCoord _attackerCoord, ActiveSkill _skill, DamageEffect _effect, List<_2DCoord> _effectRange, List<UnitInstance> _targets, UnitInstance _target, UnitInstance _target2ForComplexTargetSelectionEffect, boolean _isTarget2CurrentTarget)
    {
        if (_system == null
            || _attacker == null
            || _skill == null
            || _effect == null
            || _effectRange == null
            || _target == null
            || _attackerCoord == null)
        {
            return null;
        }

        BigDecimal damage = new BigDecimal(String.valueOf(CoreValues.DAMAGE_BASE_VALUE));

        BigDecimal strength = BigDecimal.ZERO;
        BigDecimal resistance = BigDecimal.ZERO;
        
        List<Object> targets = _targets.stream().map(x -> (Object)x).collect(Collectors.toList());
        UnitInstance defender = (_skill.BaseInfo.getEffect() instanceof IComplexTargetSelectionEffect && _isTarget2CurrentTarget && _target2ForComplexTargetSelectionEffect != null) ? _target2ForComplexTargetSelectionEffect : _target;

        if (_effect.AttackClassification == eAttackClassification.Physic)
        {
            strength = BigDecimalExtension.valueOf(PhysicalStrength(_attacker, _system, _attacker, _skill, _effect, _effectRange, targets, _target, _target2ForComplexTargetSelectionEffect, _isTarget2CurrentTarget));
            resistance = BigDecimalExtension.valueOf(PhysicalResistance(defender, _system, _attacker, _skill, _effect, _effectRange, targets, _target, _target2ForComplexTargetSelectionEffect, _isTarget2CurrentTarget));
        }
        else
        {
            strength = BigDecimalExtension.valueOf(MagicalStrength(_attacker, _system, _attacker, _skill, _effect, _effectRange, targets, _target, _target2ForComplexTargetSelectionEffect, _isTarget2CurrentTarget));
            resistance = BigDecimalExtension.valueOf(MagicalResistance(defender, _system, _attacker, _skill, _effect, _effectRange, targets, _target, _target2ForComplexTargetSelectionEffect, _isTarget2CurrentTarget));
        }

        damage = damage.multiply((strength.divide(resistance)).multiply(BigDecimalExtension.divide(strength, CoreValues.MAX_BASE_ATTRIBUTE_VALUE))); //use BigDecimal to avoid unexpected round ups

        if (!_effect.IsFixedValue)
            damage = damage.multiply(CorrectionRate_Force(_system, _attacker, _skill, _effect, _effectRange, _targets, _target, _target2ForComplexTargetSelectionEffect, _isTarget2CurrentTarget));

        EffectivenessInfo effectivenessInfo = DamageCorrectionRate_Element(_attacker, _effect.Element, defender);
        
        damage = damage.multiply(effectivenessInfo.correctionRate);

        //Based on relation ship between tile type and unit/effect
        damage = damage.multiply(CorrectionRate_TileType(_attacker, _effect, _system.Field.Board.Sockets[_attackerCoord.X][_attackerCoord.Y].TileType));

        boolean isCritical = false;
        if (IsCritical(_attacker, _skill, _effect, _effectRange, _targets, _target, _target2ForComplexTargetSelectionEffect, _isTarget2CurrentTarget, _system))
        {
            damage = damage.multiply(CoreValues.MULTIPLIER_FOR_CRITICALHIT);
            isCritical = true;
        }

        damage = ApplyBuffAndDebuffStatusEffects_Compound(damage, _system, eStatusType.FixedDamage, _attacker, _skill, _effect, _effectRange, _targets, _target, _target2ForComplexTargetSelectionEffect, _isTarget2CurrentTarget); // Applied the buff and debuff effects of effect user and target that are related to damage

        if (CoreFunctions.Compare(damage, eRelationType.LessThan, BigDecimal.ZERO)) // damage must not be a negative value
            damage = BigDecimal.ZERO;

        return new DamageInfo(damage.intValue(), isCritical, effectivenessInfo.effectiveness);
    }

    public static HealInfo HealValue(BattleSystemCore _system, UnitInstance _effectUser, _2DCoord _effectUserCoord, ActiveSkill _skill, HealEffect _effect, List<_2DCoord> _effectRange, List<UnitInstance> _targets, UnitInstance _target, UnitInstance _target2ForComplexTargetSelectionEffect, boolean _isTarget2CurrentTarget)
    {
        if (_system == null
            || _effectUser == null
            || _skill == null
            || _effect == null
            || _effectRange == null
            || _targets == null
            || _target == null
            || _effectUserCoord == null)
        {
            return null;
        }

        BigDecimal restoringHp = BigDecimalExtension.multiply(new BigDecimal("0.05"), (Vitality(_effectUser) + 1) * (Vitality(_target) + 1));

        if (!_effect.IsFixedValue)
            restoringHp = restoringHp.multiply(CorrectionRate_Force(_system, _effectUser, _skill, _effect, _effectRange, _targets, _target, _target2ForComplexTargetSelectionEffect, _isTarget2CurrentTarget));

        //Based on whether the tile is heal tile
        restoringHp = restoringHp.multiply((_system.Field.Board.Sockets[_effectUserCoord.X][_effectUserCoord.Y].TileType == eTileType.Heal) ? CoreValues.MULTIPLIER_FOR_TILETYPEMATCH : BigDecimal.ONE);

        boolean isCritical = false;
        if (IsCritical(_effectUser, _skill, _effect, _effectRange, _targets, _target, _target2ForComplexTargetSelectionEffect, _isTarget2CurrentTarget, _system))
        {
            restoringHp = restoringHp.multiply(CoreValues.MULTIPLIER_FOR_CRITICALHIT);
            isCritical = true;
        }

        restoringHp = ApplyBuffAndDebuffStatusEffects_Compound(restoringHp, _system, eStatusType.FixedHeal, _effectUser, _skill, _effect, _effectRange, _targets, _target, _target2ForComplexTargetSelectionEffect, _isTarget2CurrentTarget); // Applied the buff and debuff effects of effect user and target that are related to healing

        if (CoreFunctions.Compare(restoringHp, eRelationType.LessThan, BigDecimal.ZERO)) // restoringHp must not be a negative value
            restoringHp = BigDecimal.ZERO;

        return new HealInfo(restoringHp.intValue(), isCritical);
    }

    //private static void ApplyBuffAndDebuffStatusEffects(BigDecimal _value, BattleSystemCore _system, UnitInstance _unit, eStatusType _statusType, UnitInstance _skillUser, ActiveSkill _skill, Effect _effect, List<_2DCoord> _effectRange, List<Object> _targets, Object _target, Object _target2ForComplexTargetSelectionEffect, boolean _isTarget2CurrentTarget)
    //{
    //    if (_system == null
    //        || _unit == null)
    //    {
    //        return;
    //    }

    //    ApplyBuffAndDebuffStatusEffects_Compound(ref _value, _system, _unit, _statusType, _skillUser, _skill, _effect, _effectRange, _targets, _target, _target2ForComplexTargetSelectionEffect, _isTarget2CurrentTarget);
    //}

    private static BigDecimal ApplyBuffAndDebuffStatusEffects_Simple(BigDecimal _value, BattleSystemCore _system, UnitInstance _unit, eStatusType _statusType)
    {
        if (_system == null || _unit == null)
            return BigDecimal.ZERO;

        List<BuffStatusEffect> buffStatusEffects = _unit.getStatusEffects().stream().filter(x -> x instanceof BuffStatusEffect).map(x -> (BuffStatusEffect)x).filter(x -> x.TargetStatusType == _statusType).collect(Collectors.toList());
        List<DebuffStatusEffect> debuffStatusEffects = _unit.getStatusEffects().stream().filter(x -> x instanceof DebuffStatusEffect).map(x -> (DebuffStatusEffect)x).filter(x -> x.TargetStatusType == _statusType).collect(Collectors.toList());

        AddPassiveSkillBuffAndDebuffStatusEffects(buffStatusEffects, debuffStatusEffects, _system, _unit, _statusType);
        AddEquipmentBuffAndDebuffStatusEffects(buffStatusEffects, debuffStatusEffects, _system, _unit, _statusType);

        _value = ApplyMultiplicativeBuffStatusEffects(_value, _unit, buffStatusEffects, _system);
        _value = ApplyMultiplicativeDebuffStatusEffects(_value, _unit, debuffStatusEffects, _system);

        _value = ApplySummativeBuffStatusEffects(_value, _unit, buffStatusEffects, _system);
        _value = ApplySummativeDebuffStatusEffects(_value, _unit, debuffStatusEffects, _system);
        
        return _value;
    }
    public static BigDecimal ApplyBuffAndDebuffStatusEffects_Simple(BigDecimal _value, BattleSystemCore _system, UnitInstance _unit, eStatusType _statusType, UnitInstance _skillUser, ActiveSkill _skill, List<_2DCoord> _effectRange)
    {
    	return ApplyBuffAndDebuffStatusEffects_Simple(_value, _system, _unit, _statusType, _skillUser, _skill, null, _effectRange, null, null, null, false);
    }
    public static BigDecimal ApplyBuffAndDebuffStatusEffects_Simple(BigDecimal _value, BattleSystemCore _system, UnitInstance _unit, eStatusType _statusType, UnitInstance _skillUser, ActiveSkill _skill, List<_2DCoord> _effectRange, List<Object> _targets, Object _target, Object _target2ForComplexTargetSelectionEffect, boolean _isTarget2CurrentTarget)
    {
    	return ApplyBuffAndDebuffStatusEffects_Simple(_value, _system, _unit, _statusType, _skillUser, _skill, null, _effectRange, _targets, _target, _target2ForComplexTargetSelectionEffect, _isTarget2CurrentTarget);
    }
    public static BigDecimal ApplyBuffAndDebuffStatusEffects_Simple(BigDecimal _value, BattleSystemCore _system, UnitInstance _unit, eStatusType _statusType, UnitInstance _skillUser, ActiveSkill _skill, Effect _effect, List<_2DCoord> _effectRange, List<Object> _targets, Object _target, Object _target2ForComplexTargetSelectionEffect, boolean _isTarget2CurrentTarget)
    {
        if (_system == null
            || _unit == null
            || _skillUser == null
            || _effect == null)
        {
            return _value;
        }

        if (_unit != _skillUser)
        {
            if (!(_skill.BaseInfo.getEffect() instanceof UnitTargetingEffect))
                return _value;

            if (_target == null || _unit != _target)
            {
                if (_target2ForComplexTargetSelectionEffect == null || _unit != _target2ForComplexTargetSelectionEffect)
                    return _value;

                if (!(_skill.BaseInfo.getEffect() instanceof IComplexTargetSelectionEffect) || !_isTarget2CurrentTarget)
                    return _value;
            }
            else if (_isTarget2CurrentTarget)
                return _value;
        }
        else
        {
            if (_skill.BaseInfo.getEffect() instanceof UnitTargetingEffect)
            {
                if (_target == null && _target2ForComplexTargetSelectionEffect == null)
                    return _value;

                if (_target == null && !_isTarget2CurrentTarget)
                    return _value;

                if (_target2ForComplexTargetSelectionEffect == null && _isTarget2CurrentTarget)
                    return _value;
            }
        }

        //If it did not return, _unit is one of the entities involved in the execution of _skill and _effect.
        //Furthermore, if _unit is the _skillUser, either _skill.BaseInfo.getEffect() does not target objects of UnitInstance OR there exists an appropriate target UnitInstance.

        List<BuffStatusEffect> buffStatusEffects = new ArrayList<BuffStatusEffect>();
        List<DebuffStatusEffect> debuffStatusEffects = new ArrayList<DebuffStatusEffect>();

        // Get buff and debuff status effects
        buffStatusEffects = _unit.getStatusEffects().stream().filter(x -> x instanceof BuffStatusEffect).map(x -> (BuffStatusEffect)x).filter(x -> x.TargetStatusType == _statusType).collect(Collectors.toList());
        debuffStatusEffects = _unit.getStatusEffects().stream().filter(x -> x instanceof DebuffStatusEffect).map(x -> (DebuffStatusEffect)x).filter(x -> x.TargetStatusType == _statusType).collect(Collectors.toList());

        // Get status effects from skills if _skillUser
        if (_unit == _skillUser)
        {
            for (BuffStatusEffectData data : _skill.BaseInfo.getStatusEffectsData().stream().filter(x -> x instanceof BuffStatusEffectData).map(x -> (BuffStatusEffectData)x).filter(x -> x.TargetStatusType == _statusType && _system.DoesStatusEffectActivationPhaseMatch(x, _unit)).collect(Collectors.toList()))
            {
                buffStatusEffects.add(new BuffStatusEffect(data, _skill.Level, true));
            }

            for (DebuffStatusEffectData data : _skill.BaseInfo.getStatusEffectsData().stream().filter(x -> x instanceof DebuffStatusEffectData).map(x -> (DebuffStatusEffectData)x).filter(x -> x.TargetStatusType == _statusType && _system.DoesStatusEffectActivationPhaseMatch(x, _unit)).collect(Collectors.toList()))
            {
                debuffStatusEffects.add(new DebuffStatusEffect(data, _skill.Level, true));
            }
        }

        // Get status effects from passive skills and equipments
        AddPassiveSkillBuffAndDebuffStatusEffects(buffStatusEffects, debuffStatusEffects, _system, _unit, _statusType);
        AddEquipmentBuffAndDebuffStatusEffects(buffStatusEffects, debuffStatusEffects, _system, _unit, _statusType);

        // Apply multiplicative status effects
        _value = ApplyMultiplicativeBuffStatusEffects(_value, _unit, buffStatusEffects, _system, _skillUser, _skill, _effect, _effectRange, _targets, _target, _target2ForComplexTargetSelectionEffect, _isTarget2CurrentTarget);
        _value = ApplyMultiplicativeDebuffStatusEffects(_value, _unit, debuffStatusEffects, _system, _unit, _skill, _effect, _effectRange, _targets, _target, _target2ForComplexTargetSelectionEffect, _isTarget2CurrentTarget);

        // Apply summative status effects
        _value = ApplySummativeBuffStatusEffects(_value, _unit, buffStatusEffects, _system, _skillUser, _skill, _effect, _effectRange, _targets, _target, _target2ForComplexTargetSelectionEffect, _isTarget2CurrentTarget);
        _value = ApplySummativeDebuffStatusEffects(_value, _unit, debuffStatusEffects, _system, _skillUser, _skill, _effect, _effectRange, _targets, _target, _target2ForComplexTargetSelectionEffect, _isTarget2CurrentTarget);
    
        return _value;
    }
    //private static void ApplyBuffAndDebuffStatusEffects_Compound(BigDecimal _value, BattleSystemCore _system, UnitInstance _unit, eStatusType _statusType, UnitInstance _skillUser, ActiveSkill _skill, Effect _effect, List<_2DCoord> _effectRange, List<UnitInstance> _targets, UnitInstance _target, UnitInstance _target2ForComplexTargetSelectionEffect, boolean _isTarget2CurrentTarget)
    //{
    //    if (_system == null
    //        || _unit == null
    //        || _skillUser == null
    //        || _effect == null
    //        || _effectRange == null
    //        || _targets == null
    //        || _target == null)
    //    {
    //        return;
    //    }

    //    if (_unit != _skillUser)
    //    {
    //        if (!(_skill.BaseInfo.getEffect() is UnitTargetingEffect))
    //            return;

    //        if (_unit != _target)
    //        {
    //            if (_target2ForComplexTargetSelectionEffect == null || _unit != _target2ForComplexTargetSelectionEffect)
    //                return;

    //            if (!(_skill.BaseInfo.getEffect() is IComplexTargetSelectionEffect) || !_isTarget2CurrentTarget)
    //                return;
    //        }
    //        else if (_isTarget2CurrentTarget)
    //            return;
    //    }
    //    else
    //    {
    //        if (_skill.BaseInfo.getEffect() is UnitTargetingEffect)
    //        {
    //            if (_target2ForComplexTargetSelectionEffect == null)
    //                return;

    //            if (!_isTarget2CurrentTarget)
    //                return;

    //            if (_target2ForComplexTargetSelectionEffect == null && _isTarget2CurrentTarget)
    //                return;
    //        }
    //    }

    //    //If it did not return, _unit is one of the entities involved : the execution of _skill and _effect.

    //    //Furthermore, if _unit is the _skillUser, either _skill.BaseInfo.getEffect() does not target objects of UnitInstance OR there exists an appropriate target UnitInstance.

    //    List<Object> targets = _targets.stream().map(x -> (Object)x).collect(Collectors.toList());

    //    List<BuffStatusEffect> skillUserBuffStatusEffects = new ArrayList<BuffStatusEffect>();
    //    List<DebuffStatusEffect> skillUserDebuffStatusEffects = new ArrayList<DebuffStatusEffect>();

    //    List<BuffStatusEffect> targetBuffStatusEffects = new ArrayList<BuffStatusEffect>();
    //    List<DebuffStatusEffect> targetDebuffStatusEffects = new ArrayList<DebuffStatusEffect>();

    //    // Get buff and debuff status effects for _skillUser
    //    skillUserBuffStatusEffects = _skillUser.getStatusEffects().stream().filter(x -> x instanceof BuffStatusEffect).map(x -> (BuffStatusEffect)x).filter(x -> x.TargetStatusType == eStatusType.MaxHP).collect(Collectors.toList());
    //    skillUserDebuffStatusEffects = _skillUser.getStatusEffects().stream().filter(x -> x instanceof DebuffStatusEffect).map(x -> (DebuffStatusEffect)x).filter(x -> x.TargetStatusType == eStatusType.MaxHP).collect(Collectors.toList());

    //    for (BuffStatusEffectData data : _skill.BaseInfo.getStatusEffectsData().stream().filter(x -> x instanceof BuffStatusEffect).map(x -> (BuffStatusEffect)x).stream().filter(x -> x.TargetStatusType == _statusType && _system.DoesStatusEffectActivationPhaseMatch(x, _skillUser)))
    //    {
    //        skillUserBuffStatusEffects.add(new BuffStatusEffect(data, null, _skill.Level));
    //    }

    //    for (DebuffStatusEffectData data : _skill.BaseInfo.getStatusEffectsData().stream().filter(x -> x instanceof DebuffStatusEffect).map(x -> (DebuffStatusEffect)x).stream().filter(x -> x.TargetStatusType == _statusType && _system.DoesStatusEffectActivationPhaseMatch(x, _skillUser)))
    //    {
    //        skillUserDebuffStatusEffects.add(new DebuffStatusEffect(data, null, _skill.Level));
    //    }

    //    AddPassiveSkillBuffAndDebuffStatusEffects(ref skillUserBuffStatusEffects, ref skillUserDebuffStatusEffects, _system, _skillUser, _statusType);
    //    AddEquipmentBuffAndDebuffStatusEffects(ref skillUserBuffStatusEffects, ref skillUserDebuffStatusEffects, _system, _skillUser, _statusType);

    //    // Apply multiplicative status effects for _skillUser
    //    ApplyMultiplicativeBuffStatusEffects(ref _value, _skillUser, skillUserBuffStatusEffects, _system, _skillUser, _skill, _effect, _effectRange, targets, _target, _target2ForComplexTargetSelectionEffect);
    //    ApplyMultiplicativeDebuffStatusEffects(ref _value, _skillUser, skillUserDebuffStatusEffects, _system, _skillUser, _skill, _effect, _effectRange, targets, _target, _target2ForComplexTargetSelectionEffect);

    //    // Get buff and debuff status effects for target (if available).
    //    UnitInstance target;
    //    if (_skill.BaseInfo.getEffect() is UnitTargetingEffect)
    //    {
    //        target = (_isTarget2CurrentTarget) ? _target2ForComplexTargetSelectionEffect as UnitInstance : _target as UnitInstance;

    //        targetBuffStatusEffects = target.getStatusEffects().stream().filter(x -> x instanceof BuffStatusEffect).map(x -> (BuffStatusEffect)x).filter(x -> x.TargetStatusType == eStatusType.MaxHP).collect(Collectors.toList());
    //        targetDebuffStatusEffects = target.getStatusEffects().stream().filter(x -> x instanceof DebuffStatusEffect).map(x -> (DebuffStatusEffect)x).filter(x -> x.TargetStatusType == eStatusType.MaxHP).collect(Collectors.toList());

    //        if (_statusType == eStatusType.FixedDamage) // It means that damage dealing effect called this function
    //        {
    //            targetBuffStatusEffects = target.getStatusEffects().OfType<BuffStatusEffect>().stream().filter(x -> x.TargetStatusType == eStatusType.DamageResistance).ToList();
    //            targetDebuffStatusEffects = target.getStatusEffects().OfType<DebuffStatusEffect>().stream().filter(x -> x.TargetStatusType == eStatusType.DamageResistance).ToList();
    //            AddPassiveSkillBuffAndDebuffStatusEffects(ref targetBuffStatusEffects, ref targetDebuffStatusEffects, _system, target, eStatusType.DamageResistance);
    //            AddEquipmentBuffAndDebuffStatusEffects(ref targetBuffStatusEffects, ref targetDebuffStatusEffects, _system, target, eStatusType.DamageResistance);
    //        }
    //        else if (_statusType == eStatusType.FixedHeal) // It means that healin effect called this function
    //        {
    //            targetBuffStatusEffects = target.getStatusEffects().OfType<BuffStatusEffect>().stream().filter(x -> x.TargetStatusType == eStatusType.FixedHeal_Self).ToList();
    //            targetDebuffStatusEffects = target.getStatusEffects().OfType<DebuffStatusEffect>().stream().filter(x -> x.TargetStatusType == eStatusType.FixedHeal_Self).ToList();
    //            AddPassiveSkillBuffAndDebuffStatusEffects(ref targetBuffStatusEffects, ref targetDebuffStatusEffects, _system, target, eStatusType.FixedHeal_Self);
    //            AddEquipmentBuffAndDebuffStatusEffects(ref targetBuffStatusEffects, ref targetDebuffStatusEffects, _system, target, eStatusType.FixedHeal_Self);
    //        }
    //        else if (_statusType == eStatusType.Cri)
    //        {
    //            targetBuffStatusEffects = target.getStatusEffects().OfType<BuffStatusEffect>().stream().filter(x -> x.TargetStatusType == eStatusType.CriRes).ToList();
    //            targetDebuffStatusEffects = target.getStatusEffects().OfType<DebuffStatusEffect>().stream().filter(x -> x.TargetStatusType == eStatusType.CriRes).ToList();
    //            AddPassiveSkillBuffAndDebuffStatusEffects(ref targetBuffStatusEffects, ref targetDebuffStatusEffects, _system, target, eStatusType.CriRes);
    //            AddEquipmentBuffAndDebuffStatusEffects(ref targetBuffStatusEffects, ref targetDebuffStatusEffects, _system, target, eStatusType.CriRes);
    //        }

    //        // Apply multiplicative status effects for target
    //        ApplyMultiplicativeBuffStatusEffects(ref _value, target, targetBuffStatusEffects, _system, _skillUser, _skill, _effect, _effectRange, targets, _target, _target2ForComplexTargetSelectionEffect);
    //        ApplyMultiplicativeDebuffStatusEffects(ref _value, target, targetDebuffStatusEffects, _system, _skillUser, _skill, _effect, _effectRange, targets, _target, _target2ForComplexTargetSelectionEffect);
    //    }

    //    // Apply summative status effects for _skillUser
    //    ApplySummativeBuffStatusEffects(ref _value, _skillUser, skillUserBuffStatusEffects, _system, _skillUser, _skill, _effect, _effectRange, targets, _target, _target2ForComplexTargetSelectionEffect);
    //    ApplySummativeDebuffStatusEffects(ref _value, _skillUser, skillUserDebuffStatusEffects, _system, _skillUser, _skill, _effect, _effectRange, targets, _target, _target2ForComplexTargetSelectionEffect);

    //    if (target != null)
    //    {
    //        // Apply summative status effects for target
    //        ApplySummativeBuffStatusEffects(ref _value, target, targetBuffStatusEffects, _system, _skillUser, _skill, _effect, _effectRange, _targets, _target, _target2ForComplexTargetSelectionEffect);
    //        ApplySummativeDebuffStatusEffects(ref _value, target, targetDebuffStatusEffects, _system, _skillUser, _skill, _effect, _effectRange, _targets, _target, _target2ForComplexTargetSelectionEffect);
    //    }
    //}
    private static BigDecimal ApplyBuffAndDebuffStatusEffects_Compound(BigDecimal _value, BattleSystemCore _system, eStatusType _statusType, UnitInstance _skillUser, ActiveSkill _skill, Effect _effect, List<_2DCoord> _effectRange, List<UnitInstance> _targets, UnitInstance _target, UnitInstance _target2ForComplexTargetSelectionEffect, boolean _isTarget2CurrentTarget)
    {
        if (_system == null
            || _skillUser == null
            || _effect == null
            || _effectRange == null
            || _targets == null
            || _target == null)
        {
            return BigDecimal.ZERO;
        }

        if (_statusType != eStatusType.FixedDamage && _statusType != eStatusType.FixedHeal && _statusType != eStatusType.Cri)
            return BigDecimal.ZERO;

        if (!(_skill.BaseInfo.getEffect() instanceof UnitTargetingEffect))
            return BigDecimal.ZERO;

        UnitInstance target = _target;
        if (_skill.BaseInfo.getEffect() instanceof IComplexTargetSelectionEffect && _isTarget2CurrentTarget)
        {
            if (_target2ForComplexTargetSelectionEffect == null)
                return BigDecimal.ZERO;

            target = _target2ForComplexTargetSelectionEffect;
        }

        List<Object> targets = _targets.stream().map(x -> (Object)x).collect(Collectors.toList());

        List<BuffStatusEffect> skillUserBuffStatusEffects = new ArrayList<BuffStatusEffect>();
        List<DebuffStatusEffect> skillUserDebuffStatusEffects = new ArrayList<DebuffStatusEffect>();

        List<BuffStatusEffect> targetBuffStatusEffects = new ArrayList<BuffStatusEffect>();
        List<DebuffStatusEffect> targetDebuffStatusEffects = new ArrayList<DebuffStatusEffect>();

        // Get buff and debuff status effects for _skillUser
        skillUserBuffStatusEffects = _skillUser.getStatusEffects().stream().filter(x -> x instanceof BuffStatusEffect).map(x -> (BuffStatusEffect)x).filter(x -> x.TargetStatusType == _statusType).collect(Collectors.toList());
        skillUserDebuffStatusEffects = _skillUser.getStatusEffects().stream().filter(x -> x instanceof DebuffStatusEffect).map(x -> (DebuffStatusEffect)x).filter(x -> x.TargetStatusType == _statusType).collect(Collectors.toList());

        for (BuffStatusEffectData data : _skill.BaseInfo.getStatusEffectsData().stream().filter(x -> x instanceof BuffStatusEffectData).map(x -> (BuffStatusEffectData)x).filter(x -> x.TargetStatusType == _statusType && _system.DoesStatusEffectActivationPhaseMatch(x, _skillUser)).collect(Collectors.toList()))
        {
            skillUserBuffStatusEffects.add(new BuffStatusEffect(data, _skill.Level, true));
        }

        for (DebuffStatusEffectData data : _skill.BaseInfo.getStatusEffectsData().stream().filter(x -> x instanceof DebuffStatusEffectData).map(x -> (DebuffStatusEffectData)x).filter(x -> x.TargetStatusType == _statusType && _system.DoesStatusEffectActivationPhaseMatch(x, _skillUser)).collect(Collectors.toList()))
        {
            skillUserDebuffStatusEffects.add(new DebuffStatusEffect(data, _skill.Level, true));
        }

        AddPassiveSkillBuffAndDebuffStatusEffects(skillUserBuffStatusEffects, skillUserDebuffStatusEffects, _system, _skillUser, _statusType);
        AddEquipmentBuffAndDebuffStatusEffects(skillUserBuffStatusEffects, skillUserDebuffStatusEffects, _system, _skillUser, _statusType);

        // Apply multiplicative status effects for _skillUser
        _value = ApplyMultiplicativeBuffStatusEffects(_value, _skillUser, skillUserBuffStatusEffects, _system, _skillUser, _skill, _effect, _effectRange, targets, _target, _target2ForComplexTargetSelectionEffect, _isTarget2CurrentTarget);
        _value = ApplyMultiplicativeDebuffStatusEffects(_value, _skillUser, skillUserDebuffStatusEffects, _system, _skillUser, _skill, _effect, _effectRange, targets, _target, _target2ForComplexTargetSelectionEffect, _isTarget2CurrentTarget);

        targetBuffStatusEffects = target.getStatusEffects().stream().filter(x -> x instanceof BuffStatusEffect).map(x -> (BuffStatusEffect)x).filter(x -> x.TargetStatusType == _statusType).collect(Collectors.toList());
        targetDebuffStatusEffects = target.getStatusEffects().stream().filter(x -> x instanceof DebuffStatusEffect).map(x -> (DebuffStatusEffect)x).filter(x -> x.TargetStatusType == _statusType).collect(Collectors.toList());

        if (_statusType == eStatusType.FixedDamage) // It means that damage dealing effect called this function
        {
            targetBuffStatusEffects = target.getStatusEffects().stream().filter(x -> x instanceof BuffStatusEffect).map(x -> (BuffStatusEffect)x).filter(x -> x.TargetStatusType == eStatusType.DamageResistance).collect(Collectors.toList());
            targetDebuffStatusEffects = target.getStatusEffects().stream().filter(x -> x instanceof DebuffStatusEffect).map(x -> (DebuffStatusEffect)x).filter(x -> x.TargetStatusType == eStatusType.DamageResistance).collect(Collectors.toList());
            AddPassiveSkillBuffAndDebuffStatusEffects(targetBuffStatusEffects, targetDebuffStatusEffects, _system, target, eStatusType.DamageResistance);
            AddEquipmentBuffAndDebuffStatusEffects(targetBuffStatusEffects, targetDebuffStatusEffects, _system, target, eStatusType.DamageResistance);
        }
        else if (_statusType == eStatusType.FixedHeal) // It means that healin effect called this function
        {
            targetBuffStatusEffects = target.getStatusEffects().stream().filter(x -> x instanceof BuffStatusEffect).map(x -> (BuffStatusEffect)x).filter(x -> x.TargetStatusType == eStatusType.FixedHeal_Self).collect(Collectors.toList());
            targetDebuffStatusEffects = target.getStatusEffects().stream().filter(x -> x instanceof DebuffStatusEffect).map(x -> (DebuffStatusEffect)x).filter(x -> x.TargetStatusType == eStatusType.FixedHeal_Self).collect(Collectors.toList());
            AddPassiveSkillBuffAndDebuffStatusEffects(targetBuffStatusEffects, targetDebuffStatusEffects, _system, target, eStatusType.FixedHeal_Self);
            AddEquipmentBuffAndDebuffStatusEffects(targetBuffStatusEffects, targetDebuffStatusEffects, _system, target, eStatusType.FixedHeal_Self);
        }
        else if (_statusType == eStatusType.Cri)
        {
            targetBuffStatusEffects = target.getStatusEffects().stream().filter(x -> x instanceof BuffStatusEffect).map(x -> (BuffStatusEffect)x).filter(x -> x.TargetStatusType == eStatusType.CriRes).collect(Collectors.toList());
            targetDebuffStatusEffects = target.getStatusEffects().stream().filter(x -> x instanceof DebuffStatusEffect).map(x -> (DebuffStatusEffect)x).filter(x -> x.TargetStatusType == eStatusType.CriRes).collect(Collectors.toList());
            AddPassiveSkillBuffAndDebuffStatusEffects(targetBuffStatusEffects, targetDebuffStatusEffects, _system, target, eStatusType.CriRes);
            AddEquipmentBuffAndDebuffStatusEffects(targetBuffStatusEffects, targetDebuffStatusEffects, _system, target, eStatusType.CriRes);
        }

        // Apply multiplicative status effects for target
        _value = ApplyMultiplicativeBuffStatusEffects(_value, target, targetBuffStatusEffects, _system, _skillUser, _skill, _effect, _effectRange, targets, _target, _target2ForComplexTargetSelectionEffect, _isTarget2CurrentTarget);
        _value = ApplyMultiplicativeDebuffStatusEffects(_value, target, targetDebuffStatusEffects, _system, _skillUser, _skill, _effect, _effectRange, targets, _target, _target2ForComplexTargetSelectionEffect, _isTarget2CurrentTarget);

        // Apply summative status effects for _skillUser
        _value = ApplySummativeBuffStatusEffects(_value, _skillUser, skillUserBuffStatusEffects, _system, _skillUser, _skill, _effect, _effectRange, targets, _target, _target2ForComplexTargetSelectionEffect, _isTarget2CurrentTarget);
        _value = ApplySummativeDebuffStatusEffects(_value, _skillUser, skillUserDebuffStatusEffects, _system, _skillUser, _skill, _effect, _effectRange, targets, _target, _target2ForComplexTargetSelectionEffect, _isTarget2CurrentTarget);

        // Apply summative status effects for target
        _value = ApplySummativeBuffStatusEffects(_value, target, targetBuffStatusEffects, _system, _skillUser, _skill, _effect, _effectRange, targets, _target, _target2ForComplexTargetSelectionEffect, _isTarget2CurrentTarget);
        _value = ApplySummativeDebuffStatusEffects(_value, target, targetDebuffStatusEffects, _system, _skillUser, _skill, _effect, _effectRange, targets, _target, _target2ForComplexTargetSelectionEffect, _isTarget2CurrentTarget);
    
        return _value;
    }

    private static void AddPassiveSkillBuffAndDebuffStatusEffects(List<BuffStatusEffect> _buffStatusEffects, List<DebuffStatusEffect> _debuffStatusEffects, BattleSystemCore _system, UnitInstance _unit, eStatusType _statusType)
    {
        if (_buffStatusEffects == null
            || _debuffStatusEffects == null
            || _system == null
            || _unit == null)
        {
            return;
        }

        for (PassiveSkill passiveSkill : _unit.getSkills().stream().filter(x -> x instanceof PassiveSkill).map(x -> (PassiveSkill)x).collect(Collectors.toList()))
        {
            for (BuffStatusEffectData data : passiveSkill.BaseInfo.getStatusEffectsData().stream().filter(x -> x instanceof BuffStatusEffectData).map(x -> (BuffStatusEffectData)x).filter(x -> x.TargetStatusType == _statusType && _system.DoesStatusEffectActivationPhaseMatch(x, _unit)).collect(Collectors.toList()))
            {
                _buffStatusEffects.add(new BuffStatusEffect(data, passiveSkill.Level, true));
            }
            for (DebuffStatusEffectData data : passiveSkill.BaseInfo.getStatusEffectsData().stream().filter(x -> x instanceof DebuffStatusEffectData).map(x -> (DebuffStatusEffectData)x).filter(x -> x.TargetStatusType == _statusType && _system.DoesStatusEffectActivationPhaseMatch(x, _unit)).collect(Collectors.toList()))
            {
                _debuffStatusEffects.add(new DebuffStatusEffect(data, passiveSkill.Level, true));
            }
        }

        if (_unit.InheritedSkill instanceof PassiveSkill)
        {
            for (BuffStatusEffectData data : _unit.InheritedSkill.BaseInfo.getStatusEffectsData().stream().filter(x -> x instanceof BuffStatusEffectData).map(x -> (BuffStatusEffectData)x).filter(x -> x.TargetStatusType == _statusType && _system.DoesStatusEffectActivationPhaseMatch(x, _unit)).collect(Collectors.toList()))
            {
                _buffStatusEffects.add(new BuffStatusEffect(data, _unit.InheritedSkill.Level, true));
            }
            for (DebuffStatusEffectData data : _unit.InheritedSkill.BaseInfo.getStatusEffectsData().stream().filter(x -> x instanceof DebuffStatusEffectData).map(x -> (DebuffStatusEffectData)x).filter(x -> x.TargetStatusType == _statusType && _system.DoesStatusEffectActivationPhaseMatch(x, _unit)).collect(Collectors.toList()))
            {
                _debuffStatusEffects.add(new DebuffStatusEffect(data, _unit.InheritedSkill.Level, true));
            }
        }
    }

    private static void AddEquipmentBuffAndDebuffStatusEffects(List<BuffStatusEffect> _buffStatusEffects, List<DebuffStatusEffect> _debuffStatusEffects, BattleSystemCore _system, UnitInstance _equipmentOwner, eStatusType _statusType)
    {
        if (_buffStatusEffects == null
            || _debuffStatusEffects == null
            || _system == null
            || _equipmentOwner == null)
        {
            return;
        }

        if (_equipmentOwner.MainWeapon != null)
        {
            int mainWeaponLevel = (_equipmentOwner.MainWeapon instanceof LevelableWeapon) ? Level(((LevelableWeapon)(_equipmentOwner.MainWeapon)).getAccumulatedExperience()) : 0;
            for (BuffStatusEffectData data : _equipmentOwner.MainWeapon.BaseInfo.getStatusEffectsData().stream().filter(x -> x instanceof BuffStatusEffectData).map(x -> (BuffStatusEffectData)x).filter(x -> x.TargetStatusType == _statusType && _system.DoesStatusEffectActivationPhaseMatch(x, _equipmentOwner)).collect(Collectors.toList()))
            {
                _buffStatusEffects.add(new BuffStatusEffect(data, mainWeaponLevel, false));
            }
            for (DebuffStatusEffectData data : _equipmentOwner.MainWeapon.BaseInfo.getStatusEffectsData().stream().filter(x -> x instanceof DebuffStatusEffectData).map(x -> (DebuffStatusEffectData)x).filter(x -> x.TargetStatusType == _statusType && _system.DoesStatusEffectActivationPhaseMatch(x, _equipmentOwner)).collect(Collectors.toList()))
            {
                _debuffStatusEffects.add(new DebuffStatusEffect(data, mainWeaponLevel, false));
            }

            if (_equipmentOwner.MainWeapon.BaseInfo.MainWeaponSkill != null && _equipmentOwner.MainWeapon.BaseInfo.MainWeaponSkill instanceof PassiveSkill)
            {
                for (BuffStatusEffectData data : _equipmentOwner.MainWeapon.BaseInfo.MainWeaponSkill.BaseInfo.getStatusEffectsData().stream().filter(x -> x instanceof BuffStatusEffectData).map(x -> (BuffStatusEffectData)x).filter(x -> x.TargetStatusType == _statusType && _system.DoesStatusEffectActivationPhaseMatch(x, _equipmentOwner)).collect(Collectors.toList()))
                {
                    _buffStatusEffects.add(new BuffStatusEffect(data, _equipmentOwner.MainWeapon.BaseInfo.MainWeaponSkill.Level, mainWeaponLevel));
                }
                for (DebuffStatusEffectData data : _equipmentOwner.MainWeapon.BaseInfo.MainWeaponSkill.BaseInfo.getStatusEffectsData().stream().filter(x -> x instanceof DebuffStatusEffectData).map(x -> (DebuffStatusEffectData)x).filter(x -> x.TargetStatusType == _statusType && _system.DoesStatusEffectActivationPhaseMatch(x, _equipmentOwner)).collect(Collectors.toList()))
                {
                    _debuffStatusEffects.add(new DebuffStatusEffect(data, _equipmentOwner.MainWeapon.BaseInfo.MainWeaponSkill.Level, mainWeaponLevel));
                }
            }
        }

        if (_equipmentOwner.SubWeapon != null)
        {
            int subWeaponLevel = (_equipmentOwner.SubWeapon instanceof LevelableWeapon) ? Level(((LevelableWeapon)(_equipmentOwner.SubWeapon)).getAccumulatedExperience()) : 0;
            for (BuffStatusEffectData data : _equipmentOwner.SubWeapon.BaseInfo.getStatusEffectsData().stream().filter(x -> x instanceof BuffStatusEffectData).map(x -> (BuffStatusEffectData)x).filter(x -> x.TargetStatusType == _statusType && _system.DoesStatusEffectActivationPhaseMatch(x, _equipmentOwner)).collect(Collectors.toList()))
            {
                _buffStatusEffects.add(new BuffStatusEffect(data, subWeaponLevel, false));
            }
            for (DebuffStatusEffectData data : _equipmentOwner.SubWeapon.BaseInfo.getStatusEffectsData().stream().filter(x -> x instanceof DebuffStatusEffectData).map(x -> (DebuffStatusEffectData)x).filter(x -> x.TargetStatusType == _statusType && _system.DoesStatusEffectActivationPhaseMatch(x, _equipmentOwner)).collect(Collectors.toList()))
            {
                _debuffStatusEffects.add(new DebuffStatusEffect(data, subWeaponLevel, false));
            }
        }

        if (_equipmentOwner.Armour != null)
        {
            for (BuffStatusEffectData data : _equipmentOwner.Armour.BaseInfo.getStatusEffectsData().stream().filter(x -> x instanceof BuffStatusEffectData).map(x -> (BuffStatusEffectData)x).filter(x -> x.TargetStatusType == _statusType && _system.DoesStatusEffectActivationPhaseMatch(x, _equipmentOwner)).collect(Collectors.toList()))
            {
                _buffStatusEffects.add(new BuffStatusEffect(data));
            }
            for (DebuffStatusEffectData data : _equipmentOwner.Armour.BaseInfo.getStatusEffectsData().stream().filter(x -> x instanceof DebuffStatusEffectData).map(x -> (DebuffStatusEffectData)x).filter(x -> x.TargetStatusType == _statusType && _system.DoesStatusEffectActivationPhaseMatch(x, _equipmentOwner)).collect(Collectors.toList()))
            {
                _debuffStatusEffects.add(new DebuffStatusEffect(data));
            }
        }

        if (_equipmentOwner.Accessory != null)
        {
            for (BuffStatusEffectData data : _equipmentOwner.Accessory.BaseInfo.getStatusEffectsData().stream().filter(x -> x instanceof BuffStatusEffectData).map(x -> (BuffStatusEffectData)x).filter(x -> x.TargetStatusType == _statusType && _system.DoesStatusEffectActivationPhaseMatch(x, _equipmentOwner)).collect(Collectors.toList()))
            {
                _buffStatusEffects.add(new BuffStatusEffect(data));
            }
            for (DebuffStatusEffectData data : _equipmentOwner.Accessory.BaseInfo.getStatusEffectsData().stream().filter(x -> x instanceof DebuffStatusEffectData).map(x -> (DebuffStatusEffectData)x).filter(x -> x.TargetStatusType == _statusType && _system.DoesStatusEffectActivationPhaseMatch(x, _equipmentOwner)).collect(Collectors.toList()))
            {
                _debuffStatusEffects.add(new DebuffStatusEffect(data));
            }
        }
    }

    private static BigDecimal ApplyMultiplicativeBuffStatusEffects(BigDecimal _value, UnitInstance _effectHolder, List<BuffStatusEffect> _buffStatusEffects, BattleSystemCore _system)
    {
    	return ApplyMultiplicativeBuffStatusEffects(_value, _effectHolder, _buffStatusEffects, _system, null, null, null, null, null, null, null, false);
    }
    private static BigDecimal ApplyMultiplicativeBuffStatusEffects(BigDecimal _value, UnitInstance _effectHolder, List<BuffStatusEffect> _buffStatusEffects, BattleSystemCore _system, UnitInstance _skillUser, ActiveSkill _skill, Effect _effect, List<_2DCoord> _effectRange, List<Object> _targets, Object _target, Object _target2ForComplexTargetSelectionEffect, boolean _isTarget2CurrentTarget)
    {
        if (_effectHolder == null || _buffStatusEffects == null || _system == null)
            return BigDecimal.ZERO;

        for (BuffStatusEffect bse : _buffStatusEffects.stream().filter(x -> !x.IsSum).collect(Collectors.toList()))
        {
            if (bse.getActivationCondition().IsTrue(_system, _effectHolder, bse, _skillUser, _skill, _effect, _effectRange, _targets, _target, _target2ForComplexTargetSelectionEffect, _isTarget2CurrentTarget))
            {
                BigDecimal effectValue = bse.getValue().ToValue(BigDecimal.class, _system, _effectHolder, bse, _skillUser, _skill, _effect, _effectRange, _targets, _target, _target2ForComplexTargetSelectionEffect, _isTarget2CurrentTarget);

                if (bse.TargetStatusType != eStatusType.DamageResistance && bse.TargetStatusType != eStatusType.CriRes)
                {
                    if (CoreFunctions.Compare(effectValue, eRelationType.GreaterThanOrEqualTo, BigDecimal.ONE)) // _value must not become negative. Furthermore, if effect value is less than 1, then multiplying _value by it means that _value decreases. That is, bse would no longer be a buff (positive) status effect.
                        _value = _value.multiply(effectValue);
                }
                else // As exception, _value must not increase.
                {
                    if (CoreFunctions.Compare(effectValue, eRelationType.GreaterThanOrEqualTo, BigDecimal.ONE))
                        _value = _value.divide(effectValue);
                }

                if (bse.getDuration().ActivationTimes > 0)
                    bse.getDuration().ActivationTimes--; // Subtract one from the remaining activation times
            }
        }
        
        return _value;
    }
    private static BigDecimal ApplyMultiplicativeDebuffStatusEffects(BigDecimal _value, UnitInstance _effectHolder, List<DebuffStatusEffect> _debuffStatusEffects, BattleSystemCore _system)
    {
    	return ApplyMultiplicativeDebuffStatusEffects(_value, _effectHolder, _debuffStatusEffects, _system, null, null, null, null, null, null, null, false);
    }
    private static BigDecimal ApplyMultiplicativeDebuffStatusEffects(BigDecimal _value, UnitInstance _effectHolder, List<
        DebuffStatusEffect> _debuffStatusEffects, BattleSystemCore _system, UnitInstance _skillUser, ActiveSkill _skill, Effect _effect, List<_2DCoord> _effectRange, List<Object> _targets, Object _target, Object _target2ForComplexTargetSelectionEffect, boolean _isTarget2CurrentTarget)
    {
        if (_effectHolder == null || _debuffStatusEffects == null || _system == null)
            return BigDecimal.ZERO;

        for (DebuffStatusEffect dse : _debuffStatusEffects.stream().filter(x -> !x.IsSum).collect(Collectors.toList()))
        {
            if (dse.getActivationCondition().IsTrue(_system, _effectHolder, dse, _skillUser, _skill, _effect, _effectRange, _targets, _target, _target2ForComplexTargetSelectionEffect, _isTarget2CurrentTarget))
            {
                BigDecimal effectValue = dse.getValue().ToValue(BigDecimal.class, _system, _effectHolder, dse, _skillUser, _skill, _effect, _effectRange, _targets, _target, _target2ForComplexTargetSelectionEffect, _isTarget2CurrentTarget);

                if (dse.TargetStatusType != eStatusType.DamageResistance && dse.TargetStatusType != eStatusType.CriRes)

                {
                    if (CoreFunctions.Compare(effectValue, eRelationType.GreaterThanOrEqualTo, BigDecimal.ONE)) // _value must not become negative. Furthermore, if effect value is less than 1, then dividing _value by it means that _value increases. That is, dse would no longer be a debuff (negative) status effect.
                        _value = _value.divide(effectValue);
                }
                else // As exception, _value must not decrease
                {
                    if (CoreFunctions.Compare(effectValue, eRelationType.GreaterThanOrEqualTo, BigDecimal.ONE))
                        _value = _value.multiply(effectValue);
                }

                if (dse.getDuration().ActivationTimes > 0)
                    dse.getDuration().ActivationTimes--; // Subtract one from the remaining activation times
            }
        }
        
        return _value;
    }

    private static BigDecimal ApplySummativeBuffStatusEffects(BigDecimal _value, UnitInstance _effectHolder, List<BuffStatusEffect> _buffStatusEffects, BattleSystemCore _system)
    {
    	return ApplyMultiplicativeBuffStatusEffects(_value, _effectHolder, _buffStatusEffects, _system, null, null, null, null, null, null, null, false);
    }
    private static BigDecimal ApplySummativeBuffStatusEffects(BigDecimal _value, UnitInstance _effectHolder, List<BuffStatusEffect> _buffStatusEffects, BattleSystemCore _system, UnitInstance _skillUser, ActiveSkill _skill, Effect _effect, List<_2DCoord> _effectRange, List<Object> _targets, Object _target, Object _target2ForComplexTargetSelectionEffect, boolean _isTarget2CurrentTarget)
    {
        if (_effectHolder == null || _buffStatusEffects == null || _system == null)
            return BigDecimal.ZERO;

        for (BuffStatusEffect bse : _buffStatusEffects.stream().filter(x -> x.IsSum).collect(Collectors.toList()))
        {
            if (bse.getActivationCondition().IsTrue(_system, _effectHolder, bse, _skillUser, _skill, _effect, _effectRange, _targets, _target, _target2ForComplexTargetSelectionEffect, _isTarget2CurrentTarget))
            {
                BigDecimal effectValue = bse.getValue().ToValue(BigDecimal.class, _system, _effectHolder, bse, _skillUser, _skill, _effect, _effectRange, _targets, _target, _target2ForComplexTargetSelectionEffect, _isTarget2CurrentTarget);

                if (bse.TargetStatusType != eStatusType.DamageResistance && bse.TargetStatusType != eStatusType.CriRes)
                {
                    if (CoreFunctions.Compare(effectValue, eRelationType.GreaterThanOrEqualTo, BigDecimal.ZERO)) // If effect value is negative, then adding it to _value means that _value decreases. That is, bse would no longer be a buff (positive) status effect.
                        _value = _value.add(effectValue);
                }
                else // As exception, _value must not increase. However, _value must not become negative either.
                {
                    if (CoreFunctions.Compare(effectValue, eRelationType.LessThanOrEqualTo, _value))
                        _value = _value.subtract(effectValue);
                }

                if (bse.getDuration().ActivationTimes > 0)
                    bse.getDuration().ActivationTimes--; // Subtract one from the remaining activation times
            }
        }
        
        return _value;
    }
    private static BigDecimal ApplySummativeDebuffStatusEffects(BigDecimal _value, UnitInstance _effectHolder, List<DebuffStatusEffect> _debuffStatusEffects, BattleSystemCore _system)
    {
    	return ApplyMultiplicativeDebuffStatusEffects(_value, _effectHolder, _debuffStatusEffects, _system, null, null, null, null, null, null, null, false);
    }
    private static BigDecimal ApplySummativeDebuffStatusEffects(BigDecimal _value, UnitInstance _effectHolder, List<DebuffStatusEffect> _debuffStatusEffects, BattleSystemCore _system, UnitInstance _skillUser, ActiveSkill _skill, Effect _effect, List<_2DCoord> _effectRange, List<Object> _targets, Object _target, Object _target2ForComplexTargetSelectionEffect, boolean _isTarget2CurrentTarget)
    {
        if (_effectHolder == null || _debuffStatusEffects == null || _system == null)
            return BigDecimal.ZERO;

        for (DebuffStatusEffect dse : _debuffStatusEffects.stream().filter(x -> x.IsSum).collect(Collectors.toList()))
        {
            if (dse.getActivationCondition().IsTrue(_system, _effectHolder, dse, _skillUser, _skill, _effect, _effectRange, _targets, _target, _target2ForComplexTargetSelectionEffect, _isTarget2CurrentTarget))
            {
                BigDecimal effectValue = dse.getValue().ToValue(BigDecimal.class, _system, _effectHolder, dse, _skillUser, _skill, _effect, _effectRange, _targets, _target, _target2ForComplexTargetSelectionEffect, _isTarget2CurrentTarget);

                if (dse.TargetStatusType != eStatusType.DamageResistance && dse.TargetStatusType != eStatusType.CriRes)
                {
                    if (CoreFunctions.Compare(effectValue, eRelationType.GreaterThanOrEqualTo, _value)) // _value must not become negative. Furthermore, if effect value is negative, then subtracting it from _value means that _value increases. That is, dse would no longer be a debuff (negative) status effect.
                        _value = _value.subtract(effectValue);
                }
                else // As exception, _valude must not decrease.
                {
                    if (CoreFunctions.Compare(effectValue, eRelationType.GreaterThanOrEqualTo, BigDecimal.ZERO))
                        _value = _value.add(effectValue);
                }

                if (dse.getDuration().ActivationTimes > 0)
                    dse.getDuration().ActivationTimes--; // Subtract one from the remaining activation times
            }
        }
        
        return _value;
    }

    //public static void ApplyMultipleBuffStatusEffects(BigDecimal _value, UnitInstance _unit, List<eStatusType> _statusTypes, BattleSystemCore _system, ActiveSkill _skill)
    //{
    //    _statusTypes = _statusTypes.Distinct().ToList();

    //    List<BuffStatusEffect> buffStatusEffects = new ArrayList<BuffStatusEffect>();
    //    for (eStatusType statusType : _statusTypes)
    //    {
    //        buffStatusEffects.addRange(_unit.getStatusEffects().OfType<BuffStatusEffect>().stream().filter(x -> x.TargetStatusType == statusType).ToList());

    //        if (_skill != null)
    //            buffStatusEffects.addRange(_skill.TemporalStatusEffects.OfType<BuffStatusEffect>().stream().filter(x -> x.TargetStatusType == statusType).ToList());
    //    }

    //    for (BuffStatusEffect bse : buffStatusEffects.stream().filter(x -> !x.IsSum))
    //    {
    //        if (bse.getActivationCondition().IsTrue(_system, _unit))
    //        {
    //            BigDecimal effectValue = bse.getValue().ToValue(BigDecimal.class, _system);
    //            if (effectValue > 0) // If effect value is 0 or negative, then multiplying _value by it means that _value decreases. That is, bse would no longer be a buff (positive) status effect.
    //                _value = _value.multiply(effectValue);
    //        }
    //    }

    //    for (BuffStatusEffect bse : buffStatusEffects.stream().filter(x -> x.IsSum))
    //    {
    //        if (bse.getActivationCondition().IsTrue(_system, _unit))
    //        {
    //            BigDecimal effectValue = bse.getValue().ToValue(BigDecimal.class, _system);
    //            if (CoreFunctions.Compare(effectValue, eRelationType.GreaterThanOrEqualTo, BigDecimal.ZERO)) // If effect value is negative, then adding it to _value means that _value decreases. That is, bse would no longer be a buff (positive) status effect.
    //                _value = _value.add(effectValue);
    //        }
    //    }

    //    for (BuffStatusEffect bse : buffStatusEffects)
    //    {
    //        if (bse.getDuration().ActivationTimes > 0) // If it could be activated more than once
    //            bse.getDuration().ActivationTimes--; // Subtract one from the remaining activation times
    //    }
    //}

    public static List<_2DCoord> ApplyTargetRangeModStatusEffects(List<_2DCoord> _targetRange, UnitInstance _effectHolder, boolean _isMovementRangeClassification, BattleSystemCore _system)
    {
        if (_targetRange == null
            || _effectHolder == null
            || _system == null)
        {
            return null;
        }

        return ApplyTargetRangeModStatusEffects_ActualDefinition(_targetRange, _effectHolder, _isMovementRangeClassification, _system, null, null);
    }
    public static List<_2DCoord> ApplyTargetRangeModStatusEffects(List<_2DCoord> _targetRange, UnitInstance _effectHolder, boolean _isMovementRangeClassification, BattleSystemCore _system, ActiveSkill _skill, Effect _effect)
    {
        if (_targetRange == null
            || _effectHolder == null
            || _system == null
            || _skill == null
            || _effect == null)
        {
            return null;
        }

        return ApplyTargetRangeModStatusEffects_ActualDefinition(_targetRange, _effectHolder, _isMovementRangeClassification, _system, _skill, _effect);
    }
    private static List<_2DCoord> ApplyTargetRangeModStatusEffects_ActualDefinition(List<_2DCoord> _targetRange, UnitInstance _effectHolder, boolean _isMovementRangeClassification, BattleSystemCore _system, Skill _skill, Effect _effect)
    {
        List<TargetRangeModStatusEffect> targetRangeModStatusEffects = _effectHolder.getStatusEffects().stream().filter(x -> x instanceof TargetRangeModStatusEffect).map(x -> (TargetRangeModStatusEffect)x).filter(x -> x.IsMovementRangeClassification == _isMovementRangeClassification).collect(Collectors.toList());

        AddPassiveSkillTargetRangeModStatusEffects(targetRangeModStatusEffects, _system, _effectHolder);
        AddEquipmentTargetRangeModStatusEffects(targetRangeModStatusEffects, _system, _effectHolder);

        if (_skill != null && !_isMovementRangeClassification)
        {
            for (TargetRangeModStatusEffectData data : _skill.BaseInfo.getStatusEffectsData().stream().filter(x -> x instanceof TargetRangeModStatusEffectData).map(x -> (TargetRangeModStatusEffectData)x).collect(Collectors.toList()))
            {
                targetRangeModStatusEffects.add(new TargetRangeModStatusEffect(data));
            }
        }

        // If there is at least one status effect such that its modification method is 'Overwrite,'
        // get a list of status effects where modification method is Overwrite.
        // Then apply only the last status effect : such list.
        if (targetRangeModStatusEffects.stream().anyMatch(x -> x.ModificationMethod == eModificationMethod.Overwrite))
        {
            targetRangeModStatusEffects = targetRangeModStatusEffects.stream().filter(x -> x.ModificationMethod == eModificationMethod.Overwrite).collect(Collectors.toList());
            _targetRange = TargetArea.GetTargetArea(targetRangeModStatusEffects.get(targetRangeModStatusEffects.size() - 1).TargetRangeClassification);
        }
        else
        {
            // Add each target range allowing duplicates
            for (TargetRangeModStatusEffect trmse : targetRangeModStatusEffects.stream().filter(x -> x.ModificationMethod == eModificationMethod.Add).collect(Collectors.toList()))
            {
                if (trmse.getActivationCondition().IsTrue(_system, _effectHolder, trmse, _effectHolder, _skill, _effect))
                    _targetRange.addAll(TargetArea.GetTargetArea(trmse.TargetRangeClassification));
            }

            // For each coordinate : each target range, subtract the first occurence of the coordinate from _targetRange if it contains the coordinate
            for (TargetRangeModStatusEffect trmse : targetRangeModStatusEffects.stream().filter(x -> x.ModificationMethod == eModificationMethod.Subtract).collect(Collectors.toList()))
            {
                if (trmse.getActivationCondition().IsTrue(_system, _effectHolder, trmse, _effectHolder, _skill, _effect))
                {
                    for (_2DCoord coord : TargetArea.GetTargetArea(trmse.TargetRangeClassification))
                    {
                        _targetRange.remove(coord);
                    }
                }
            }

            // Remove duplicates
            _targetRange = _targetRange.stream().distinct().collect(Collectors.toList());
        }
        
        return _targetRange;
    }

    private static void AddPassiveSkillTargetRangeModStatusEffects(List<TargetRangeModStatusEffect> _targetRangeModStatusEffects, BattleSystemCore _system, UnitInstance _unit)
    {
        if (_targetRangeModStatusEffects == null
            || _system == null
            || _unit == null)
        {
            return;
        }

        for (PassiveSkill passiveSkill : _unit.getSkills().stream().filter(x -> x instanceof PassiveSkill).map(x -> (PassiveSkill)x).collect(Collectors.toList()))
        {
            for (TargetRangeModStatusEffectData data : passiveSkill.BaseInfo.getStatusEffectsData().stream().filter(x -> x instanceof TargetRangeModStatusEffectData).map(x -> (TargetRangeModStatusEffectData)x).collect(Collectors.toList()))
            {
                _targetRangeModStatusEffects.add(new TargetRangeModStatusEffect(data, passiveSkill.Level, true));
            }
        }

        if (_unit.InheritedSkill instanceof PassiveSkill)
        {
            for (TargetRangeModStatusEffectData data : _unit.InheritedSkill.BaseInfo.getStatusEffectsData().stream().filter(x -> x instanceof TargetRangeModStatusEffectData).map(x -> (TargetRangeModStatusEffectData)x).collect(Collectors.toList()))
            {
                _targetRangeModStatusEffects.add(new TargetRangeModStatusEffect(data, _unit.InheritedSkill.Level, true));
            }
        }
    }

    private static void AddEquipmentTargetRangeModStatusEffects(List<TargetRangeModStatusEffect> _targetRangeModStatusEffects, BattleSystemCore _system, UnitInstance _equipmentOwner)
    {
        if (_targetRangeModStatusEffects == null
            || _system == null
            || _equipmentOwner == null)
        {
            return;
        }

        if (_equipmentOwner.MainWeapon != null)
        {
            int mainWeaponLevel = (_equipmentOwner.MainWeapon instanceof LevelableWeapon) ? Level(((LevelableWeapon)(_equipmentOwner.MainWeapon)).getAccumulatedExperience()) : 0;
            for (TargetRangeModStatusEffectData data : _equipmentOwner.MainWeapon.BaseInfo.getStatusEffectsData().stream().filter(x -> x instanceof TargetRangeModStatusEffectData).map(x -> (TargetRangeModStatusEffectData)x).collect(Collectors.toList()))
            {
                _targetRangeModStatusEffects.add(new TargetRangeModStatusEffect(data, mainWeaponLevel, false));
            }

            if (_equipmentOwner.MainWeapon.BaseInfo.MainWeaponSkill != null && _equipmentOwner.MainWeapon.BaseInfo.MainWeaponSkill instanceof PassiveSkill)
            {
                for (TargetRangeModStatusEffectData data : _equipmentOwner.MainWeapon.BaseInfo.MainWeaponSkill.BaseInfo.getStatusEffectsData().stream().filter(x -> x instanceof TargetRangeModStatusEffectData).map(x -> (TargetRangeModStatusEffectData)x).collect(Collectors.toList()))
                {
                    _targetRangeModStatusEffects.add(new TargetRangeModStatusEffect(data, _equipmentOwner.MainWeapon.BaseInfo.MainWeaponSkill.Level, mainWeaponLevel));
                }
            }
        }

        if (_equipmentOwner.SubWeapon != null)
        {
            int subWeaponLevel = (_equipmentOwner.SubWeapon instanceof LevelableWeapon) ? Level(((LevelableWeapon)(_equipmentOwner.SubWeapon)).getAccumulatedExperience()) : 0;
            for (TargetRangeModStatusEffectData data : _equipmentOwner.SubWeapon.BaseInfo.getStatusEffectsData().stream().filter(x -> x instanceof TargetRangeModStatusEffectData).map(x -> (TargetRangeModStatusEffectData)x).collect(Collectors.toList()))
            {
                _targetRangeModStatusEffects.add(new TargetRangeModStatusEffect(data, subWeaponLevel, false));
            }
        }

        if (_equipmentOwner.Armour != null)
        {
            for (TargetRangeModStatusEffectData data : _equipmentOwner.Armour.BaseInfo.getStatusEffectsData().stream().filter(x -> x instanceof TargetRangeModStatusEffectData).map(x -> (TargetRangeModStatusEffectData)x).collect(Collectors.toList()))
            {
                _targetRangeModStatusEffects.add(new TargetRangeModStatusEffect(data));
            }
        }

        if (_equipmentOwner.Accessory != null)
        {
            for (TargetRangeModStatusEffectData data : _equipmentOwner.Accessory.BaseInfo.getStatusEffectsData().stream().filter(x -> x instanceof TargetRangeModStatusEffectData).map(x -> (TargetRangeModStatusEffectData)x).collect(Collectors.toList()))
            {
                _targetRangeModStatusEffects.add(new TargetRangeModStatusEffect(data));
            }
        }
    }

    public static void AddPassiveSkillForegroundStatusEffects(List<ForegroundStatusEffect> _foregroundStatusEffects, BattleSystemCore _system, UnitInstance _unit, eEventTriggerTiming _eventTriggerTiming)
    {
        if (_foregroundStatusEffects == null
            || _system == null
            || _unit == null)
        {
            return;
        }

        for (PassiveSkill passiveSkill : _unit.getSkills().stream().filter(x -> x instanceof PassiveSkill).map(x -> (PassiveSkill)x).collect(Collectors.toList()))
        {
            for (ForegroundStatusEffectData data : passiveSkill.BaseInfo.getStatusEffectsData().stream().filter(x -> x instanceof ForegroundStatusEffectData).map(x -> (ForegroundStatusEffectData)x)
            		.filter(x -> _system.DoesStatusEffectActivationPhaseMatch(x, _unit, _eventTriggerTiming)).collect(Collectors.toList()))
            {
                if (data instanceof DamageStatusEffectData)
                    _foregroundStatusEffects.add(new DamageStatusEffect((DamageStatusEffectData)data, passiveSkill.Level, true));
                else if (data instanceof HealStatusEffectData)
                    _foregroundStatusEffects.add(new HealStatusEffect((HealStatusEffectData)data, passiveSkill.Level, true));
            }
        }

        if (_unit.InheritedSkill instanceof PassiveSkill)
        {
            for (ForegroundStatusEffectData data : _unit.InheritedSkill.BaseInfo.getStatusEffectsData().stream().filter(x -> x instanceof ForegroundStatusEffectData).map(x -> (ForegroundStatusEffectData)x)
                .filter(x -> _system.DoesStatusEffectActivationPhaseMatch(x, _unit, _eventTriggerTiming)).collect(Collectors.toList()))
            {
                if (data instanceof DamageStatusEffectData)
                    _foregroundStatusEffects.add(new DamageStatusEffect((DamageStatusEffectData)data, _unit.InheritedSkill.Level, true));
                else if (data instanceof HealStatusEffectData)
                    _foregroundStatusEffects.add(new HealStatusEffect((HealStatusEffectData)data, _unit.InheritedSkill.Level, true));
            }
        }
    }

    public static void AddEquipmentForegroundStatusEffects(List<ForegroundStatusEffect> _foregroundStatusEffects, BattleSystemCore _system, UnitInstance _equipmentOwner, eEventTriggerTiming _eventTriggerTiming)
    {
        if (_foregroundStatusEffects == null
            || _system == null
            || _equipmentOwner == null)
        {
            return;
        }

        if (_equipmentOwner.MainWeapon != null)
        {
            int mainWeaponLevel = (_equipmentOwner.MainWeapon instanceof LevelableWeapon) ? Level(((LevelableWeapon)(_equipmentOwner.MainWeapon)).getAccumulatedExperience()) : 0;
            for (ForegroundStatusEffectData data : _equipmentOwner.MainWeapon.BaseInfo.getStatusEffectsData().stream().filter(x -> x instanceof ForegroundStatusEffectData).map(x -> (ForegroundStatusEffectData)x)
                .filter(x -> _system.DoesStatusEffectActivationPhaseMatch(x, _equipmentOwner, _eventTriggerTiming)).collect(Collectors.toList()))
            {
                if (data instanceof DamageStatusEffectData)
                    _foregroundStatusEffects.add(new DamageStatusEffect((DamageStatusEffectData)data, mainWeaponLevel, false));
                else if (data instanceof HealStatusEffectData)
                    _foregroundStatusEffects.add(new HealStatusEffect((HealStatusEffectData)data, mainWeaponLevel, false));
            }

            if (_equipmentOwner.MainWeapon.BaseInfo.MainWeaponSkill != null && _equipmentOwner.MainWeapon.BaseInfo.MainWeaponSkill instanceof PassiveSkill)
            {
                for (ForegroundStatusEffectData data : _equipmentOwner.MainWeapon.BaseInfo.MainWeaponSkill.BaseInfo.getStatusEffectsData().stream().filter(x -> x instanceof ForegroundStatusEffectData).map(x -> (ForegroundStatusEffectData)x)
                    .filter(x -> _system.DoesStatusEffectActivationPhaseMatch(x, _equipmentOwner, _eventTriggerTiming)).collect(Collectors.toList()))
                {
                    if (data instanceof DamageStatusEffectData)
                        _foregroundStatusEffects.add(new DamageStatusEffect((DamageStatusEffectData)data, _equipmentOwner.MainWeapon.BaseInfo.MainWeaponSkill.Level, mainWeaponLevel));
                    else if (data instanceof HealStatusEffectData)
                        _foregroundStatusEffects.add(new HealStatusEffect((HealStatusEffectData)data, _equipmentOwner.MainWeapon.BaseInfo.MainWeaponSkill.Level, mainWeaponLevel));
                }
            }
        }

        if (_equipmentOwner.SubWeapon != null)
        {
            int subWeaponLevel = (_equipmentOwner.SubWeapon instanceof LevelableWeapon) ? Level(((LevelableWeapon)(_equipmentOwner.SubWeapon)).getAccumulatedExperience()) : 0;
            for (ForegroundStatusEffectData data : _equipmentOwner.SubWeapon.BaseInfo.getStatusEffectsData().stream().filter(x -> x instanceof ForegroundStatusEffectData).map(x -> (ForegroundStatusEffectData)x)
                .filter(x -> _system.DoesStatusEffectActivationPhaseMatch(x, _equipmentOwner, _eventTriggerTiming)).collect(Collectors.toList()))
            {
                if (data instanceof DamageStatusEffectData)
                    _foregroundStatusEffects.add(new DamageStatusEffect((DamageStatusEffectData)data, subWeaponLevel, false));
                else if (data instanceof HealStatusEffectData)
                    _foregroundStatusEffects.add(new HealStatusEffect((HealStatusEffectData)data, subWeaponLevel, false));
            }
        }

        if (_equipmentOwner.Armour != null)
        {
            for (ForegroundStatusEffectData data : _equipmentOwner.Armour.BaseInfo.getStatusEffectsData().stream().filter(x -> x instanceof ForegroundStatusEffectData).map(x -> (ForegroundStatusEffectData)x)
                .filter(x -> _system.DoesStatusEffectActivationPhaseMatch(x, _equipmentOwner, _eventTriggerTiming)).collect(Collectors.toList()))
            {
                if (data instanceof DamageStatusEffectData)
                    _foregroundStatusEffects.add(new DamageStatusEffect((DamageStatusEffectData)data));
                else if (data instanceof HealStatusEffectData)
                    _foregroundStatusEffects.add(new HealStatusEffect((HealStatusEffectData)data));
            }
        }

        if (_equipmentOwner.Accessory != null)
        {
            for (ForegroundStatusEffectData data : _equipmentOwner.Accessory.BaseInfo.getStatusEffectsData().stream().filter(x -> x instanceof ForegroundStatusEffectData).map(x -> (ForegroundStatusEffectData)x)
                .filter(x -> _system.DoesStatusEffectActivationPhaseMatch(x, _equipmentOwner, _eventTriggerTiming)).collect(Collectors.toList()))
            {
                if (data instanceof DamageStatusEffectData)
                    _foregroundStatusEffects.add(new DamageStatusEffect((DamageStatusEffectData)data));
                else if (data instanceof HealStatusEffectData)
                    _foregroundStatusEffects.add(new HealStatusEffect((HealStatusEffectData)data));
            }
        }
    }

    // Example:
    // 0 represents the initial position and other numbers show the distance.
    // 3 3 3 3 3 3 3
    // 3 2 2 2 2 2 3
    // 3 2 1 1 1 2 3
    // 3 2 1 0 1 2 3
    // 3 2 1 1 1 2 3
    // 3 2 2 2 2 2 3
    // 3 3 3 3 3 3 3
    /// <summary>
    /// PreCondition: _initialCoord and _targetCoord are not null.
    /// PostCondition: The distance between _initialCoord and _targetCoord will be returned. The distance will be calculated as : the example : the comments above.
    /// </summary>
    /// <param name="_character1"></param>
    /// <param name="_character2"></param>
    /// <returns></returns>
    public static int Distance(_2DCoord _initialCoord, _2DCoord _targetCoord)
    {
        int distance = 0;

        for (int i = CoreValues.SIZE_OF_A_SIDE_OF_BOARD - 1; i >= 1; i--)
        {
            if (Math.abs(_initialCoord.X - _targetCoord.X) <= i && Math.abs(_initialCoord.Y - _targetCoord.Y) <= i)
                distance = i;
        }

        return distance;
    }

    /// <summary>
    /// Returns element effectivenessValue as double
    /// Example:
    /// If the returned value is 2.0, it means that the effect will be twice as effective against the target
    /// </summary>
    /// <param name="_effectUserElement"></param>
    /// <param name=""></param>
    /// <returns></returns>
    /// 
    public static EffectivenessInfo DamageCorrectionRate_Element(UnitInstance _attacker, eElement _effectElement, UnitInstance _defender)
    {
        BigDecimal correctionRate = BigDecimal.ONE;

        if (DoesElementMatch(_attacker.BaseInfo.getElements(), _effectElement))
            correctionRate = correctionRate.multiply(CoreValues.MULTIPLIER_FOR_ELEMENT_MATCH);

        EffectivenessInfo effectivenessInfo = ElementEffectiveness(_attacker, _effectElement, _defender);

        correctionRate = correctionRate.multiply(effectivenessInfo.correctionRate);
        
        return new EffectivenessInfo(effectivenessInfo.effectiveness, correctionRate);
    }

    /// <summary>
    /// PreCondition: _attacker, _defender, and _effect have been initialized successfully.
    /// PostCondition: Correct boolean value whether _effect succeeded or not will be returned.
    /// </summary>
    /// <param name="_skillUser"></param>
    /// <param name="_target"></param>
    /// <param name="_effect"></param>
    /// <returns></returns>
    public static boolean DoesSucceed(BattleSystemCore _system, UnitInstance _skillUser, ActiveSkill _skill, Effect _effect, List<_2DCoord> _effectRange, List<Object> _targets, Object _target, Object _target2ForComplexTargetSelectionEffect, boolean _isTarget2CurrentTarget)
    {
        if (_system == null
            || _skillUser == null
            || _skill == null
            || _effect == null
            || _effectRange == null)
        {
            return false;
        }

        BigDecimal successRate = _effect.getSuccessRate().ToValue(BigDecimal.class, _system, _skillUser, _skill, _effect, _effectRange, _targets, _target, _target2ForComplexTargetSelectionEffect, _isTarget2CurrentTarget);

        BigDecimal precision = Precision(_skillUser, _system, _skillUser, _skill, _effect, _effectRange, _targets, _target, _target2ForComplexTargetSelectionEffect, _isTarget2CurrentTarget);
        if (CoreFunctions.Compare(precision, eRelationType.LessThanOrEqualTo, BigDecimal.ZERO))
            return false;
        else
            successRate = successRate.multiply(precision);

        if (_target != null)
        {
            BigDecimal evasion = Evasion(_skillUser, _system, _skillUser, _skill, _effect, _effectRange, _targets, _target, _target2ForComplexTargetSelectionEffect, _isTarget2CurrentTarget);
            if (CoreFunctions.Compare(evasion, eRelationType.LessThanOrEqualTo, BigDecimal.ZERO))
                return true;
            else
                successRate = successRate.divide(evasion);
        }
        
        return isSuccess(successRate);
    }

    /// <summary>
    /// PreCondition: _attacker, _defender, and _effect have been initialized successfully.
    /// PostCondition: A boolean value representing whether the action(or skill) was critical will be returned based on the properties of _attacker, _defender, and _effect.
    /// </summary>
    /// <param name="_attacker"></param>
    /// <param name="_defender"></param>
    /// <param name="_effect"></param>
    /// <returns></returns>
    public static boolean IsCritical(UnitInstance _attacker, ActiveSkill _skill, DamageEffect _effect, List<_2DCoord> _effectRange, List<UnitInstance> _targets, UnitInstance _target, UnitInstance _target2ForComplexTargetSelectionEffect, boolean _isTarget2CurrentTarget, BattleSystemCore _system)
    {
        if (_attacker == null
            || _skill == null
            || _effect == null
            || _effectRange == null
            || _target == null
            || _system == null)
        {
            return false;
        }

        BigDecimal criticalRate = CoreValues.DEFAULT_CRITICAL_RATE;

        criticalRate = ApplyBuffAndDebuffStatusEffects_Compound(criticalRate, _system, eStatusType.Cri, _attacker, _skill, _effect, _effectRange, _targets, _target, _target2ForComplexTargetSelectionEffect, _isTarget2CurrentTarget);

        return isSuccess(criticalRate);
    }

    public static boolean IsCritical(UnitInstance _effectUser, ActiveSkill _skill, HealEffect _effect, List<_2DCoord> _effectRange, List<UnitInstance> _targets, UnitInstance _target, UnitInstance _target2ForComplexTargetSelectionEffect, boolean _isTarget2CurrentTarget, BattleSystemCore _system)
    {
        if (_effectUser == null
            || _target == null
            || _effect == null)
        {
            return false;
        }

        BigDecimal criticalRate = CoreValues.DEFAULT_CRITICAL_RATE;

        criticalRate = ApplyBuffAndDebuffStatusEffects_Compound(criticalRate, _system, eStatusType.Cri, _effectUser, _skill, _effect, _effectRange, _targets, _target, _target2ForComplexTargetSelectionEffect, _isTarget2CurrentTarget);

        return isSuccess(criticalRate);
    }
    //End Public Methods

    //Private Methods
    private static BigDecimal CorrectionRate_Force(BattleSystemCore _system, UnitInstance _effectUser, ActiveSkill _skill, DamageEffect _effect, List<_2DCoord> _effectRange, List<UnitInstance> _targets, UnitInstance _target, UnitInstance _target2ForComplexTargetSelectionEffect, boolean _isTarget2CurrentTarget)
    {
        if (_system == null
            || _effectUser == null
            || _skill == null
            || _effect == null
            || _target == null
            || _effectRange == null)
        {
            return BigDecimal.ZERO;
        }
        
        try
        {
            List<Object> targets = _targets.stream().map(x -> (Object)x).collect(Collectors.toList());

            BigDecimal force = _effect.getValue().ToValue(BigDecimal.class, _system, _effectUser, _skill, _effect, _effectRange, targets, _target, _target2ForComplexTargetSelectionEffect, _isTarget2CurrentTarget);

            if (CoreFunctions.Compare(force, eRelationType.GreaterThan, BigDecimal.ZERO))
            	force = CoreValues.POW_ADJUSTMENT_CONST_A.multiply(force.pow(2)).add(CoreValues.POW_ADJUSTMENT_CONST_B); // A = 19/9999 and B = (1 - A) so that this equation equals 1 when force is 1 

            force = ApplyBuffAndDebuffStatusEffects_Simple(force, _system, _effectUser, eStatusType.DamageForce, _effectUser, _skill, _effect, _effectRange, targets, _target, _target2ForComplexTargetSelectionEffect, _isTarget2CurrentTarget);

            return force;
        }
        catch (Exception ex)
        {
            return BigDecimal.ZERO;
        }
    }

    private static BigDecimal CorrectionRate_Force(BattleSystemCore _system, UnitInstance _effectUser, ActiveSkill _skill, HealEffect _effect, List<_2DCoord> _effectRange, List<UnitInstance> _targets, UnitInstance _target, UnitInstance _target2ForComplexTargetSelectionEffect, boolean _isTarget2CurrentTarget)
    {
        if (_system == null
            || _effectUser == null
            || _skill == null
            || _effect == null
            || _target == null
            || _effectRange == null)
        {
            return BigDecimal.ZERO;
        }

        try
        {
            List<Object> targets = _targets.stream().map(x -> (Object)x).collect(Collectors.toList());

            BigDecimal force = _effect.getValue().ToValue(BigDecimal.class, _system, _effectUser, _skill, _effect, _effectRange, targets, _target, _target2ForComplexTargetSelectionEffect, _isTarget2CurrentTarget);

            if (CoreFunctions.Compare(force, eRelationType.GreaterThan, BigDecimal.ZERO))
                force = CoreValues.POW_ADJUSTMENT_CONST_A.multiply(force.pow(2)).add(CoreValues.POW_ADJUSTMENT_CONST_B); // A = 19/9999 and B = (1 - A) so that this equation equals 1 when force is 1 

            force = ApplyBuffAndDebuffStatusEffects_Simple(force, _system, _effectUser, eStatusType.HealForce, _effectUser, _skill, _effect, _effectRange, targets, _target, _target2ForComplexTargetSelectionEffect, _isTarget2CurrentTarget);

            return force;
        }
        catch (Exception ex)
        {
            return BigDecimal.ZERO;
        }
    }

    private static EffectivenessInfo ElementEffectiveness(UnitInstance _attacker, eElement _effectElement, UnitInstance _defender)
    {
        eEffectiveness effectiveness = eEffectiveness.Neutral;
        BigDecimal effectivenessValue = BigDecimal.ONE;
        
        int effectiveCount = 0;
        int ineffectiveCount = 0;

        //Effect base effectivenessValue
        for (eElement targetElement : _defender.BaseInfo.getElements())
        {
            switch (_effectElement)
            {
                case Blue:
                    if (targetElement == eElement.Red)
                        effectiveCount++;
                    else if (targetElement == eElement.Ocher)
                        ineffectiveCount++;
                    break;
                case Red:
                    if (targetElement == eElement.Green)
                        effectiveCount++;
                    else if (targetElement == eElement.Blue)
                        ineffectiveCount++;
                    break;
                case Green:
                    if (targetElement == eElement.Ocher)
                        effectiveCount++;
                    else if (targetElement == eElement.Red)
                        ineffectiveCount++;
                    break;
                case Ocher:
                    if (targetElement == eElement.Blue)
                        effectiveCount++;
                    else if (targetElement == eElement.Green)
                        ineffectiveCount++;
                    break;
                case Purple:
                    if (targetElement == eElement.Yellow)
                        effectiveCount++;
                    break;
                case Yellow:
                    if (targetElement == eElement.Purple)
                        effectiveCount++;
                    break;
                default: //case None
                	break;
            }
        }

        if (effectiveCount > ineffectiveCount)
        {
            effectiveness = eEffectiveness.Effective;
            effectivenessValue = BigDecimalExtension.multiply(CoreValues.MULTIPLIER_FOR_EFFECTIVE_ELEMENT, effectiveCount - ineffectiveCount);
        }
        else if (effectiveCount < ineffectiveCount)
        {
            effectiveness = eEffectiveness.Ineffective;
            effectivenessValue = BigDecimalExtension.multiply(CoreValues.MULTIPLIER_FOR_INEFFECTIVE_ELEMENT, ineffectiveCount - effectiveCount);
        }

        return new EffectivenessInfo(effectiveness, effectivenessValue);
    }

    private static boolean DoesElementMatch(List<eElement> _unitElements, eElement _targetElement)
    {
        for (eElement e : _unitElements)
        {
            if (e == _targetElement)
                return true;
        }

        return false;
    }

    private static BigDecimal CorrectionRate_TileType(UnitInstance _unit, Effect _effect, eTileType _tileType)
    {
        switch (_tileType)
        {
            case Blue:
                if (DoesElementMatch(_unit.BaseInfo.getElements(), eElement.Blue))
                    return CoreValues.MULTIPLIER_FOR_TILETYPEMATCH;
                break;
            case Red:
                if (DoesElementMatch(_unit.BaseInfo.getElements(), eElement.Red))
                    return CoreValues.MULTIPLIER_FOR_TILETYPEMATCH;
                break;
            case Green:
                if (DoesElementMatch(_unit.BaseInfo.getElements(), eElement.Green))
                    return CoreValues.MULTIPLIER_FOR_TILETYPEMATCH;
                break;
            case Ocher:
                if (DoesElementMatch(_unit.BaseInfo.getElements(), eElement.Ocher))
                    return CoreValues.MULTIPLIER_FOR_TILETYPEMATCH;
                break;
            case Purple:
                if (DoesElementMatch(_unit.BaseInfo.getElements(), eElement.Purple))
                    return CoreValues.MULTIPLIER_FOR_TILETYPEMATCH;
                break;
            case Yellow:
                if (DoesElementMatch(_unit.BaseInfo.getElements(), eElement.Yellow))
                    return CoreValues.MULTIPLIER_FOR_TILETYPEMATCH;
                break;
            case Heal:
                if (_effect instanceof HealEffect)
                    return CoreValues.MULTIPLIER_FOR_TILETYPEMATCH;
                break;
            default: //case Normal
                return BigDecimal.ONE;
        }

        return BigDecimal.ONE;
    }
    
    private static boolean isSuccess(BigDecimal _value)
    {
        if (CoreFunctions.Compare(_value, eRelationType.LessThanOrEqualTo, BigDecimal.ZERO))
            return false;
        else if (CoreFunctions.Compare(_value, eRelationType.GreaterThanOrEqualTo, BigDecimal.ONE))
            return true;
        else
        {
            int rangeNumber = BigDecimalExtension.multiply(_value, 10000).intValue();

            MTRandom.randInit();
            int randomNumber = MTRandom.getRand(1, 10000);

            if (randomNumber < rangeNumber)
                return true;
            else
                return false;
        }
    }
    //End Private Methods
}