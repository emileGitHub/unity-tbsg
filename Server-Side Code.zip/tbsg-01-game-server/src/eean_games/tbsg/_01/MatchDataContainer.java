package eean_games.tbsg._01;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import eean_games.main.MTRandom;
import eean_games.main._2DCoord;
import eean_games.tbsg._01.player.Player;
import eean_games.tbsg._01.player.PlayerOnBoard;
import eean_games.tbsg._01.skill.ActiveSkill;
import eean_games.tbsg._01.unit.UnitInstance;

public class MatchDataContainer 
{
	//Public Static Fields
    public static List<BattleSystemCore> matches;
	//End Public Static Fields
    
    //Private Static Fields
    private static List<MatchingPlayerInfo> playersWaitingForMatching;
    
    private static boolean isInitialized = false;
    //End Private Static Fields
    
    //Public Methods
    public static void ChangeUnit(int _playerId, int _unitIndex)
    {
    	//Get the match that contains the player with the given id
    	BattleSystemCore match = matches.stream()
    			.filter(x -> x.Field.getPlayers().stream()
    					.anyMatch(y -> y.Id == _playerId))
    			.findFirst().get();
    	
    	//Get data of the corresponding player
    	PlayerOnBoard player = match.Field.getPlayers().stream().filter(x -> x.Id == _playerId).findFirst().get();
    	
    	match.ChangeSelectedUnit(player, _unitIndex);
    }
    
    public static void ChangeTurn(int _playerId)
    {
    	//Get the match that contains the player with the given id
    	BattleSystemCore match = matches.stream()
    			.filter(x -> x.Field.getPlayers().stream()
    					.anyMatch(y -> y.Id == _playerId))
    			.findFirst().get();
    	
    	//Get data of the corresponding player
    	PlayerOnBoard player = match.Field.getPlayers().stream().filter(x -> x.Id == _playerId).findFirst().get();
    	
    	match.ChangeTurn(player);
    }
    
    public static void Concede(int _playerId)
    {
    	//Get the match that contains the player with the given id
    	BattleSystemCore match = matches.stream()
    			.filter(x -> x.Field.getPlayers().stream()
    					.anyMatch(y -> y.Id == _playerId))
    			.findFirst().get();
    	
    	//Get data of the corresponding player
    	PlayerOnBoard player = match.Field.getPlayers().stream().filter(x -> x.Id == _playerId).findFirst().get();
    	
    	match.EndMatch(player);
    }
    
    public static void MoveUnit(int _playerId, _2DCoord _destination)
    {
    	//Get the match that contains the player with the given id
    	BattleSystemCore match = matches.stream()
    			.filter(x -> x.Field.getPlayers().stream()
    					.anyMatch(y -> y.Id == _playerId))
    			.findFirst().get();
    	
    	//Get data of the corresponding player
    	PlayerOnBoard player = match.Field.getPlayers().stream().filter(x -> x.Id == _playerId).findFirst().get();
    	
    	//Get data of the unit currently selected by the player
    	UnitInstance unit = player.AlliedUnits.get(player.SelectedUnitIndex);
    	
    	match.MoveUnit(unit, _destination);
    }
    
    public static void Attack(int _playerId, List<_2DCoord> _targetCoords)
    {
    	//Get the match that contains the player with the given id
    	BattleSystemCore match = matches.stream()
    			.filter(x -> x.Field.getPlayers().stream()
    					.anyMatch(y -> y.Id == _playerId))
    			.findFirst().get();
    	
    	//Get data of the corresponding player
    	PlayerOnBoard player = match.Field.getPlayers().stream().filter(x -> x.Id == _playerId).findFirst().get();
    	
    	//Get data of the unit currently selected by the player
    	UnitInstance unit = player.AlliedUnits.get(player.SelectedUnitIndex);
    	
    	match.RequestAttack(unit, _targetCoords);
    }
    
    public static void UseSkill(int _playerId, String _skillName, List<_2DCoord> _targetCoords)
    {
    	//Get the match that contains the player with the given id
    	BattleSystemCore match = matches.stream()
    			.filter(x -> x.Field.getPlayers().stream()
    					.anyMatch(y -> y.Id == _playerId))
    			.findFirst().get();
    	
    	//Get data of the corresponding player
    	PlayerOnBoard player = match.Field.getPlayers().stream().filter(x -> x.Id == _playerId).findFirst().get();
    	
    	//Get data of the unit currently selected by the player
    	UnitInstance unit = player.AlliedUnits.get(player.SelectedUnitIndex);
    	
    	//Get data of the skill that corresponds to the _skillName
    	ActiveSkill skill = unit.getSkills().stream()
    			.filter(x -> x instanceof ActiveSkill)
    			.map(x -> (ActiveSkill)x)
    			.filter(x -> x.BaseInfo.Name.equals(_skillName)).findFirst().get();
    	
    	match.RequestSkillUse(unit, skill, _targetCoords);
    }
    
    public static boolean hasPlayerBeenAssignedToMatch(Player _player) { return matches.stream().anyMatch(x -> x.Field.getPlayers().stream().anyMatch(y -> y.Id == _player.Id)); }
    
    public static String assignPlayerToMatch(Player _player, int _teamIndex)
    {
    	if (!isInitialized)
    		initialize();
    	if (!isInitialized)
    		return "error";
    	
    	try
    	{
        	//Check whether the given _player is already assigned to a match
        	boolean isPlayerInMatch = hasPlayerBeenAssignedToMatch(_player);
        	
        	//Check whether the given _player is already assigned to the waiting list
        	boolean isPlayerInWaitingList = playersWaitingForMatching.stream().anyMatch(x -> x.player == _player);
        			
        	if (isPlayerInMatch) 
        		return "alreadyInMatch";
        	else if (isPlayerInWaitingList)
        		return "alreadyWaiting";
        	else //The given _player is not in match nor in the waiting list
        		playersWaitingForMatching.add(new MatchingPlayerInfo(_player, _teamIndex));
        	
        	assignPlayersInWaitingListToMatch();
        	
        	System.out.println("Matches Running: " + String.valueOf(matches.size()));
        	System.out.println("Players in Waiting List: " + String.valueOf(playersWaitingForMatching.size()));
        	
        	return "matching";
    	}
    	catch (Exception ex)
    	{
    		System.out.println(ex.toString());
    		playersWaitingForMatching.remove(playersWaitingForMatching.stream().filter(x -> x.player == _player).findFirst().get());
    		return "error";
    	}
    }
    //End Public Methods
    
    //Private Methods
    private static void initialize()
    {
    	if (isInitialized)
    		return;
    	
    	if (matches == null)
    		matches = Collections.synchronizedList(new ArrayList<BattleSystemCore>());
    	
    	if (playersWaitingForMatching == null)
    		playersWaitingForMatching = Collections.synchronizedList(new ArrayList<MatchingPlayerInfo>());
    	
    	isInitialized = true;
    }
    
    private static void assignPlayersInWaitingListToMatch()
    {
    	if (playersWaitingForMatching.size() < 2)
    		return;
    		
    	//Get information of players to assign to a new match
    	MatchingPlayerInfo matchingPlayerInfo1 = playersWaitingForMatching.get(0);
    	MatchingPlayerInfo matchingPlayerInfo2 = playersWaitingForMatching.get(1);
    	
    	//Set the order in which each player will start playing
		MTRandom.randInit();
		int randNum = MTRandom.getRand(1, 10);
		if (randNum > 5)
		{
			MatchingPlayerInfo tmp = matchingPlayerInfo1;
			matchingPlayerInfo1 = matchingPlayerInfo2;
			matchingPlayerInfo2 = tmp;
		}
		
		//Get players' data required to create a new battle field
    	Player player1 = matchingPlayerInfo1.player;
    	int teamIndexForPlayer1 = matchingPlayerInfo1.teamIndex;
    	
    	Player player2 = matchingPlayerInfo2.player;
    	int teamIndexForPlayer2 = matchingPlayerInfo2.teamIndex;
    	
    	//Load the tile set that will be used for the match
    	TileSet tileSet = SharedGameDataContainer.getTileSets().get(0);
    	
    	//Prepare new field for the match
    	Field field = Field.NewField(player1, teamIndexForPlayer1, player2, teamIndexForPlayer2, tileSet.getTileTypes());
    
    	//Instantiate the battle system for the match
    	BattleSystemCore match = new BattleSystemCore(field);
    	
    	matches.add(match);
    	
    	//Remove players from the waiting list
    	playersWaitingForMatching.remove(matchingPlayerInfo1);
    	playersWaitingForMatching.remove(matchingPlayerInfo2);
    	
    	assignPlayersInWaitingListToMatch(); // Loop until the waiting list contains less than two players
    }
    //End Private Methods
}
