package eean_games.tbsg._01.effect;

public interface IComplexTargetSelectionEffect{
	final boolean fromTargetToTarget2 = false;
}
