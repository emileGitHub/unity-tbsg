package eean_games.tbsg._01;

import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import javax.imageio.ImageIO;

import org.apache.tomcat.util.codec.binary.Base64;

import eean_games.main.CoreValues;
import eean_games.main.MapEntry;
import eean_games.main.eRelationType;
import eean_games.tbsg._01.effect.DamageEffect;
import eean_games.tbsg._01.effect.Effect;
import eean_games.tbsg._01.effect.HealEffect;
import eean_games.tbsg._01.effect.StatusEffectAttachmentEffect;
import eean_games.tbsg._01.effect.UnitTargetingEffect;
import eean_games.tbsg._01.enumerable.eAccessoryClassification;
import eean_games.tbsg._01.enumerable.eActivationTurnClassification;
import eean_games.tbsg._01.enumerable.eArmourClassification;
import eean_games.tbsg._01.enumerable.eAttackClassification;
import eean_games.tbsg._01.enumerable.eElement;
import eean_games.tbsg._01.enumerable.eEventTriggerTiming;
import eean_games.tbsg._01.enumerable.eGender;
import eean_games.tbsg._01.enumerable.eModificationMethod;
import eean_games.tbsg._01.enumerable.eRarity;
import eean_games.tbsg._01.enumerable.eStatusType;
import eean_games.tbsg._01.enumerable.eTargetRangeClassification;
import eean_games.tbsg._01.enumerable.eTargetUnitClassification;
import eean_games.tbsg._01.enumerable.eTileType;
import eean_games.tbsg._01.enumerable.eWeaponClassification;
import eean_games.tbsg._01.enumerable.eWeaponType;
import eean_games.tbsg._01.equipment.Accessory;
import eean_games.tbsg._01.equipment.AccessoryData;
import eean_games.tbsg._01.equipment.Armour;
import eean_games.tbsg._01.equipment.ArmourData;
import eean_games.tbsg._01.equipment.LevelableTransformableWeapon;
import eean_games.tbsg._01.equipment.LevelableWeapon;
import eean_games.tbsg._01.equipment.OrdinaryWeapon;
import eean_games.tbsg._01.equipment.TransformableWeapon;
import eean_games.tbsg._01.equipment.Weapon;
import eean_games.tbsg._01.equipment.WeaponData;
import eean_games.tbsg._01.item.EquipmentMaterial;
import eean_games.tbsg._01.item.EvolutionMaterial;
import eean_games.tbsg._01.item.Item;
import eean_games.tbsg._01.item.ItemMaterial;
import eean_games.tbsg._01.item.ItemSet;
import eean_games.tbsg._01.item.SkillItem;
import eean_games.tbsg._01.item.SkillMaterial;
import eean_games.tbsg._01.player.Player;
import eean_games.tbsg._01.recipe.UnitEvolutionRecipe;
import eean_games.tbsg._01.skill.ActiveSkillData;
import eean_games.tbsg._01.skill.CounterSkill;
import eean_games.tbsg._01.skill.CounterSkillData;
import eean_games.tbsg._01.skill.OrdinarySkill;
import eean_games.tbsg._01.skill.OrdinarySkillData;
import eean_games.tbsg._01.skill.PassiveSkillData;
import eean_games.tbsg._01.skill.Skill;
import eean_games.tbsg._01.skill.SkillData;
import eean_games.tbsg._01.skill.UltimateSkillData;
import eean_games.tbsg._01.status_effect.BackgroundStatusEffectData;
import eean_games.tbsg._01.status_effect.BuffStatusEffectData;
import eean_games.tbsg._01.status_effect.DamageStatusEffectData;
import eean_games.tbsg._01.status_effect.DebuffStatusEffectData;
import eean_games.tbsg._01.status_effect.DurationData;
import eean_games.tbsg._01.status_effect.ForegroundStatusEffectData;
import eean_games.tbsg._01.status_effect.HealStatusEffectData;
import eean_games.tbsg._01.status_effect.StatusEffectData;
import eean_games.tbsg._01.status_effect.TargetRangeModStatusEffectData;
import eean_games.tbsg._01.unit.Unit;
import eean_games.tbsg._01.unit.UnitData;

public class SharedGameDataContainer 
{
	//Public Static Fields
    public static List<Player> getPlayers() { return Collections.unmodifiableList(players); }
	//End Public Static Fields
	
    //Getters
    public static List<TileSet> getTileSets() { return Collections.unmodifiableList(tileSets); }
    
    public static List<UnitData> getUnits() { return Collections.unmodifiableList(units); }
    public static List<WeaponData> getWeapons() { return Collections.unmodifiableList(weapons); }
    public static List<ArmourData> getArmours() { return Collections.unmodifiableList(armours); }
    public static List<AccessoryData> getAccessories() { return Collections.unmodifiableList(accessories); }
    public static List<Item> getItems() { return Collections.unmodifiableList(items); }
    
    public static List<SkillData> getSkills() { return Collections.unmodifiableList(skills); }
    public static List<Effect> getEffects() { return Collections.unmodifiableList(effects); }
	public static List<StatusEffectData> getStatusEffects() { return Collections.unmodifiableList(statusEffects); }
	//End Getters
    
    //Private Static Fields
	private static List<Player> players;
	
    private static List<UnitData> units;
    private static List<String> unitsAsResponseStrings;
    private static List<WeaponData> weapons;
    private static List<String> weaponsAsResponseStrings;
    private static List<ArmourData> armours;
    private static List<String> armoursAsResponseStrings;
    private static List<AccessoryData> accessories;
    private static List<String> accessoriesAsResponseStrings;
    private static List<Item> items;
    private static List<String> itemsAsResponseStrings;

    private static List<SkillData> skills;
    private static List<String> skillsAsResponseStrings;
    private static List<Effect> effects;
    private static List<String> effectsAsResponseStrings;
    private static List<StatusEffectData> statusEffects;
    private static List<String> statusEffectsAsResponseStrings;
    
    private static List<TileSet> tileSets;
    
    private static boolean isInitialized = false;
    //End Private Static Fields
    
    public static String getAllDataAsResponseString()
    {
    	if (!isInitialized)
    		initialize();
    	if (!isInitialized)
    		return "loadingError";
    	
    	String result = "";
    	
    	result = result + "<StatusEffects>";
    	for (String responseString : statusEffectsAsResponseStrings)
    	{
    		result = result + responseString;
    	}
    	result = result + "</StatusEffects>";
    	
    	result = result + "<Effects>";
    	for (String responseString : effectsAsResponseStrings)
    	{
    		result = result + responseString;
    	}
    	result = result + "</Effects>";
    	
    	result = result + "<Skills>";
    	for (String responseString : skillsAsResponseStrings)
    	{
    		result = result + responseString;
    	}
    	result = result + "</Skills>";
    	
    	result = result + "<Weapons>";
    	for (String responseString : weaponsAsResponseStrings)
    	{
    		result = result + responseString;
    	}
    	result = result + "</Weapons>";
    	
    	result = result + "<Armours>";
    	for (String responseString : armoursAsResponseStrings)
    	{
    		result = result + responseString;
    	}
    	result = result + "</Armours>";
    	
    	result = result + "<Accessories>";
    	for (String responseString : accessoriesAsResponseStrings)
    	{
    		result = result + responseString;
    	}
    	result = result + "</Accessories>";
    	
    	result = result + "<Items>";
    	for (String responseString : itemsAsResponseStrings)
    	{
    		result = result + responseString;
    	}
    	result = result + "</Items>";
    	
    	result = result + "<Units>";
    	for (String responseString : unitsAsResponseStrings)
    	{
    		result = result + responseString;
    	}
    	result = result + "</Units>";
    
    	return result;
    }

    private static void initialize()
    {
    	if (isInitialized)
    		return;
    	
    	if (units == null)
    		units = Collections.synchronizedList(new ArrayList<UnitData>());
    	
    	if (unitsAsResponseStrings == null)
    		unitsAsResponseStrings = Collections.synchronizedList(new ArrayList<String>());
    		
    	if (weapons == null)
    		weapons = Collections.synchronizedList(new ArrayList<WeaponData>());
    	
    	if (weaponsAsResponseStrings == null)
    		weaponsAsResponseStrings = Collections.synchronizedList(new ArrayList<String>());
    	
    	if (armours == null)
    		armours = Collections.synchronizedList(new ArrayList<ArmourData>());
    	
    	if (armoursAsResponseStrings == null)
    		armoursAsResponseStrings = Collections.synchronizedList(new ArrayList<String>());
    	
    	if (accessories == null)
    		accessories = Collections.synchronizedList(new ArrayList<AccessoryData>());
    	
    	if (accessoriesAsResponseStrings == null)
    		accessoriesAsResponseStrings = Collections.synchronizedList(new ArrayList<String>());
    	
    	if (items == null)
    		items = Collections.synchronizedList(new ArrayList<Item>());
    	
    	if (itemsAsResponseStrings == null)
    		itemsAsResponseStrings = Collections.synchronizedList(new ArrayList<String>());
    	
    	if (skills == null)
    		skills = Collections.synchronizedList(new ArrayList<SkillData>());
    	
    	if (skillsAsResponseStrings == null)
    		skillsAsResponseStrings = Collections.synchronizedList(new ArrayList<String>());
    	
    	if (effects == null)
    		effects = Collections.synchronizedList(new ArrayList<Effect>());
    	
    	if (effectsAsResponseStrings == null)
    		effectsAsResponseStrings = Collections.synchronizedList(new ArrayList<String>());
    	
    	if (statusEffects == null)
    		statusEffects = Collections.synchronizedList(new ArrayList<StatusEffectData>());
    	
    	if (statusEffectsAsResponseStrings == null)
    		statusEffectsAsResponseStrings = Collections.synchronizedList(new ArrayList<String>());

    	if (tileSets == null)
    		tileSets = Collections.synchronizedList(new ArrayList<TileSet>());
    	
    	if (players == null)
    		players = Collections.synchronizedList(new ArrayList<Player>());
    	
    	try 
    	{
    		//-------------------------------Connection----------------------------------------
			Class.forName("com.mysql.jdbc.Driver");
			
			Connection con = DriverManager
					.getConnection("jdbc:mysql://localhost:3306/GameDB", "tbsg-01", "Chocochan311206@4");
			//---------------------------------------------------------------------------------
    		
			loadStatusEffects(con);
    		loadEffects(con);
    		loadSecondaryEffects(con);
    		loadSkills(con);
    		loadUnits(con);
    		loadWeapons(con);
    		loadTransformableWeaponsData(con);
    		loadLevelableTransformableWeaponsData(con);
    		loadArmours(con);
    		loadAccessories(con);
    		loadItems(con);
    		loadUnitEvolutionRecipes(con);
    		
    		loadTileSets(con);
    		
    		loadPlayers(con);
    		loadSkillInheritors(con);
    		
    		loadStatusEffectsAsResponseStrings();
    		loadEffectsAsResponseStrings();
    		loadSkillsAsResponseStrings();
    		loadUnitsAsResponseStrings();
    		loadWeaponsAsResponseStrings();
    		loadArmoursAsResponseStrings();
    		loadAccessoriesAsResponseStrings();
    		loadItemsAsResponseStrings();
    		
        	isInitialized = true;
    	}
    	catch (Exception ex)
    	{
    		System.out.println(ex.toString());
    	}
    }

    private static void loadUnitsAsResponseStrings()
    {
    	for (UnitData unitData : units)
    	{
    		unitsAsResponseStrings.add(unitDataToResponseString(unitData));
    	}
    }
    
    private static String unitDataToResponseString(UnitData _unitData)
    {
    	String responseString = "<UnitData>";
		
		responseString = responseString + "<Id>" + String.valueOf(_unitData.Id) + "</Id>";
		responseString = responseString  + "<Name>" + _unitData.Name + "</Name>";
		responseString = responseString + "<IconAsBytes>" + Base64.encodeBase64String(_unitData.getIconAsBytes()) + "</IconAsBytes>";
		responseString = responseString + "<Gender>" + _unitData.Gender.toString() + "</Gender>";
		responseString = responseString + "<Rarity>" + _unitData.getRarity().toString() + "</Rarity>";
		responseString = responseString + "<MovementRangeClassification>" + _unitData.MovementRangeClassification.toString() + "</MovementRangeClassification>";
		responseString = responseString + "<NonMovementActionRangeClassification>" + _unitData.NonMovementActionRangeClassification.toString() + "</NonMovementActionRangeClassification>";
		responseString = responseString + "<Element1>" + _unitData.getElements().get(0).toString() + "</Element1>";
		responseString = responseString + "<Element2>" + _unitData.getElements().get(1).toString() + "</Element2>";
		
		responseString = responseString + "<EquipableWeaponClassifications>";
		for (eWeaponClassification classification : _unitData.getEquipableWeaponClassifications())
		{
			responseString = responseString + "<WeaponClassification>";
			responseString = responseString + classification.toString();
			responseString = responseString + "</WeaponClassification>";
		}
		responseString = responseString + "</EquipableWeaponClassifications>";
		
		responseString = responseString + "<EquipableArmourClassifications>";
		for (eArmourClassification classification : _unitData.getEquipableArmourClassifications())
		{
			responseString = responseString + "<ArmourClassification>";
			responseString = responseString + classification.toString();
			responseString = responseString + "</ArmourClassification>";
		}
		responseString = responseString + "</EquipableArmourClassifications>";
		
		responseString = responseString + "<EquipableAccessoryClassifications>";
		for (eAccessoryClassification classification : _unitData.getEquipableAccessoryClassifications())
		{
			responseString = responseString + "<AccessoryClassification>";
			responseString = responseString + classification.toString();
			responseString = responseString + "</AccessoryClassification>";
		}
		responseString = responseString + "</EquipableAccessoryClassifications>";
		
		responseString = responseString + "<MaxLevelHP>" + String.valueOf(_unitData.MaxLevel_HP) + "</MaxLevelHP>";
		responseString = responseString + "<MaxLevelPhysicalStrength>" + String.valueOf(_unitData.MaxLevel_PhysicalStrength) + "</MaxLevelPhysicalStrength>";
		responseString = responseString + "<MaxLevelPhysicalResistance>" + String.valueOf(_unitData.MaxLevel_PhysicalResistance) + "</MaxLevelPhysicalResistance>";
		responseString = responseString + "<MaxLevelMagicalStrength>" + String.valueOf(_unitData.MaxLevel_MagicalStrength) + "</MaxLevelMagicalStrength>";
		responseString = responseString + "<MaxLevelMagicalResistance>" + String.valueOf(_unitData.MaxLevel_MagicalResistance) + "</MaxLevelMagicalResistance>";
		responseString = responseString + "<MaxLevelVitality>" + String.valueOf(_unitData.MaxLevel_Vitality) + "</MaxLevelVitality>";
		
		responseString = responseString + "<SkillIds>";
		for (SkillData skillData : _unitData.getSkills())
		{
			responseString = responseString + "<SkillId>";
			responseString = responseString + String.valueOf(skillData.Id);
			responseString = responseString + "</SkillId>";
		}
		responseString = responseString + "</SkillIds>";
		
		responseString = responseString + "<Labels>";
		for (String label : _unitData.getLabels())
		{
			responseString = responseString + "<Label>";
			responseString = responseString + label;
			responseString = responseString + "</Label>";
		}
		responseString = responseString + "</Labels>";
		
		responseString = responseString + "<Description>" + _unitData.Description + "</Description>";
		
		responseString = responseString + "<ProgressiveEvolutionRecipes>";
		for (UnitEvolutionRecipe progressiveEvolutionRecipe : _unitData.getProgressiveEvolutionRecipes())
		{
			responseString = responseString + unitEvolutionRecipeToResponseString(progressiveEvolutionRecipe, "ProgressiveEvolutionRecipe");
		}
		responseString = responseString + "</ProgressiveEvolutionRecipes>";
		
		UnitEvolutionRecipe retrogressiveEvolutionRecipe = _unitData.getRetrogressiveEvolutionRecipe();
		if (retrogressiveEvolutionRecipe != null)
			responseString = responseString + unitEvolutionRecipeToResponseString(retrogressiveEvolutionRecipe, "RetrogressiveEvolutionRecipe");
		
		responseString = responseString + "</UnitData>";
		
    	return responseString;
    }
    
    private static String unitEvolutionRecipeToResponseString(UnitEvolutionRecipe _unitEvolutionRecipe, String _tagTitle)
    {
    	String responseString = "<" + _tagTitle + ">";
    	
    	responseString = responseString + "<AfterEvolutionUnitId>" + String.valueOf(_unitEvolutionRecipe.UnitAfterEvolution.Id) + "</AfterEvolutionUnitId>";
    	
    	responseString = responseString + "<MaterialIds>";
    	for (int i = 0; i < CoreValues.MAX_NUM_OF_ELEMENTS_IN_RECIPE; i++)
    	{
    		responseString = responseString + "<MaterialId>" + String.valueOf(_unitEvolutionRecipe.getMaterials().get(i)) + "</MaterialId>";
    	}
    	responseString = responseString + "</MaterialIds>";
    	
    	responseString = responseString + "<Cost>" + String.valueOf(_unitEvolutionRecipe.Cost) + "</Cost>";
    	
    	responseString = responseString + "</" + _tagTitle + ">";
    	
    	return responseString;
    }
    
    private static void loadWeaponsAsResponseStrings()
    {
    	for (WeaponData weaponData : weapons)
    	{
    		weaponsAsResponseStrings.add(weaponDataToResponseString(weaponData));
    	}
    }
    
    private static String weaponDataToResponseString(WeaponData _weaponData)
    {
    	String responseString = "<WeaponData>";
		
		responseString = responseString + "<Id>" + String.valueOf(_weaponData.Id) + "</Id>";
		responseString = responseString  + "<Name>" + _weaponData.Name + "</Name>";
		responseString = responseString + "<IconAsBytes>" + Base64.encodeBase64String(_weaponData.getIconAsBytes()) + "</IconAsBytes>";
		responseString = responseString + "<Rarity>" + _weaponData.getRarity().toString() + "</Rarity>";
		
		responseString = responseString + "<StatusEffectDataIds>";
		for (StatusEffectData statusEffectData : _weaponData.getStatusEffectsData())
		{
			responseString = responseString + "<StatusEffectDataId>";
			responseString = responseString + String.valueOf(statusEffectData.Id);
			responseString = responseString + "</StatusEffectDataId>";
		}
		responseString = responseString + "</StatusEffectDataIds>";
		
		responseString = responseString + "<WeaponType>" + _weaponData.WeaponType.toString() + "</WeaponType>";

		responseString = responseString + "<WeaponClassifications>";
		for (eWeaponClassification classification : _weaponData.getWeaponClassifications())
		{
			responseString = responseString + "<WeaponClassification>";
			responseString = responseString + classification.toString();
			responseString = responseString + "</WeaponClassification>";
		}
		responseString = responseString + "</WeaponClassifications>";
		
		responseString = responseString + "<MainWeaponSkillId>" + _weaponData.MainWeaponSkill.BaseInfo.Id + "</MainWeaponSkillId>";
		responseString = responseString + "<MainWeaponSkillLevel>" + _weaponData.MainWeaponSkill.Level + "</MainWeaponSkillLevel>";
		
		if (_weaponData.WeaponType == eWeaponType.LevelableTransformable || _weaponData.WeaponType == eWeaponType.Transformable)
		{
			responseString = responseString + "<TargetWeaponsInCaseTypeIsTransformable>";
			for (WeaponData targetWeaponData : _weaponData.getTransformableWeapons())
			{
				responseString = responseString + "<WeaponId>";
				responseString = responseString + String.valueOf(targetWeaponData.Id);
				responseString = responseString + "</WeaponId>";
			}
			responseString = responseString + "</TargetWeaponsInCaseTypeIsTransformable>";
		}
		
		responseString = responseString + "</WeaponData>";
		
    	return responseString;
    }
    
    private static void loadArmoursAsResponseStrings()
    {
    	for (ArmourData armourData : armours)
    	{
    		armoursAsResponseStrings.add(armourDataToResponseString(armourData));
    	}
    }
    
    private static String armourDataToResponseString(ArmourData _armourData)
    {
    	String responseString = "<ArmourData>";
		
		responseString = responseString + "<Id>" + String.valueOf(_armourData.Id) + "</Id>";
		responseString = responseString  + "<Name>" + _armourData.Name + "</Name>";
		responseString = responseString + "<IconAsBytes>" + Base64.encodeBase64String(_armourData.getIconAsBytes()) + "</IconAsBytes>";
		responseString = responseString + "<Rarity>" + _armourData.getRarity().toString() + "</Rarity>";
		
		responseString = responseString + "<StatusEffectDataIds>";
		for (StatusEffectData statusEffectData : _armourData.getStatusEffectsData())
		{
			responseString = responseString + "<StatusEffectDataId>";
			responseString = responseString + String.valueOf(statusEffectData.Id);
			responseString = responseString + "</StatusEffectDataId>";
		}
		responseString = responseString + "</StatusEffectDataIds>";
		
		responseString = responseString + "<ArmourClassification>" + _armourData.ArmourClassification.toString() + "</ArmourClassification>";
		responseString = responseString + "<TargetGender>" + _armourData.TargetGender.toString() + "</TargetGender>";
		
		responseString = responseString + "</ArmourData>";
		
    	return responseString;
    }
    
    private static void loadAccessoriesAsResponseStrings()
    {
    	for (AccessoryData accessoryData : accessories)
    	{
    		accessoriesAsResponseStrings.add(accessoryDataToResponseString(accessoryData));
    	}
    }
    
    private static String accessoryDataToResponseString(AccessoryData _accessoryData)
    {
    	String responseString = "<AccessoryData>";
		
		responseString = responseString + "<Id>" + String.valueOf(_accessoryData.Id) + "</Id>";
		responseString = responseString  + "<Name>" + _accessoryData.Name + "</Name>";
		responseString = responseString + "<IconAsBytes>" + Base64.encodeBase64String(_accessoryData.getIconAsBytes()) + "</IconAsBytes>";
		responseString = responseString + "<Rarity>" + _accessoryData.getRarity().toString() + "</Rarity>";
		
		responseString = responseString + "<StatusEffectDataIds>";
		for (StatusEffectData statusEffectData : _accessoryData.getStatusEffectsData())
		{
			responseString = responseString + "<StatusEffectDataId>";
			responseString = responseString + String.valueOf(statusEffectData.Id);
			responseString = responseString + "</StatusEffectDataId>";
		}
		responseString = responseString + "</StatusEffectDataIds>";
		
		responseString = responseString + "<AccessoryClassification>" + _accessoryData.accessoryClassification.toString() + "</AccessoryClassification>";
		responseString = responseString + "<TargetGender>" + _accessoryData.TargetGender.toString() + "</TargetGender>";
		
		responseString = responseString + "</AccessoryData>";
		
    	return responseString;
    }
    
    private static void loadItemsAsResponseStrings()
    {
    	for (Item item : items)
    	{
    		itemsAsResponseStrings.add(itemToResponseString(item));
    	}
    }
    
    private static String itemToResponseString(Item _item)
    {
    	String responseString = "";
		
		if (_item instanceof SkillItem)
			responseString = responseString + "<SkillItem>";
    	else if (_item instanceof SkillMaterial)
    		responseString = responseString + "<SkillMaterial>";
    	else if (_item instanceof ItemMaterial)
    		responseString = responseString + "<ItemMaterial>";
    	else if (_item instanceof EquipmentMaterial)
    		responseString = responseString + "<EquipmentMaterial>";
    	else if (_item instanceof EvolutionMaterial)
    		responseString = responseString + "<EvolutionMaterial>";
		
		responseString = responseString + "<Id>" + String.valueOf(_item.Id) + "</Id>";
		responseString = responseString  + "<Name>" + _item.Name + "</Name>";
		responseString = responseString + "<IconAsBytes>" + Base64.encodeBase64String(_item.getIconAsBytes()) + "</IconAsBytes>";
		responseString = responseString + "<Rarity>" + _item.getRarity().toString() + "</Rarity>";
		responseString = responseString + "<SellingPrice>" + String.valueOf(_item.SellingPrice) + "</SellingPrice>";
		
		if (_item instanceof SkillItem)
		{
			SkillItem skillItem = (SkillItem)_item;
			
			responseString = responseString + "<SkillId>" + String.valueOf(skillItem.getSkill().BaseInfo.Id) + "</SkillId>";
			responseString = responseString + "<SkillLevel>" + String.valueOf(skillItem.getSkill().Level) + "</SkillLevel>";
			
			responseString = responseString + "</SkillItem>";
		}
		else if (_item instanceof SkillMaterial)
			responseString = responseString + "</SkillMaterial>";
    	else if (_item instanceof ItemMaterial)
    		responseString = responseString + "</ItemMaterial>";
		else if (_item instanceof EquipmentMaterial)
			responseString = responseString + "</EquipmentMaterial>";
    	else if (_item instanceof EvolutionMaterial)
    		responseString = responseString + "</EvolutionMaterial>";
		
    	return responseString;
    }
    
    private static void loadSkillsAsResponseStrings()
    {
    	for (SkillData skillData : skills)
    	{
    		skillsAsResponseStrings.add(SkillDataToResponseString(skillData));
    	}
    }
    
    private static String SkillDataToResponseString(SkillData _skillData)
    {
    	String responseString = "";
    	
    	if (_skillData instanceof ActiveSkillData)
    	{
    		ActiveSkillData activeSkillData = (ActiveSkillData)_skillData;
			
    		if (activeSkillData instanceof OrdinarySkillData)
    			responseString = responseString + "<OrdinarySkillData>";
        	else if (activeSkillData instanceof CounterSkillData)
        		responseString = responseString + "<CounterSkillData>";
        	else if (activeSkillData instanceof UltimateSkillData)
        		responseString = responseString + "<UltimateSkillData>";
    		
    		responseString = responseString + "<Id>" + String.valueOf(activeSkillData.Id) + "</Id>";
			responseString = responseString  + "<Name>" + activeSkillData.Name + "</Name>";
			responseString = responseString + "<IconAsBytes>" + Base64.encodeBase64String(activeSkillData.getIconAsBytes()) + "</IconAsBytes>";
			
			responseString = responseString + "<TemporalStatusEffectDataIds>";
			for (BackgroundStatusEffectData temporalStatusEffectData : activeSkillData.getStatusEffectsData().stream().filter(x -> x instanceof BackgroundStatusEffectData).map(x -> (BackgroundStatusEffectData)x).collect(Collectors.toList()))
			{
				responseString = responseString + "<StatusEffectDataId>";
				responseString = responseString + String.valueOf(temporalStatusEffectData.Id);
				responseString = responseString + "</StatusEffectDataId>";
			}
			responseString = responseString + "</TemporalStatusEffectDataIds>";
			
			responseString = responseString + "<AnimationId>" + String.valueOf(activeSkillData.AnimationId) + "</AnimationId>";
			responseString = responseString + "<MaxNumberOfTargets>" + activeSkillData.getMaxNumberOfTargets().completeTagString + "</MaxNumberOfTargets>";
			responseString = responseString + "<EffectId>" + String.valueOf(activeSkillData.getEffect().Id) + "</EffectId>";
			
			if (activeSkillData instanceof OrdinarySkillData)
			{
				OrdinarySkillData ordinarySkillData = (OrdinarySkillData)activeSkillData;
				
				responseString = responseString + "<SPCost>" + ordinarySkillData.SPCost + "</SPCost>";
				responseString = responseString + ItemCostsToResponseString(ordinarySkillData.getItemCosts(), "ItemCosts");
				
    			responseString = responseString + "</OrdinarySkillData>";
			}
    		else if (activeSkillData instanceof CounterSkillData)
			{
	    		CounterSkillData counterSkillData = (CounterSkillData)activeSkillData;
				
				responseString = responseString + "<SPCost>" + counterSkillData.SPCost + "</SPCost>";
				responseString = responseString + ItemCostsToResponseString(counterSkillData.getItemCosts(), "ItemCosts");
				responseString = responseString + "<EventTriggerTiming>" + counterSkillData.EventTriggerTiming.toString() + "</EventTriggerTiming>";
				responseString = responseString + complexConditionToResponseString(counterSkillData.getActivationCondition(), "ActivationCondition");
			
    			responseString = responseString + "</CounterSkillData>";
			}
	    	else if (activeSkillData instanceof UltimateSkillData)
	    		responseString = responseString + "</UltimateSkillData>";
    	}
    	else if (_skillData instanceof PassiveSkillData)
    	{
			responseString = responseString + "<PassiveSkillData>";
    		
    		PassiveSkillData passiveSkillData = (PassiveSkillData)_skillData;
    		
    		responseString = responseString + "<Id>" + String.valueOf(passiveSkillData.Id) + "</Id>";
			responseString = responseString  + "<Name>" + passiveSkillData.Name + "</Name>";
			responseString = responseString + "<IconAsBytes>" + Base64.encodeBase64String(passiveSkillData.getIconAsBytes()) + "</IconAsBytes>";
			
			responseString = responseString + "<TemporalStatusEffectDataIds>";
			for (StatusEffectData temporalStatusEffectData : passiveSkillData.getStatusEffectsData())
			{
				responseString = responseString + "<StatusEffectDataId>";
				responseString = responseString + String.valueOf(temporalStatusEffectData.Id);
				responseString = responseString + "</StatusEffectDataId>";
			}
			responseString = responseString + "</TemporalStatusEffectDataIds>";
			
			responseString = responseString + "<AnimationId>" + String.valueOf(passiveSkillData.AnimationId) + "</AnimationId>";
			responseString = responseString + "<TargetClassification>" + passiveSkillData.TargetClassification.toString() + "</TargetClassification>";
			responseString = responseString + "<ActivationCondition>" + complexConditionToResponseString(passiveSkillData.getActivationCondition(), "ActivationCondition") + "</ActivationCondition>";
			
			
	    	responseString = responseString + "</PassiveSkillData>";
    	}
    	
    	return responseString;
    }
    
    private static String ItemCostsToResponseString(Map<Integer, Integer> _itemCosts, String _tagTitle)
    {
    	String responseString = "<" + _tagTitle + ">";
    	
    	for (Map.Entry<Integer, Integer> itemCost : _itemCosts.entrySet())
    	{
        	responseString = responseString + "<ItemCost>";
        	responseString = responseString + "<ItemId>" + String.valueOf(itemCost.getKey()) + "</ItemId>";
        	responseString = responseString + "<Quantity>" + String.valueOf(itemCost.getValue()) + "</Quantity>";
        	responseString = responseString + "</ItemCost>";
    	}
    	
    	responseString = responseString + "</" + _tagTitle + ">";
    	
    	return responseString;
    }
    
    private static void loadEffectsAsResponseStrings()
    {
    	for (Effect effect : effects)
    	{
        	effectsAsResponseStrings.add(effectToResponseString(effect));
    	}
    }
    
    private static String effectToResponseString(Effect _effect)
    {
    	String responseString = "";
    	
    	if (_effect instanceof UnitTargetingEffect)
    	{
    		UnitTargetingEffect unitTargetingEffect = (UnitTargetingEffect)_effect;
			
    		if (unitTargetingEffect instanceof DamageEffect)
    			responseString = responseString + "<DamageEffect>";
        	else if (unitTargetingEffect instanceof HealEffect)
        		responseString = responseString + "<HealEffect>";
        	else if (unitTargetingEffect instanceof StatusEffectAttachmentEffect)
        		responseString = responseString + "<StatusEffectAttachmentEffect>";
    		
    		responseString = responseString + "<Id>" + String.valueOf(unitTargetingEffect.Id) + "</Id>";
			responseString = responseString  + complexConditionToResponseString(unitTargetingEffect.getActivationCondition(), "ActivationCondition");
			responseString = responseString + "<TimesToApply>" + unitTargetingEffect.getTimesToApply().completeTagString + "</TimesToApply>";
			responseString = responseString + "<SuccessRate>" + unitTargetingEffect.getSuccessRate().completeTagString + "</SuccessRate>";
			responseString = responseString + "<DiffusionDistance>" + unitTargetingEffect.getDiffusionDistance().completeTagString + "</DiffusionDistance>";
			
			responseString = responseString + "<SecondaryEffectIds>";
			for (Effect secondaryEffect : unitTargetingEffect.getSecondaryEffects())
			{
				responseString = responseString + "<SecondaryEffectId>";
				responseString = responseString + String.valueOf(secondaryEffect.Id);
				responseString = responseString + "</SecondaryEffectId>";
			}
			responseString = responseString + "</SecondaryEffectIds>";
			
			responseString = responseString + "<AnimationId>" + String.valueOf(unitTargetingEffect.AnimationId) + "</AnimationId>";
			responseString = responseString + "<TargetClassification>" + unitTargetingEffect.TargetClassification.toString() + "</TargetClassification>";
			
			if (unitTargetingEffect instanceof DamageEffect)
			{
				DamageEffect damageEffect = (DamageEffect)unitTargetingEffect;
				
				responseString = responseString + "<AttackClassification>" + damageEffect.AttackClassification.toString() + "</AttackClassification>";
				responseString = responseString + "<Value>" + damageEffect.getValue().completeTagString + "</Value>";
				responseString = responseString + "<IsFixedValue>" + String.valueOf(damageEffect.IsFixedValue) + "</IsFixedValue>";
				responseString = responseString + "<Element>" + damageEffect.Element.toString() + "</Element>";
			
    			responseString = responseString + "</DamageEffect>";
			}
	    	else if (unitTargetingEffect instanceof HealEffect)
			{
	    		HealEffect healEffect = (HealEffect)unitTargetingEffect;
				
				responseString = responseString + "<Value>" + healEffect.getValue().completeTagString + "</Value>";
				responseString = responseString + "<IsFixedValue>" + String.valueOf(healEffect.IsFixedValue) + "</IsFixedValue>";
			
    			responseString = responseString + "</HealEffect>";
			}
	    	else if (unitTargetingEffect instanceof StatusEffectAttachmentEffect)
			{
	    		StatusEffectAttachmentEffect statusEffectAttachmentEffect = (StatusEffectAttachmentEffect)unitTargetingEffect;
				
	    		responseString = responseString + "<StatusEffectDataId>" + String.valueOf(statusEffectAttachmentEffect.getDataOfStatusEffectToAttach().Id) + "</StatusEffectDataId>";
	    		
	    		responseString = responseString + "</StatusEffectAttachmentEffect>";
			}
    	}
    	
    	return responseString;
    }
    
    private static void loadStatusEffectsAsResponseStrings()
    {
    	for (StatusEffectData statusEffectData : statusEffects)
    	{
    		statusEffectsAsResponseStrings.add(statusEffectDataToResponseString(statusEffectData));
    	}
    }
    
    private static String statusEffectDataToResponseString(StatusEffectData _statusEffectData)
    {
    	String responseString = "";
    	
    	if (_statusEffectData instanceof BackgroundStatusEffectData)
    	{
    		BackgroundStatusEffectData backgroundStatusEffectData = (BackgroundStatusEffectData)_statusEffectData;
			
    		if (backgroundStatusEffectData instanceof BuffStatusEffectData)
    			responseString = responseString + "<BuffStatusEffectData>";
        	else if (backgroundStatusEffectData instanceof DebuffStatusEffectData)
        		responseString = responseString + "<DebuffStatusEffectData>";
        	else if (backgroundStatusEffectData instanceof TargetRangeModStatusEffectData)
        		responseString = responseString + "<TargetRangeModStatusEffectData>";
    		
    		responseString = responseString + "<Id>" + String.valueOf(backgroundStatusEffectData.Id) + "</Id>";
    		responseString = responseString + durationDataToResponseString(backgroundStatusEffectData.getDuration(), "Duration");
			responseString = responseString + complexConditionToResponseString(backgroundStatusEffectData.getActivationCondition(), "ActivationCondition");
			responseString = responseString + "<IconAsBytes>" + Base64.encodeBase64String(backgroundStatusEffectData.getIconAsBytes()) + "</IconAsBytes>";
			responseString = responseString + "<ActivationTurnClassification>" + backgroundStatusEffectData.ActivationTurnClassification.toString() + "</ActivationTurnClassification>";
			
			if (backgroundStatusEffectData instanceof BuffStatusEffectData)
			{
				BuffStatusEffectData buffStatusEffectData = (BuffStatusEffectData)backgroundStatusEffectData;
				
				responseString = responseString + "<TargetStatusType>" + buffStatusEffectData.TargetStatusType.toString() + "</TargetStatusType>";
				responseString = responseString + "<Value>" + buffStatusEffectData.getValue().completeTagString + "</Value>";
				responseString = responseString + "<IsSum>" + String.valueOf(buffStatusEffectData.IsSum) + "</IsSum>";
				
    			responseString = responseString + "</BuffStatusEffectData>";
			}
	    	else if (backgroundStatusEffectData instanceof DebuffStatusEffectData)
			{
	    		DebuffStatusEffectData debuffStatusEffectData = (DebuffStatusEffectData)backgroundStatusEffectData;
				
				responseString = responseString + "<TargetStatusType>" + debuffStatusEffectData.TargetStatusType.toString() + "</TargetStatusType>";
				responseString = responseString + "<Value>" + debuffStatusEffectData.getValue().completeTagString + "</Value>";
				responseString = responseString + "<IsSum>" + String.valueOf(debuffStatusEffectData.IsSum) + "</IsSum>";
			
    			responseString = responseString + "</DebuffStatusEffectData>";
			}
	    	else if (backgroundStatusEffectData instanceof TargetRangeModStatusEffectData)
			{
	    		TargetRangeModStatusEffectData targetRangeModStatusEffectData = (TargetRangeModStatusEffectData)backgroundStatusEffectData;
				
				responseString = responseString + "<IsMovementRangeClassification>" + String.valueOf(targetRangeModStatusEffectData.IsMovementRangeClassification) + "</IsMovementRangeClassification>";
	    		responseString = responseString + "<TargetRangeClassification>" + targetRangeModStatusEffectData.TargetRangeClassification.toString() + "</TargetRangeClassification>";
				responseString = responseString + "<ModificationMethod>" + targetRangeModStatusEffectData.ModificationMethod.toString() + "</ModificationMethod>";

	    		responseString = responseString + "</TargetRangeModStatusEffectData>";
			}
    	}
    	else if (_statusEffectData instanceof ForegroundStatusEffectData)
    	{
    		ForegroundStatusEffectData foregroundStatusEffectData = (ForegroundStatusEffectData)_statusEffectData;
			
    		if (foregroundStatusEffectData instanceof DamageStatusEffectData)
    			responseString = responseString + "<DamageStatusEffectData>";
        	else if (foregroundStatusEffectData instanceof HealStatusEffectData)
        		responseString = responseString + "<HealStatusEffectData>";
    		
    		responseString = responseString + "<Id>" + String.valueOf(foregroundStatusEffectData.Id) + "</Id>";
    		responseString = responseString + durationDataToResponseString(foregroundStatusEffectData.getDuration(), "Duration");
			responseString = responseString + complexConditionToResponseString(foregroundStatusEffectData.getActivationCondition(), "ActivationCondition");
			responseString = responseString + "<IconAsBytes>" + Base64.encodeBase64String(foregroundStatusEffectData.getIconAsBytes()) + "</IconAsBytes>";
			responseString = responseString + "<ActivationTurnClassification>" + foregroundStatusEffectData.ActivationTurnClassification.toString() + "</ActivationTurnClassification>";
			responseString = responseString + "<EventTriggerTiming>" + foregroundStatusEffectData.EventTriggerTiming.toString() + "</EventTriggerTiming>";
			responseString = responseString + "<AnimationId>" + String.valueOf(foregroundStatusEffectData.AnimationId) + "</AnimationId>";
			
			if (foregroundStatusEffectData instanceof DamageStatusEffectData)
			{
				DamageStatusEffectData damageStatusEffectData = (DamageStatusEffectData)foregroundStatusEffectData;
				
				responseString = responseString + "<Value>" + damageStatusEffectData.getValue().completeTagString + "</Value>";
				
    			responseString = responseString + "</DamageStatusEffectData>";
			}
	    	else if (foregroundStatusEffectData instanceof HealStatusEffectData)
			{
	    		HealStatusEffectData healStatusEffectData = (HealStatusEffectData)foregroundStatusEffectData;
				
				responseString = responseString + "<Value>" + healStatusEffectData.getValue().completeTagString + "</Value>";
			
    			responseString = responseString + "</HealStatusEffectData>";
			}
    	}
    	
    	return responseString;
    }
    
    private static String durationDataToResponseString(DurationData _durationData, String _tagTitle)
    {
    	String responseString = "<" + _tagTitle + ">";
    	
    	responseString = responseString + "<ActivationTimes>" + _durationData.getActivationTimes().completeTagString + "</ActivationTimes>";
    	responseString = responseString + "<Turns>" + _durationData.getTurns().completeTagString + "</Turns>";
    	responseString = responseString + complexConditionToResponseString(_durationData.getWhileCondition(), "WhileCondition");
    	
    	responseString = responseString + "</" + _tagTitle + ">";;
    	
    	return responseString;
    }
    
    private static String complexConditionToResponseString(ComplexCondition _complexCondition, String _tagTitle)
    {
    	String responseString = "<" + _tagTitle + ">";
    	
    	for (List<Condition> conditionSet : _complexCondition.getConditionSets())
    	{
        	responseString = responseString + "<ConditionSet>";
        	
        	for (Condition condition : conditionSet)
        	{
            	responseString = responseString + "<Condition>";
            	responseString = responseString + conditionToResponseString(condition);
            	responseString = responseString + "</Condition>";
        	}
        	
        	responseString = responseString + "</ConditionSet>";
    	}
    	
    	responseString = responseString + "</" + _tagTitle + ">";
    	
    	return responseString;
    }
    
    private static String conditionToResponseString(Condition _condition)
    {
    	String responseString = "<Condition>";
    	
    	responseString = responseString + "<TagA>" + _condition.getA().completeTagString + "</TagA>";
    	responseString = responseString + "<RelationType>" + _condition.RelationType.toString() + "</RelationType>";
    	responseString = responseString + "<TagB>" + _condition.getB().completeTagString + "</TagB>";
    	
    	responseString = responseString + "</Condition>";
    	
    	return responseString;
    }
    
    private static void loadItems(Connection _con)
    {
    	items.clear();
    	
    	try 
    	{	    		
			String query = "select Id from BaseItems"; //Load the entire BaseItems.Id column
			PreparedStatement statement = _con.prepareStatement(query);
			
			ResultSet resultSet = statement.executeQuery();
			while (resultSet.next())
			{
				int id = resultSet.getInt("Id");
				items.add(loadItem(_con, id));
			}
    	}
    	catch (Exception ex)
    	{
    		System.out.println(ex.toString());
    	}
    }
    
    private static Item loadItem(Connection _con, int _id)
    {
    	try
    	{
    		String query = "select * from BaseItems"; //Load the entire BaseItems table
    		PreparedStatement statement = _con.prepareStatement(query);
        	
    		ResultSet resultSet = statement.executeQuery();
    		if (!resultSet.next())
    			return null;
    		
    		String name = resultSet.getString("Name");
			int classificationId = resultSet.getInt("ClassificationId");
			int rarityId = resultSet.getInt("RarityId");
			int sellingPrice = resultSet.getInt("SellingPrice");
    		int iconId = resultSet.getInt("IconId");
    		
    		byte[] iconAsBytes = loadSkillIconAsBytes(_con, iconId);
    		eRarity rarity = loadRarity(_con, rarityId);
    		
    		query = "select Name from ItemClassifications where Id=?"; //Get classification name for the item
    		statement = _con.prepareStatement(query);
    		statement.setInt(1, classificationId);
    		
    		ResultSet resultSet2 = statement.executeQuery();
    		if (!resultSet2.next())
    			return null;
    		
    		String classificationName = resultSet2.getString("Name");
    		switch (classificationName)
    		{
    			case "SkillItem":
    				return loadSkillItem(_con, _id, name, iconAsBytes, rarity, sellingPrice);
    			case "SkillMaterial":
    				return new SkillMaterial(_id, name, iconAsBytes, rarity, sellingPrice);
    			case "ItemMaterial":
    				return new ItemMaterial(_id, name, iconAsBytes, rarity, sellingPrice);
    			case "EquipmentMaterial":
    				return new EquipmentMaterial(_id, name, iconAsBytes, rarity, sellingPrice);
    			case "EvolutionMaterial":
    				return new EvolutionMaterial(_id, name, iconAsBytes, rarity, sellingPrice);
    			default:
    				return null;						
    		}	
    	}
    	catch (Exception ex)
    	{
    		System.out.println(ex.toString());
    		return null;
    	}
    }
    
    private static SkillItem loadSkillItem(Connection _con, int _id, String _name, byte[] _iconAsBytes, eRarity _rarity, int _sellingPrice) 
    {
    	try 
		{
			String query = "select * from SkillItems where BaseItemId=?"; //Load detailed data of the item
			PreparedStatement statement = _con.prepareStatement(query);
			statement.setInt(1, _id);
			
			ResultSet resultSet = statement.executeQuery();
			if (!resultSet.next())
				return null;
			
			int skillId = resultSet.getInt("SkillId");
			int skillLevel = resultSet.getInt("SkillLevel");
			
			SkillData skillData = skills.stream().filter(x -> x.Id == skillId).findFirst().get();
			Skill skill = null;
			if (skillData instanceof OrdinarySkillData)
				skill = new OrdinarySkill((OrdinarySkillData)skillData, skillLevel);
			else if (skillData instanceof CounterSkillData)
				skill = new CounterSkill((CounterSkillData)skillData, skillLevel);
			else if (skillData instanceof CounterSkillData)
				skill = new CounterSkill((CounterSkillData)skillData, skillLevel);
			else if (skillData instanceof CounterSkillData)
				skill = new CounterSkill((CounterSkillData)skillData, skillLevel);
			
			return new SkillItem(_id, _name, _iconAsBytes, _rarity, _sellingPrice, skill);
		} 
		catch (SQLException e) 
		{
			e.printStackTrace();
			return null;
		}   
	}
    
    private static void loadAccessories(Connection _con)
    {
    	accessories.clear();
    	
    	try
    	{  		
			String query = "select * from BaseAccessories"; //Load the entire BaseAccessories table
			PreparedStatement statement = _con.prepareStatement(query);
			
			ResultSet resultSet = statement.executeQuery();
			while (resultSet.next())
			{
				int id = resultSet.getInt("Id");
				String name = resultSet.getString("Name");
				int rarityId = resultSet.getInt("RarityId");
				int classificationId = resultSet.getInt("ClassificationId");
				int targetGenderId = resultSet.getInt("TargetGenderId");
				String iconPath = resultSet.getString("IconPath");
				
				BufferedImage icon = ImageIO.read(new File(iconPath));
				ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
				ImageIO.write(icon, "png", outputStream);
		    	byte[] iconAsBytes = outputStream.toByteArray();
				eRarity rarity = loadRarity(_con, rarityId);
				List<StatusEffectData> statusEffectsData = new ArrayList<StatusEffectData>();
				addAccessoryStatusEffectsData(_con, id, statusEffectsData);
				eAccessoryClassification classification = loadAccessoryClassification(_con, classificationId);
				eGender targetGender = loadGender(_con, targetGenderId);
				
				accessories.add(new AccessoryData(id, name, iconAsBytes, rarity, statusEffectsData, classification, targetGender));
			}
    	}
    	catch (Exception ex)
    	{
    		System.out.println(ex.toString());
    	}
    }
    
    private static void loadArmours(Connection _con)
    {
    	armours.clear();
    	
    	try
    	{  		
			String query = "select * from BaseArmours"; //Load the entire BaseArmours table
			PreparedStatement statement = _con.prepareStatement(query);
			
			ResultSet resultSet = statement.executeQuery();
			while (resultSet.next())
			{
				int id = resultSet.getInt("Id");
				String name = resultSet.getString("Name");
				int rarityId = resultSet.getInt("RarityId");
				int classificationId = resultSet.getInt("ClassificationId");
				int targetGenderId = resultSet.getInt("TargetGenderId");
				String iconPath = resultSet.getString("IconPath");
				
				BufferedImage icon = ImageIO.read(new File(iconPath));
				ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
				ImageIO.write(icon, "png", outputStream);
		    	byte[] iconAsBytes = outputStream.toByteArray();
				eRarity rarity = loadRarity(_con, rarityId);
				List<StatusEffectData> statusEffectsData = new ArrayList<StatusEffectData>();
				addArmourStatusEffectsData(_con, id, statusEffectsData);
				eArmourClassification classification = loadArmourClassification(_con, classificationId);
				eGender targetGender = loadGender(_con, targetGenderId);
				
				armours.add(new ArmourData(id, name, iconAsBytes, rarity, statusEffectsData, classification, targetGender));
			}
    	}
    	catch (Exception ex)
    	{
    		System.out.println(ex.toString());
    	}
    }
    
    private static void loadWeapons(Connection _con)
    {
    	weapons.clear();
    	
    	try
    	{
			String query = "select * from BaseWeapons"; //Load the entire BaseWeapons table
			PreparedStatement statement = _con.prepareStatement(query);
			
			ResultSet resultSet = statement.executeQuery();	
			while (resultSet.next())
			{
				int id = resultSet.getInt("Id");
				String name = resultSet.getString("Name");
				int rarityId = resultSet.getInt("RarityId");
				int typeId = resultSet.getInt("TypeId");
				String iconPath = resultSet.getString("IconPath");
				int mainWeaponSkillId = resultSet.getInt("MainWeaponSkillId");
				int mainWeaponSkillLevel = resultSet.getInt("MainWeaponSkillLevel");
				
				BufferedImage icon = ImageIO.read(new File(iconPath));
				ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
				ImageIO.write(icon, "png", outputStream);
		    	byte[] iconAsBytes = outputStream.toByteArray();
				eRarity rarity = loadRarity(_con, rarityId);
				List<StatusEffectData> statusEffectsData = new ArrayList<StatusEffectData>();
				addWeaponStatusEffectsData(_con, id, statusEffectsData);
				eWeaponType type = loadWeaponType(_con, typeId);
				List<eWeaponClassification> classifications = new ArrayList<eWeaponClassification>();
				addWeaponClassifications(_con, id, classifications);
				
				SkillData mainWeaponSkillData = skills.stream().filter(x -> x.Id == mainWeaponSkillId).findFirst().orElse(null);
				Skill mainWeaponSkill = null;
				if (mainWeaponSkillData != null)
				{
					if (mainWeaponSkillData instanceof OrdinarySkillData)
						mainWeaponSkill = new OrdinarySkill((OrdinarySkillData)mainWeaponSkillData, mainWeaponSkillLevel);
					else if (mainWeaponSkillData instanceof CounterSkillData)
						mainWeaponSkill = new CounterSkill((CounterSkillData)mainWeaponSkillData, mainWeaponSkillLevel);
					else if (mainWeaponSkillData instanceof CounterSkillData)
						mainWeaponSkill = new CounterSkill((CounterSkillData)mainWeaponSkillData, mainWeaponSkillLevel);
					else if (mainWeaponSkillData instanceof CounterSkillData)
						mainWeaponSkill = new CounterSkill((CounterSkillData)mainWeaponSkillData, mainWeaponSkillLevel);
				}
				
				weapons.add(new WeaponData(id, name, iconAsBytes, rarity, statusEffectsData, type, classifications, mainWeaponSkill, new ArrayList<WeaponData>()));
			}
    	}
    	catch (Exception ex)
    	{
    		System.out.println(ex.toString());
    	}
    }
    
    private static void loadTransformableWeaponsData(Connection _con)
    {
		try 
		{
			for (WeaponData weaponData : weapons.stream().filter(x -> x.WeaponType == eWeaponType.Transformable).collect(Collectors.toList()))
			{
				String query = "select TargetId from TransformableWeapon_TargetWeapon where WeaponId=?"; //Load the Ids for the target weapons
				PreparedStatement statement = _con.prepareStatement(query);
				statement.setInt(1, weaponData.Id);
				
				ResultSet resultSet = statement.executeQuery();
				while (resultSet.next())
				{
					int targetId = resultSet.getInt("TargetId");
					weaponData.getTransformableWeapons().add(weapons.stream().filter(x -> x.Id == targetId).findFirst().get());
				}
				
				weaponData.DisableModification();
			}
		} 
		catch (SQLException e) 
		{
			e.printStackTrace();
		}   
    }
    
    private static void addWeaponStatusEffectsData(Connection _con, int _id, List<StatusEffectData> _statusEffectsData)
    {
    	addEquipmentStatusEffectsData(_con, _id, _statusEffectsData, "select StatusEffectId from Weapon_StatusEffect where WeaponId=?");
    }
    private static void addArmourStatusEffectsData(Connection _con, int _id, List<StatusEffectData> _statusEffectsData)
    {
    	addEquipmentStatusEffectsData(_con, _id, _statusEffectsData, "select StatusEffectId from Armour_StatusEffect where ArmourId=?");
    }
    private static void addAccessoryStatusEffectsData(Connection _con, int _id, List<StatusEffectData> _statusEffectsData)
    {
    	addEquipmentStatusEffectsData(_con, _id, _statusEffectsData, "select StatusEffectId from Accessory_StatusEffect where AccessoryId=?");
    }
    private static void addEquipmentStatusEffectsData(Connection _con, int _id, List<StatusEffectData> _statusEffectsData, String _query)
    {
		try 
		{
			PreparedStatement statement = _con.prepareStatement(_query);
			statement.setInt(1, _id);
			
			ResultSet resultSet = statement.executeQuery();
			while (resultSet.next())
			{
				int statusEffectId = resultSet.getInt("StatusEffectId");
				_statusEffectsData.add(statusEffects.stream().filter(x -> x.Id == statusEffectId).findFirst().get());
			}
		} 
		catch (SQLException e) 
		{
			e.printStackTrace();
		}   
    }
    
    private static void addWeaponClassifications(Connection _con, int _id, List<eWeaponClassification> _weaponClassifications)
    {
		try 
		{
			String query = "select ClassificationId from Weapon_Classification where WeaponId=?"; //Load the Ids for the classifications
			PreparedStatement statement = _con.prepareStatement(query);
			statement.setInt(1, _id);
			
			ResultSet resultSet = statement.executeQuery();
			while (resultSet.next())
			{
				int classificationId = resultSet.getInt("ClassificationId");
				_weaponClassifications.add(loadWeaponClassification(_con, classificationId));
			}
		} 
		catch (SQLException e) 
		{
			e.printStackTrace();
		}   
    }
    
    private static void loadLevelableTransformableWeaponsData(Connection _con)
    {
		try 
		{
			for (WeaponData weaponData : weapons.stream().filter(x -> x.WeaponType == eWeaponType.LevelableTransformable).collect(Collectors.toList()))
			{
				String query = "select TargetId from LevelableTransformableWeapon_TargetWeapon where WeaponId=?"; //Load the Ids for the target weapons
				PreparedStatement statement = _con.prepareStatement(query);
				statement.setInt(1, weaponData.Id);
				
				ResultSet resultSet = statement.executeQuery();
				while (resultSet.next())
				{
					int targetId = resultSet.getInt("TargetId");
					weaponData.getTransformableWeapons().add(weapons.stream().filter(x -> x.Id == targetId).findFirst().get());
				}
				
				weaponData.DisableModification();
			}
		} 
		catch (SQLException e) 
		{
			e.printStackTrace();
		}   
    }

    private static void loadPlayers(Connection _con)
    {
    	players.clear();
    	
    	try 
    	{	
			String query = "select * from Players"; //Load the entire Players table;
			PreparedStatement statement = _con.prepareStatement(query);
			
			ResultSet resultSet = statement.executeQuery();
			while (resultSet.next())
			{
				int id = resultSet.getInt("Id");
				String playerName = resultSet.getString("PlayerName");
				int gemsOwned = resultSet.getInt("GemsOwned");
				int goldOwned = resultSet.getInt("GoldOwned");
				
				List<Unit> unitsOwned = new ArrayList<Unit>();
				addUnitsOwned(_con, id, unitsOwned);
				Map<Item, Integer> itemsOwned = new HashMap<Item, Integer>();
				addItemsOwned(_con, id, itemsOwned);
				List<Weapon> weaponsOwned = new ArrayList<Weapon>();
				addWeaponsOwned(_con, id, weaponsOwned);
				List<Armour> armoursOwned = new ArrayList<Armour>();
				addArmoursOwned(_con, id, armoursOwned);
				List<Accessory> accessoriesOwned = new ArrayList<Accessory>();
				addAccessoriesOwned(_con, id, accessoriesOwned);
				List<MemberSet> memberSets = new ArrayList<MemberSet>();
				addMemberSets(_con, id, unitsOwned, weaponsOwned, armoursOwned, accessoriesOwned, memberSets);
				List<ItemSet> itemSets = new ArrayList<ItemSet>();
				addItemSets(_con, id, itemSets);
				List<Team> teams = new ArrayList<Team>();
				addTeams(_con, id, memberSets, itemSets, teams);
				
				players.add(new Player(id, playerName, unitsOwned, weaponsOwned, armoursOwned, accessoriesOwned, itemsOwned, memberSets, itemSets, teams, gemsOwned, goldOwned));
			}
    	}
    	catch (Exception ex)
    	{
    		System.out.println(ex.toString());
    	}
    }
    
    private static void addUnitsOwned(Connection _con, int _id, List<Unit> _unitsOwned)
    {
    	try 
		{
			String query = "select * from PlayableUnits where OwnerPlayerId=?";
			PreparedStatement statement = _con.prepareStatement(query);
			statement.setInt(1, _id);
			
			ResultSet resultSet = statement.executeQuery();
			while (resultSet.next())
			{
				int uniqueId = resultSet.getInt("Id");
				int baseUnitId = resultSet.getInt("BaseUnitId");
				int accumulatedExperience = resultSet.getInt("AccumulatedExperience");
				String nickname = resultSet.getString("Nickname");
				
				UnitData baseUnit = units.stream().filter(x -> x.Id == baseUnitId).findFirst().get();				
				Map<Integer, Integer> levelPerSkill = new HashMap<Integer, Integer>();
				addPlayableUnitLevelPerSkill(_con, _id, levelPerSkill);
				
				_unitsOwned.add(new Unit(baseUnit, uniqueId, nickname, accumulatedExperience, levelPerSkill));
			}
		}
		catch (SQLException e) 
		{
			e.printStackTrace();
		}
    }
    
    private static void addPlayableUnitLevelPerSkill(Connection _con, int _id, Map<Integer, Integer> _levelPerSkill)
    {
		try 
		{
			String query = "select SkillId, SkillLevel from PlayableUnit_SkillLevel where UnitId=?";
			PreparedStatement statement = _con.prepareStatement(query);
			statement.setInt(1, _id);
			
			ResultSet resultSet = statement.executeQuery();
			while (resultSet.next())
			{
				int skillId = resultSet.getInt("SkillId");
				int skillLevel = resultSet.getInt("SkillLevel");
				
				_levelPerSkill.put(skillId, skillLevel);
			}
		} 
		catch (SQLException e) 
		{
			e.printStackTrace();
		}   
    }
    
    private static void loadSkillInheritors(Connection _con)
    {
		try 
		{
			for (Player player : players)
			{
				for (Unit unit : player.UnitsOwned)
				{
					String query = "select SkillInheritorUnitId, InheritingSkillId from PlayableUnits where Id=?";
					PreparedStatement statement = _con.prepareStatement(query);
					statement.setInt(1, unit.UniqueId);
					
					ResultSet resultSet = statement.executeQuery();
					while (resultSet.next())
					{
						int skillInheritorUnitId = resultSet.getInt("SkillInheritorUnitId");
						int inheritingSkillId = resultSet.getInt("InheritingSkillId");
						
						unit.SkillInheritor = player.UnitsOwned.stream().filter(x -> x.UniqueId == skillInheritorUnitId).findFirst().orElse(null);
						unit.InheritingSkillId = inheritingSkillId;
					}
				}
			}
		} 
		catch (SQLException e) 
		{
			e.printStackTrace();
		}   
    }
    
    private static void addItemsOwned(Connection _con, int _id, Map<Item, Integer> _itemsOwned)
    {
    	try 
		{
			String query = "select * from Player_ItemOwned where PlayerId=?";
			PreparedStatement statement = _con.prepareStatement(query);
			statement.setInt(1, _id);
			
			ResultSet resultSet = statement.executeQuery();
			while (resultSet.next())
			{
				int itemId = resultSet.getInt("ItemId");
				int quantity = resultSet.getInt("Quantity");
				
				Item item = items.stream().filter(x -> x.Id == itemId).findFirst().get();
				_itemsOwned.put(item, quantity);
			}
		}
		catch (SQLException e) 
		{
			e.printStackTrace();
		}
    }
    
    private static void addWeaponsOwned(Connection _con, int _id, List<Weapon> _weaponsOwned)
    {
    	try 
		{
			String query = "select * from UsableWeapons where OwnerPlayerId=?";
			PreparedStatement statement = _con.prepareStatement(query);
			statement.setInt(1, _id);
			
			ResultSet resultSet = statement.executeQuery();
			while (resultSet.next())
			{
				int uniqueId = resultSet.getInt("Id");
				int baseWeaponId = resultSet.getInt("BaseWeaponId");
				
				WeaponData baseWeapon = weapons.stream().filter(x -> x.Id == baseWeaponId).findFirst().get();
				
				int accumulatedExperience = resultSet.getInt("AccumulatedExperience");
				if (baseWeapon.WeaponType == eWeaponType.Levelable || baseWeapon.WeaponType == eWeaponType.LevelableTransformable)
				{
					query = "select AccumulatedExperience from UsableLevelableWeapons where BaseUsableWeaponId=?";
					statement = _con.prepareStatement(query);
					statement.setInt(1, uniqueId);
					
					ResultSet resultSet2 = statement.executeQuery();
					if (!resultSet2.next())
						return;
					
					accumulatedExperience = resultSet2.getInt("AccumulatedExperience");
				}
				
				switch (baseWeapon.WeaponType)
				{
					default: //case Ordinary:
						_weaponsOwned.add(new OrdinaryWeapon(baseWeapon, uniqueId));
						break;
						
					case Levelable:
						_weaponsOwned.add(new LevelableWeapon(baseWeapon, uniqueId, accumulatedExperience));
						break;
						
					case LevelableTransformable:
						_weaponsOwned.add(new LevelableTransformableWeapon(baseWeapon, uniqueId, accumulatedExperience));
						break;
						
					case Transformable:
						_weaponsOwned.add(new TransformableWeapon(baseWeapon, uniqueId));
						break;
				}
			}
		}
		catch (SQLException e) 
		{
			e.printStackTrace();
		}
    }
    
    private static void addArmoursOwned(Connection _con, int _id, List<Armour> _armoursOwned)
    {
    	try 
		{
			String query = "select * from UsableArmours where OwnerPlayerId=?";
			PreparedStatement statement = _con.prepareStatement(query);
			statement.setInt(1, _id);
			
			ResultSet resultSet = statement.executeQuery();
			while (resultSet.next())
			{
				int uniqueId = resultSet.getInt("Id");
				int baseArmourId = resultSet.getInt("BaseArmourId");
				
				ArmourData baseArmour = armours.stream().filter(x -> x.Id == baseArmourId).findFirst().get();
				
				_armoursOwned.add(new Armour(baseArmour, uniqueId));
			}
		}
		catch (SQLException e) 
		{
			e.printStackTrace();
		}
    }
    
    private static void addAccessoriesOwned(Connection _con, int _id, List<Accessory> _accessoriesOwned)
    {
    	try 
		{
			String query = "select * from UsableAccessories where OwnerPlayerId=?";
			PreparedStatement statement = _con.prepareStatement(query);
			statement.setInt(1, _id);
			
			ResultSet resultSet = statement.executeQuery();
			while (resultSet.next())
			{
				int uniqueId = resultSet.getInt("Id");
				int baseAccessoryId = resultSet.getInt("BaseAccessoryId");
				
				AccessoryData baseAccessory = accessories.stream().filter(x -> x.Id == baseAccessoryId).findFirst().get();
				
				_accessoriesOwned.add(new Accessory(baseAccessory, uniqueId));
			}
		}
		catch (SQLException e) 
		{
			e.printStackTrace();
		}
    }
    
    private static void addMemberSets(Connection _con, int _id, List<Unit> _unitsOwned, List<Weapon> _weaponsOwned, List<Armour> _armoursOwned, List<Accessory> _accessoriesOwned, List<MemberSet> _memberSets)
    {
    	try 
		{
			String query = "select * from MemberSets where OwnerId=?";
			PreparedStatement statement = _con.prepareStatement(query);
			statement.setInt(1, _id);
			
			ResultSet resultSet = statement.executeQuery();
			while (resultSet.next())
			{
				int id = resultSet.getInt("Id");
				int memberId = resultSet.getInt("MemberId");
				int mainWeaponId = resultSet.getInt("MainWeaponId");
				int subWeaponId = resultSet.getInt("SubWeaponId");
				int armourId = resultSet.getInt("ArmourId");
				int accessoryId = resultSet.getInt("AccessoryId");
			
				Unit member = _unitsOwned.stream().filter(x -> x.UniqueId == memberId).findFirst().get();
				Weapon mainWeapon = _weaponsOwned.stream().filter(x -> x.UniqueId == mainWeaponId).findFirst().orElse(null);
				Weapon subWeapon = _weaponsOwned.stream().filter(x -> x.UniqueId == subWeaponId).findFirst().orElse(null);
				Armour armour = _armoursOwned.stream().filter(x -> x.UniqueId == armourId).findFirst().orElse(null);
				Accessory accessory = _accessoriesOwned.stream().filter(x -> x.UniqueId == accessoryId).findFirst().orElse(null);
				
				_memberSets.add(new MemberSet(id, member, mainWeapon, subWeapon, armour, accessory));
			}
		}
		catch (SQLException e) 
		{
			e.printStackTrace();
		}
    }
    
    private static void addItemSets(Connection _con, int _id, List<ItemSet> _itemSets)
    {
    	try 
		{
			String query = "select Id from BattleItemSets where OwnerId=?";
			PreparedStatement statement = _con.prepareStatement(query);
			statement.setInt(1, _id);
			
			ResultSet resultSet = statement.executeQuery();
			while (resultSet.next())
			{
				int itemSetId = resultSet.getInt("Id");
				
				Map<Item, Integer> quantityPerItem = new HashMap<Item, Integer>();
				
				query = "select * from BattleItemSet_Item where ItemSetId=?";
				statement = _con.prepareStatement(query);
				statement.setInt(1, itemSetId);
				
				ResultSet resultSet2 = statement.executeQuery();
				while (resultSet2.next())
				{
					int itemId = resultSet2.getInt("ItemId");
					int quantity = resultSet2.getInt("Quantity");
					
					Item item = items.stream().filter(x -> x.Id == itemId).findFirst().get();
					
					quantityPerItem.put(item, quantity);
				}
				
				_itemSets.add(new ItemSet(itemSetId, quantityPerItem));
			}
		}
		catch (SQLException e) 
		{
			e.printStackTrace();
		}
    }
    
    private static void addTeams(Connection _con, int _id, List<MemberSet> _memberSets, List<ItemSet> _itemSets, List<Team> _teams)
    {
    	try 
		{
			String query = "select * from Teams where OwnerId=?";
			PreparedStatement statement = _con.prepareStatement(query);
			statement.setInt(1, _id);
			
			ResultSet resultSet = statement.executeQuery();
			while (resultSet.next())
			{
				int memberSet1Id = resultSet.getInt("MemberSet1Id");
				int memberSet2Id = resultSet.getInt("MemberSet2Id");
				int memberSet3Id = resultSet.getInt("MemberSet3Id");
				int memberSet4Id = resultSet.getInt("MemberSet4Id");
				int memberSet5Id = resultSet.getInt("MemberSet5Id");
				int itemSetId = resultSet.getInt("ItemSetId");
				
				List<MemberSet> memberSets = new ArrayList<MemberSet>();
				MemberSet memberSet1 = _memberSets.stream().filter(x -> x.Id == memberSet1Id).findFirst().get();
				MemberSet memberSet2 = _memberSets.stream().filter(x -> x.Id == memberSet2Id).findFirst().orElse(null);
				MemberSet memberSet3 = _memberSets.stream().filter(x -> x.Id == memberSet3Id).findFirst().orElse(null);
				MemberSet memberSet4 = _memberSets.stream().filter(x -> x.Id == memberSet4Id).findFirst().orElse(null);
				MemberSet memberSet5 = _memberSets.stream().filter(x -> x.Id == memberSet5Id).findFirst().orElse(null);
				memberSets.add(memberSet1);
				memberSets.add(memberSet2);
				memberSets.add(memberSet3);
				memberSets.add(memberSet4);
				memberSets.add(memberSet5);
				ItemSet itemSet = _itemSets.stream().filter(x -> x.Id == itemSetId).findFirst().orElse(null);
				
				_teams.add(new Team(memberSets, itemSet));
			}
		}
		catch (SQLException e) 
		{
			e.printStackTrace();
		}
    }
    
    private static void loadUnits(Connection _con)
    {
    	units.clear();
    	
    	try 
    	{	
			String query = "select * from BaseUnits"; //Load the entire BaseUnits table;
			PreparedStatement statement = _con.prepareStatement(query);
			
			ResultSet resultSet = statement.executeQuery();
			while (resultSet.next())
			{
				int id = resultSet.getInt("Id");
				String name = resultSet.getString("Name");
				int rarityId = resultSet.getInt("RarityId");
				int genderId = resultSet.getInt("GenderId");
				int movementRangeClassificationId = resultSet.getInt("MovementRangeClassificationId");
				int nonMovementActionRangeClassificationId = resultSet.getInt("NonMovementActionRangeClassificationId");
				int elementId1 = resultSet.getInt("ElementId1");
				int elementId2 = resultSet.getInt("ElementId2");
				int maxHPAtMaxLevel = resultSet.getInt("MaxHPAtMaxLevel");
				int physicalStrengthAtMaxLevel = resultSet.getInt("PhysicalStrengthAtMaxLevel");
				int physicalResistanceAtMaxLevel = resultSet.getInt("PhysicalResistanceAtMaxLevel");
				int magicalStrengthAtMaxLevel = resultSet.getInt("MagicalStrengthAtMaxLevel");
				int magicalResistanceAtMaxLevel = resultSet.getInt("MagicalResistanceAtMaxLevel");
				int vitalityAtMaxLevel = resultSet.getInt("VitalityAtMaxLevel");
				String description = resultSet.getString("Description");
				String iconPath = resultSet.getString("IconPath");
				
				BufferedImage icon = ImageIO.read(new File(iconPath));
				ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
				ImageIO.write(icon, "png", outputStream);
		    	byte[] iconAsBytes = outputStream.toByteArray();
				eGender gender = loadGender(_con, genderId);
				eRarity rarity = loadRarity(_con, rarityId);
				eTargetRangeClassification movementRangeClassification = loadTargetRangeClassification(_con, movementRangeClassificationId);
				eTargetRangeClassification nonMovementActionRangeClassification = loadTargetRangeClassification(_con, nonMovementActionRangeClassificationId);
				List<eElement> elements = new ArrayList<eElement>();
				elements.add(loadElement(_con, elementId1));
				elements.add(loadElement(_con, elementId2));
				List<eWeaponClassification> equipableWeaponClassifications = new ArrayList<eWeaponClassification>();
				addUnitEquipableWeaponClassifications(_con, id, equipableWeaponClassifications);
				List<eArmourClassification> equipableArmourClassifications = new ArrayList<eArmourClassification>();
				addUnitEquipableArmourClassifications(_con, id, equipableArmourClassifications);
				List<eAccessoryClassification> equipableAccessoryClassifications = new ArrayList<eAccessoryClassification>();
				addUnitEquipableAccessoryClassifications(_con, id, equipableAccessoryClassifications);
				List<SkillData> skills = new ArrayList<SkillData>();
				addUnitSkillsData(_con, id, skills);
				List<String> labels = new ArrayList<String>();
				addUnitLabels(_con, id, labels);
				List<UnitEvolutionRecipe> progressiveEvolutionRecipes = new ArrayList<UnitEvolutionRecipe>(); //Recipes will be added afterwards
				UnitEvolutionRecipe retrogressiveEvolutionRecipe = null; //Recipe will be added afterwards
				
				units.add(new UnitData(id, name, iconAsBytes, gender, rarity, movementRangeClassification, nonMovementActionRangeClassification, elements, equipableWeaponClassifications, equipableArmourClassifications, equipableAccessoryClassifications, maxHPAtMaxLevel, physicalStrengthAtMaxLevel, physicalResistanceAtMaxLevel, magicalStrengthAtMaxLevel, magicalResistanceAtMaxLevel, vitalityAtMaxLevel, skills, labels, description, progressiveEvolutionRecipes, retrogressiveEvolutionRecipe));
			}
    	}
    	catch (Exception ex)
    	{
    		System.out.println(ex.toString());
    	}
    }
    
    private static void addUnitEquipableWeaponClassifications(Connection _con, int _id, List<eWeaponClassification> _equipableWeaponClassifications)
    {
		try 
		{
			String query = "select WeaponClassificationId from Unit_EquipableWeaponClassification where UnitId=?"; //Load the Ids for the equipable weapon classifications
			PreparedStatement statement = _con.prepareStatement(query);
			statement.setInt(1, _id);
			
			ResultSet resultSet = statement.executeQuery();
			while (resultSet.next())
			{
				int weaponClassificationId = resultSet.getInt("WeaponClassificationId");
				_equipableWeaponClassifications.add(loadWeaponClassification(_con, weaponClassificationId));
			}
		} 
		catch (SQLException e) 
		{
			e.printStackTrace();
		}   
    }
    
    private static void addUnitEquipableArmourClassifications(Connection _con, int _id, List<eArmourClassification> _equipableArmourClassifications)
    {
		try 
		{
			String query = "select ArmourClassificationId from Unit_EquipableArmourClassification where UnitId=?"; //Load the Ids for the equipable armour classifications
			PreparedStatement statement = _con.prepareStatement(query);
			statement.setInt(1, _id);
			
			ResultSet resultSet = statement.executeQuery();
			while (resultSet.next())
			{
				int armourClassificationId = resultSet.getInt("ArmourClassificationId");
				_equipableArmourClassifications.add(loadArmourClassification(_con, armourClassificationId));
			}
		} 
		catch (SQLException e) 
		{
			e.printStackTrace();
		}   
    }
    
    private static void addUnitEquipableAccessoryClassifications(Connection _con, int _id, List<eAccessoryClassification> _equipableAccessoryClassifications)
    {
		try 
		{
			String query = "select AccessoryClassificationId from Unit_EquipableAccessoryClassification where UnitId=?"; //Load the Ids for the equipable accessory classifications
			PreparedStatement statement = _con.prepareStatement(query);
			statement.setInt(1, _id);
			
			ResultSet resultSet = statement.executeQuery();
			while (resultSet.next())
			{
				int accessoryClassificationId = resultSet.getInt("AccessoryClassificationId");
				_equipableAccessoryClassifications.add(loadAccessoryClassification(_con, accessoryClassificationId));
			}
		} 
		catch (SQLException e) 
		{
			e.printStackTrace();
		}   
    }
    
    private static void addUnitSkillsData(Connection _con, int _id, List<SkillData> _skills)
    {
		try 
		{
			String query = "select SkillId from Unit_Skill where UnitId=?"; //Load the Ids for the skills
			PreparedStatement statement = _con.prepareStatement(query);
			statement.setInt(1, _id);
			
			ResultSet resultSet = statement.executeQuery();
			while (resultSet.next())
			{
				int skillId = resultSet.getInt("SkillId");
				_skills.add(skills.stream().filter(x -> x.Id == skillId).findFirst().get());
			}
		} 
		catch (SQLException e) 
		{
			e.printStackTrace();
		}   
    }
    
    private static void addUnitLabels(Connection _con, int _id, List<String> _labels)
    {
		try 
		{
			String query = "select LabelId from Unit_Label where UnitId=?"; //Load the Ids for the labels
			PreparedStatement statement = _con.prepareStatement(query);
			statement.setInt(1, _id);
			
			ResultSet resultSet = statement.executeQuery();
			while (resultSet.next())
			{
				int labelId = resultSet.getInt("LabelId");
				_labels.add(loadLabel(_con, labelId));
			}
		} 
		catch (SQLException e) 
		{
			e.printStackTrace();
		}   
    }
    
    private static String loadLabel(Connection _con, int _id)
    {
		try 
		{
			String query = "select String from Labels where Id=?";
			PreparedStatement statement = _con.prepareStatement(query);
			statement.setInt(1, _id);
			
			ResultSet resultSet = statement.executeQuery();
			if (!resultSet.next())
				return null;
			
			return resultSet.getString("String");
		} 
		catch (SQLException e) 
		{
			e.printStackTrace();
			return null;
		}   
    }
    
    private static void loadUnitEvolutionRecipes(Connection _con)
    {
		try 
		{
			for (UnitData unitData : units)
			{
				String query = "select RecipeId from Unit_EvolutionRecipe where UnitId=?"; //Load the Ids for the evolution recipes
				PreparedStatement statement = _con.prepareStatement(query);
				statement.setInt(1, unitData.Id);
				
				ResultSet resultSet = statement.executeQuery();
				while (resultSet.next())
				{
					int recipeId = resultSet.getInt("RecipeId");
					unitData.getProgressiveEvolutionRecipes().add(loadUnitEvolutionRecipe(_con, recipeId));
				}
				
				query = "select RetrogressiveEvolutionRecipeId from BaseUnits where Id=?";
				statement = _con.prepareStatement(query);
				statement.setInt(1, unitData.Id);
				
				ResultSet resultSet2 = statement.executeQuery();
				if (resultSet2.next())
				{
					int retrogressiveEvolutionRecipeId = resultSet2.getInt("RetrogressiveEvolutionRecipeId");
					unitData.setRetrogressiveEvolutionRecipe(loadUnitEvolutionRecipe(_con, retrogressiveEvolutionRecipeId));
				}

				unitData.DisableModification();
			}
		} 
		catch (SQLException e) 
		{
			e.printStackTrace();
		}   
    }
    
    private static UnitEvolutionRecipe loadUnitEvolutionRecipe(Connection _con, int _id)
    {
    	try
    	{
    		String query = "select * from UnitEvolutionRecipes where Id=?";
    		PreparedStatement statement = _con.prepareStatement(query);
    		statement.setInt(1, _id);
        	
    		ResultSet resultSet = statement.executeQuery();
    		if (!resultSet.next())
    			return null;
    		
        	int afterEvolutionUnitId = resultSet.getInt("AfterEvolutionUnitId");
        	int material1Id = resultSet.getInt("Material1Id");
        	int material2Id = resultSet.getInt("Material2Id");
        	int material3Id = resultSet.getInt("Material3Id");
        	int material4Id = resultSet.getInt("Material4Id");
        	int material5Id = resultSet.getInt("Material5Id");
        	int cost = resultSet.getInt("Cost");
    		
    		UnitData unitAfterEvolution = units.stream().filter(x -> x.Id == afterEvolutionUnitId).findFirst().get();
    		EvolutionMaterial material1 = items.stream().filter(x -> x instanceof EvolutionMaterial).map(x -> (EvolutionMaterial)x).filter(x -> x.Id == material1Id).findFirst().get();
    		EvolutionMaterial material2 = items.stream().filter(x -> x instanceof EvolutionMaterial).map(x -> (EvolutionMaterial)x).filter(x -> x.Id == material2Id).findFirst().get();
    		EvolutionMaterial material3 = items.stream().filter(x -> x instanceof EvolutionMaterial).map(x -> (EvolutionMaterial)x).filter(x -> x.Id == material3Id).findFirst().get();
    		EvolutionMaterial material4 = items.stream().filter(x -> x instanceof EvolutionMaterial).map(x -> (EvolutionMaterial)x).filter(x -> x.Id == material4Id).findFirst().get();
    		EvolutionMaterial material5 = items.stream().filter(x -> x instanceof EvolutionMaterial).map(x -> (EvolutionMaterial)x).filter(x -> x.Id == material5Id).findFirst().get();
    		List<EvolutionMaterial> materials = new ArrayList<EvolutionMaterial>();
    		materials.add(material1);
    		materials.add(material2);
    		materials.add(material3);
    		materials.add(material4);
    		materials.add(material5);
    		
    		return new UnitEvolutionRecipe(unitAfterEvolution, materials, cost);
    	}
    	catch (Exception ex)
    	{
    		System.out.println(ex.toString());
    		return null;
    	}
    }
    
    private static void loadSkills(Connection _con)
    {
    	skills.clear();
    	
    	Tag one = Tag.NewTag("<#1/>");
    	Effect basicEffect = effects.stream().filter(x -> x.Id == -1).findFirst().get();
    	skills.add(new OrdinarySkillData(-1, "Basic Attack", null, null, 1, one, basicEffect, 0, null));
    	
    	try 
    	{	    		
			String query = "select Id from BaseSkills"; //Load the entire BaseSkills.Id column
			PreparedStatement statement = _con.prepareStatement(query);
			
			ResultSet resultSet = statement.executeQuery();
			while (resultSet.next())
			{
				int id = resultSet.getInt("Id");
				skills.add(loadSkillData(_con, id));
			}
    	}
    	catch (Exception ex)
    	{
    		System.out.println(ex.toString());
    	}
    }
    
    private static SkillData loadSkillData(Connection _con, int _id)
    {
    	try
    	{
    		String query = "select * from BaseSkills where Id=?";
    		PreparedStatement statement = _con.prepareStatement(query);
        	statement.setInt(1, _id);
    		
    		ResultSet resultSet = statement.executeQuery();
    		if (!resultSet.next())
    			return null;
    		
        	int classificationId = resultSet.getInt("ClassificationId");
    		String name = resultSet.getString("Name");
    		int iconId = resultSet.getInt("IconId");
    		int animationNumber = resultSet.getInt("AnimationNumber");
    		
    		byte[] iconAsBytes = loadSkillIconAsBytes(_con, iconId);
    		
    		query = "select Name from SkillClassifications where Id=?"; //Get classification name for the skill
    		statement = _con.prepareStatement(query);
    		statement.setInt(1, classificationId);
    		
    		ResultSet resultSet2 = statement.executeQuery();
    		if (!resultSet2.next())
    			return null;
    		
    		String classificationName = resultSet2.getString("Name");
    		switch (classificationName)
    		{
    			case "Ordinary":
    				return loadOrdinarySkillData(_con, _id, name, iconAsBytes, animationNumber);
    			case "Counter":
    				return loadCounterSkillData(_con, _id, name, iconAsBytes, animationNumber);
    			case "Ultimate":
    				return loadUltimateSkillData(_con, _id, name, iconAsBytes, animationNumber);
    			case "Passive":
    				return loadPassiveSkillData(_con, _id, name, iconAsBytes, animationNumber);
    			default:
    				return null;						
    		}	
    	}
    	catch (Exception ex)
    	{
    		System.out.println(ex.toString());
    		return null;
    	}
    }
    
	private static OrdinarySkillData loadOrdinarySkillData(Connection _con, int _id, String _name, byte[] _iconAsBytes, int _animationId)
    {
		try 
		{
			String query = "select * from ActiveSkills where BaseSkillId=?"; //Load detailed data of the skill
			PreparedStatement statement = _con.prepareStatement(query);
			statement.setInt(1, _id);
			
			ResultSet resultSet = statement.executeQuery();
			if (!resultSet.next())
				return null;
			
			int maxNumberOfTargetsTagId = resultSet.getInt("MaxNumberOfTargetsTagId");
			int effectId = resultSet.getInt("EffectId");
			
			List<BackgroundStatusEffectData> temporalStatusEffectsData = new ArrayList<BackgroundStatusEffectData>();
			addActiveSkillBackgroundStatusEffectsData(_con, _id, temporalStatusEffectsData);
			Tag maxNumberOfTargets = loadTag(_con, maxNumberOfTargetsTagId);
			Effect effect = effects.stream().filter(x -> x.Id == effectId).findFirst().get();
			
			query = "select * from CostRequiringSkills where BaseSkillId=?"; //Load detailed data of the skill
			statement = _con.prepareStatement(query);
			statement.setInt(1, _id);
			
			ResultSet resultSet2 = statement.executeQuery();
			if (!resultSet2.next())
				return null;
			
			int spCost = resultSet2.getInt("SPCost");
			
			Map<Integer, Integer> itemCosts = new HashMap<Integer, Integer>();
			addSkillItemCosts(_con, _id, itemCosts);
			
			return new OrdinarySkillData(_id, _name, _iconAsBytes, temporalStatusEffectsData, _animationId, maxNumberOfTargets, effect, spCost, itemCosts);
		} 
		catch (SQLException e) 
		{
			e.printStackTrace();
			return null;
		}   
    }
	
    private static CounterSkillData loadCounterSkillData(Connection _con, int _id, String _name, byte[] _iconAsBytes, int _animationId) 
    {
    	try 
		{
			String query = "select * from ActiveSkills where BaseSkillId=?"; //Load detailed data of the skill
			PreparedStatement statement = _con.prepareStatement(query);
			statement.setInt(1, _id);
			
			ResultSet resultSet = statement.executeQuery();
			if (!resultSet.next())
				return null;
			
			int maxNumberOfTargetsTagId = resultSet.getInt("MaxNumberOfTargetsTagId");
			int effectId = resultSet.getInt("EffectId");
			
			List<BackgroundStatusEffectData> temporalStatusEffectsData = new ArrayList<BackgroundStatusEffectData>();
			addActiveSkillBackgroundStatusEffectsData(_con, _id, temporalStatusEffectsData);
			Tag maxNumberOfTargets = loadTag(_con, maxNumberOfTargetsTagId);
			Effect effect = effects.stream().filter(x -> x.Id == effectId).findFirst().get();
			
			query = "select * from CostRequiringSkills where BaseSkillId=?"; //Load detailed data of the skill
			statement = _con.prepareStatement(query);
			statement.setInt(1, _id);
			
			ResultSet resultSet2 = statement.executeQuery();
			if (!resultSet2.next())
				return null;
			
			int spCost = resultSet2.getInt("SPCost");
			
			Map<Integer, Integer> itemCosts = new HashMap<Integer, Integer>();
			addSkillItemCosts(_con, _id, itemCosts);
			
			query = "select * from CounterSkills where BaseSkillId=?"; //Load detailed data of the skill
			statement = _con.prepareStatement(query);
			statement.setInt(1, _id);
			
			ResultSet resultSet3 = statement.executeQuery();
			if (!resultSet3.next())
				return null;
			
			int eventTriggerTimingId = resultSet3.getInt("EventTriggerTimingId");
			
			eEventTriggerTiming eventTriggerTiming = loadEventTriggerTiming(_con, eventTriggerTimingId);
			ComplexCondition activationCondition = loadCounterSkillActivationCondition(_con, _id);
			
			return new CounterSkillData(_id, _name, _iconAsBytes, temporalStatusEffectsData, _animationId, maxNumberOfTargets, effect, spCost, itemCosts, eventTriggerTiming, activationCondition);
		} 
		catch (SQLException e) 
		{
			e.printStackTrace();
			return null;
		}   
	}
    
    private static UltimateSkillData loadUltimateSkillData(Connection _con, int _id, String _name, byte[] _iconAsBytes, int _animationId) 
    {
    	try 
		{
			String query = "select * from ActiveSkills where BaseSkillId=?"; //Load detailed data of the skill
			PreparedStatement statement = _con.prepareStatement(query);
			statement.setInt(1, _id);
			
			ResultSet resultSet = statement.executeQuery();
			if (!resultSet.next())
				return null;
			
			int maxNumberOfTargetsTagId = resultSet.getInt("MaxNumberOfTargetsTagId");
			int effectId = resultSet.getInt("EffectId");
			
			List<BackgroundStatusEffectData> temporalStatusEffectsData = new ArrayList<BackgroundStatusEffectData>();
			addActiveSkillBackgroundStatusEffectsData(_con, _id, temporalStatusEffectsData);
			Tag maxNumberOfTargets = loadTag(_con, maxNumberOfTargetsTagId);
			Effect effect = effects.stream().filter(x -> x.Id == effectId).findFirst().get();
			
			
			return new UltimateSkillData(_id, _name, _iconAsBytes, temporalStatusEffectsData, _animationId, maxNumberOfTargets, effect);
		} 
		catch (SQLException e) 
		{
			e.printStackTrace();
			return null;
		}   
	}
    
    private static PassiveSkillData loadPassiveSkillData(Connection _con, int _id, String _name, byte[] _iconAsBytes, int _animationId) 
    {
    	try 
		{
			String query = "select * from PassiveSkills where BaseSkillId=?"; //Load detailed data of the skill
			PreparedStatement statement = _con.prepareStatement(query);
			statement.setInt(1, _id);
			
			ResultSet resultSet = statement.executeQuery();
			if (!resultSet.next())
				return null;
			
			int targetUnitClassificationId = resultSet.getInt("TargetUnitClassificationId");
			
			List<StatusEffectData> temporalStatusEffectsData = new ArrayList<StatusEffectData>();
			addPassiveSkillStatusEffectsData(_con, _id, temporalStatusEffectsData);
			eTargetUnitClassification targetClassification = loadTargetUnitClassification(_con, targetUnitClassificationId);
			ComplexCondition activationCondition = loadPassiveSkillActivationCondition(_con, _id);
			
			return new PassiveSkillData(_id, _name, _iconAsBytes, temporalStatusEffectsData, _animationId, targetClassification, activationCondition);
		} 
		catch (SQLException e) 
		{
			e.printStackTrace();
			return null;
		}   
	}
    
    private static void addActiveSkillBackgroundStatusEffectsData(Connection _con, int _id, List<BackgroundStatusEffectData> _statusEffectsData)
    {
		try 
		{
			String query = "select TemporalStatusEffectId from ActiveSkill_TemporalStatusEffect where SkillId=?"; //Load the Ids for the temporal status effects
			PreparedStatement statement = _con.prepareStatement(query);
			statement.setInt(1, _id);
			
			ResultSet resultSet = statement.executeQuery();
			while (resultSet.next())
			{
				int temporalStatusEffectId = resultSet.getInt("TemporalStatusEffectId");
				_statusEffectsData.add(statusEffects.stream().filter(x -> x instanceof BackgroundStatusEffectData).map(x -> (BackgroundStatusEffectData)x).filter(x -> x.Id == temporalStatusEffectId).findFirst().get());
			}
		} 
		catch (SQLException e) 
		{
			e.printStackTrace();
		}   
    }
    
    private static void addPassiveSkillStatusEffectsData(Connection _con, int _id, List<StatusEffectData> _statusEffectsData)
    {
		try 
		{
			String query = "select TemporalStatusEffectId from PassiveSkill_TemporalStatusEffect where SkillId=?"; //Load the Ids for the temporal status effects
			PreparedStatement statement = _con.prepareStatement(query);
			statement.setInt(1, _id);
			
			ResultSet resultSet = statement.executeQuery();
			while (resultSet.next())
			{
				int temporalStatusEffectId = resultSet.getInt("TemporalStatusEffectId");
				_statusEffectsData.add(statusEffects.stream().filter(x -> x.Id == temporalStatusEffectId).findFirst().get());
			}
		} 
		catch (SQLException e) 
		{
			e.printStackTrace();
		}   
    }
    
    private static void addSkillItemCosts(Connection _con, int _id, Map<Integer, Integer> _itemCosts)
    {
		try 
		{
			String query = "select ItemCostId from CostRequiringSkill_ItemCost where SkillId=?"; //Load the Ids for the item costs
			PreparedStatement statement = _con.prepareStatement(query);
			statement.setInt(1, _id);
			
			ResultSet resultSet = statement.executeQuery();
			while (resultSet.next())
			{
				int itemCostId = resultSet.getInt("ItemCostId");
				MapEntry<Integer, Integer> itemCost = loadItemCost(_con, itemCostId);
				_itemCosts.put(itemCost.getKey(), itemCost.getValue());
			}
		} 
		catch (SQLException e) 
		{
			e.printStackTrace();
		}   
    }
    
    private static MapEntry<Integer, Integer> loadItemCost(Connection _con, int _id)
    {
		try 
		{
			String query = "select * from ItemCosts where Id=?";
			PreparedStatement statement = _con.prepareStatement(query);
			statement.setInt(1, _id);
			
			ResultSet resultSet = statement.executeQuery();
			if (!resultSet.next())
				return null;
			
			int itemId = resultSet.getInt("ItemId");
			int quantity = resultSet.getInt("Quantity");
			
			return new MapEntry<Integer, Integer>(itemId, quantity);
		} 
		catch (SQLException e) 
		{
			e.printStackTrace();
			return null;
		}   
    }
    
    private static void loadEffects(Connection _con)
    {
    	effects.clear();
    	
    	Tag one = Tag.NewTag("<#1/>");
    	effects.add(new DamageEffect(-1, null, one, one, null, null, 1, eTargetUnitClassification.EnemyInRange, eAttackClassification.Physic, one, false, eElement.None));
    	
    	try 
    	{	
			String query;
			PreparedStatement statement;
			
			ResultSet resultSet;
    		
			query = "select Id from BaseEffects"; //Load the entire BaseEffects.Id column
			statement = _con.prepareStatement(query);
			
			resultSet = statement.executeQuery();
			while (resultSet.next())
			{
				int id = resultSet.getInt("Id");
				effects.add(loadEffect(_con, id));
			}
    	}
    	catch (Exception ex)
    	{
    		System.out.println(ex.toString());
    	}
    }
    
    private static Effect loadEffect(Connection _con, int _id)
    {
    	try
    	{	
			String query = "select * from BaseEffects where Id=?";
			PreparedStatement statement = _con.prepareStatement(query);
			statement.setInt(1, _id);
			
			ResultSet resultSet = statement.executeQuery();
    		if (!resultSet.next())
    			return null;
			
    		int classificationId = resultSet.getInt("ClassificationId");
			int timesToApplyTagId = resultSet.getInt("TimesToApplyTagId");
			int successRateTagId = resultSet.getInt("SuccessRateTagId");
			int diffusionDistanceTagId = resultSet.getInt("DiffusionDistanceTagId");
			int animationNumber = resultSet.getInt("AnimationNumber");
			
			ComplexCondition activationCondition = loadEffectActivationCondition(_con, _id);
			Tag timesToApply = loadTag(_con, timesToApplyTagId);
			Tag successRate = loadTag(_con, successRateTagId);
			Tag diffusionDistance = loadTag(_con, diffusionDistanceTagId);
			List<Effect> secondaryEffects = new ArrayList<Effect>(); //Data will be added afterwards
			
			query = "select Name from EffectClassifications where Id=?"; //Get classification name for the effect
			statement = _con.prepareStatement(query);
			statement.setInt(1, classificationId);
			
			ResultSet resultSet2 = statement.executeQuery();
			if (!resultSet2.next())
				return null;
			
			String classificationName = resultSet2.getString("Name");
			switch (classificationName)
			{
				case "Damage":
					return loadDamageEffect(_con, _id, activationCondition, timesToApply, successRate, diffusionDistance, secondaryEffects, animationNumber);
				case "Heal":
					return loadHealEffect(_con, _id, activationCondition, timesToApply, successRate, diffusionDistance, secondaryEffects, animationNumber);
				case "StatusEffectAttachment":
					return loadStatusEffectAttachmentEffect(_con, _id, activationCondition, timesToApply, successRate, diffusionDistance, secondaryEffects, animationNumber);
				default:
					return null;						
			}
    	}
    	catch (Exception ex)
    	{
    		System.out.println(ex.toString());
    		return null;
    	}
    }
    
    private static void loadSecondaryEffects(Connection _con)
    {
		try 
		{
			for (Effect effect : effects)
			{
				String query = "select SecondaryEffectId from Effect_SecondaryEffect where EffectId=?"; //Load the Ids for the secondary effects
				PreparedStatement statement = _con.prepareStatement(query);
				statement.setInt(1, effect.Id);
				
				ResultSet resultSet = statement.executeQuery();
				while (resultSet.next())
				{
					int secondaryEffectId = resultSet.getInt("SecondaryEffectId");
					effect.getSecondaryEffects().add(effects.stream().filter(x -> x.Id == secondaryEffectId).findFirst().get());
				}
				
				effect.DisableModification();
			}
		} 
		catch (SQLException e) 
		{
			e.printStackTrace();
		}   
    }
    
    private static DamageEffect loadDamageEffect(Connection _con, int _id, ComplexCondition _activationCondition, Tag _timesToApply, Tag _successRate, Tag _diffusionDistance, List<Effect> _secondaryEffects, int _animationId)
    {
		try 
		{
			String query = "select * from DamageEffects where BaseEffectId=?"; //Load detailed data of the effect
			PreparedStatement statement = _con.prepareStatement(query);
			statement.setInt(1, _id);
			
			ResultSet resultSet = statement.executeQuery();
			if (!resultSet.next())
				return null;
			
			int targetClassificationId = resultSet.getInt("TargetClassificationId");
			int attackClassificationId = resultSet.getInt("AttackClassificationId");
			int valueTagId = resultSet.getInt("ValueTagId");
			boolean isFixedValue = resultSet.getBoolean("IsFixedValue");
			int elementId = resultSet.getInt("ElementId");
			
			eTargetUnitClassification targetClassification = loadTargetUnitClassification(_con, targetClassificationId);
			eAttackClassification attackClassification = loadAttackClassification(_con, attackClassificationId);
			Tag value = loadTag(_con, valueTagId);
			eElement element = loadElement(_con, elementId);
			
			return new DamageEffect(_id, _activationCondition, _timesToApply, _successRate, _diffusionDistance, _secondaryEffects, _animationId, targetClassification, attackClassification, value, isFixedValue, element);
		} 
		catch (SQLException e) 
		{
			e.printStackTrace();
			return null;
		}   
    }
    
    private static HealEffect loadHealEffect(Connection _con, int _id, ComplexCondition _activationCondition, Tag _timesToApply, Tag _successRate, Tag _diffusionDistance, List<Effect> _secondaryEffects, int _animationId)
    {
		try 
		{
			String query = "select * from HealEffects where BaseEffectId=?"; //Load detailed data of the effect
			PreparedStatement statement = _con.prepareStatement(query);
			statement.setInt(1, _id);
			
			ResultSet resultSet = statement.executeQuery();
			if (!resultSet.next())
				return null;
			
			int targetClassificationId = resultSet.getInt("TargetClassificationId");
			int valueTagId = resultSet.getInt("ValueTagId");
			boolean isFixedValue = resultSet.getBoolean("IsFixedValue");
			
			eTargetUnitClassification targetClassification = loadTargetUnitClassification(_con, targetClassificationId);
			Tag value = loadTag(_con, valueTagId);
			
			return new HealEffect(_id, _activationCondition, _timesToApply, _successRate, _diffusionDistance, _secondaryEffects, _animationId, targetClassification, value, isFixedValue);
		} 
		catch (SQLException e) 
		{
			e.printStackTrace();
			return null;
		}   
    }
    
    private static StatusEffectAttachmentEffect loadStatusEffectAttachmentEffect(Connection _con, int _id, ComplexCondition _activationCondition, Tag _timesToApply, Tag _successRate, Tag _diffusionDistance, List<Effect> _secondaryEffects, int _animationId)
    {
		try 
		{
			String query = "select * from StatusEffectAttachmentEffects where BaseEffectId=?"; //Load detailed data of the effect
			PreparedStatement statement = _con.prepareStatement(query);
			statement.setInt(1, _id);
			
			ResultSet resultSet = statement.executeQuery();
			if (!resultSet.next())
				return null;
			
			int targetClassificationId = resultSet.getInt("TargetClassificationId");
			int statusEffectId = resultSet.getInt("StatusEffectId");
			
			eTargetUnitClassification targetClassification = loadTargetUnitClassification(_con, targetClassificationId);
			StatusEffectData statusEffectData = statusEffects.stream().filter(x -> x.Id == statusEffectId).findFirst().get();
			
			return new StatusEffectAttachmentEffect(_id, _activationCondition, _timesToApply, _successRate, _diffusionDistance, _secondaryEffects, _animationId, targetClassification, statusEffectData);
		} 
		catch (SQLException e) 
		{
			e.printStackTrace();
			return null;
		}   
    }
    
    private static void loadStatusEffects(Connection _con)
    {
    	statusEffects.clear();
    	
    	try 
    	{	
			String query;
			PreparedStatement statement;
			
			ResultSet resultSet;
    		
			query = "select Id from BaseStatusEffects"; //Load the entire BaseStatusEffects.Id column
			statement = _con.prepareStatement(query);
			
			resultSet = statement.executeQuery();
			while (resultSet.next())
			{
				int id = resultSet.getInt("Id");
				statusEffects.add(loadStatusEffectData(_con, id));
			}
    	}
    	catch (Exception ex)
    	{
    		System.out.println(ex.toString());
    	}
    }
    
    private static StatusEffectData loadStatusEffectData(Connection _con, int _id)
    {
		try 
		{
			String query = "select * from BaseStatusEffects where Id=?"; 
			PreparedStatement statement = _con.prepareStatement(query);
			statement.setInt(1, _id);
			
			ResultSet resultSet = statement.executeQuery();
			if (!resultSet.next())
				return null;
			
			boolean isBackgroundStatusEffect = resultSet.getBoolean("IsBackgroundStatusEffect");
			int durationId = resultSet.getInt("DurationId");
			int iconId = resultSet.getInt("IconId");
			
			DurationData duration = loadDurationData(_con, durationId);
			ComplexCondition activationCondition = loadStatusEffectActivationCondition(_con, _id);
			byte[] iconAsBytes = loadStatusEffectIconAsBytes(_con, iconId);
			
			if (isBackgroundStatusEffect)
				return loadBackgroundStatusEffectData(_con, _id, duration, activationCondition, iconAsBytes);
			else
				return loadForegroundStatusEffectData(_con, _id, duration, activationCondition, iconAsBytes);
		} 
		catch (SQLException e) 
		{
			e.printStackTrace();
			return null;
		}   
    }
    
    private static BackgroundStatusEffectData loadBackgroundStatusEffectData(Connection _con, int _id, DurationData _duration, ComplexCondition _activationCondition, byte[] _iconAsBytes)
    {
		try 
		{
			String query = "select * from BackgroundStatusEffects where BaseStatusEffectId=?"; 
			PreparedStatement statement = _con.prepareStatement(query);
			statement.setInt(1, _id);
			
			ResultSet resultSet = statement.executeQuery();
			if (!resultSet.next())
				return null;
			
			int classificationId = resultSet.getInt("ClassificationId");
			int activationTurnClassificationId = resultSet.getInt("ActivationTurnClassificationId");
			
			eActivationTurnClassification activationTurnClassification = loadActivationTurnClassification(_con, activationTurnClassificationId);
			
			query = "select Name from BackgroundStatusEffectClassifications where Id=?"; //Get classification name for the effect
			statement = _con.prepareStatement(query);
			statement.setInt(1, classificationId);
			
			resultSet = statement.executeQuery();
			if (!resultSet.next())
				return null;
			
			String classificationName = resultSet.getString("Name");
			switch (classificationName)
			{
				case "Buff":
					return loadBuffStatusEffectData(_con, _id, _duration, _activationCondition, _iconAsBytes, activationTurnClassification);
				case "Debuff":
					return loadDebuffStatusEffectData(_con, _id, _duration, _activationCondition, _iconAsBytes, activationTurnClassification);
				case "TargetRangeMod":
					return loadTargetRangeModStatusEffectData(_con, _id, _duration, _activationCondition, _iconAsBytes, activationTurnClassification);
				default:
					return null;
			}
		} 
		catch (SQLException e) 
		{
			e.printStackTrace();
			return null;
		}   
    }
    
    private static BuffStatusEffectData loadBuffStatusEffectData(Connection _con, int _id, DurationData _duration, ComplexCondition _activationCondition, byte[] _iconAsBytes, eActivationTurnClassification _activationTurnClassification)
    {
		try 
		{
			String query = "select * from BuffStatusEffects where BaseStatusEffectId=?"; 
			PreparedStatement statement = _con.prepareStatement(query);
			statement.setInt(1, _id);
			
			ResultSet resultSet = statement.executeQuery();
			if (!resultSet.next())
				return null;
			
			int targetStatusClassificationId = resultSet.getInt("TargetStatusClassificationId");
			int valueTagId = resultSet.getInt("ValueTagId");
			boolean isSum = resultSet.getBoolean("IsSum");
			
			eStatusType targetStatusType = loadStatusType(_con, targetStatusClassificationId);
			Tag value = loadTag(_con, valueTagId);
			
			return new BuffStatusEffectData(_id, _duration, _activationTurnClassification, _activationCondition, _iconAsBytes, targetStatusType, value, isSum);
		} 
		catch (SQLException e) 
		{
			e.printStackTrace();
			return null;
		}   
    }
    
    private static DebuffStatusEffectData loadDebuffStatusEffectData(Connection _con, int _id, DurationData _duration, ComplexCondition _activationCondition, byte[] _iconAsBytes, eActivationTurnClassification _activationTurnClassification)
    {
		try 
		{
			String query = "select * from DebuffStatusEffects where BaseStatusEffectId=?"; 
			PreparedStatement statement = _con.prepareStatement(query);
			statement.setInt(1, _id);
			
			ResultSet resultSet = statement.executeQuery();
			if (!resultSet.next())
				return null;
			
			int targetStatusClassificationId = resultSet.getInt("TargetStatusClassificationId");
			int valueTagId = resultSet.getInt("ValueTagId");
			boolean isSum = resultSet.getBoolean("IsSum");
			
			eStatusType targetStatusType = loadStatusType(_con, targetStatusClassificationId);
			Tag value = loadTag(_con, valueTagId);
			
			return new DebuffStatusEffectData(_id, _duration, _activationTurnClassification, _activationCondition, _iconAsBytes, targetStatusType, value, isSum);
		} 
		catch (SQLException e) 
		{
			e.printStackTrace();
			return null;
		}   
    }
    
    private static TargetRangeModStatusEffectData loadTargetRangeModStatusEffectData(Connection _con, int _id, DurationData _duration, ComplexCondition _activationCondition, byte[] _iconAsBytes, eActivationTurnClassification _activationTurnClassification)
    {
		try 
		{
			String query = "select * from TargetRangeModStatusEffects where BaseStatusEffectId=?"; 
			PreparedStatement statement = _con.prepareStatement(query);
			statement.setInt(1, _id);
			
			ResultSet resultSet = statement.executeQuery();
			if (!resultSet.next())
				return null;
			
			boolean isMovementRangeClassification = resultSet.getBoolean("IsMovementRangeClassification");
			int targetRangeClassificationId = resultSet.getInt("TargetRangeClassificationId");
			int modificationMethodId = resultSet.getInt("ModificationMethodId");
			
			eTargetRangeClassification targetRangeClassification = loadTargetRangeClassification(_con, targetRangeClassificationId);
			eModificationMethod modificationMethod = loadModificationMethod(_con, modificationMethodId);
			
			return new TargetRangeModStatusEffectData(_id, _duration, _activationTurnClassification, _activationCondition, _iconAsBytes, isMovementRangeClassification, targetRangeClassification, modificationMethod);
		} 
		catch (SQLException e) 
		{
			e.printStackTrace();
			return null;
		}   
    }
    
    private static ForegroundStatusEffectData loadForegroundStatusEffectData(Connection _con, int _id, DurationData _duration, ComplexCondition _activationCondition, byte[] _iconAsBytes)
    {
		try 
		{
			String query = "select * from ForegroundStatusEffects where BaseStatusEffectId=?"; 
			PreparedStatement statement = _con.prepareStatement(query);
			statement.setInt(1, _id);
			
			ResultSet resultSet = statement.executeQuery();
			if (!resultSet.next())
				return null;
			
			int classificationId = resultSet.getInt("ClassificationId");
			int activationTurnClassificationId = resultSet.getInt("ActivationTurnClassificationId");
			int eventTriggerTimingId = resultSet.getInt("EventTriggerTimingId");
			int animationNumber = resultSet.getInt("AnimationNumber");
			
			eActivationTurnClassification activationTurnClassification = loadActivationTurnClassification(_con, activationTurnClassificationId);
			eEventTriggerTiming eventTriggerTiming = loadEventTriggerTiming(_con, eventTriggerTimingId);
			
			query = "select Name from ForegroundStatusEffectClassifications where Id=?"; //Get classification name for the effect
			statement = _con.prepareStatement(query);
			statement.setInt(1, classificationId);
			
			resultSet = statement.executeQuery();
			if (!resultSet.next())
				return null;
			
			String classificationName = resultSet.getString("Name");
			switch (classificationName)
			{
				case "Damage":
					return loadDamageStatusEffectData(_con, _id, _duration, _activationCondition, _iconAsBytes, activationTurnClassification, eventTriggerTiming, animationNumber);
				case "Heal":
					return loadHealStatusEffectData(_con, _id, _duration, _activationCondition, _iconAsBytes, activationTurnClassification, eventTriggerTiming, animationNumber);
				default:
					return null;
			}
		} 
		catch (SQLException e) 
		{
			e.printStackTrace();
			return null;
		}   
    }
    
    private static HealStatusEffectData loadHealStatusEffectData(Connection _con, int _id, DurationData _duration, ComplexCondition _activationCondition, byte[] _iconAsBytes, eActivationTurnClassification _activationTurnClassification, eEventTriggerTiming _eventTriggerTiming, int _animationId)
    {
		try 
		{
			String query = "select * from HealStatusEffects where BaseStatusEffectId=?"; 
			PreparedStatement statement = _con.prepareStatement(query);
			statement.setInt(1, _id);
			
			ResultSet resultSet = statement.executeQuery();
			if (!resultSet.next())
				return null;
			
			int valueTagId = resultSet.getInt("ValueTagId");
			
			Tag value = loadTag(_con, valueTagId);
			
			return new HealStatusEffectData(_id, _duration, _activationTurnClassification, _eventTriggerTiming, _activationCondition, _iconAsBytes, _animationId, value);
		} 
		catch (SQLException e) 
		{
			e.printStackTrace();
			return null;
		}   
    }
    
    private static DamageStatusEffectData loadDamageStatusEffectData(Connection _con, int _id, DurationData _duration, ComplexCondition _activationCondition, byte[] _iconAsBytes, eActivationTurnClassification _activationTurnClassification, eEventTriggerTiming _eventTriggerTiming, int _animationId)
    {
		try 
		{
			String query = "select * from DamageStatusEffects where BaseStatusEffectId=?"; 
			PreparedStatement statement = _con.prepareStatement(query);
			statement.setInt(1, _id);
			
			ResultSet resultSet = statement.executeQuery();
			if (!resultSet.next())
				return null;
			
			int valueTagId = resultSet.getInt("ValueTagId");
			
			Tag value = loadTag(_con, valueTagId);
			
			return new DamageStatusEffectData(_id, _duration, _activationTurnClassification, _eventTriggerTiming, _activationCondition, _iconAsBytes, _animationId, value);
		} 
		catch (SQLException e) 
		{
			e.printStackTrace();
			return null;
		}   
    }
    
    private static DurationData loadDurationData(Connection _con, int _id)
    {
		try 
		{
			String query = "select * from Durations where Id=?"; 
			PreparedStatement statement = _con.prepareStatement(query);
			statement.setInt(1, _id);
			
			ResultSet resultSet = statement.executeQuery();
			if (!resultSet.next())
				return null;
			
			int activationTimesTagId = resultSet.getInt("ActivationTimesTagId");
			int turnsTagId = resultSet.getInt("TurnsTagId");
			
			Tag activationTimes = loadTag(_con, activationTimesTagId);
			Tag turns = loadTag(_con, turnsTagId);
			ComplexCondition whileCondition = loadDurationDataWhileCondition(_con, _id);
			
			return new DurationData(activationTimes, turns, whileCondition);
		} 
		catch (SQLException e) 
		{
			e.printStackTrace();
			return null;
		}   
    }
    
    private static ComplexCondition loadCounterSkillActivationCondition(Connection _con, int _id)
    {
    	return loadComplexCondition(_con, _id, "select ConditionSetId from CounterSkill_ActivationConditionSet where SkillId=?");
    }
    private static ComplexCondition loadPassiveSkillActivationCondition(Connection _con, int _id)
    {
    	return loadComplexCondition(_con, _id, "select ConditionSetId from PassiveSkill_ActivationConditionSet where SkillId=?");
    }
    private static ComplexCondition loadEffectActivationCondition(Connection _con, int _id)
    {
    	return loadComplexCondition(_con, _id, "select ConditionSetId from Effect_ActivationConditionSet where EffectId=?");
    }
    private static ComplexCondition loadStatusEffectActivationCondition(Connection _con, int _id)
    {
    	return loadComplexCondition(_con, _id, "select ConditionSetId from StatusEffect_ActivationConditionSet where StatusEffectId=?");
    }
    private static ComplexCondition loadDurationDataWhileCondition(Connection _con, int _id)
    {
    	return loadComplexCondition(_con, _id, "select ConditionSetId from Duration_WhileConditionSet where DurationId=?");
    }
    private static ComplexCondition loadComplexCondition(Connection _con, int _id, String _query)
    {
    	try 
		{
    		List<List<Condition>> conditionSets = new ArrayList<List<Condition>>();
    		
	    	PreparedStatement statement;
			statement = _con.prepareStatement(_query);
	    	statement.setInt(1, _id);
	    	
	    	ResultSet resultSet = statement.executeQuery();
	    	while (resultSet.next())
	    	{
	    		List<Condition> conditionSet = new ArrayList<Condition>();
	    		int conditionSetId = resultSet.getInt("ConditionSetId");
	    		addConditions(_con, conditionSetId, conditionSet);
	    		conditionSets.add(conditionSet);
	    	}
	    	
	    	return new ComplexCondition(conditionSets);
		} 
		catch (SQLException e) 
		{
			e.printStackTrace();
			return null;
		}
    }
    
    private static byte[] loadSkillIconAsBytes(Connection _con, int _id)
    {
    	return loadImageAsBytes(_con, _id, "select IconPath from SkillIcons where Id=?", "IconPath");
    }
    private static byte[] loadStatusEffectIconAsBytes(Connection _con, int _id)
    {
    	return loadImageAsBytes(_con, _id, "select IconPath from StatusEffectIcons where Id=?", "IconPath");
    }
    private static byte[] loadImageAsBytes(Connection _con, int _id, String _query, String _columnName)
    {
    	try 
		{
	    	PreparedStatement statement;
			statement = _con.prepareStatement(_query);
	    	statement.setInt(1, _id);
	    	
	    	ResultSet resultSet = statement.executeQuery();
	    	if (!resultSet.next())
	    		return null;
	    	
	    	String imagePath = resultSet.getString(_columnName);
	    	
	    	BufferedImage image = ImageIO.read(new File(imagePath));
			ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
			ImageIO.write(image, "png", outputStream);
	    	return outputStream.toByteArray();
		} 
		catch (Exception ex) 
		{
			ex.printStackTrace();
			return null;
		}
    }
    
    private static void addConditions(Connection _con, int _id, List<Condition> _conditionSet)
    {
    	try 
		{  		
			String query = "select ConditionId from ConditionSet_Condition where ConditionSetId=?";
	    	PreparedStatement statement;
			statement = _con.prepareStatement(query);
	    	statement.setInt(1, _id);
	    	
	    	ResultSet resultSet = statement.executeQuery();
	    	while (resultSet.next())
	    	{
	    		int conditionId = resultSet.getInt("ConditionId");
	    		Condition condition = loadCondition(_con, conditionId);
	    		_conditionSet.add(condition);
	    	}
		} 
		catch (SQLException e) 
		{
			e.printStackTrace();
		}
    }
    
    private static Condition loadCondition(Connection _con, int _id)
    {
    	try 
		{  		
			String query = "select * from Conditions where Id=?";
	    	PreparedStatement statement;
			statement = _con.prepareStatement(query);
	    	statement.setInt(1, _id);
	    	
	    	ResultSet resultSet = statement.executeQuery();
	    	if (!resultSet.next())
	    		return null;
	    	
	    	int tagIdA = resultSet.getInt("TagIdA");
	    	int relationId = resultSet.getInt("RelationId");
	    	int tagIdB = resultSet.getInt("TagIdB");
	    	
	    	Tag tagA = loadTag(_con, tagIdA);
	    	eRelationType relation = loadRelationType(_con, relationId);
	    	Tag tagB = loadTag(_con, tagIdB);
	    	
	    	return new Condition(tagA, relation, tagB);
		} 
		catch (SQLException e) 
		{
			e.printStackTrace();
			return null;
		}
    }
    
    private static Tag loadTag(Connection _con, int _id)
    {
		try 
		{
			String query = "select String from Tags where Id=?";
	    	PreparedStatement statement;
			statement = _con.prepareStatement(query);
	    	statement.setInt(1, _id);
	    	
	    	ResultSet resultSet = statement.executeQuery();
	    	if (!resultSet.next())
	    		return null;
	    	
	    	String string = resultSet.getString("String");
	    	
	    	return Tag.NewTag(string);
		} 
		catch (SQLException e) 
		{
			e.printStackTrace();
			return null;
		}    	
    }
    
    private static void loadTileSets(Connection _con)
    {
    	tileSets.clear();
    	
    	try 
    	{	
			String query;
			PreparedStatement statement;
			
			ResultSet resultSet;
    		
			query = "select Id from TileSets"; //Load the entire TileSets.Id column
			statement = _con.prepareStatement(query);
			
			resultSet = statement.executeQuery();
			while (resultSet.next())
			{
				int id = resultSet.getInt("Id");
				tileSets.add(loadTileSet(_con, id));
			}
    	}
    	catch (Exception ex)
    	{
    		System.out.println(ex.toString());
    	}
    }
    
    private static TileSet loadTileSet(Connection _con, int _id)
    {
    	List<eTileType> tileTypes = new ArrayList<eTileType>();
    	
    	try
    	{	
			String query = "select * from TileSet_TileClassification where TileSetId=?";
			PreparedStatement statement = _con.prepareStatement(query);
			statement.setInt(1, _id);
			
			ResultSet resultSet = statement.executeQuery();
    		while(resultSet.next())
    		{
        		int classificationId = resultSet.getInt("ClassificationId");
    			int relativeQuantity = resultSet.getInt("RelativeQuantity");
    			
    			eTileType tileType = loadTileType(_con, classificationId);
    			
    			for (int i = 0; i < relativeQuantity; i++)
    			{
    				tileTypes.add(tileType);
    			}
    		}
			
			return new TileSet(tileTypes);
    	}
    	catch (Exception ex)
    	{
    		System.out.println(ex.toString());
    		return null;
    	}
    }
    
    private static eTargetUnitClassification loadTargetUnitClassification(Connection _con, int _id)
    {
		try 
		{
			String query = "select Name from TargetUnitClassifications where Id=?";
	    	PreparedStatement statement;
			statement = _con.prepareStatement(query);
	    	statement.setInt(1, _id);
	    	
	    	ResultSet resultSet = statement.executeQuery();
	    	if (!resultSet.next())
	    		return eTargetUnitClassification.values()[0];
	    	
	    	return eTargetUnitClassification.valueOf(resultSet.getString("Name"));
		} 
		catch (SQLException e) 
		{
			e.printStackTrace();
			return eTargetUnitClassification.values()[0];
		}    	
    }

    private static eAttackClassification loadAttackClassification(Connection _con, int _id)
    {
		try 
		{
			String query = "select Name from AttackClassifications where Id=?";
	    	PreparedStatement statement;
			statement = _con.prepareStatement(query);
	    	statement.setInt(1, _id);
	    	
	    	ResultSet resultSet = statement.executeQuery();
	    	if (!resultSet.next())
	    		return eAttackClassification.values()[0];
	    	
	    	return eAttackClassification.valueOf(resultSet.getString("Name"));
		} 
		catch (SQLException e) 
		{
			e.printStackTrace();
			return eAttackClassification.values()[0];
		}    	
    }
    
    private static eElement loadElement(Connection _con, int _id)
    {
		try 
		{
			String query = "select Name from Elements where Id=?";
	    	PreparedStatement statement;
			statement = _con.prepareStatement(query);
	    	statement.setInt(1, _id);
	    	
	    	ResultSet resultSet = statement.executeQuery();
	    	if (!resultSet.next())
	    		return eElement.values()[0];
	    	
	    	return eElement.valueOf(resultSet.getString("Name"));
		} 
		catch (SQLException e) 
		{
			e.printStackTrace();
			return eElement.values()[0];
		}    	
    }
    
    private static eRelationType loadRelationType(Connection _con, int _id)
    {
		try 
		{
			String query = "select Name from Relations where Id=?";
	    	PreparedStatement statement;
			statement = _con.prepareStatement(query);
	    	statement.setInt(1, _id);
	    	
	    	ResultSet resultSet = statement.executeQuery();
	    	if (!resultSet.next())
	    		return eRelationType.values()[0];
	    	
	    	return eRelationType.valueOf(resultSet.getString("Name"));
		} 
		catch (SQLException e) 
		{
			e.printStackTrace();
			return eRelationType.values()[0];
		}    	
    }
    
    private static eActivationTurnClassification loadActivationTurnClassification(Connection _con, int _id)
    {
		try 
		{
			String query = "select Name from ActivationTurnClassifications where Id=?";
	    	PreparedStatement statement;
			statement = _con.prepareStatement(query);
	    	statement.setInt(1, _id);
	    	
	    	ResultSet resultSet = statement.executeQuery();
	    	if (!resultSet.next())
	    		return eActivationTurnClassification.values()[0];
	    	
	    	return eActivationTurnClassification.valueOf(resultSet.getString("Name"));
		} 
		catch (SQLException e) 
		{
			e.printStackTrace();
			return eActivationTurnClassification.values()[0];
		}    	
    }
    
    private static eEventTriggerTiming loadEventTriggerTiming(Connection _con, int _id)
    {
		try 
		{
			String query = "select Name from EventTriggerTimings where Id=?";
	    	PreparedStatement statement;
			statement = _con.prepareStatement(query);
	    	statement.setInt(1, _id);
	    	
	    	ResultSet resultSet = statement.executeQuery();
	    	if (!resultSet.next())
	    		return eEventTriggerTiming.values()[0];
	    	
	    	return eEventTriggerTiming.valueOf(resultSet.getString("Name"));
		} 
		catch (SQLException e) 
		{
			e.printStackTrace();
			return eEventTriggerTiming.values()[0];
		}    	
    }
    
    private static eStatusType loadStatusType(Connection _con, int _id)
    {
		try 
		{
			String query = "select Name from StatusClassifications where Id=?";
	    	PreparedStatement statement;
			statement = _con.prepareStatement(query);
	    	statement.setInt(1, _id);
	    	
	    	ResultSet resultSet = statement.executeQuery();
	    	if (!resultSet.next())
	    		return eStatusType.values()[0];
	    	
	    	return eStatusType.valueOf(resultSet.getString("Name"));
		} 
		catch (SQLException e) 
		{
			e.printStackTrace();
			return eStatusType.values()[0];
		}    	
    }
    
    private static eTargetRangeClassification loadTargetRangeClassification(Connection _con, int _id)
    {
		try 
		{
			String query = "select Name from TargetRangeClassifications where Id=?";
	    	PreparedStatement statement;
			statement = _con.prepareStatement(query);
	    	statement.setInt(1, _id);
	    	
	    	ResultSet resultSet = statement.executeQuery();
	    	if (!resultSet.next())
	    		return eTargetRangeClassification.values()[0];
	    	
	    	return eTargetRangeClassification.valueOf(resultSet.getString("Name"));
		} 
		catch (SQLException e) 
		{
			e.printStackTrace();
			return eTargetRangeClassification.values()[0];
		}    	
    }
    
    private static eModificationMethod loadModificationMethod(Connection _con, int _id)
    {
		try 
		{
			String query = "select Name from TargetRangeModificationMethods where Id=?";
	    	PreparedStatement statement;
			statement = _con.prepareStatement(query);
	    	statement.setInt(1, _id);
	    	
	    	ResultSet resultSet = statement.executeQuery();
	    	if (!resultSet.next())
	    		return eModificationMethod.values()[0];
	    	
	    	return eModificationMethod.valueOf(resultSet.getString("Name"));
		} 
		catch (SQLException e) 
		{
			e.printStackTrace();
			return eModificationMethod.values()[0];
		}    	
    }
    
    private static eRarity loadRarity(Connection _con, int _id)
    {
		try 
		{
			String query = "select Name from Rarities where Id=?";
	    	PreparedStatement statement;
			statement = _con.prepareStatement(query);
	    	statement.setInt(1, _id);
	    	
	    	ResultSet resultSet = statement.executeQuery();
	    	if (!resultSet.next())
	    		return eRarity.values()[0];
	    	
	    	return eRarity.valueOf(resultSet.getString("Name"));
		} 
		catch (SQLException e) 
		{
			e.printStackTrace();
			return eRarity.values()[0];
		}    	
    }
    
    private static eGender loadGender(Connection _con, int _id)
    {
		try 
		{
			String query = "select Name from Genders where Id=?";
	    	PreparedStatement statement;
			statement = _con.prepareStatement(query);
	    	statement.setInt(1, _id);
	    	
	    	ResultSet resultSet = statement.executeQuery();
	    	if (!resultSet.next())
	    		return eGender.values()[0];
	    	
	    	return eGender.valueOf(resultSet.getString("Name"));
		} 
		catch (SQLException e) 
		{
			e.printStackTrace();
			return eGender.values()[0];
		}    	
    }
    
    private static eWeaponClassification loadWeaponClassification(Connection _con, int _id)
    {
		try 
		{
			String query = "select Name from WeaponClassifications where Id=?";
	    	PreparedStatement statement;
			statement = _con.prepareStatement(query);
	    	statement.setInt(1, _id);
	    	
	    	ResultSet resultSet = statement.executeQuery();
	    	if (!resultSet.next())
	    		return eWeaponClassification.values()[0];
	    	
	    	return eWeaponClassification.valueOf(resultSet.getString("Name"));
		} 
		catch (SQLException e) 
		{
			e.printStackTrace();
			return eWeaponClassification.values()[0];
		}    	
    }
    
    private static eArmourClassification loadArmourClassification(Connection _con, int _id)
    {
		try 
		{
			String query = "select Name from ArmourClassifications where Id=?";
	    	PreparedStatement statement;
			statement = _con.prepareStatement(query);
	    	statement.setInt(1, _id);
	    	
	    	ResultSet resultSet = statement.executeQuery();
	    	if (!resultSet.next())
	    		return eArmourClassification.values()[0];
	    	
	    	return eArmourClassification.valueOf(resultSet.getString("Name"));
		} 
		catch (SQLException e) 
		{
			e.printStackTrace();
			return eArmourClassification.values()[0];
		}    	
    }
    
    private static eAccessoryClassification loadAccessoryClassification(Connection _con, int _id)
    {
		try 
		{
			String query = "select Name from AccessoryClassifications where Id=?";
	    	PreparedStatement statement;
			statement = _con.prepareStatement(query);
	    	statement.setInt(1, _id);
	    	
	    	ResultSet resultSet = statement.executeQuery();
	    	if (!resultSet.next())
	    		return eAccessoryClassification.values()[0];
	    	
	    	return eAccessoryClassification.valueOf(resultSet.getString("Name"));
		} 
		catch (SQLException e) 
		{
			e.printStackTrace();
			return eAccessoryClassification.values()[0];
		}    	
    }
    
    private static eWeaponType loadWeaponType(Connection _con, int _id)
    {
		try 
		{
			String query = "select Name from WeaponTypes where Id=?";
	    	PreparedStatement statement;
			statement = _con.prepareStatement(query);
	    	statement.setInt(1, _id);
	    	
	    	ResultSet resultSet = statement.executeQuery();
	    	if (!resultSet.next())
	    		return eWeaponType.values()[0];
	    	
	    	return eWeaponType.valueOf(resultSet.getString("Name"));
		} 
		catch (SQLException e) 
		{
			e.printStackTrace();
			return eWeaponType.values()[0];
		}    	
    }

    private static eTileType loadTileType(Connection _con, int _id)
    {
		try 
		{
			String query = "select Name from TileClassifications where Id=?";
	    	PreparedStatement statement;
			statement = _con.prepareStatement(query);
	    	statement.setInt(1, _id);
	    	
	    	ResultSet resultSet = statement.executeQuery();
	    	if (!resultSet.next())
	    		return eTileType.values()[0];
	    	
	    	return eTileType.valueOf(resultSet.getString("Name"));
		} 
		catch (SQLException e) 
		{
			e.printStackTrace();
			return eTileType.values()[0];
		}    
    }
}
