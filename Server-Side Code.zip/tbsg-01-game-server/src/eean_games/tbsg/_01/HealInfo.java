package eean_games.tbsg._01;

public class HealInfo 
{
	public HealInfo(int _hpAmount, boolean _isCritical)
	{
		hpAmount = _hpAmount;
		isCritical = _isCritical;
	}
	
	public int hpAmount;
	public boolean isCritical;
}
