package eean_games.tbsg._01;

public enum eFieldDirection {
    POSITIVE_Y,
    POSITIVE_X,
    NEGATIVE_Y,
    NEGATIVE_X,
}
